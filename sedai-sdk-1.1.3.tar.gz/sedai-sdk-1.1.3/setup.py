from setuptools import setup

setup(
    name='sedai-sdk',
    version='1.1.3',
    packages=['sedai', 'sedai.__impl', 'sedai.__impl.jsonpath', 'sedai.__impl.urllib3', 'sedai.__impl.urllib3.contrib',
              'sedai.__impl.urllib3.util', ],
    install_requires=[
        # List your dependencies here
    ],
)
