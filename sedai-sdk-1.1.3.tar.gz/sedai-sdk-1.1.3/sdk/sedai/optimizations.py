from sedai.__impl import api
from sedai.account import search_accounts_by_id

__OPPORTUNITIES_LEVELS = ["account", "cluster"]


def get_recommendations():
    """
    Retrieves recommendations from the Sedai API.
    Returns:
        dict: A dictionary containing the recommendation data.
    """
    request = api.GetRequest('/api/ui/recommendations/allrecommendationsv3')
    response = api.do_get(request)
    if response['status'] != 'OK':
        print(f"Failed to get recommendation: {response['message']}")
        return None
    else:
        print(f"Successfully got recommendation")
        return response['result']


def get_opportunities(level, id):
    """
    Retrieves recommendations from the Sedai API.
    Returns:
        dict: A dictionary containing the recommendation data.
    """
    if level not in __OPPORTUNITIES_LEVELS:
        raise Exception(f"Invalid opportunities level: {level}")
    if level == "account":
        account = search_accounts_by_id(id)
        if len(account) == 0:
            print("Account with id: " + id + " does not exist")
            return False
        request = api.GetRequest(f'/api/cluster/optimization/summarylist?accountIds={id}')

    elif level == "cluster":
        request = api.GetRequest(f'/api/cluster/optimization/summarylist?clusterId={id}')

    response = api.do_get(request)
    if response['status'] != 'OK':
        print(f"Failed to get opportunities: {response['message']}")
        return None
    else:
        print(f"Successfully got opportunities")
        return response['result']
