from sedai.__impl import api, log
from sedai.__impl.model_converter import transform

__account_fields = [
    "id",
    "name",
    "accountDetails.cloudProvider",
    "accountDetails.integrationType"]

CLOUD_PROVIDERS = ["AWS", "AZURE", "GCP", "KUBERNETES"]
INTEGRATION_TYPES = ["AGENTLESS", "AGENT_BASED"]
CLUSTER_PROVIDERS = ["AWS", "AZURE", "GCP", "SELF_MANAGED"]


def get_all_accounts():
    """
    Get all accounts that are integrated with Sedai
    :return: A list of accounts
    Each account is an object with the following fields:

    - **id** - the account id in Sedai
    - **name** - the name of the account as specified by the user
    -  **accountDetails.cloudProvider** - the cloud provider of the account. Values are: `AWS`,
     `AZURE`, `GCP`, `KUBERNETES`, `VMWARE`
    - **accountDetails.integrationType** - the type of integration. Values are: `AGENTLESS`, `AGENT_BASED`

    Sample code:
    .. code-block:: python

            models.to_json(account.get_all_accounts())

    Output:
    .. code-block:: json

            [
                {
                    "id": "5f4f5d3a-9c6e-4b3e-8a5a-1e4b6b5b2a7e",
                    "name": "test env",
                    "accountDetails": {
                        "cloudProvider": "AWS",
                        "integrationType": "AGENTLESS"
                    }
                }
            ]

    """
    request = api.GetRequest('/api/site/accounts')
    response = api.do_get(request)
    if response['status'] == 'OK' and response['result'] is not None:
        return transform(response['result'], __account_fields)


def search_accounts_by_name(name):
    """
    Search for all accounts that are integrated with Sedai that match the given name
    :param name: The name of the account to search for
    :return: A list of accounts that match the given name\. Output is in the same structure
     as :py:func:`get_all_accounts`
    """
    accounts = get_all_accounts()
    return transform(list(filter(lambda x: x.name == name, accounts)))


def search_accounts_by_id(id):
    """
    Search for all accounts that are integrated with Sedai that match the given id
    :param id: The accountId of the account to search for
    :return: A list of accounts that match the given id\. Output is in the same structure
     as :py:func:`get_all_accounts`
    """
    accounts = get_all_accounts()
    return transform(list(filter(lambda x: x.id == id, accounts)))


def create_account(name, cloud_provider, credentials, integration_type, cluster_provider=None):
    """
    Create an account in Sedai
    :param name: The name of the account
    :param cloud_provider: Cloud provider of the account. Valid values are: `AWS`, `AZURE`, `GCP`, `KUBERNETES`
    :param credentials: Credentials for the account. See :ref:`credentials` for more details
    :param integration_type: Type of integration for Kubernetes accounts. Valid values are: `AGENTLESS`, `AGENT_BASED`
    :param cluster_provider: Cluster provider for Kubernetes accounts. Valid values are: `AWS`, `AZURE`, `GCP`, `SELF_MANAGED`
    :return: True if the account was created successfully, False otherwise
    """
    if cloud_provider not in CLOUD_PROVIDERS:
        raise ValueError("Invalid cloud provider: " + cloud_provider)
    if integration_type not in INTEGRATION_TYPES:
        raise ValueError("Invalid integration type: " + integration_type)
    if cloud_provider == "KUBERNETES":
        if cluster_provider not in CLUSTER_PROVIDERS:
            raise ValueError("cluster_provider is required for Kubernetes accounts. Valid values are: " + ", ".join(
                CLUSTER_PROVIDERS))
        if integration_type == "AGENTLESS" and credentials is None:
            from sedai.credentials import AwsRoleCredentials
            credentials = AwsRoleCredentials(role_arn=None, external_id=None)

    # Check if an account with the same name already exists
    accounts = search_accounts_by_name(name)
    if len(accounts) > 0:
        log("Account with name: " + name + " already exists")
        return False

    payload = {
        "accountDetails": {
            "cloudProvider": cloud_provider,
            "integrationType": integration_type,
            "enabled": True,
            "metadata": {
                "clusterProvider": cluster_provider,
                "clusterName": name
            },
            "credentialsDetail": {
                "credentials": credentials.to_dict()
            }
        },
        "name": name
    }

    request = api.PostRequest('/api/site/accounts', payload)
    response = api.do_post(request)
    if response['status'] != 'OK':
        log(f"Failed to create account: {response['message']}")
        return False
    else:
        log(f"Successfully created account: {name}")
        return True


def delete_account(name):
    """
    Delete an account in Sedai
    :param name: Name of the account to delete
    :return: True if the account was deleted successfully, False otherwise
    """
    accounts = search_accounts_by_name(name)
    if len(accounts) == 0:
        log("No account with name: " + name)
        return False
    if len(accounts) > 1:
        log("Multiple accounts with name: " + name)
        return False
    account = accounts[0]
    request = api.DeleteRequest('/api/site/accounts/' + account.id)
    response = api.do_delete(request)
    if response['status'] != 'OK':
        log(f"Failed to delete account: {response['message']}")
        return False
    else:
        log(f"Successfully deleted account: {name}")
        return True


def get_agent_installation_command(name):
    """
    Get the agent installation command for the given account
    :param name: Name of tMhe account
    :return: The agent installation command details
    Contains the following fields:
    - **accountId** - The Sedai account id
    - **apiKey** - The Sedai API key used for the command
    - **kubeInstallCmd** - The kubectl command to install the agent on Kubernetes clusters
    - **helmInstallCmd** - The helm command to install the agent on Kubernetes clusters

    Output:
    .. code-block:: json

        {
            "accountId": "n9dngzfd",
            "apiKey": "eyJhbGciOiJSUzI1NiJ9...[Truncated]",
            "kubeInstallCmd": "kubectl apply -f “https://[Truncated. URL for the YAML file]“",
            "helmInstallCmd": "helm upgrade --install sedai-smart-agent-abc oci://[...] --version 1.21.36 -f “https://[Truncated. URL for the YAML file]“]"
        }

    """
    accounts = search_accounts_by_name(name)
    if len(accounts) == 0:
        log("No account with name: " + name)
        return False
    if len(accounts) > 1:
        log("Multiple accounts with name: " + name)
        return False
    account = accounts[0]
    request = api.GetRequest('/api/agent/accounts/' + account.id + '/agent-installation-cmds')
    response = api.do_get(request)
    if response['status'] == 'OK' and response['result'] is not None:
        return transform(response['result'])
