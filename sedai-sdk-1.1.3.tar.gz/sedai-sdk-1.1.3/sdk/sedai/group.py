from sedai import models
from sedai.__impl import api, log
from sedai.__impl.model_converter import transform

__group__fields = [
    "name",
    "tags",
    "cluster",
    "region",
    "namespace",
    "autoRefresh"]


def get_all_groups():
    """
    Get all groups that are integrated with Sedai
    :return: A list of groups
    Each account is a dictionary with the following fields:

    - **id** - the group id in Sedai
    - **name** - the name of the group as specified by the user
    """
    request = api.GetRequest('/api/sedaigroup/groups')
    response = api.do_get(request)
    if response['status'] == 'OK' and response['result'] is not None:
        return transform(response['result'], __group__fields)


def search_groups_by_name(name):
    """
    Search for all groups that are integrated with Sedai that match the given name
    :param name: The name of the group to search for
    :return: A list of groups that match the given id\. Output is in the same structure
     as :py:func:`get_all_groups`
    """
    groups = get_all_groups()
    return transform(list(filter(lambda x: x.name == name, groups)))


def search_groups_by_id(id):
    """
    Search for all groups that are integrated with Sedai that match the given id
    :param id: The groupId of the group to search for
    :return: A list of groups that match the given name\. Output is in the same structure
     as :py:func:`get_all_groups`
    """
    groups = get_all_groups()
    return transform(list(filter(lambda x: x.id == id, groups)))


def create_group(name: object, tags: object, cluster: object, region: object, namespace: object,
                 autoRefresh: object) -> object:
    """
    Create group in Sedai
    :param name: The name of the group to create
    :param tags: The tags of the group to create
    :param clusters: The clusters of the group to create
    :param region: The region of the group to create
    :param namespace: The namespace of the group to create
    :param autoRefresh: The autoRefresh of the group to create
    :return: True if successful, False otherwise
    """

    # Check if an group with the same name already exists
    groups = search_groups_by_name(name)
    if len(groups) > 0:
        log("Group with name: " + name + " already exists")
        return False

    payload = {
        "name": name,
        "tags": tags,
        "cluster": cluster,
        "region": region,
        "namespace": namespace,
        "autoRefresh": autoRefresh
    }
    payload = models.to_json(payload)
    print(payload)
    request = api.PostRequest('/api/sedaigroup/group/lite', payload)
    response = api.do_post(request)
    if response['status'] != 'OK':
        log(f"Failed to create group: {response['message']}")
        return False
    else:
        log(f"Successfully created group: {name}")
        return True
