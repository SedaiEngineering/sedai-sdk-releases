# %%
data = """
{
    "status": "OK",
    "message": null,
    "result": [
        {
            "id": "jqhjezvz",
            "name": "AzureMultitenant",
            "accountDetails": {
                "cloudProvider": "AZURE",
                "credentialsDetail": {
                    "id": "b4e3803d-9942-4f8d-89f5-81b5f3abfcbf",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWdyyUr1yI1k+eGS6mLRLEPXU36KsNzhymk6MF2lFx6fHtG5QWZtU2yDOA7ocXI2zvsPN+v8FbjF/3bBNgOyekEEeeOEm6E5j0smq4/j40zlwNtpWEfCG7taC3SLMEb6AlZgaqceIpZfTqIemKPDnlGamRLBLWypxIRvN6rwUf2hpMFhHAO9BMKuVDvCQWuLoJNwBLq6zuW9Q8M0eN0SG5hkG0QKDp4fmNoADZjx5coTX",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENTLESS",
                "encryptionKey": null,
                "subscriptionId": "abb3c293-f595-4468-843d-82f49d0cd956",
                "tenantId": "5bff8b06-5db8-4c9c-976e-a18993eb699a",
                "userSelectedManagedServices": null,
                "enabled": true
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "Akash Vijayan",
                    "updatedTime": 1700630245112,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "Akash Vijayan",
                    "updatedTime": 1700630245112,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "Akash Vijayan",
                    "updatedTime": 1700630245112,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": null,
                "ecsSpecificDetail": null,
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Akash Vijayan",
                            "updatedTime": 1700630245112,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1700630245143,
            "updatedTime": 1700630245143,
            "createdUser": "Akash Vijayan",
            "updatedUser": "Akash Vijayan",
            "providerAccountId": "jqhjezvz",
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "hhn5frpy",
            "name": "GKE",
            "accountDetails": {
                "cloudProvider": "KUBERNETES",
                "credentialsDetail": {
                    "id": "82043261-3529-40d3-8598-0626cbdb74f2",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWbQkRcXcLMyCDfwaW0IZApK5j1Gx6B/XUmcVUxkgl1Sh",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENT_BASED",
                "encryptionKey": "AnFnwFjPYwOKGrmKFtnM9GLzacQX7nLViahWO1mrZsDLkdHsQuQYzZQ4GX8+F+8b",
                "metadata": {
                    "clusterUrl": null,
                    "caCertData": null,
                    "clusterName": "GKE",
                    "clusterProvider": "GCP",
                    "region": null
                },
                "userSelectedManagedServices": [
                    [
                        "GcpManagedService",
                        "GKE"
                    ]
                ],
                "enabled": false
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "Tatum Smith",
                    "updatedTime": 1699474651217,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "Tatum Smith",
                    "updatedTime": 1699474651217,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "Tatum Smith",
                    "updatedTime": 1699474651217,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": {
                    "optimization": {
                        "type": "KubernetesOptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Tatum Smith",
                            "updatedTime": 1699474651217,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        },
                        "optimizationFocus": {
                            "type": "KubernetesOptimizationFocusItem",
                            "updatedUser": "Tatum Smith",
                            "updatedTime": 1699474651217,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "focus": "COST",
                            "maxMemoryIncreasePct": null,
                            "maxCPUIncreasePct": null,
                            "maxLatencyIncreasePct": 0
                        }
                    },
                    "enableVerticalScaling": {
                        "updatedUser": "Tatum Smith",
                        "updatedTime": 1699474651217,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "enableHorizontalScaling": {
                        "horizontalScalingConfig": {
                            "updatedUser": "Tatum Smith",
                            "updatedTime": 1699474651217,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        },
                        "minReplicas": null,
                        "maxReplicas": null,
                        "replicaMultiplier": null,
                        "horizontalScalingConfigMode": false
                    },
                    "enablePredictiveScaling": {
                        "updatedUser": "Tatum Smith",
                        "updatedTime": 1699474651217,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "autonomousActionWithoutTraffic": null,
                    "isProd": {
                        "updatedUser": "Tatum Smith",
                        "updatedTime": 1699474651217,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true
                    }
                },
                "ecsSpecificDetail": null,
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Tatum Smith",
                            "updatedTime": 1699474651217,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [
                    "APP"
                ],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1699474651398,
            "updatedTime": 1701684240315,
            "createdUser": "Tatum Smith",
            "updatedUser": "Tapan Manu",
            "providerAccountId": "hhn5frpy",
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "lgw8oxtn",
            "name": "EKS",
            "accountDetails": {
                "cloudProvider": "KUBERNETES",
                "credentialsDetail": {
                    "id": "80efcbf6-3450-4ec9-9baf-868e6055580c",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWbQkRcXcLMyCDfwaW0IZApK5j1Gx6B/XUmcVUxkgl1Sh",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENT_BASED",
                "encryptionKey": "Jc6+De4fr5wPTsEYy45bwDaqrwsW1sSM4X5j8sHpw7+QDUqB7aBae/8r3OkUsfCW",
                "metadata": {
                    "clusterUrl": null,
                    "caCertData": null,
                    "clusterName": "EKS",
                    "clusterProvider": "AWS",
                    "region": null
                },
                "userSelectedManagedServices": [
                    [
                        "AwsManagedService",
                        "EKS"
                    ]
                ],
                "enabled": true
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "Mohammed Hisham",
                    "updatedTime": 1701843744682,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "Mohammed Hisham",
                    "updatedTime": 1701843744682,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "Mohammed Hisham",
                    "updatedTime": 1701843744682,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": {
                    "optimization": {
                        "type": "KubernetesOptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Mohammed Hisham",
                            "updatedTime": 1701843744682,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        },
                        "optimizationFocus": {
                            "type": "KubernetesOptimizationFocusItem",
                            "updatedUser": "Mohammed Hisham",
                            "updatedTime": 1701843744682,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "focus": "COST",
                            "maxMemoryIncreasePct": null,
                            "maxCPUIncreasePct": null,
                            "maxLatencyIncreasePct": 0
                        }
                    },
                    "enableVerticalScaling": {
                        "updatedUser": "Mohammed Hisham",
                        "updatedTime": 1701843744682,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "enableHorizontalScaling": {
                        "horizontalScalingConfig": {
                            "updatedUser": "Mohammed Hisham",
                            "updatedTime": 1701843744682,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        },
                        "minReplicas": null,
                        "maxReplicas": null,
                        "replicaMultiplier": null,
                        "horizontalScalingConfigMode": false
                    },
                    "enablePredictiveScaling": {
                        "updatedUser": "Mohammed Hisham",
                        "updatedTime": 1701843744682,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "autonomousActionWithoutTraffic": null,
                    "isProd": {
                        "updatedUser": "Mohammed Hisham",
                        "updatedTime": 1701843744682,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true
                    }
                },
                "ecsSpecificDetail": null,
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Mohammed Hisham",
                            "updatedTime": 1701843744682,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [
                    "APP"
                ],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1701843744710,
            "updatedTime": 1701843744710,
            "createdUser": "Mohammed Hisham",
            "updatedUser": "Mohammed Hisham",
            "providerAccountId": "lgw8oxtn",
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "0mltdaql",
            "name": "Metric-SubType-Test",
            "accountDetails": {
                "cloudProvider": "KUBERNETES",
                "credentialsDetail": {
                    "id": "aa4ffd64-0c4c-428c-80d0-fdc31370e1e4",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWbQkRcXcLMyCDfwaW0IZApK5j1Gx6B/XUmcVUxkgl1Sh",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENT_BASED",
                "encryptionKey": "0HWSwZ3iWYc5QrRKI0Trx49NLRbJbIGXpp/7KV4kegJStnx4k1owO7ZlgBEB6iYU",
                "metadata": {
                    "clusterUrl": null,
                    "caCertData": null,
                    "clusterName": "sedai-labs-02-us-east-1",
                    "clusterProvider": "SELF_MANAGED"
                },
                "userSelectedManagedServices": null,
                "enabled": true
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": null,
                "slo": null,
                "releaseIntelligence": null,
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": null,
                "ecsSpecificDetail": null,
                "appSpecificDetail": null,
                "supportedResourceTypes": null,
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1704308785899,
            "updatedTime": 1704311272513,
            "createdUser": "Praveen Prakash",
            "updatedUser": "Praveen Prakash",
            "providerAccountId": "0mltdaql",
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "6ls5agr4",
            "name": "tatum test",
            "accountDetails": {
                "cloudProvider": "AZURE",
                "credentialsDetail": {
                    "id": "97a29c75-4ec9-4af0-a4f5-aac95f47a206",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWfmXV7ePqsgb9CZ5PHgNfPNGyPo9doXF4BJxbOdwYWOfyYKQCRO+4i+aCJXP5EC3L3lc26etpZAs1kau57y7p5Js2NmG3SW0s9UXDDCFrHGP",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENTLESS",
                "encryptionKey": null,
                "subscriptionId": "test",
                "tenantId": "test",
                "userSelectedManagedServices": null,
                "enabled": false
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "Tatum Smith",
                    "updatedTime": 1699387610113,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "Tatum Smith",
                    "updatedTime": 1699387610113,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "Tatum Smith",
                    "updatedTime": 1699387610113,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": null,
                "ecsSpecificDetail": null,
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Tatum Smith",
                            "updatedTime": 1699387610113,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1699387610140,
            "updatedTime": 1701684238605,
            "createdUser": "Tatum Smith",
            "updatedUser": "Tapan Manu",
            "providerAccountId": "6ls5agr4",
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "zljfhxef",
            "name": "GCP Instance Kube - AJ",
            "accountDetails": {
                "cloudProvider": "KUBERNETES",
                "credentialsDetail": {
                    "id": "3e2f71f9-88a6-411b-952b-850a41e55b12",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWbQkRcXcLMyCDfwaW0IZApK5j1Gx6B/XUmcVUxkgl1Sh",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENT_BASED",
                "encryptionKey": "L/ibhPxnphEz135ZU21vgwQfOvRwBks3RQJOkAUYxhbfyqmHFT95ymLkVsETEGJR",
                "metadata": {
                    "clusterUrl": null,
                    "caCertData": null,
                    "clusterName": "GCP Instance Kube - AJ",
                    "clusterProvider": "SELF_MANAGED"
                },
                "userSelectedManagedServices": null,
                "enabled": false
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "Ajay Jeevan",
                    "updatedTime": 1692336021569,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "Ajay Jeevan",
                    "updatedTime": 1692336021569,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "Ajay Jeevan",
                    "updatedTime": 1692336021569,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": {
                    "optimization": {
                        "type": "KubernetesOptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Ajay Jeevan",
                            "updatedTime": 1692336021569,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        },
                        "optimizationFocus": {
                            "type": "KubernetesOptimizationFocusItem",
                            "updatedUser": "Ajay Jeevan",
                            "updatedTime": 1692336021569,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "focus": "COST",
                            "maxMemoryIncreasePct": null,
                            "maxCPUIncreasePct": null,
                            "maxLatencyIncreasePct": 0
                        }
                    },
                    "enableVerticalScaling": {
                        "updatedUser": "Ajay Jeevan",
                        "updatedTime": 1692336021569,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "enableHorizontalScaling": {
                        "horizontalScalingConfig": {
                            "updatedUser": "Ajay Jeevan",
                            "updatedTime": 1692336021569,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        },
                        "minReplicas": null,
                        "maxReplicas": null,
                        "replicaMultiplier": null,
                        "horizontalScalingConfigMode": false
                    },
                    "enablePredictiveScaling": {
                        "updatedUser": "Ajay Jeevan",
                        "updatedTime": 1692336021569,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "autonomousActionWithoutTraffic": null,
                    "isProd": {
                        "updatedUser": "Ajay Jeevan",
                        "updatedTime": 1692336021569,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true
                    }
                },
                "ecsSpecificDetail": null,
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Ajay Jeevan",
                            "updatedTime": 1692336021569,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [
                    "APP"
                ],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1692336021590,
            "updatedTime": 1693897563432,
            "createdUser": "Ajay Jeevan",
            "updatedUser": "Tapan Manu",
            "providerAccountId": "zljfhxef",
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "jytfa1km",
            "name": "Azure Kubernetes",
            "accountDetails": {
                "cloudProvider": "KUBERNETES",
                "credentialsDetail": {
                    "id": "12cb0097-d368-443c-9945-28afa5974f5b",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWQZKI/XCYnmhWGHkhzSpNSoyqzI/OUJW1jKPIqBR0NHj",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENTLESS",
                "encryptionKey": null,
                "metadata": {
                    "clusterUrl": "t",
                    "caCertData": null,
                    "clusterName": "Azure Kubernetes",
                    "clusterProvider": "AZURE",
                    "apiServerId": "t",
                    "tenantId": "t",
                    "region": "t"
                },
                "userSelectedManagedServices": [
                    [
                        "AzureManagedService",
                        "AKS"
                    ]
                ],
                "enabled": false
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "Aby Jacob",
                    "updatedTime": 1701713438167,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "Aby Jacob",
                    "updatedTime": 1701713438167,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "Aby Jacob",
                    "updatedTime": 1701713438167,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": {
                    "optimization": {
                        "type": "KubernetesOptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Aby Jacob",
                            "updatedTime": 1701713438167,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        },
                        "optimizationFocus": {
                            "type": "KubernetesOptimizationFocusItem",
                            "updatedUser": "Aby Jacob",
                            "updatedTime": 1701713438167,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "focus": "COST",
                            "maxMemoryIncreasePct": null,
                            "maxCPUIncreasePct": null,
                            "maxLatencyIncreasePct": 0
                        }
                    },
                    "enableVerticalScaling": {
                        "updatedUser": "Aby Jacob",
                        "updatedTime": 1701713438167,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "enableHorizontalScaling": {
                        "horizontalScalingConfig": {
                            "updatedUser": "Aby Jacob",
                            "updatedTime": 1701713438167,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        },
                        "minReplicas": null,
                        "maxReplicas": null,
                        "replicaMultiplier": null,
                        "horizontalScalingConfigMode": false
                    },
                    "enablePredictiveScaling": {
                        "updatedUser": "Aby Jacob",
                        "updatedTime": 1701713438167,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "autonomousActionWithoutTraffic": null,
                    "isProd": {
                        "updatedUser": "Aby Jacob",
                        "updatedTime": 1701713438167,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true
                    }
                },
                "ecsSpecificDetail": null,
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Aby Jacob",
                            "updatedTime": 1701713438167,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [
                    "APP"
                ],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1701713438188,
            "updatedTime": 1701713535051,
            "createdUser": "Aby Jacob",
            "updatedUser": "Aby Jacob",
            "providerAccountId": null,
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "kinbxcbk",
            "name": "EKS",
            "accountDetails": {
                "cloudProvider": "KUBERNETES",
                "credentialsDetail": {
                    "id": "46c30c79-170b-4bdb-bbc0-e0600d7405ad",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWbQkRcXcLMyCDfwaW0IZApK5j1Gx6B/XUmcVUxkgl1Sh",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENT_BASED",
                "encryptionKey": "YCQWO+nW8gaywYuz7NheY5cl/IoGD+82RySNyH/dknEcPl5PcJ9Kod0DIP6WhigN",
                "metadata": {
                    "clusterUrl": null,
                    "caCertData": null,
                    "clusterName": "EKS",
                    "clusterProvider": "AWS",
                    "region": null
                },
                "userSelectedManagedServices": [
                    [
                        "AwsManagedService",
                        "EKS"
                    ]
                ],
                "enabled": true
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "Mohammed Hisham",
                    "updatedTime": 1701857709491,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "Mohammed Hisham",
                    "updatedTime": 1701857709491,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "Mohammed Hisham",
                    "updatedTime": 1701857709491,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": {
                    "optimization": {
                        "type": "KubernetesOptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Mohammed Hisham",
                            "updatedTime": 1701857709491,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        },
                        "optimizationFocus": {
                            "type": "KubernetesOptimizationFocusItem",
                            "updatedUser": "Mohammed Hisham",
                            "updatedTime": 1701857709491,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "focus": "COST",
                            "maxMemoryIncreasePct": null,
                            "maxCPUIncreasePct": null,
                            "maxLatencyIncreasePct": 0
                        }
                    },
                    "enableVerticalScaling": {
                        "updatedUser": "Mohammed Hisham",
                        "updatedTime": 1701857709491,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "enableHorizontalScaling": {
                        "horizontalScalingConfig": {
                            "updatedUser": "Mohammed Hisham",
                            "updatedTime": 1701857709491,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        },
                        "minReplicas": null,
                        "maxReplicas": null,
                        "replicaMultiplier": null,
                        "horizontalScalingConfigMode": false
                    },
                    "enablePredictiveScaling": {
                        "updatedUser": "Mohammed Hisham",
                        "updatedTime": 1701857709491,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "autonomousActionWithoutTraffic": null,
                    "isProd": {
                        "updatedUser": "Mohammed Hisham",
                        "updatedTime": 1701857709491,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true
                    }
                },
                "ecsSpecificDetail": null,
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Mohammed Hisham",
                            "updatedTime": 1701857709491,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [
                    "APP"
                ],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1701857709516,
            "updatedTime": 1701857709516,
            "createdUser": "Mohammed Hisham",
            "updatedUser": "Mohammed Hisham",
            "providerAccountId": "kinbxcbk",
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "lkwn4tqh",
            "name": "Delete",
            "accountDetails": {
                "cloudProvider": "KUBERNETES",
                "credentialsDetail": {
                    "id": "f24bc510-18c3-4072-ac9d-42ae71d4a267",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWQZKI/XCYnmhWGHkhzSpNSqHwwwjQd2t8bVBtO+B60djnz3xbhkADOeGPqz1iW1udA==",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENTLESS",
                "encryptionKey": null,
                "metadata": {
                    "clusterUrl": "http://test.c",
                    "caCertData": null,
                    "clusterName": "Delete",
                    "clusterProvider": "AZURE",
                    "apiServerId": "abc",
                    "tenantId": "tidt",
                    "region": "us-w"
                },
                "userSelectedManagedServices": [
                    [
                        "AzureManagedService",
                        "AKS"
                    ]
                ],
                "enabled": false
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "Vinod Sethumadhavan",
                    "updatedTime": 1699893853694,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "Vinod Sethumadhavan",
                    "updatedTime": 1699893853694,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "Vinod Sethumadhavan",
                    "updatedTime": 1699893853694,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": {
                    "optimization": {
                        "type": "KubernetesOptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Vinod Sethumadhavan",
                            "updatedTime": 1699893853694,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        },
                        "optimizationFocus": {
                            "type": "KubernetesOptimizationFocusItem",
                            "updatedUser": "Vinod Sethumadhavan",
                            "updatedTime": 1699893853694,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "focus": "COST",
                            "maxMemoryIncreasePct": null,
                            "maxCPUIncreasePct": null,
                            "maxLatencyIncreasePct": 0
                        }
                    },
                    "enableVerticalScaling": {
                        "updatedUser": "Vinod Sethumadhavan",
                        "updatedTime": 1699893853694,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "enableHorizontalScaling": {
                        "horizontalScalingConfig": {
                            "updatedUser": "Vinod Sethumadhavan",
                            "updatedTime": 1699893853694,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        },
                        "minReplicas": null,
                        "maxReplicas": null,
                        "replicaMultiplier": null,
                        "horizontalScalingConfigMode": false
                    },
                    "enablePredictiveScaling": {
                        "updatedUser": "Vinod Sethumadhavan",
                        "updatedTime": 1699893853694,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "autonomousActionWithoutTraffic": null,
                    "isProd": {
                        "updatedUser": "Vinod Sethumadhavan",
                        "updatedTime": 1699893853694,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true
                    }
                },
                "ecsSpecificDetail": null,
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Vinod Sethumadhavan",
                            "updatedTime": 1699893853694,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [
                    "APP"
                ],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1699893853740,
            "updatedTime": 1699894864688,
            "createdUser": "Vinod Sethumadhavan",
            "updatedUser": "Vinod Sethumadhavan",
            "providerAccountId": null,
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "swev6ymj",
            "name": "Azure Kubernetes",
            "accountDetails": {
                "cloudProvider": "KUBERNETES",
                "credentialsDetail": {
                    "id": "b197239e-ac61-4899-a7e8-44777aad5f17",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWbQkRcXcLMyCDfwaW0IZApK5j1Gx6B/XUmcVUxkgl1Sh",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENT_BASED",
                "encryptionKey": "lsDd2JvzlStfGjG5bqkTMtKtCfQ5FWP/40AWoCcnREtuC2xaNbD7m+R9uMPk2E6p",
                "metadata": {
                    "clusterUrl": null,
                    "caCertData": null,
                    "clusterName": "Azure Kubernetes",
                    "clusterProvider": "AZURE",
                    "apiServerId": null,
                    "tenantId": null,
                    "region": null
                },
                "userSelectedManagedServices": [
                    [
                        "AzureManagedService",
                        "AKS"
                    ]
                ],
                "enabled": true
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "snt(API Key)",
                    "updatedTime": 1702378512595,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "snt(API Key)",
                    "updatedTime": 1702378512595,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "snt(API Key)",
                    "updatedTime": 1702378512595,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": {
                    "optimization": {
                        "type": "KubernetesOptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "snt(API Key)",
                            "updatedTime": 1702378512595,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        },
                        "optimizationFocus": {
                            "type": "KubernetesOptimizationFocusItem",
                            "updatedUser": "snt(API Key)",
                            "updatedTime": 1702378512595,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "focus": "COST",
                            "maxMemoryIncreasePct": null,
                            "maxCPUIncreasePct": null,
                            "maxLatencyIncreasePct": 0
                        }
                    },
                    "enableVerticalScaling": {
                        "updatedUser": "snt(API Key)",
                        "updatedTime": 1702378512595,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "enableHorizontalScaling": {
                        "horizontalScalingConfig": {
                            "updatedUser": "snt(API Key)",
                            "updatedTime": 1702378512595,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        },
                        "minReplicas": null,
                        "maxReplicas": null,
                        "replicaMultiplier": null,
                        "horizontalScalingConfigMode": false
                    },
                    "enablePredictiveScaling": {
                        "updatedUser": "snt(API Key)",
                        "updatedTime": 1702378512595,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "autonomousActionWithoutTraffic": null,
                    "isProd": {
                        "updatedUser": "snt(API Key)",
                        "updatedTime": 1702378512595,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true
                    }
                },
                "ecsSpecificDetail": null,
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "snt(API Key)",
                            "updatedTime": 1702378512595,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [
                    "APP"
                ],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1702378512622,
            "updatedTime": 1702378512622,
            "createdUser": "snt(API Key)",
            "updatedUser": "snt(API Key)",
            "providerAccountId": "swev6ymj",
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "hvo8fujn",
            "name": "AWS",
            "accountDetails": {
                "cloudProvider": "AWS",
                "credentialsDetail": {
                    "id": "207b73d0-5293-4775-8091-7a3835bb3d6e",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWbQkRcXcLMyCDfwaW0IZApJDR1kKhZngLWL6ewoA6hgu1wR19ubbiCgAW9bMyhw4qWRRNN1mRhLeQ2vzFRRzmz4=",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENTLESS",
                "encryptionKey": null,
                "userSelectedManagedServices": null,
                "enabled": true
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "Abrar Wali",
                    "updatedTime": 1702561301498,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "Abrar Wali",
                    "updatedTime": 1702561301498,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "Abrar Wali",
                    "updatedTime": 1702561301498,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": {
                    "optimization": {
                        "type": "ServerlessOptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Abrar Wali",
                            "updatedTime": 1702561301498,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        },
                        "optimizationFocus": {
                            "type": "ServerlessOptimizationFocusItem",
                            "updatedUser": "Abrar Wali",
                            "updatedTime": 1702561301498,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "focus": "COST_AND_DURATION",
                            "autoOptMaxCostChangePct": null,
                            "autoOptMaxLatencyChangePct": null
                        },
                        "provisionedConcurrencyOptimization": {
                            "updatedUser": "Abrar Wali",
                            "updatedTime": 1702561301498,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        },
                        "autonomousConcurrency": {
                            "updatedUser": "Abrar Wali",
                            "updatedTime": 1702561301498,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        },
                        "telemetryLogging": {
                            "updatedUser": "Abrar Wali",
                            "updatedTime": 1702561301498,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        }
                    }
                },
                "kubeSpecificDetail": null,
                "ecsSpecificDetail": {
                    "optimization": {
                        "type": "ECSOptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Abrar Wali",
                            "updatedTime": 1702561301498,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "MANUAL"
                        },
                        "optimizationFocus": {
                            "type": "ECSOptimizationFocusItem",
                            "updatedUser": "Abrar Wali",
                            "updatedTime": 1702561301498,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "focus": "COST",
                            "maxMemoryIncreasePct": null,
                            "maxCPUIncreasePct": null,
                            "maxLatencyIncreasePct": 0
                        }
                    },
                    "enableVerticalScaling": {
                        "updatedUser": "Abrar Wali",
                        "updatedTime": 1702561301498,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true,
                        "minCpu": null,
                        "minMemory": null
                    },
                    "enableHorizontalScaling": {
                        "updatedUser": "Abrar Wali",
                        "updatedTime": 1702561301498,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true,
                        "minReplicas": 2,
                        "maxReplicas": null,
                        "replicaIncrement": null
                    },
                    "enablePredictiveScaling": {
                        "updatedUser": "Abrar Wali",
                        "updatedTime": 1702561301498,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "enableServiceAutoscalingConfiguration": {
                        "updatedUser": "Abrar Wali",
                        "updatedTime": 1702561301498,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "autonomousActionWithoutTraffic": {
                        "updatedUser": "Abrar Wali",
                        "updatedTime": 1702561301498,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "isProd": {
                        "updatedUser": "Abrar Wali",
                        "updatedTime": 1702561301498,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true
                    }
                },
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Abrar Wali",
                            "updatedTime": 1702561301498,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [
                    "SERVERLESS_FUNCTION",
                    "APP"
                ],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1702561301527,
            "updatedTime": 1702561301527,
            "createdUser": "Abrar Wali",
            "updatedUser": "Abrar Wali",
            "providerAccountId": null,
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "quzn0y9m",
            "name": "EKS",
            "accountDetails": {
                "cloudProvider": "KUBERNETES",
                "credentialsDetail": {
                    "id": "c26e5864-c1b3-4e1f-8287-2bdbb71996c1",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWbQkRcXcLMyCDfwaW0IZApK5j1Gx6B/XUmcVUxkgl1Sh",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENT_BASED",
                "encryptionKey": "Bz9ew3Mcaakp5DpUWfLTNs8wyXOK2KIwCr0HQMHapMDPt4GLyXtkV4mVfqg+rkmA",
                "metadata": {
                    "clusterUrl": null,
                    "caCertData": null,
                    "clusterName": "EKS",
                    "clusterProvider": "AWS",
                    "region": null
                },
                "userSelectedManagedServices": [
                    [
                        "AwsManagedService",
                        "EKS"
                    ]
                ],
                "enabled": false
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "Mathew Koshy",
                    "updatedTime": 1699798552952,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "Mathew Koshy",
                    "updatedTime": 1699798552952,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "Mathew Koshy",
                    "updatedTime": 1699798552952,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": {
                    "optimization": {
                        "type": "KubernetesOptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Mathew Koshy",
                            "updatedTime": 1699798552952,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        },
                        "optimizationFocus": {
                            "type": "KubernetesOptimizationFocusItem",
                            "updatedUser": "Mathew Koshy",
                            "updatedTime": 1699798552952,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "focus": "COST",
                            "maxMemoryIncreasePct": null,
                            "maxCPUIncreasePct": null,
                            "maxLatencyIncreasePct": 0
                        }
                    },
                    "enableVerticalScaling": {
                        "updatedUser": "Mathew Koshy",
                        "updatedTime": 1699798552952,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "enableHorizontalScaling": {
                        "horizontalScalingConfig": {
                            "updatedUser": "Mathew Koshy",
                            "updatedTime": 1699798552952,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        },
                        "minReplicas": null,
                        "maxReplicas": null,
                        "replicaMultiplier": null,
                        "horizontalScalingConfigMode": false
                    },
                    "enablePredictiveScaling": {
                        "updatedUser": "Mathew Koshy",
                        "updatedTime": 1699798552952,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "autonomousActionWithoutTraffic": null,
                    "isProd": {
                        "updatedUser": "Mathew Koshy",
                        "updatedTime": 1699798552952,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true
                    }
                },
                "ecsSpecificDetail": null,
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Mathew Koshy",
                            "updatedTime": 1699798552952,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [
                    "APP"
                ],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1699798552978,
            "updatedTime": 1701684209324,
            "createdUser": "Mathew Koshy",
            "updatedUser": "Tapan Manu",
            "providerAccountId": "quzn0y9m",
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "cezm6n0p",
            "name": "Self Managed Kubernetes",
            "accountDetails": {
                "cloudProvider": "KUBERNETES",
                "credentialsDetail": {
                    "id": "b079f9c9-9151-4290-8cb0-c38e94905bb5",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWbQkRcXcLMyCDfwaW0IZApK5j1Gx6B/XUmcVUxkgl1Sh",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENT_BASED",
                "encryptionKey": "wgP1emZermKZBwp9h4dp/dM2CHRWfYocC/SDSlteydWVZoBW2fSg8xGDCdjDExit",
                "metadata": {
                    "clusterUrl": null,
                    "caCertData": null,
                    "clusterName": "Self Managed Kubernetes",
                    "clusterProvider": "SELF_MANAGED"
                },
                "userSelectedManagedServices": null,
                "enabled": true
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "Tatum Smith",
                    "updatedTime": 1702594691247,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "Tatum Smith",
                    "updatedTime": 1702594691247,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "Tatum Smith",
                    "updatedTime": 1702594691247,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": {
                    "optimization": {
                        "type": "KubernetesOptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Tatum Smith",
                            "updatedTime": 1702594691247,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        },
                        "optimizationFocus": {
                            "type": "KubernetesOptimizationFocusItem",
                            "updatedUser": "Tatum Smith",
                            "updatedTime": 1702594691247,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "focus": "COST",
                            "maxMemoryIncreasePct": null,
                            "maxCPUIncreasePct": null,
                            "maxLatencyIncreasePct": 0
                        }
                    },
                    "enableVerticalScaling": {
                        "updatedUser": "Tatum Smith",
                        "updatedTime": 1702594691247,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "enableHorizontalScaling": {
                        "horizontalScalingConfig": {
                            "updatedUser": "Tatum Smith",
                            "updatedTime": 1702594691247,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        },
                        "minReplicas": null,
                        "maxReplicas": null,
                        "replicaMultiplier": null,
                        "horizontalScalingConfigMode": false
                    },
                    "enablePredictiveScaling": {
                        "updatedUser": "Tatum Smith",
                        "updatedTime": 1702594691247,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "autonomousActionWithoutTraffic": null,
                    "isProd": {
                        "updatedUser": "Tatum Smith",
                        "updatedTime": 1702594691247,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true
                    }
                },
                "ecsSpecificDetail": null,
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Tatum Smith",
                            "updatedTime": 1702594691247,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [
                    "APP"
                ],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1702594691278,
            "updatedTime": 1702594691278,
            "createdUser": "Tatum Smith",
            "updatedUser": "Tatum Smith",
            "providerAccountId": "cezm6n0p",
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "8ryzpatt",
            "name": "GKE - agentless",
            "accountDetails": {
                "cloudProvider": "KUBERNETES",
                "credentialsDetail": {
                    "id": "f7f9b302-c493-4379-9aa5-cf1c7ef2db21",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWV5cQUWVU6ee6HI89+MxmUkL/1DGGD2Usu/iHNfwgQ1Jv/CYEykC+PmbJnq922Fp1wgVca+ENsy+vTyXIABdeaNK51oEJS6CXUgiB/QPzqTEk6DHXaZqtxMjE4g7+90gCKl1XKccNn9bnbmARePMRQ1vHRRQXmS0BzEaH3Y1ODMZ4D7rdJO7wwF+1F5nvKykT189kYl+Yi16NLbkPW2f1T7GEzgqIJZCIqYVwzTfxTB3ebfeNeAAHqc2I85bHqV4/xLOb0dReqxsl0X3wz/2wRld475KF8eTb0/ilhRWdd/yR1G6/SwucDblj6x6jekI6a2uzsQ4px1WjvzfpqXHklkO0mjH1z2xJHQL6dDGrwZbrmSeoTM6xi0Di1H5lmoPbJnj4w9UL+HMDTzDgm04hzMGbwY42bI/nV2uMn76WUoX7V5zdGtengLc7pNXQrZbbF3XBD/OvuNIgtuB0hDvxttUwmD4uMxGR6gdhmXi5A4kRa+A9SfYlQhRYLHeIGtNSuRA0Y3hTbixlhDyGMRnCkLw7GpQShtlK/WiIG6XXolnmds0Qg1oGx3dIcb3KjmphPrhQB7b64XE5rW6RqDRmD2TQ3pSCG9sT24dLc+kRtN6hfaeF4hiYcveghJhA7fWHCccccwuZfaW/nKFvHawRS3hDe6exEVzWYQAhGpGwn7gwPHADYTeVK7t4A1p7cQwCHwg2O1kWCnGBX+ERpS9qV72ITebZxpTlun1pNLAERq0JdcnA+TxhokuFTrgJfJ1HMEkd1yEEaV+ijblynzmBpKhXdZhGTZXDEvH5wh0K5EjPDkzXWYgff5MKQ87Lz+P7PX1bPaDTWCPHvwVfejeM3UO0ZtmYkdtR2cGy65oWiD9cYHPllyaKcXZLm3pRtSj5iK9yLrzjSwFjpBk30zkI4+sqII8zNJUtcMdOMwrLqRmbSdA43ZxRh0vibDrKN9iwval/31OAsKuIbAGRvfqhJJ+QZF2hkKQ6y07paOZnSDgnm2NDzkPqlC6uUVRTdZy1H5PZZc++3NSbCWxS9FfHJWX2Fzx7oxjNlx7c12nHvOtWp9YsR/Bj2r/NO9wSJcNYelYclKbjiRQ4vYPyVMwXuUzc7812BoGzplIfYGp852apm/h77ZDG8N9PNznve2UHO8SWuBUqxIYTRaSo8ndhY+7zuNT9FqRYzmxaEIxMs/ZrtEgCfDNIOZvywOcu3fjz6yAZb3EZGGCaxMdG690iIMxGopv2bHsLkZsoWpJ0kMBBRbRBDzTmolexDnS44ZvMiOVr87qiF4I4UPys8qU4NUcYxqn5STnf0+l49i+h4qr4Ww2S9y07odNFiRbMMKizLTiOAVsjpt3iGMaSDsibmhC2iAd3KqrShtbbPY1msqwEe+b7g4noaD1EfxtaGxhKrag+3y9wmP+mSmyK/Y8gZQzjQWxsZmJkx1k6FpnNfSDXFBkF+tMNZ7FxaxANRRs4wuALQVxlm3NIL4BdM92x58QJAKKv0i7x1EVHTgDN6vTCVnWB2C6Lk9+TrKEr6PGL4Bl/FqOueK4w+l0btv+av9q9veFkYnG1oVLXEEGrCB9IavFkvuODy+xCnYrjiKY9kH9iAjH1kBfEG5YinMtZXtH5SaXvHJ/P8khZqs/36XJDmruGPi/Qe//fZJVPBvb+a77xFwVUobAHa4DZe2Z3KI+ghYcznvcmwUzk0WmGCKDedKQwynoDE++JRFOhrDo+sm0OV2wz2/GPU4ADTrVn1iXXz/TTW91vV7qfK1iiUCADIAPBB7xFdgYOJui2rI8AurGmdkPCtLXEV70GI5Ba4KK2ONShWmEaEDfAxeIAo0sxX8gr3Xjuy76+PV/+mF7DANu24eP5RhiVXyAUTAHkXtFhxHnpjnyRVKkBCAoJabcrelLh7c82jMaj5QEtG0HB7lZbMr22Glq+rm7QKJV5g3/FAcxOYavtfcysCdxyVmqieDUsU20EiJmKdkF6qrgBwyNwW1QJAtueWJ+L2thyzQQ/F6MLEWFFHpD8tPprLqvg3M3QpTAICipCSvbQz7X2C14532O8MVh5qGDq4p2gMrzZ0CN7oZsy6q2mLsBZl3CvPT6j7l0tt3rUXteB37ikR4+SmfzQRRDxcvj9GtZDEWjcy8+nj8wXk7oRs9z31j11+g+RzMsrND2MrCgLD5cvuMPLjMG4m3XIWmEHzzjngtDvQ9l/haq21fGcC1ao3CENGEuw1h4eUvMe7sgadk3oZLtNKyi+r2erFOIzK/gCe45X6+LFbTaTBQQWlInlItX37EwWXoi/qSwiL4iWpe3aWATasNqQhOnFfOlfv7oaE4n3AEqofRZlJiav4cCQ6AbvKmsTUKqbLxuK8iBKnBGR7DRGmLE2qyDub961xsG/rx4mv1wJAZNOxww4QRESnr87InhrHrw1Fdc0N34j5jj/3tHO7BDLAZ87JjUazkRfyKnu8Xjb3lTuc2P3TvuSeF4eGvPTisRfQdqWwF1bUbczZev96/o7zhKXX1aEmaYB1ii+WHIekVHflg22natVAj3M2gukrgmpZ0Y+fZhBfIkUPgI2q1Xz8lueYyTNYvpiqi8fRI5LDAGHJKA+y4lrOOPtamMHiKzfHyXOChGMGDSjnmducatmTXENLOxnohgKXXe69ne9akuH4j9iuKrSAwKB1f4OuSB6wNqaKLJgwLIweLl58ZFxAn2wIC6SRnd7usiQqZKlPX+KSpHuRV/7hb4w05pKXvULdn873NhTFEDaQD1J7OIBOcc4SEr7foFiwDJNJ/11nw/FUHwmzrerhbmbumJ7+w8BfeYkX91Gjf5YAwpYks7MAX0Snvghn/qWCGxVz3QbsIFI11J+BOm2UQfmSB0ldREFO8qAhuNcFPy2MtojGBiNBiCZFQ+NImZrT85WPS3w/L5vK80sjda3e+XIQ4W/3NnZzzAc+urzoZC3oPULq7y6nDvp9OO0NW8woOKY0YVwTQ+jP71JYrUsQFvST2RK/CYzZgxTj6k1G4jTe0jlSjdTiEg38gYY9+6UfGXdx9hUEpamaTmS8rpopx424vUfEZjMNrm6USoLSXjk5x3WN9wCQSTUHhIs+j5KaD0opVdEN/5/AiiNTxzF7rExdDtf5c0lhuUuHajr91gAw7W+RxtCDJ+ghfn2bqagrVcCCBzMYG1y0sAJ4pR3nYFvm3CbaCZe5GqX4jmz4nnfKoP/9GwF7uAz+UHmSNq/oj8O41ZY9/KkAMnbuKhtaQMJ8tEoFT3cmc6/CEJkBBYbtKbNZSE9HwFswn8UDfwquuVQEvfwmpSDcKxKr8I1FX839SXjK3WjD+jJpQZn2OERetDivIKiPrRecg3YY9Ak2w=",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENTLESS",
                "encryptionKey": null,
                "metadata": {
                    "clusterUrl": "https://108.59.84.6",
                    "caCertData": null,
                    "clusterName": "GKE - agentless",
                    "clusterProvider": "GCP",
                    "region": "us-central1"
                },
                "userSelectedManagedServices": [
                    [
                        "GcpManagedService",
                        "GKE"
                    ]
                ],
                "enabled": true
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": null,
                "slo": null,
                "releaseIntelligence": null,
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": null,
                "ecsSpecificDetail": null,
                "appSpecificDetail": null,
                "supportedResourceTypes": null,
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1703870147106,
            "updatedTime": 1703870310800,
            "createdUser": "Pooja Malik",
            "updatedUser": "Pooja Malik",
            "providerAccountId": "KUBERNETES/AGENTLESS/GCP/us-central1/https://108.59.84.6",
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "sueilwzx",
            "name": "test account",
            "accountDetails": {
                "cloudProvider": "CUSTOM",
                "credentialsDetail": {
                    "id": "9d9db96c-d1b6-4294-8d6d-db546b1c211b",
                    "externalCredentialsId": null,
                    "credentials": null,
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENTLESS",
                "encryptionKey": null,
                "userSelectedManagedServices": null,
                "enabled": false
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "Monica Poovizhi",
                    "updatedTime": 1701233824067,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "Monica Poovizhi",
                    "updatedTime": 1701233824067,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "Monica Poovizhi",
                    "updatedTime": 1701233824067,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": null,
                "ecsSpecificDetail": null,
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Monica Poovizhi",
                            "updatedTime": 1701233824067,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1701233824091,
            "updatedTime": 1701686948189,
            "createdUser": "Monica Poovizhi",
            "updatedUser": "Tapan Manu",
            "providerAccountId": "sueilwzx",
            "credentialsStore": "INTERNAL",
            "dummyAccount": true
        },
        {
            "id": "kfboxbvq",
            "name": "Azure",
            "accountDetails": {
                "cloudProvider": "AZURE",
                "credentialsDetail": {
                    "id": "1495c8b0-8ac6-4d5b-b93b-aeb4b828f647",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWfmXV7ePqsgb9CZ5PHgNfPNGyPo9doXF4BJxbOdwYWOfyYKQCRO+4i+aCJXP5EC3L3lc26etpZAs1kau57y7p5Js2NmG3SW0s9UXDDCFrHGP",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENTLESS",
                "encryptionKey": null,
                "subscriptionId": "test",
                "tenantId": "test",
                "userSelectedManagedServices": null,
                "enabled": true
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "Tatum Smith",
                    "updatedTime": 1702664271769,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "Tatum Smith",
                    "updatedTime": 1702664271769,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "Tatum Smith",
                    "updatedTime": 1702664271769,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": null,
                "ecsSpecificDetail": null,
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Tatum Smith",
                            "updatedTime": 1702664271769,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1702664271805,
            "updatedTime": 1702664271805,
            "createdUser": "Tatum Smith",
            "updatedUser": "Tatum Smith",
            "providerAccountId": "test/test",
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "zerpskcx",
            "name": "EKS",
            "accountDetails": {
                "cloudProvider": "KUBERNETES",
                "credentialsDetail": {
                    "id": "fa455cc6-dcbc-4bfa-802f-733a48d473a9",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWbQkRcXcLMyCDfwaW0IZApK5j1Gx6B/XUmcVUxkgl1Sh",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENT_BASED",
                "encryptionKey": "ry/m+imFutoCW6jCOk0u3SWwgwPCkW+sK+Pm723hv+PP7hR7jmyS4hXxG1q+zh67",
                "metadata": {
                    "clusterUrl": null,
                    "caCertData": null,
                    "clusterName": "EKS",
                    "clusterProvider": "AWS",
                    "region": null
                },
                "userSelectedManagedServices": [
                    [
                        "AwsManagedService",
                        "EKS"
                    ]
                ],
                "enabled": true
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "Tatum Smith",
                    "updatedTime": 1702928961291,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "Tatum Smith",
                    "updatedTime": 1702928961291,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "Tatum Smith",
                    "updatedTime": 1702928961291,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": {
                    "optimization": {
                        "type": "KubernetesOptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Tatum Smith",
                            "updatedTime": 1702928961291,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        },
                        "optimizationFocus": {
                            "type": "KubernetesOptimizationFocusItem",
                            "updatedUser": "Tatum Smith",
                            "updatedTime": 1702928961291,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "focus": "COST",
                            "maxMemoryIncreasePct": null,
                            "maxCPUIncreasePct": null,
                            "maxLatencyIncreasePct": 0
                        }
                    },
                    "enableVerticalScaling": {
                        "updatedUser": "Tatum Smith",
                        "updatedTime": 1702928961291,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "enableHorizontalScaling": {
                        "horizontalScalingConfig": {
                            "updatedUser": "Tatum Smith",
                            "updatedTime": 1702928961291,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        },
                        "minReplicas": null,
                        "maxReplicas": null,
                        "replicaMultiplier": null,
                        "horizontalScalingConfigMode": false
                    },
                    "enablePredictiveScaling": {
                        "updatedUser": "Tatum Smith",
                        "updatedTime": 1702928961291,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "autonomousActionWithoutTraffic": null,
                    "isProd": {
                        "updatedUser": "Tatum Smith",
                        "updatedTime": 1702928961291,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true
                    }
                },
                "ecsSpecificDetail": null,
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Tatum Smith",
                            "updatedTime": 1702928961291,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [
                    "APP"
                ],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1702928961334,
            "updatedTime": 1702928961334,
            "createdUser": "Tatum Smith",
            "updatedUser": "Tatum Smith",
            "providerAccountId": "zerpskcx",
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "mstk5sjb",
            "name": "sedai-lab-ECS-test-acc-dec-05",
            "accountDetails": {
                "cloudProvider": "AWS",
                "credentialsDetail": {
                    "id": "06a4ad2d-5844-4470-915c-43959651b6af",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWcCJvC0aTrnqUIT/9ss+56t9UKqHbhNriixIsrAOWAh22M5aDdbcg53EbklCIwHqMtMUOyShr4fd7P4RKaRbvdQeM0bo73KIMIoHr4fyjaoWHSWB6qtOHL2j2dsp1kpRDbyTz5FnuvGQC8HNVNN4588=",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENTLESS",
                "encryptionKey": null,
                "userSelectedManagedServices": null,
                "enabled": true
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "Meenakshi S",
                    "updatedTime": 1682053233915,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "Emil Titus",
                    "updatedTime": 1670247651189,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "Meenakshi S",
                    "updatedTime": 1682052792373,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": {
                    "optimization": {
                        "type": "ServerlessOptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Emil Titus",
                            "updatedTime": 1670247651189,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        },
                        "optimizationFocus": {
                            "type": "ServerlessOptimizationFocusItem",
                            "updatedUser": "Michelle Doe Morrison",
                            "updatedTime": 1696966547915,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "focus": "COST",
                            "autoOptMaxCostChangePct": null,
                            "autoOptMaxLatencyChangePct": 4.0
                        },
                        "provisionedConcurrencyOptimization": {
                            "updatedUser": "Emil Titus",
                            "updatedTime": 1670247651189,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        },
                        "autonomousConcurrency": {
                            "updatedUser": "Emil Titus",
                            "updatedTime": 1670247651189,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        },
                        "telemetryLogging": {
                            "updatedUser": "Emil Titus",
                            "updatedTime": 1670247651189,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        }
                    }
                },
                "kubeSpecificDetail": null,
                "ecsSpecificDetail": {
                    "optimization": {
                        "type": "ECSOptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Bichu Kuruvilla",
                            "updatedTime": 1692110053465,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "MANUAL"
                        },
                        "optimizationFocus": {
                            "type": "ECSOptimizationFocusItem",
                            "updatedUser": "Michelle Doe Morrison",
                            "updatedTime": 1696966503356,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "focus": "COST",
                            "maxMemoryIncreasePct": null,
                            "maxCPUIncreasePct": null,
                            "maxLatencyIncreasePct": 5
                        }
                    },
                    "enableVerticalScaling": {
                        "updatedUser": "Bichu Kuruvilla",
                        "updatedTime": 1679486857051,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true,
                        "minCpu": 128,
                        "minMemory": 128
                    },
                    "enableHorizontalScaling": {
                        "updatedUser": "Meenakshi S",
                        "updatedTime": 1684437770812,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true,
                        "minReplicas": 2,
                        "maxReplicas": 5,
                        "replicaIncrement": 1
                    },
                    "enablePredictiveScaling": {
                        "updatedUser": "Sedai SuperAdmin",
                        "updatedTime": 1678897501273,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true
                    },
                    "enableServiceAutoscalingConfiguration": {
                        "updatedUser": "Sedai SuperAdmin",
                        "updatedTime": 1678898684898,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "autonomousActionWithoutTraffic": {
                        "updatedUser": "Bichu Kuruvilla",
                        "updatedTime": 1691738770342,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true
                    },
                    "isProd": {
                        "updatedUser": "Bichu Kuruvilla",
                        "updatedTime": 1693390607102,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true
                    }
                },
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Emil Titus",
                            "updatedTime": 1670247651189,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [
                    "SERVERLESS_FUNCTION",
                    "APP"
                ],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1670247651281,
            "updatedTime": 1691755133308,
            "createdUser": "Emil Titus",
            "updatedUser": "SYSTEM",
            "providerAccountId": "0721257675542",
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "fmzuxcag",
            "name": "sedai-labs-02-us-east-1",
            "accountDetails": {
                "cloudProvider": "KUBERNETES",
                "credentialsDetail": {
                    "id": "535c552e-82bc-499d-a322-1ff6e7a66337",
                    "externalCredentialsId": null,
                    "credentials": null,
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENT_BASED",
                "encryptionKey": "NyWXT0rD7xfDwR6iLN+70gWlRaTKhnoBHU5Ou3x9mwXLZoaJQSGjQF+vhgbjZwbD",
                "metadata": {
                    "clusterUrl": null,
                    "caCertData": null,
                    "clusterName": "sedai-labs-02-us-east-1",
                    "clusterProvider": "AWS",
                    "region": null
                },
                "userSelectedManagedServices": [
                    [
                        "AwsManagedService",
                        "EKS"
                    ]
                ],
                "enabled": true
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "Pooja Malik",
                    "updatedTime": 1666982684744,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "Pooja Malik",
                    "updatedTime": 1666982331145,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "OFF"
                },
                "releaseIntelligence": {
                    "updatedUser": "Pooja Malik",
                    "updatedTime": 1671742914565,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": {
                    "optimization": {
                        "type": "KubernetesOptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Pooja Malik",
                            "updatedTime": 1676074697724,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "OFF"
                        },
                        "optimizationFocus": {
                            "type": "KubernetesOptimizationFocusItem",
                            "updatedUser": "SYSTEM",
                            "updatedTime": 1691755133308,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "focus": "COST",
                            "maxMemoryIncreasePct": null,
                            "maxCPUIncreasePct": null,
                            "maxLatencyIncreasePct": 0
                        }
                    },
                    "enableVerticalScaling": {
                        "updatedUser": "Pooja Malik",
                        "updatedTime": 1667514821892,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true
                    },
                    "enableHorizontalScaling": {
                        "horizontalScalingConfig": {
                            "updatedUser": "Pooja Malik",
                            "updatedTime": 1667514821892,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": true
                        },
                        "minReplicas": null,
                        "maxReplicas": null,
                        "replicaMultiplier": null,
                        "horizontalScalingConfigMode": true
                    },
                    "enablePredictiveScaling": {
                        "updatedUser": "Pooja Malik",
                        "updatedTime": 1666982331145,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "autonomousActionWithoutTraffic": null,
                    "isProd": {
                        "updatedUser": "SYSTEM",
                        "updatedTime": 1685095772247,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true
                    }
                },
                "ecsSpecificDetail": null,
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Pooja Malik",
                            "updatedTime": 1666982331145,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "OFF"
                        }
                    }
                },
                "supportedResourceTypes": [
                    "APP"
                ],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1666982331168,
            "updatedTime": 1702965711608,
            "createdUser": null,
            "updatedUser": "Mohammed Hisham",
            "providerAccountId": "fmzuxcag",
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "bsm5yg0c",
            "name": "x",
            "accountDetails": {
                "cloudProvider": "CUSTOM",
                "credentialsDetail": {
                    "id": "56993a4a-dbf0-40c6-8d07-4aa31c92704a",
                    "externalCredentialsId": null,
                    "credentials": null,
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENTLESS",
                "encryptionKey": null,
                "userSelectedManagedServices": null,
                "enabled": true
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "Aby Jacob",
                    "updatedTime": 1701714755469,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "Aby Jacob",
                    "updatedTime": 1701714755469,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "Aby Jacob",
                    "updatedTime": 1701714755469,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": null,
                "ecsSpecificDetail": null,
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Aby Jacob",
                            "updatedTime": 1701714755469,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1701714755528,
            "updatedTime": 1701714755528,
            "createdUser": "Aby Jacob",
            "updatedUser": "Aby Jacob",
            "providerAccountId": "bsm5yg0c",
            "credentialsStore": "INTERNAL",
            "dummyAccount": true
        },
        {
            "id": "bofj23qx",
            "name": "sedai-prom-aks-cluster",
            "accountDetails": {
                "cloudProvider": "KUBERNETES",
                "credentialsDetail": {
                    "id": "abc6fb9c-d5c0-4b9b-b486-a6fa87f856cd",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWQZKI/XCYnmhWGHkhzSpNSq4sEW8C9JqVS6kg9U7D8c7MeqD2pQDLPh4Hmb5tz80LOrlEcuhB8ywLIOFptZVkPghPra5FSCrCOF2w1YCKViBnqi48uax5S+TG1eX5CKNberS3fy1YTSskwS2Mo0AsBrHH8YGmQI3sF7Ff7oQnH1RN5/t94gEawX3AxyBsVjD3jxTLPhAT5DALq5nVgd+Ebc=",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENTLESS",
                "encryptionKey": null,
                "metadata": {
                    "clusterUrl": "https://sedai-prom-aks-cluster-dns-kps6dft2.hcp.eastus.azmk8s.io:443",
                    "caCertData": "LS0tLS1CRUdJTiBDRVJUSUZJQ0FURS0tLS0tCk1JSUU2RENDQXRDZ0F3SUJBZ0lRQ245bWlodFFaekFvekNoVHJVcmFqakFOQmdrcWhraUc5dzBCQVFzRkFEQU4KTVFzd0NRWURWUVFERXdKallUQWdGdzB5TXpFeU1EUXdOekF6TWpsYUdBOHlNRFV6TVRJd05EQTNNVE15T1ZvdwpEVEVMTUFrR0ExVUVBeE1DWTJFd2dnSWlNQTBHQ1NxR1NJYjNEUUVCQVFVQUE0SUNEd0F3Z2dJS0FvSUNBUUMwCjNHQ0dUV3ZiVWlGR0U0RG5zWktqbU41dURsVEpGZ3hQSGx2VVVNVWFPL240V2NRNGNnTVdVOWk0NUppeEl5eEoKcWdlOGJLQkZuTG9EOVA3L0UyMDlzWVZpL3NHckN4OVhYenBCcXYwV0hCbzlmZXlhcFpqTTVVNUJvVkJESDkxRgpQMHRLMEtzUlUxZEx6NGRyRVdXWlJ3TkNhQTlLMm5rWllnd0Yyb2V6bDZtTkhjaEdkNnlHd1hobTNBY1hNWUFFCkF2VjZQaUVyOUxZbnEzUC9NL1BDSTl5NTVETXduNmwzWGpjVllodnRCRTFwR1F4TTh4dzU2d2FHWEttUHNXcHkKNmZsNytQTnZYUEVtRkF3YVdxcS94UEZMNElyTE94OXd2ZHpGU0Ewa3B6c3czTjJhdDN2bWZZZHRrWWtHbmRTYQpLcG9yS3A2a1Z0dTRnZnlQdTk1cHJkTnliNnZDVStCV1RwUnMyZWhwS0NpYzlTU0FLWSs4MFRORml6NW41N292ClFCMVRuQU5kb2ZZcWREU0lWMWhkZmUxUVowZHZnYllVTkJlN08rdVpiMFRGV3VER3ZQQnlnQmFiY0YzQ1V6enYKMmdBUm02M0ViUkQ4TERRK0J0ZHI4Zm81akpSS3l6d05qZ2tJdmdXUjF0QWV5d0c3a1o1WWdsTjJsME9KTm9zNAphUHFEMEIyczFia3loYy9hUTRTVmZnc0I4UjJFT1JYbU1TOXo3RHZjcFh0NUp4YW8zT0JNNzFVdmZObWNUZUpGCmdmbUF1RXR2KzZKUzdkTHFrUDd4c1RLc2E4cy9qblRrdllIakFva3ZGREFCUFoxTk82ZWlLZnVPSzczRldJazMKdmx6R0ozNFEwbk96QzJqMkxBUWozSUV1VG1CTFVLZWszMkh5WTNYZ1lRSURBUUFCbzBJd1FEQU9CZ05WSFE4QgpBZjhFQkFNQ0FxUXdEd1lEVlIwVEFRSC9CQVV3QXdFQi96QWRCZ05WSFE0RUZnUVVhaVdtNmZIakdjOU1uSXc5CkhxSlJiUjJPQXZjd0RRWUpLb1pJaHZjTkFRRUxCUUFEZ2dJQkFKMWtYbEw2d2QrbWVFTzYxSStwdnBuaTRSNzUKQm45Y01GY2Vxb0tWMUFuV2poVUN1WDZkeStVaWxpbmp0bFRaRjNKa1dPYTNnQUEwSlE4c2YrakdDUks3S242aApUVm9UcGFiSnVJQ3U2c0ZXdVc0MVdmK3VQeUdOSGtsU3R1TFgvY2pyZFlmWW5jU0hVdldmSENyL0lCaUNXell1CjRwYmpibFV3T1hBbm05Y0M4NHBiSGw3ZTZsNE9QcFdSYTlwbXZtejdXMUVYY01ZU29QNmFyYVdzZzUvSXhUeVMKN25pN2FSazVhYTgyWlpzUDNRVjYxNHNiejh2eGZMUTF3alhvYlU0bklrNG11aHNwNjFhKytzbFdUaXlidDR5KwpTSXZ4SUE2MHR6S3RYZGtyYXZuUSt3aVBFeHp3K3laMDdZOG9aR2ZEbkpMNGwxM0poV1dTaWlQTnkxOHlBeG5qCkhxZUZLMEkvbEdvTS82dTl2TzRua29GQjlBcXFXZ2Y2MjJtSm1qOFdnY2hyejU0Z1J4REVCMGxDdGtSZklOTmoKOXFMcjdVTGtYenIzSWVrYmtUeGIrTi90MXNablM0djZ5QU0wQ0xBczdaTGZ3aWhnTVN4ZDNkREd3d3l5UURwYwoyK29sTEt3RUYrZml0M3RuR2kxNC8yV0RNbEJ5bnk2WUZ4NTJaSWVMZ01HNFZ4VGZvVi9WMXNRWVRjUm14T2pMCiswTVFTZXRGOVB2TDN3d2pHNHNFNkc2bWZiMnNsVVhaSThnUHdyM3lWajVYNHJRY1ZVclNQWGlCVUl3TitHVVkKcUlHUmJxMStkVm1uNHdyaWlCWmxUYXV6NnQ0T1FpU1F5RjVxMzMyN2FoandDRG5zYkxOb0NLWENSU1B3MmcrbQp3Mk43blYwN3NmaHZkVHNUCi0tLS0tRU5EIENFUlRJRklDQVRFLS0tLS0K",
                    "clusterName": "sedai-prom-aks-cluster",
                    "clusterProvider": "AZURE",
                    "apiServerId": "6dae42f8-4368-4678-94ff-3960e28e3630",
                    "tenantId": "5bff8b06-5db8-4c9c-976e-a18993eb699a",
                    "region": "eastus"
                },
                "userSelectedManagedServices": [
                    [
                        "AzureManagedService",
                        "AKS"
                    ]
                ],
                "enabled": false
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "d27f90d2-b835-4c2e-9b32-0d65aa550829",
                    "updatedTime": 1701690844639,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "d27f90d2-b835-4c2e-9b32-0d65aa550829",
                    "updatedTime": 1701690844639,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "d27f90d2-b835-4c2e-9b32-0d65aa550829",
                    "updatedTime": 1701690844639,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": {
                    "optimization": {
                        "type": "KubernetesOptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "d27f90d2-b835-4c2e-9b32-0d65aa550829",
                            "updatedTime": 1701690844639,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        },
                        "optimizationFocus": {
                            "type": "KubernetesOptimizationFocusItem",
                            "updatedUser": "d27f90d2-b835-4c2e-9b32-0d65aa550829",
                            "updatedTime": 1701690844639,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "focus": "COST",
                            "maxMemoryIncreasePct": null,
                            "maxCPUIncreasePct": null,
                            "maxLatencyIncreasePct": 0
                        }
                    },
                    "enableVerticalScaling": {
                        "updatedUser": "d27f90d2-b835-4c2e-9b32-0d65aa550829",
                        "updatedTime": 1701690844639,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "enableHorizontalScaling": {
                        "horizontalScalingConfig": {
                            "updatedUser": "d27f90d2-b835-4c2e-9b32-0d65aa550829",
                            "updatedTime": 1701690844639,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        },
                        "minReplicas": null,
                        "maxReplicas": null,
                        "replicaMultiplier": null,
                        "horizontalScalingConfigMode": false
                    },
                    "enablePredictiveScaling": {
                        "updatedUser": "d27f90d2-b835-4c2e-9b32-0d65aa550829",
                        "updatedTime": 1701690844639,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "autonomousActionWithoutTraffic": null,
                    "isProd": {
                        "updatedUser": "d27f90d2-b835-4c2e-9b32-0d65aa550829",
                        "updatedTime": 1701690844639,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true
                    }
                },
                "ecsSpecificDetail": null,
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "d27f90d2-b835-4c2e-9b32-0d65aa550829",
                            "updatedTime": 1701690844639,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [
                    "APP"
                ],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1701690844669,
            "updatedTime": 1701940298437,
            "createdUser": "d27f90d2-b835-4c2e-9b32-0d65aa550829",
            "updatedUser": "Sreejith narayanan",
            "providerAccountId": null,
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "hyvrermk",
            "name": "EKS",
            "accountDetails": {
                "cloudProvider": "KUBERNETES",
                "credentialsDetail": {
                    "id": "22a17769-2c5f-4184-9e0d-2dd65a8179dc",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWbQkRcXcLMyCDfwaW0IZApK5j1Gx6B/XUmcVUxkgl1Sh",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENT_BASED",
                "encryptionKey": "GJvJMUWeVlpg3YXlFWrcewxKVlRken1y2LqyDhXFLi3nUVMnZk6OJJFereJwuCpo",
                "metadata": {
                    "clusterUrl": null,
                    "caCertData": null,
                    "clusterName": "EKS",
                    "clusterProvider": "AWS",
                    "region": null
                },
                "userSelectedManagedServices": [
                    [
                        "AwsManagedService",
                        "EKS"
                    ]
                ],
                "enabled": false
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "Laya Prasad",
                    "updatedTime": 1698404123475,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "Laya Prasad",
                    "updatedTime": 1698404123475,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "Laya Prasad",
                    "updatedTime": 1698404123475,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": {
                    "optimization": {
                        "type": "KubernetesOptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Laya Prasad",
                            "updatedTime": 1698404123475,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        },
                        "optimizationFocus": {
                            "type": "KubernetesOptimizationFocusItem",
                            "updatedUser": "Laya Prasad",
                            "updatedTime": 1698404123475,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "focus": "COST",
                            "maxMemoryIncreasePct": null,
                            "maxCPUIncreasePct": null,
                            "maxLatencyIncreasePct": 0
                        }
                    },
                    "enableVerticalScaling": {
                        "updatedUser": "Laya Prasad",
                        "updatedTime": 1698404123475,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "enableHorizontalScaling": {
                        "horizontalScalingConfig": {
                            "updatedUser": "Laya Prasad",
                            "updatedTime": 1698404123475,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        },
                        "minReplicas": null,
                        "maxReplicas": null,
                        "replicaMultiplier": null,
                        "horizontalScalingConfigMode": false
                    },
                    "enablePredictiveScaling": {
                        "updatedUser": "Laya Prasad",
                        "updatedTime": 1698404123475,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "autonomousActionWithoutTraffic": null,
                    "isProd": {
                        "updatedUser": "Laya Prasad",
                        "updatedTime": 1698404123475,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true
                    }
                },
                "ecsSpecificDetail": null,
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Laya Prasad",
                            "updatedTime": 1698404123475,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [
                    "APP"
                ],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1698404123489,
            "updatedTime": 1701684221483,
            "createdUser": "Laya Prasad",
            "updatedUser": "Tapan Manu",
            "providerAccountId": "hyvrermk",
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "juu10oid",
            "name": "Freetrial AKS",
            "accountDetails": {
                "cloudProvider": "KUBERNETES",
                "credentialsDetail": {
                    "id": "6fe09bea-8921-4079-9ad8-fea70a03910c",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWQZKI/XCYnmhWGHkhzSpNSoETEDufsuBWUIhlZ4lVbTR6tF5BQOtkjougjnZ0U8C+D7j4cvH91Ukkun/rRnJsZnDV60Q0YGsCEOJGVhjp8RZpE7+iPDldmk5xoMRm0SIFenVqyGnMd7lodsX5PZKLeJZ9kBNwi1/4sXlXAWZGog3NM4W1Y1yKerp3accVdzRj2uRj5LmpFs5WjoIfgrp6no=",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENTLESS",
                "encryptionKey": null,
                "metadata": {
                    "clusterUrl": "https://sedaifreetrial-f9539792.hcp.eastus.azmk8s.io",
                    "caCertData": "LS0tLS1CRUdJTiBDRVJUSUZJQ0FURS0tLS0tCk1JSUU2RENDQXRDZ0F3SUJBZ0lRUWVYNjFCZDVNZGg3a3ZpZjFVZGxNVEFOQmdrcWhraUc5dzBCQVFzRkFEQU4KTVFzd0NRWURWUVFERXdKallUQWdGdzB5TWpBNE1ESXdOekkwTkRaYUdBOHlNRFV5TURnd01qQTNNelEwTmxvdwpEVEVMTUFrR0ExVUVBeE1DWTJFd2dnSWlNQTBHQ1NxR1NJYjNEUUVCQVFVQUE0SUNEd0F3Z2dJS0FvSUNBUURBCkp5T211MnlVb3ZtYVkvemtBU0EvdklTdzlxM3NicGNkcmlRR213d1hDelpwSGVIaFY5MnU1OTFER2FyK3pvdE0KTkxXUGF1WXVTeGRtQnIvZHNHMmc5K2VVSWNIQkxzVnRwa2hqd1U5OGliNVIvZlcvS3RJRDA5Y29xb1hjL3NIMgpXTWlTOVIvWGVJYzRhTFgxTFlKdXI2T1pKMmI0cDBodGFoNmMvN0pDYWJxNVl4ZXZVTVJLUlRnUXJxRVBHSHhEClQxMTZUK0FoTHk2ZUc4WWU2cDI0aVJ1R0VBSWdVQmJpS25rcHN0aHZTQUdZbjBHUVpKUEpuWWI5M2lGTlhmOUoKWm1JaklhbkRNQlFBMitGWjRaRzNrelg5TTgya0szN0xZNHdnNUZtL0FNc0Q2V2tWWkRrUEE4Mzl2cTVwNXp5SApHTVJFa2wvc1NDRkt2Y0pDS3NCdHVDNE5hdG1SaDFBMDlvNzQ1bFZ1R1QrMlE0R0tBcml1S3FUMmdTdkIvbHoyCldyVmJDclZEREdNOS9sc1BSS3VsekFaMFFOdVUwcm14RjZKdVlNNHdhOXJTcjdDM2VieTFWeHpSK1hYcWZXY2IKbWVKS3Q5cnRjdzZVc3M0S0hySnVuUFl0R2ZMSXVzL2xIRFVsQndBNlBhclNoZVdpWDE1UHpjK1J0aC9yNlQwQQpiWG1wZWl1c3YyVkIwSlB6ZEV6TjY3cmZUODkwRFJ3MFZhUGppOGdXdHljZE1zSkViM3Nxa2ovTW1qamtPcUYwCjhZZXFYMEF4c2tNRGdiMTBuWG9UNlF1NHMvOUEyb0l1ODBaUUNkRno4Y0kyNm9Cei9vV09tZGw2T1dSdnV4MG8KOUlyYytmSGZLVW1mN3JGZXBLRWllcVFKZThkYnBYbk9yLy9FMmNMN2d3SURBUUFCbzBJd1FEQU9CZ05WSFE4QgpBZjhFQkFNQ0FxUXdEd1lEVlIwVEFRSC9CQVV3QXdFQi96QWRCZ05WSFE0RUZnUVVPUEY2NXJSUG80MGd0aHpUCjUraGIxNFQrK1hjd0RRWUpLb1pJaHZjTkFRRUxCUUFEZ2dJQkFFeVpHSXVFNUNZVjh4Zk9TZ0c3VDJSdzYzdzUKMDdJY2RhMGNiS1FmNUNJelFLTnZVeVFmaWNYZGJSMU5SeUpqZURBNENJVUlpM0FYNTU5WXFFN0YyckdNazNHbgpLUkVBY3RXMFREbjhlbjZsSGRXbGJiN1oyV0diUkRUQWtySDd4Mlc2V2Z0ajVKMUEvREJSaUlRZGY1cERPSGR3ClU1dE4wdTcrUnhUdnp4MVVyRkNWTjVsbEJOY3B0c0xUZTdzTjNqUmRublNsenlTNXJ5Z2lmM3J4ZDhBcVRwWDYKVXpKdDU2WkdSYkgzaFdlc1IvcnMzZjlVNFNWRG9ZRXdlWjdkYkpKTEhVaTFCcm1UNEhmdXBwRGxGdFhNSmFnbgpkbzNab200dzFsbEdsZGhjTTlnK1VaTUV5dTFtbFBmTWtoUGtWcmxPSHhXYnFlQUNkVTJaRjNYUmgvSnQ4SnAyCnR0UUtSejUwZTF5eWxzcXBONlptK09Ga1M1YVMyY3MzSk9TTVZrb0NTUW5hTmVva2JHQjQxelpCT1hha1A1MW0KY3JDVitqcGJUdHJrSFBZQnZvbjZGa09xOXVXVGNTTm5FcmpLNU5EQjZOWDFUR05WTk0xaEtFejFjZlE0Y2tqQwpDa09ORW5kU0xIdG56S05KV3g0aEpzQWpXYlpoOWliUWE4MC92SllVZDdjd0xmQ3FWaXFva1ZqQmZraUlRWGNHCkhKc0tkc01CdGFCb0VsdjczQ1lNVWpPRkZBcjJaeU9FLzJmRjN5LzlQNHlWRlBDcU9LOFY4MnRtRDhKVTVsZkwKTGk2TjQ5UzBPL3UxSWs2RVhWS2VpMUd3MVdjVUF1UElFb25wOXBuRHpKZFFMdlhlUy9HNzh2dVNnVUhwOWsxQQpsTTZ1WkVma212ZXRubjB4Ci0tLS0tRU5EIENFUlRJRklDQVRFLS0tLS0K",
                    "clusterName": "Freetrial AKS",
                    "clusterProvider": "AZURE",
                    "apiServerId": "6dae42f8-4368-4678-94ff-3960e28e3630",
                    "tenantId": "5bff8b06-5db8-4c9c-976e-a18993eb699a",
                    "region": "eastus"
                },
                "userSelectedManagedServices": [
                    [
                        "AzureManagedService",
                        "AKS"
                    ]
                ],
                "enabled": false
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "Mohammed Hisham",
                    "updatedTime": 1695623455190,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "Mohammed Hisham",
                    "updatedTime": 1695623455190,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "Mohammed Hisham",
                    "updatedTime": 1695623455190,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": {
                    "optimization": {
                        "type": "KubernetesOptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Mohammed Hisham",
                            "updatedTime": 1695623455190,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        },
                        "optimizationFocus": {
                            "type": "KubernetesOptimizationFocusItem",
                            "updatedUser": "Mohammed Hisham",
                            "updatedTime": 1695623455190,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "focus": "COST",
                            "maxMemoryIncreasePct": null,
                            "maxCPUIncreasePct": null,
                            "maxLatencyIncreasePct": 0
                        }
                    },
                    "enableVerticalScaling": {
                        "updatedUser": "Mohammed Hisham",
                        "updatedTime": 1695623455190,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "enableHorizontalScaling": {
                        "horizontalScalingConfig": {
                            "updatedUser": "Mohammed Hisham",
                            "updatedTime": 1695623455190,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        },
                        "minReplicas": null,
                        "maxReplicas": null,
                        "replicaMultiplier": null,
                        "horizontalScalingConfigMode": false
                    },
                    "enablePredictiveScaling": {
                        "updatedUser": "Mohammed Hisham",
                        "updatedTime": 1695623455190,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "autonomousActionWithoutTraffic": null,
                    "isProd": {
                        "updatedUser": "Mohammed Hisham",
                        "updatedTime": 1695623455190,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true
                    }
                },
                "ecsSpecificDetail": null,
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Mohammed Hisham",
                            "updatedTime": 1695623455190,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [
                    "APP"
                ],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1695623455217,
            "updatedTime": 1701684283319,
            "createdUser": "Mohammed Hisham",
            "updatedUser": "Tapan Manu",
            "providerAccountId": null,
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "kimmqb3z",
            "name": "GKE",
            "accountDetails": {
                "cloudProvider": "KUBERNETES",
                "credentialsDetail": {
                    "id": "4b024ae7-38c4-45bd-be03-5ee97eef1c36",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWbQkRcXcLMyCDfwaW0IZApK5j1Gx6B/XUmcVUxkgl1Sh",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENT_BASED",
                "encryptionKey": "dnrRUI4csz5RdO/k9N9mZjYEx49OP8yiF1fsD7DmQ1BFqhLC0s7HTz5dDhhwi9Ly",
                "metadata": {
                    "clusterUrl": null,
                    "caCertData": null,
                    "clusterName": "GKE",
                    "clusterProvider": "GCP",
                    "region": null
                },
                "userSelectedManagedServices": [
                    [
                        "GcpManagedService",
                        "GKE"
                    ]
                ],
                "enabled": true
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "Benjamin",
                    "updatedTime": 1702941213290,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "Benjamin",
                    "updatedTime": 1702941213290,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "Benjamin",
                    "updatedTime": 1702941213290,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": {
                    "optimization": {
                        "type": "KubernetesOptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Benjamin",
                            "updatedTime": 1702941213290,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        },
                        "optimizationFocus": {
                            "type": "KubernetesOptimizationFocusItem",
                            "updatedUser": "Benjamin",
                            "updatedTime": 1702941213290,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "focus": "COST",
                            "maxMemoryIncreasePct": null,
                            "maxCPUIncreasePct": null,
                            "maxLatencyIncreasePct": 0
                        }
                    },
                    "enableVerticalScaling": {
                        "updatedUser": "Benjamin",
                        "updatedTime": 1702941213290,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "enableHorizontalScaling": {
                        "horizontalScalingConfig": {
                            "updatedUser": "Benjamin",
                            "updatedTime": 1702941213290,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        },
                        "minReplicas": null,
                        "maxReplicas": null,
                        "replicaMultiplier": null,
                        "horizontalScalingConfigMode": false
                    },
                    "enablePredictiveScaling": {
                        "updatedUser": "Benjamin",
                        "updatedTime": 1702941213290,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "autonomousActionWithoutTraffic": null,
                    "isProd": {
                        "updatedUser": "Benjamin",
                        "updatedTime": 1702941213290,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true
                    }
                },
                "ecsSpecificDetail": null,
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Benjamin",
                            "updatedTime": 1702941213290,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [
                    "APP"
                ],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1702941213331,
            "updatedTime": 1702941213331,
            "createdUser": "Benjamin",
            "updatedUser": "Benjamin",
            "providerAccountId": "kimmqb3z",
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "ktuqmyy2",
            "name": "HC_Test_Agentless_k8s",
            "accountDetails": {
                "cloudProvider": "KUBERNETES",
                "credentialsDetail": {
                    "id": "0b6dff37-dc05-4f26-a037-a36277376c0c",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWbQkRcXcLMyCDfwaW0IZApK5j1Gx6B/XUmcVUxkgl1Sh",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENT_BASED",
                "encryptionKey": "9cMHGc8nobkxOF4cqpV5BIElQt/uW+pPl4sIgBQ9Df8DnOOQXRIcnL8zh3JDZPUv",
                "metadata": {
                    "clusterUrl": null,
                    "caCertData": null,
                    "clusterName": "HC_Test_Agentless_k8s",
                    "clusterProvider": "AZURE",
                    "apiServerId": null,
                    "tenantId": null,
                    "region": null
                },
                "userSelectedManagedServices": [
                    [
                        "AzureManagedService",
                        "AKS"
                    ]
                ],
                "enabled": true
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": null,
                "slo": null,
                "releaseIntelligence": null,
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": null,
                "ecsSpecificDetail": null,
                "appSpecificDetail": null,
                "supportedResourceTypes": null,
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1703702680205,
            "updatedTime": 1703702680205,
            "createdUser": "Hari Chandrasekhar",
            "updatedUser": "Hari Chandrasekhar",
            "providerAccountId": "ktuqmyy2",
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "e9orvez7",
            "name": "AWS",
            "accountDetails": {
                "cloudProvider": "AWS",
                "credentialsDetail": {
                    "id": "cdcaada2-1913-4fe7-8761-7f221bc4c635",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWbQkRcXcLMyCDfwaW0IZApJDR1kKhZngLWL6ewoA6hguwTuZyO+kR7HyUyTcXJRWXhZQMBdtkrknn8hCLyhByoDN8MO6Dmk7n/HuhnWVcErg",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENTLESS",
                "encryptionKey": null,
                "userSelectedManagedServices": null,
                "enabled": true
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "Abrar Wali",
                    "updatedTime": 1701692374183,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "Abrar Wali",
                    "updatedTime": 1701692374183,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "Abrar Wali",
                    "updatedTime": 1701692374183,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": {
                    "optimization": {
                        "type": "ServerlessOptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Abrar Wali",
                            "updatedTime": 1701692374183,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        },
                        "optimizationFocus": {
                            "type": "ServerlessOptimizationFocusItem",
                            "updatedUser": "Abrar Wali",
                            "updatedTime": 1701692374183,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "focus": "COST_AND_DURATION",
                            "autoOptMaxCostChangePct": null,
                            "autoOptMaxLatencyChangePct": null
                        },
                        "provisionedConcurrencyOptimization": {
                            "updatedUser": "Abrar Wali",
                            "updatedTime": 1701692374183,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        },
                        "autonomousConcurrency": {
                            "updatedUser": "Abrar Wali",
                            "updatedTime": 1701692374183,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        },
                        "telemetryLogging": {
                            "updatedUser": "Abrar Wali",
                            "updatedTime": 1701692374183,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        }
                    }
                },
                "kubeSpecificDetail": null,
                "ecsSpecificDetail": {
                    "optimization": {
                        "type": "ECSOptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Abrar Wali",
                            "updatedTime": 1701692374183,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "MANUAL"
                        },
                        "optimizationFocus": {
                            "type": "ECSOptimizationFocusItem",
                            "updatedUser": "Abrar Wali",
                            "updatedTime": 1701692374183,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "focus": "COST",
                            "maxMemoryIncreasePct": null,
                            "maxCPUIncreasePct": null,
                            "maxLatencyIncreasePct": 0
                        }
                    },
                    "enableVerticalScaling": {
                        "updatedUser": "Abrar Wali",
                        "updatedTime": 1701692374183,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true,
                        "minCpu": null,
                        "minMemory": null
                    },
                    "enableHorizontalScaling": {
                        "updatedUser": "Abrar Wali",
                        "updatedTime": 1701692374183,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true,
                        "minReplicas": 2,
                        "maxReplicas": null,
                        "replicaIncrement": null
                    },
                    "enablePredictiveScaling": {
                        "updatedUser": "Abrar Wali",
                        "updatedTime": 1701692374183,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "enableServiceAutoscalingConfiguration": {
                        "updatedUser": "Abrar Wali",
                        "updatedTime": 1701692374183,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "autonomousActionWithoutTraffic": {
                        "updatedUser": "Abrar Wali",
                        "updatedTime": 1701692374183,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "isProd": {
                        "updatedUser": "Abrar Wali",
                        "updatedTime": 1701692374183,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true
                    }
                },
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Abrar Wali",
                            "updatedTime": 1701692374183,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [
                    "SERVERLESS_FUNCTION",
                    "APP"
                ],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1701692374220,
            "updatedTime": 1701692527827,
            "createdUser": "Abrar Wali",
            "updatedUser": "Abrar Wali",
            "providerAccountId": null,
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "atpf0zlf",
            "name": "dev environment",
            "accountDetails": {
                "cloudProvider": "GCP",
                "credentialsDetail": {
                    "id": "0689b8fb-9100-4dd2-8ebe-96321cb113db",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWV5cQUWVU6ee6HI89+MxmUkL/1DGGD2Usu/iHNfwgQ1Jv/CYEykC+PmbJnq922Fp1zCPxCTYQVBQu1pZB5/4FebN8MO6Dmk7n/HuhnWVcErg",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENTLESS",
                "encryptionKey": null,
                "projectId": "65765765765",
                "regions": [
                    "us-west1"
                ],
                "userSelectedManagedServices": null,
                "enabled": true
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "Benjamin",
                    "updatedTime": 1702941296858,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "Benjamin",
                    "updatedTime": 1702941296858,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "Benjamin",
                    "updatedTime": 1702941296858,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": null,
                "ecsSpecificDetail": null,
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Benjamin",
                            "updatedTime": 1702941296858,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1702941296879,
            "updatedTime": 1702941296879,
            "createdUser": "Benjamin",
            "updatedUser": "Benjamin",
            "providerAccountId": null,
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "mlgjgk7t",
            "name": "CustomCloud",
            "accountDetails": {
                "cloudProvider": "CUSTOM",
                "credentialsDetail": {
                    "id": "239d09b1-8083-4250-b805-15bab695d3bc",
                    "externalCredentialsId": null,
                    "credentials": null,
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENTLESS",
                "encryptionKey": null,
                "userSelectedManagedServices": null,
                "enabled": true
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "Mathew Koshy",
                    "updatedTime": 1703220462558,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "Mathew Koshy",
                    "updatedTime": 1703220462558,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "Mathew Koshy",
                    "updatedTime": 1703220462558,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": null,
                "ecsSpecificDetail": null,
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Mathew Koshy",
                            "updatedTime": 1703220462558,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1703220462582,
            "updatedTime": 1703220462582,
            "createdUser": "Mathew Koshy",
            "updatedUser": "Mathew Koshy",
            "providerAccountId": null,
            "credentialsStore": "INTERNAL",
            "dummyAccount": true
        },
        {
            "id": "7kbyomhs",
            "name": "test env",
            "accountDetails": {
                "cloudProvider": "GCP",
                "credentialsDetail": {
                    "id": "e7720381-dbce-4aae-8340-b5495a8d5b6b",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWV5cQUWVU6ee6HI89+MxmUkL/1DGGD2Usu/iHNfwgQ1Jv/CYEykC+PmbJnq922Fp1zCPxCTYQVBQu1pZB5/4FebN8MO6Dmk7n/HuhnWVcErg",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENTLESS",
                "encryptionKey": null,
                "projectId": "22222",
                "regions": [
                    "asia-east1"
                ],
                "userSelectedManagedServices": null,
                "enabled": true
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "Benjamin",
                    "updatedTime": 1702941903228,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "Benjamin",
                    "updatedTime": 1702941903228,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "Benjamin",
                    "updatedTime": 1702941903228,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": null,
                "ecsSpecificDetail": null,
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Benjamin",
                            "updatedTime": 1702941903228,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1702941903245,
            "updatedTime": 1702941903245,
            "createdUser": "Benjamin",
            "updatedUser": "Benjamin",
            "providerAccountId": null,
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "gk70xszf",
            "name": "test-kube",
            "accountDetails": {
                "cloudProvider": "KUBERNETES",
                "credentialsDetail": {
                    "id": "e8e76b2d-dd68-4099-8029-6b0b11db079a",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWQZKI/XCYnmhWGHkhzSpNSqUwK03973sd6QLugIW2MwC",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENTLESS",
                "encryptionKey": null,
                "metadata": {
                    "clusterUrl": "test",
                    "caCertData": "test",
                    "clusterName": "test",
                    "clusterProvider": "SELF_MANAGED"
                },
                "userSelectedManagedServices": null,
                "enabled": false
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "Monica Poovizhi",
                    "updatedTime": 1693987278639,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "Monica Poovizhi",
                    "updatedTime": 1693987278639,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "Monica Poovizhi",
                    "updatedTime": 1693987278639,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": {
                    "optimization": {
                        "type": "KubernetesOptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Monica Poovizhi",
                            "updatedTime": 1693987278639,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        },
                        "optimizationFocus": {
                            "type": "KubernetesOptimizationFocusItem",
                            "updatedUser": "Monica Poovizhi",
                            "updatedTime": 1693987278639,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "focus": "COST",
                            "maxMemoryIncreasePct": null,
                            "maxCPUIncreasePct": null,
                            "maxLatencyIncreasePct": 0
                        }
                    },
                    "enableVerticalScaling": {
                        "updatedUser": "Monica Poovizhi",
                        "updatedTime": 1693987278639,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "enableHorizontalScaling": {
                        "horizontalScalingConfig": {
                            "updatedUser": "Monica Poovizhi",
                            "updatedTime": 1693987278639,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        },
                        "minReplicas": null,
                        "maxReplicas": null,
                        "replicaMultiplier": null,
                        "horizontalScalingConfigMode": false
                    },
                    "enablePredictiveScaling": {
                        "updatedUser": "Monica Poovizhi",
                        "updatedTime": 1693987278639,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "autonomousActionWithoutTraffic": null,
                    "isProd": {
                        "updatedUser": "Monica Poovizhi",
                        "updatedTime": 1693987278639,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true
                    }
                },
                "ecsSpecificDetail": null,
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Monica Poovizhi",
                            "updatedTime": 1693987278639,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [
                    "APP"
                ],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1693987278789,
            "updatedTime": 1699944738339,
            "createdUser": "Monica Poovizhi",
            "updatedUser": "snt(API Key)",
            "providerAccountId": "gk70xszf",
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "py2hyvro",
            "name": "Azure Kubernetes",
            "accountDetails": {
                "cloudProvider": "KUBERNETES",
                "credentialsDetail": {
                    "id": "72ee1894-14c0-4e2d-87e1-c9503acba62c",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWbQkRcXcLMyCDfwaW0IZApK5j1Gx6B/XUmcVUxkgl1Sh",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENT_BASED",
                "encryptionKey": "IcDURZfdRgGtErH/FUia3nceeZ2wUfKe+Lp7cDCzVipNCAbF3/K0LoETVcbJ45cR",
                "metadata": {
                    "clusterUrl": null,
                    "caCertData": null,
                    "clusterName": "Azure Kubernetes",
                    "clusterProvider": "AZURE",
                    "apiServerId": null,
                    "tenantId": null,
                    "region": null
                },
                "userSelectedManagedServices": [
                    [
                        "AzureManagedService",
                        "AKS"
                    ]
                ],
                "enabled": false
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "Hari Chandrasekhar",
                    "updatedTime": 1693954540482,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "Hari Chandrasekhar",
                    "updatedTime": 1693954540482,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "Hari Chandrasekhar",
                    "updatedTime": 1693954540482,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": {
                    "optimization": {
                        "type": "KubernetesOptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Hari Chandrasekhar",
                            "updatedTime": 1693954540482,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        },
                        "optimizationFocus": {
                            "type": "KubernetesOptimizationFocusItem",
                            "updatedUser": "Hari Chandrasekhar",
                            "updatedTime": 1693954540482,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "focus": "COST",
                            "maxMemoryIncreasePct": null,
                            "maxCPUIncreasePct": null,
                            "maxLatencyIncreasePct": 0
                        }
                    },
                    "enableVerticalScaling": {
                        "updatedUser": "Hari Chandrasekhar",
                        "updatedTime": 1693954540482,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "enableHorizontalScaling": {
                        "horizontalScalingConfig": {
                            "updatedUser": "Hari Chandrasekhar",
                            "updatedTime": 1693954540482,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        },
                        "minReplicas": null,
                        "maxReplicas": null,
                        "replicaMultiplier": null,
                        "horizontalScalingConfigMode": false
                    },
                    "enablePredictiveScaling": {
                        "updatedUser": "Hari Chandrasekhar",
                        "updatedTime": 1693954540482,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "autonomousActionWithoutTraffic": null,
                    "isProd": {
                        "updatedUser": "Hari Chandrasekhar",
                        "updatedTime": 1693954540482,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true
                    }
                },
                "ecsSpecificDetail": null,
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Hari Chandrasekhar",
                            "updatedTime": 1693954540482,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [
                    "APP"
                ],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1693954540510,
            "updatedTime": 1694062489616,
            "createdUser": "Hari Chandrasekhar",
            "updatedUser": "Tapan Manu",
            "providerAccountId": "py2hyvro",
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "vgrgj4mu",
            "name": "GKE Test Cluster",
            "accountDetails": {
                "cloudProvider": "KUBERNETES",
                "credentialsDetail": {
                    "id": "6ff5e53b-9d2c-48f6-800f-517186f71a39",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWbQkRcXcLMyCDfwaW0IZApK5j1Gx6B/XUmcVUxkgl1Sh",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENT_BASED",
                "encryptionKey": "r8BTj5S9nFvagohzYdonWoaeZlDyeVwRnwvJQtgcXuX5nopjEPun4O88IYodWXKd",
                "metadata": {
                    "clusterUrl": null,
                    "caCertData": null,
                    "clusterName": "GKE Test Cluster",
                    "clusterProvider": "GCP",
                    "region": null
                },
                "userSelectedManagedServices": [
                    [
                        "GcpManagedService",
                        "GKE"
                    ]
                ],
                "enabled": true
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "Benjamin",
                    "updatedTime": 1702942462980,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "Benjamin",
                    "updatedTime": 1702942462980,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "Benjamin",
                    "updatedTime": 1702942462980,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": {
                    "optimization": {
                        "type": "KubernetesOptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Benjamin",
                            "updatedTime": 1702942462980,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        },
                        "optimizationFocus": {
                            "type": "KubernetesOptimizationFocusItem",
                            "updatedUser": "Benjamin",
                            "updatedTime": 1702942462980,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "focus": "COST",
                            "maxMemoryIncreasePct": null,
                            "maxCPUIncreasePct": null,
                            "maxLatencyIncreasePct": 0
                        }
                    },
                    "enableVerticalScaling": {
                        "updatedUser": "Benjamin",
                        "updatedTime": 1702942462980,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "enableHorizontalScaling": {
                        "horizontalScalingConfig": {
                            "updatedUser": "Benjamin",
                            "updatedTime": 1702942462980,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        },
                        "minReplicas": null,
                        "maxReplicas": null,
                        "replicaMultiplier": null,
                        "horizontalScalingConfigMode": false
                    },
                    "enablePredictiveScaling": {
                        "updatedUser": "Benjamin",
                        "updatedTime": 1702942462980,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "autonomousActionWithoutTraffic": null,
                    "isProd": {
                        "updatedUser": "Benjamin",
                        "updatedTime": 1702942462980,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true
                    }
                },
                "ecsSpecificDetail": null,
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Benjamin",
                            "updatedTime": 1702942462980,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [
                    "APP"
                ],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1702942463006,
            "updatedTime": 1702942463006,
            "createdUser": "Benjamin",
            "updatedUser": "Benjamin",
            "providerAccountId": "vgrgj4mu",
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "qacdwci3",
            "name": "GCP Streaming Test",
            "accountDetails": {
                "cloudProvider": "GCP",
                "credentialsDetail": {
                    "id": "6bf5f8fe-7d10-4f1d-9059-685a22423959",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWV5cQUWVU6ee6HI89+MxmUkL/1DGGD2Usu/iHNfwgQ1Jv/CYEykC+PmbJnq922Fp1wgVca+ENsy+vTyXIABdeaNK51oEJS6CXUgiB/QPzqTEk6DHXaZqtxMjE4g7+90gCKl1XKccNn9bnbmARePMRQ1vHRRQXmS0BzEaH3Y1ODMZ4D7rdJO7wwF+1F5nvKykT4Ny5UD8pHxiyTvHC4TbMYEcawZSIKZc0OSXCoxGSGJ4yuW1uBr0K6/Re79gqvy0kz1IgXffahhUhg3s1pic/0Nd475KF8eTb0/ilhRWdd/yR1G6/SwucDblj6x6jekI6a2uzsQ4px1WjvzfpqXHklkO0mjH1z2xJHQL6dDGrwZbrmSeoTM6xi0Di1H5lmoPbH1dhhUT8kpscmOPsIuhCod4xNU9JzQiOpYScJaWFZMfaSes/EC+ijyO+Jel697SPXkqgOnZ6m0VvFJ/cH9oWiYcOgcECHpiyDLE9ZGPv6djs4wD8If/3qgE4k284b9A7Me0P/acLzwOp+Y+Hgnrzu0+OPRt3vg4FKdUrC18yDcb1FaHvSBMIKsrBro5TB/rSj+tk74vFW1IBsVvpWYNRDWLopuHiwa7sza0E2Qj1EgHP4khpiW3o/3o7oxu1gKRGlg9vO0hWWiPw/gefJx1GgT/Ft42wEnJsQ7mWvo3arMVrMkSOLDpMpZX7s1Ngj2LmMBJp6dwA5VqmYnMqT1B2ShnwTHatnJ3IpgO43wH2d1q1d9mEk/OzwDopK4MR4w9nau+6V4STkPD/uMYq7u8pDqwccNKtcfO61mbhWvlKf4rqbR2g35pHCV6oRJRYxT7C5A6V7mdAIt8Q9FbbnpZTDZ64x4oET0zAl4wBemfsK2WpC0xIvwlKYyH3Fy9eIS4n0SuH7qTCpW/A9crV/AIsLxox75QVqclkXzvvj7YhDPdjSEjnO2YZ2f633OKdXaTwCdkJHb4DtK7FMLMN5df3pCb+7rCNNt4r5Pp2GsBqUWa5O80KiBvccJ6wXifjWB6g1ZfINKbhWqg16wx93HJvnMRMwcPkKqCz0d/QQo/Hksh55lXrBVlDmxL6MLLVkaw38PIFm4JdJzVCzCKf9v8wGpv/eF8WeEiXaVsmSqaR+gJ3s+mBJlCZK7UUOoyW/kbMC29WdOeMJzwdCb0nA+LJqQpe+Vo+oj7tBEJ7ME7yCus50mxvBdUI7HMOmAKMfXcy2XOcVGSJGtyMPlmDVdD2uvcl2XQdZ7CRDEaNHz9dojuGamMAz0c4Z/bVug7ZJ18PawcIGbRzsNOyqiA2tO5/wr967IQb5DmiGea6UQ+OwYe0YryYssvcrffTaNtXafydruxCx4PB+7DyoCA1C744Ii54CJ3ykpiZVp3E0jDRXKHf30CwKFBeBb/D5Kp86nHtXYK/G57F1F4Q0JM2GbKAMYlSbw6D8VJbkKvx5FHB5YrB3MjDf0KeQdnoMCik8GLVvly5In+ICirMJS1F+rk3dvMVHmETb+mG3U7MD8neOjCyUcx7EdrhVf/aEiSBdKfd0x8JJg5Ey6H35CfhAQEeyWNU9GZk2yXLQbik+ocuUaUMR36JawpXwIQe3pbUC4Iq2503LZ44e6vft0h+6goFVpBVQsgkshMn5pvARZgAQpXygF/kuVFj2JVJNAO0A/sVKkxQ6FvDnuq2O9EiIkckZemBGczPPh+fdzcQjO0+1WE8ThceOb9sfdiewOmNvk9jPorPzcGJZKaqkrkoF5iYoBZuF+fjC2hbdPd13XkA4IICQbwk41CPukVnGIw34pV1uZOlBv30/OooNyTpdzf1g7jRlzFI6NPsgxD/ONWd3k3NuFoWtd+inFliWPuwxMbVvmZHyyLuDhZwJ/cEpXSpC1Rclfk6dPjncDRkToqRKHNgAGhyeF+Qvf+nsoiQiMtt6xFfK8D3HN89CmMr5JXSSbhsGXa+IGjN2JJhIK8FyC8wfTkPlcR/GQfG6hhmZrgoZQ0cBA5fkjP9zgfaUQA4eB8EmPHPfrVzOQJN9EedbAQ8MDGomTnnpvNRrXMv6tGDywJUfwEd7O92yMtJ5WnZg7hKtCp5WIcbYa583SmA+oTkvRu4am8SaOH/Vbv3vSp74Z0vjrwmwuox4fqKRNCdjT92FyDnwRhLkVMzdwt3G4zT3cVOJfQt7kyJp0Yqwtz8RIcQQH4NinebF8JBI8zMtOkEYG1pcmbHw3uImlXLGUxV66+HhVXU9uG894o8jS7acpZyGqOk36hlwpBgmABJUyQ0Ogq2hOpIlJ8BbR5rgwUtre1a0ZROKx4RGxNJHIAqNg6jmCTzm8YLGpTG7bJuvCp65le+I4QEvq6maEubKm2jvikhJiCmPVeh2VmSv9RHxuDF9e7afJOe8Snhp8tq1izNwwXRcHGGBfaVK0I2LeknTgMVDNISCpg0vc27UekSV0NyId7Luj35UlmBS9C8WKlPLFLDXx1/sZ1EubZaJxtwn3VapPhheFzXY4VU57ZI9HhS1G/O/b09mHEFrZpdaRFumTj6r3jDeQoBHu9LYVqOToJqVLqjL+fhx/5xtpJYVRlX7AEFOi0bZBrDAHoxq2Pu74CHh1f6JfxW938LRp3tamMHiKzfHyXOChGMGDSjnmducatmTXENLOxnohgKXXe69ne9akuH4j9iuKrSAwK4aodoCysQC7OAXjxdtE7/33r3btCTYIXhsIPzxwTCid0ABm0UcVTDhXz6CV4qo9xJ8tEoFT3cmc6/CEJkBBYbtKbNZSE9HwFswn8UDfwqusQNiQl0w80zJlhBcfwp2FOoqftTe+LPP05JPcpuzY3QnqweHTDBx6RQ7IbV2vsKSS8yHOi8G2EKPX9Xo1B3WpVd4HLCHQZl7R/hROQy36b/ASpPjmdIAK1MNY34OETtBGwgsvs2MSK/Q/lZIsl8Kxe8dwpGoA6IOFt7GNtHm5VmVOCXMvzaAKb8kUy/HJOxF+OnLGYcNoYSs3IWO/GFM8C/xsvScmp35Lt0RD8jf5exQy9NXtUvGnRmpfHA3UwtxA7VDKiuGMC/vQWnDfXIt9R57tvccRL0vqAhBeS6HMMqCAiBAinG3/poEFMrWvqgrT0nzhmN0riGV81FT9hr2StCMW4zmyGfKcM6uzlfrp5nGoWD1PSVfNZmcNIbvDa+aVju6sp1stTxBTpUSwBBl+sYK/BrNbo6Ln95q6eUyIBBrEtr+WixdGwkMS3ukq43VqpqheZhKJJvdGURTuxKMPNxjBV4Ysv8j3wlj8YiaRFkoviRM3fZC8yHgk2RWRyrboB/Zb7JKnJxHlUgW6vKS3gvS8H+QnwEZF0ql9gz+k5xdbV3l+AkSdTa4rouxNM0XeHSA0TsoyogGI9cxf8TWQy3NI1B3lsU02vvfHpwJvUFQ==",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENTLESS",
                "encryptionKey": null,
                "projectId": "sedai-gcp-test",
                "regions": [
                    ""
                ],
                "userSelectedManagedServices": null,
                "enabled": false
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "Hari Govind K K",
                    "updatedTime": 1693814418246,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "Hari Govind K K",
                    "updatedTime": 1693814418246,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "Hari Govind K K",
                    "updatedTime": 1693814418246,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": null,
                "ecsSpecificDetail": null,
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Hari Govind K K",
                            "updatedTime": 1693814418246,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1693814418273,
            "updatedTime": 1694537506356,
            "createdUser": "Hari Govind K K",
            "updatedUser": "Tapan Manu",
            "providerAccountId": "qacdwci3",
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "necx0rer",
            "name": "gcp-test-qa",
            "accountDetails": {
                "cloudProvider": "GCP",
                "credentialsDetail": {
                    "id": "f5d7d60e-76de-481b-8cf5-bd248964f001",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWV5cQUWVU6ee6HI89+MxmUkL/1DGGD2Usu/iHNfwgQ1Jv/CYEykC+PmbJnq922Fp17+hMs1a33o8FQAxljiOHD2GDwlLBqylgdGQXrEKWdxtLEDHO9/nryf+XpkkaM5CWUYEAdbrlbA8d2/UbO9/CYPfdit936lf7QJNqqctVB+5nS58fCfVXq8oefk4MoUuCFkJ5VcrGfDxYDK+GdHYWw7IusyHgRpaLORpOvbHxeC+vFdiHmc7qRyn2q1nWyk34ydBPxxeeuci97Nkn4ucJP9MMVaWqUqKiwGq/oRVtXJlIpo9fz2yjnLCITtix5gRjKAoeCIFyhW6zK2pd69f0LcWNc0djBFaeTZmQ/4HksJYuDzwnusMa+ZlW8Mp4lbtnQKtMNj2Myw07tjl9lCV3f6YXfTQx/ymgY+n+8470Il4M57c/bP88JYtVDWN1vl8CcblQu/m79UxuAnSi8kW9nnKqkRlYn0HYXsgWUAHO9F6t3fyOSlrirOECs2F/zPrrtDM/LEj2t1rLRHPeNaGi7e+A8Aoc6OTOpBpysj5eNhNl/73gVZtcEB/iTL1/9htrqmBn0UyuOE7dTpzazSSD3xTpTtLu3zfbD2HvK0JXfndYsVMt/BMCpwmhbMNtiVCflixjcRG1y/hzw6Qw+1Rrf4ykqgbdsnkpxOiglYhlgThr+Ib1kEkeZaw0xauPnMyQ7F4KSkEmxLm04/xw/qcKnAM/EqGSQTP4zlFBMLgUQgaBYbP5JiZYcV++dFIdjGDTvbD6Vehl5jfltbdNjIztsAEpgn/MA3X0UVDee8P+Du1JdyBv5wlvIPPYKZT9rhHQHZ7FY9KY6CswdQ4MVHBDn6pejmA0edJUrKtYY14reNwxWVkoeVdUpFViLqQagfKQkSKJCBQZH9v8QP6EBDsWpKqRzuzJV9AVCoA3YFHm7IOdNP+VHj7gKr341T1uuMpn3UcuYe1mSVcFAG16Amvkn2PDJZ5VJrDeVhmWl2r4m3cPWgjqKEk1cP0xv3Wfwi6jB3nTtTwrOdfUd1Fr0oWK70GJGfKouR2CGarHeYJTNVV/6mPBIkm/+EeU358asiqtVoviFP3/kbQeRtR/i8RQ4tGBAt6V/uFxIBys5GxTaLZ9hFjB+kZY9x79+Mi8/sTIBa9oUR3D+4RUzhR8cJT66B8LL5HA2aYfxN1x8UQs7VyGqrzXMQqr0I8kun4Is4PMDm36V5gqhCiun/Rhnqa4vy5bD7Ah/NGE9FKf77Qv7FcL4WGvRvYgdLv5ZJUyMZEgUxnGjwVNDQ/rq7bGfClmt2OcZC3rlGML41NTx1aQNwRpw051qSCWZE7tciA0Lio1bCmQUUwmBA6ZsTfw6gloP/20ZDG8De0xz19mlw6eFRDMVOobA2GyQq3hS3v8wNv1JBSRvngukLanD43Iv9ymfZobpO4WI/Dv6+rd6tSUGIE4XLSs/H78UgEczJomZEOU6BPStH30ZHrqBwuPRZzoqcVwoKRefj24/HDSRMx/yAQJiYDbqtdzM5eQEcv1SuT+94Y1YLQ2BKxJbI3dHRoWLGGDTU4Kzs/QJfiF7VVsqEwqvOqV5UUdSp8rGevR95EdW2/E6Vc8gFVgAR8A6M+L5QdE5UbKMif0pb6fs02pZO4bT7TNakDARKZAAw5DHxMyCaqYNaASfp5sQyhPO9frvSNC+Elw5+02Ccq6n/A5KdMAUcKCFl9ENdCHrTAZnqDM061Bg8zkt66QS2TfYm98U28B8PrTHdENeq6vQFwra8Hqh1b+k5tWhvURDgr4xQTOQRRhzSskMwyc4uFnOJZi+CnTZ151i1voPoCQgEMta0RErNtLXcuOWvyg3RL1K4UB1AauL2FJIFNkBKadIIiI28OSSRrcsW04JBTb9n9Jqs+GJPlBInEFZf3z3uv/ex57tTNq0QWJHPwJ6ZMun0Xv/kGHK4FTFtkIWdV1L2EDgmRr/KDglVm9+o4LTJIVSXBaYtxaSuHb+exUmzaqlMqa4qu8CMVX8H4f8vKBGx2QuGRP8pSPVW46kfNHET0VeSRUt5CH/hxdnjG0vMSKEBBCpMmsVKUiOMRCMKQx5DhmTPRvlmJCX2q6QncJcU1Ho7X6kdFq3N05DA5De0y5fORYY/rWARiZisdH5zqSYfdjTWTrkXKg4a80rwFsgywkZJQX7lXbbfq8SEAigNIfNynaz4yrhP+zMusmwH9od8/wD/jjtgaqtMGgHJjre+NE6CcL1ASirLlrcfCIWV/IqVGpQeWrP3LuZkPPvgx7tRJUAXxXbmZpHL1unDwW2S3tx9PYAdYuZgpF3iES091pqEmsTO+idXTKueXleT5Hqs7Wqy5WKKvKzhnvXBXW9ffpfCGZk4ZWfMFgKUR0DTXK7S5+RyfRV2Vt8QvYIiNfsS4sfK974OQIduUap0sIWJ9CjuIdfCLgNIr6J0y2Tex0Z6CPjEpbF+FxY3Wkva+x4Ww04od5weQvq43FchbXEFW4Je+EMzIsJInIHiiOnBpI/oORtQFaFA4bLPzL90PwKlLU5wczJpWUCCgL2q3tqv6558JvS+meqL8M0Gpir081MYsYJA2WJHsNyzxf4PnuLqwWf0bbpwyFyjqj5y4CX4b6O5oC6lOdrx3I2eHXTlgbxyrp4XBG5h1aOjDvyZmBq+rYVzvvGh8JwX+b7eR3yalDemmPcwg3jZY/N2UljcijyTzE8rENVgE/ggNNGrh+XXxnCWuRuAACVuraqP4xdRM74n4YvM7NfEWfMguEukjX1+NF0Z3hEILVHQWlGHJKqvkgZzYf41fR/2F5Y7Z2ocPiL744FZ/O/4aEk6uAE+aolEnUq8VIbXmgDCJHHlUioE1pbAtefOwhI3U4WFa2nIHxueSnL1/vcMVqciewzGGAwiIDizHUazFsXyKOPiSMP51GGz1cjlr6X+ZPs/EuF0YZm6P5ndcGN/Xz4sAmjjm2QsQ4HAdwbxjuaVGR+MJC2YjT37i9EFdIbR5Ow3HglDXUAnOzWoWD1PSVfNZmcNIbvDa+aVju6sp1stTxBTpUSwBBl+s+aVZdHAW6NQm/PxUzXCPkZcP3Nkd4S1WLvlm0vUXAZKbEPmUQlUG/3dMbXweOT3w3V1NLP+oHBQgPoEFFjzXKR+1uID9JN5eGV+3wHOP7pCvO7vgJ+oy10yVPKPzysvWPy7DDo/Y249vh0thLJdb0pnX6sVjcHjKg6YJAXyMQHknqu0BsTEzLblnHa7l5w6BL0VOA8NaH6uERDs1hgkr7Tqxv0lq4xMt61hKTAmMAfchPWWnrYqYJembzDZMNUL0JLILyjiffslXtQka7wVVgI4lk+zYim6PRrruyRa6sm4=",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENTLESS",
                "encryptionKey": null,
                "projectId": "sedai-gcp-test",
                "regions": [
                    "us-central1"
                ],
                "userSelectedManagedServices": null,
                "enabled": false
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "Monica Poovizhi",
                    "updatedTime": 1693986594691,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "Monica Poovizhi",
                    "updatedTime": 1693986594691,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "Monica Poovizhi",
                    "updatedTime": 1693986594691,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": null,
                "ecsSpecificDetail": null,
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Monica Poovizhi",
                            "updatedTime": 1693986594691,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1693986594721,
            "updatedTime": 1694537496090,
            "createdUser": "Monica Poovizhi",
            "updatedUser": "Tapan Manu",
            "providerAccountId": "necx0rer",
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "ag1soeqm",
            "name": "dev-gcp-sa-permissions-test",
            "accountDetails": {
                "cloudProvider": "GCP",
                "credentialsDetail": {
                    "id": "041b6d4e-1018-4529-83a6-d273e70ac474",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWV5cQUWVU6ee6HI89+MxmUkL/1DGGD2Usu/iHNfwgQ1Jv/CYEykC+PmbJnq922Fp17+hMs1a33o8FQAxljiOHD2GDwlLBqylgdGQXrEKWdxtLEDHO9/nryf+XpkkaM5CWSrafjxOB3zWPD3IYq0Hzd47FtFcZ4x0Kg+QloAfnugDnS58fCfVXq8oefk4MoUuCLG7xQAjh3gbB+RjsnbxafGaut1bg6DIfukxFtDFtdFDHcBnpzBoQRI8W/Eb4/TDJGJzd1psR2pI70ZnYBwCzPJMMVaWqUqKiwGq/oRVtXJlIpo9fz2yjnLCITtix5gRjKTLdyuIWuFShW3TEhnMqLQWNc0djBFaeTZmQ/4HksJYoLDapCVv9U7Iyb8b3kfGo0PsizHKoMU8eBm2XbpasiTSut6w6S6X6wVbu033tojgPE8M/i8rtYyCYHyev121XYZCgEAFjCePhnWgaLT3AM3u/Vxi6PMGype6JXh5boiS1LOY8jN7LKM1hZd8ZsdXqpYOGHjMuQkqs52zayXhAkoQ78aWbtenw339ZWbkyCOHOiCpuUO8dff2ex+RPUBg+1F3V3AgrHwcyL3lORKovSfjABJa/0OuF7dt/N3px/rjIhQS0stJOlywkKlqIJqDY193ufBjyM2ipPFhw5Pdn6qQ6QFI1mS8DeA1MP09fz+tmWWe/JtR2bb+lno0ktkZ4B82y35cyziJPR6PLAPBnBKIp1TFUsOEYq0MP5Z+l/raf0KQeK8JpPAzyxkZ1uiWcOkdT5XiZSDIjWkF22CuDJnYwl4a/kg5AdRwY5yesteIDj5FnaKERGtZnKAfUC/jf/HcfhcG06ylrcRRzfoVmHM043gIqfxWfD/cz0SBH31B+DGEm3pXmeWFLVcG+oJJCIle8jESWMKwb4myienLLKGEs9Q6TdJU45n5nCwfMKca+srulo3zB+lsmTgpjG6YqvXUGe8E7xMHVrYJ2H+BXI3OtRe6iRtayeXU+/8kEjcyOZj3GiKoBBbXamsp041meu3xCFkOoc0IpApZGchPHzCjcMmDYFAgfuEKLVVbeAkX7H+UbaR3Sd6s8qjiTaxbqAGD774m+XMzOSJYBaAuQ3mBE4sahde0yPzj9qWJ6n90WH/3ZdxZW0GpotXL5Pf6IPOkpAHf3ppOBoGmHHyBQvOteS64qYJq/38cRj05U8t1UXLmgBXq9PnzTJhGObDBOr+pmujAAR+zJ2jkzUNyNn0RhQQ7CdtP+BWzWaypB+SMOl6RNHx5wD2bscD30emG8VI9EaTgIsqZBX4MNeqIIVNmnmDLSnP9HvgEvA/ehmY2PSTh78LzBh5N44s/RBX36TBSLWlzVlZ8E3Vh0Eq6yBclPMW7NBcMI4vao1nwnL0cSJLIXlaopQte90CCkloux8a1Il5HrMZvJdOOPMiq15Ytd8qlV/lfJzzeQSyC5JMps4ajGHi4uCher1uNVCoIafLa1f5OUdYxg/dndDGMfEtFyWPRIm5+ySpRVQ7eD+fVx1dVHSwG05Npbu/3d3o0A847uBsUJjy3J63vuI2QFURb461i5AiUHiFLPJ7bJ1/0Of+UhhDhwcsA5Z8bhvKTRuwh7hvx+DIS+MQsSO6T40LTVnUnfnF+1EqM/ki8PsRjBQIislRhYAahbfDwMbD+sIHoDlv/ZZ8rdiG/3LoLSpobsfMQXKk3ZjELvy4u7JnpRdlbKjQgtXH87JLIWrLnoz4j+h+I9JJOS4FCNhmWY/mSe2qCtlaZqIENbrzbxfmcosFtKUJCK9LDNRhoi3DsCK60mmK3IsZPmfXSgky6NAy2F/xlxZe4O3WGmbQXCUhh8G2y0Y2edWyQTi0O1hoWBFJIqaAN2vQ8mcQrDLm0veuOjY7Ug6dYwh2dA9b0WvdwEe81iYsyCmL3lVKE6TeXFFbImEEJ0IaasJizAzcxpu3D769rYCaSVcNV3ibTG2dUGOZ2rSi1ZpbwM2dhEiEmcYS6Tp+nPUD0EsZRtrCghIbWOqTV1aC0/ogqI9Qm35NTAO9J59/gYogUckY1AMIkz9NyVvnadA3ZMvkQF9+VsYczZDET8NOx4LpxT2u3/ZF21mhM3xgv4jsFokRqM16Rf/f/dP4logK+An8ZUYXa25j/IqftgnwX9J8X1SQh1OQtQDp92nttPLmH5UvGs6amHwP9G2ckARuimey441C6kQw967SOnaGFY/givilqKDl1wTSaHA39AT4ghFnOv6WH7MLKK6+lMpelOso5HmTbuTXKSKGq+B1MqVfHbsLcuIR7XzSymRwvpmg8ZBf3VOb/KqSCqWjvm45IlRIgpHw38T1WDBTMpIlPWgCyKVbnR2gj+QEqpOVXpXgpJhSRUO9/VRRhOeK4kjytAZe2G/yAbh8VARUldZHuxG1ptIBr+N627LHlTzMybzeUcG6cxEwd8cJkPOHrSTyR5BeaZPCN2tbT/oSRTnQo1WpYsfdB9UJBk0qbJ0o7uCO22CK1XxerVHe4o+PspQXmnbqkL2sP9uHziVK/VqGCz6kPZGOep1vjuVoMyscdybXWQeis1KMlT7Qy81SP5qz7DeztadmUIwTei8JJBjzpuCRjf+a9vv7AbpwyFyjqj5y4CX4b6O5oC6lOdrx3I2eHXTlgbxyrp4XBG5h1aOjDvyZmBq+rYVzv9HWwAEXApmz0/a8rx6hN/GkHk+JrdTH47ra4FT+6H14mHac0zo6GY/ooh8wBm5gQ6TaOtS4/mklMwHVAUQVSQOlPYDNoABKVj0A+kXyjUIksPLJdIVZaz+TGokNuPT1k24oZcVTWr+PwL91ttEsq4Z+AQUkUaFA5TENTsLu9DJImF0z9tVRn7ucxO7RVdfmIdjh8Ivg2NFDVdhme8nOqDTUvg9apTVsG2U9U99xPSv7x3CkagDog4W3sY20eblWZU4Jcy/NoApvyRTL8ck7EX46csZhw2hhKzchY78YUzwJdJqCMnQITixSjR4KdGbWo3kbstPmn3adVQlno9LVEkd6fU7iPG5MxMlVoNx3okhv2zJbrCNeGRzaTYHSBQNxbDZCXmOsjA7lN6q5Os4IHZH+kJ6sji3LPyPoLWzE253JASz1/e4Ejs+4IzpbmppDz0Kx0hVAM9/JcDgK2DfUZ90ekcOIZn/Hz7NVhSyWtQPLeQwfn2GTckePKobYes6Fhwr9n7IDzJN2r3TWz78l2JRaze9en1OYuPLpOCjdhqB80KixyGAFreV/B7m8LdHUCV2pWw2JLLHkap8wYQAE6gU2q5bxy2LmGhsBVHx83I2Ngr6Af7DzKAbjm4BYLXpdiX3JN8zqCsFfikapZQYJDkyvtyTsI94b7CxWsjnivjQc=",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENTLESS",
                "encryptionKey": null,
                "projectId": "dev-gcp-394616",
                "regions": [
                    "us-central1"
                ],
                "userSelectedManagedServices": null,
                "enabled": false
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "Praveen Prakash",
                    "updatedTime": 1695672256681,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "Praveen Prakash",
                    "updatedTime": 1695672256681,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "Praveen Prakash",
                    "updatedTime": 1695672256681,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": null,
                "ecsSpecificDetail": null,
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Praveen Prakash",
                            "updatedTime": 1695672256681,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1695672256724,
            "updatedTime": 1701684304049,
            "createdUser": "Praveen Prakash",
            "updatedUser": "Tapan Manu",
            "providerAccountId": "ag1soeqm",
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "ygfcwyrz",
            "name": "tatum test",
            "accountDetails": {
                "cloudProvider": "KUBERNETES",
                "credentialsDetail": {
                    "id": "786076f6-579a-4dd6-9d33-0b0c291c075f",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWbQkRcXcLMyCDfwaW0IZApK5j1Gx6B/XUmcVUxkgl1Sh",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENT_BASED",
                "encryptionKey": "DXNaPUnnd8VoWGHH8JsvghWGEMQ4nxk3uZBsRfH1KBspLxCpR5a5ePsTi5S+5WFb",
                "metadata": {
                    "clusterUrl": null,
                    "caCertData": null,
                    "clusterName": "tatum test",
                    "clusterProvider": "AZURE",
                    "apiServerId": null,
                    "tenantId": null,
                    "region": null
                },
                "userSelectedManagedServices": [
                    [
                        "AzureManagedService",
                        "AKS"
                    ]
                ],
                "enabled": false
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "Tatum Smith",
                    "updatedTime": 1699386732616,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "Tatum Smith",
                    "updatedTime": 1699386732616,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "Tatum Smith",
                    "updatedTime": 1699386732616,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": {
                    "optimization": {
                        "type": "KubernetesOptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Tatum Smith",
                            "updatedTime": 1699386732616,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        },
                        "optimizationFocus": {
                            "type": "KubernetesOptimizationFocusItem",
                            "updatedUser": "Tatum Smith",
                            "updatedTime": 1699386732616,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "focus": "COST",
                            "maxMemoryIncreasePct": null,
                            "maxCPUIncreasePct": null,
                            "maxLatencyIncreasePct": 0
                        }
                    },
                    "enableVerticalScaling": {
                        "updatedUser": "Tatum Smith",
                        "updatedTime": 1699386732616,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "enableHorizontalScaling": {
                        "horizontalScalingConfig": {
                            "updatedUser": "Tatum Smith",
                            "updatedTime": 1699386732616,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        },
                        "minReplicas": null,
                        "maxReplicas": null,
                        "replicaMultiplier": null,
                        "horizontalScalingConfigMode": false
                    },
                    "enablePredictiveScaling": {
                        "updatedUser": "Tatum Smith",
                        "updatedTime": 1699386732616,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "autonomousActionWithoutTraffic": null,
                    "isProd": {
                        "updatedUser": "Tatum Smith",
                        "updatedTime": 1699386732616,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true
                    }
                },
                "ecsSpecificDetail": null,
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Tatum Smith",
                            "updatedTime": 1699386732616,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [
                    "APP"
                ],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1699386732642,
            "updatedTime": 1701684235599,
            "createdUser": "Tatum Smith",
            "updatedUser": "Tapan Manu",
            "providerAccountId": "ygfcwyrz",
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "hcmc2u5s",
            "name": "IFTT Cluster",
            "accountDetails": {
                "cloudProvider": "KUBERNETES",
                "credentialsDetail": {
                    "id": "ca0ab6d2-eac8-4d32-a95f-3eb86cd262a0",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWQZKI/XCYnmhWGHkhzSpNSoCrS4Aljs5HJQ7YlOFBNhMQvWRFfg9VbI1K1Wdjesvbtj+apM7HzNSJs/lQz62S44xeZg5ULSidkQ3Fu6+hTiAenqu2sFuW88FFSJ3DKmxfSSsijHQ4HmRmaCYMMIMz/AwUnD4+6+X7KDll2DQqCMWvhfX94JYVlO3v9tcOLFcBQAmH1TehpAsxWBxBt/JAWI=",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENTLESS",
                "encryptionKey": null,
                "metadata": {
                    "clusterUrl": "https://sedaiiftt01-0b6a9c14.hcp.eastus.azmk8s.io",
                    "caCertData": "LS0tLS1CRUdJTiBDRVJUSUZJQ0FURS0tLS0tCk1JSUZIakNDQXdhZ0F3SUJBZ0lSQUxrMU1iSCt2c3ByZjQ2VWNiMUgzZkV3RFFZSktvWklodmNOQVFFTEJRQXcKRFRFTE1Ba0dBMVVFQXhNQ1kyRXdIaGNOTWpNd05qRXpNVGN5T1RVNVdoY05NalV3TmpFek1UY3pPVFU1V2pBdwpNUmN3RlFZRFZRUUtFdzV6ZVhOMFpXMDZiV0Z6ZEdWeWN6RVZNQk1HQTFVRUF4TU1iV0Z6ZEdWeVkyeHBaVzUwCk1JSUNJakFOQmdrcWhraUc5dzBCQVFFRkFBT0NBZzhBTUlJQ0NnS0NBZ0VBd3kzMmh2SGd2Z1A2TDI1RE55Zy8KRXN6TU8xbGFQU2VKdUxhMUIwREVuUTZkeXlTbmd4eVBRVkhZMU1rTjdab2JXZlpTN3M0NE0waXNNanZ1bEFXZwp0T1l2VVBLTDU4YWszZWlWUldLTm9aVFhvbXFOU0d2dWdoOGFoUWVZanNJaWtTV3lpTzVPa2x1N0k3MllEcEQvCjhweFpwK2xwZFplNmZSMDZNdTZxaXd4RTI2TTdOOVlxNFNrNU1vM3pRMVBpcWJMbkRFRk5XNUUvWjVkNFVFbnkKVndCbjROTHBZVzgrTzZXbjZRWG1zUUdXcW01T0hWMlRibSt0TXBlZFVNNFRyRTB6L3NsQnEzdFhTb2ZEbGVhMwpVblpaUGZzNkFraUhrUnBOM09PNTFISGIrbWhPcUNlQndjOStVaC9VVkdQOUM4bzcvMjJmaFdMc0QyV1hDRzBYCnUyWUgyQXdzdi9XaFhybExEaXJweFZ6eXRGK1BCc0k3eW8rSUt0Q3p0YXRNTWxlTzhkdlI5Q3dsMDBUTUVpcjkKcmdwT2drbEFDMVg5Y1dpci9rRUFMNlV0NWpRb0UyQzNaOTlYbmxNZS9YZTU1YVVwZFNSWVgvb0M0K1dSQzZVVQpLLzNRTlpRaVBXZkJiZHJZVG1KV2U5WXBXclhyU1B0b3NVM2lEMFRNcnE3dUtPYlV6THZiWWs0U2xwLzI1RnNlCkZwbzNySVpXOEUxNkNJRkM4N2NlOUxVamJDbGpKM3h1TlJLTHJ2d1JwNmQ5SW0yazZuN2FBa0QwSzdHUXZpV2YKZmhUYW1TWExzaGxGOVlYdlBwUGFBMUlncDQvTE9jZ0FoVjNWdHZSMHZWQ0VIR2xwSHZGTC9GWmwyZG9Yb2RaSgpkTk1USUsrc0R0MGgyMGZ1QlJjTm91a0NBd0VBQWFOV01GUXdEZ1lEVlIwUEFRSC9CQVFEQWdXZ01CTUdBMVVkCkpRUU1NQW9HQ0NzR0FRVUZCd01DTUF3R0ExVWRFd0VCL3dRQ01BQXdId1lEVlIwakJCZ3dGb0FVMm41Uy9uTW8KLzliRGUvT0V4S3pOM1JnZmdKZ3dEUVlKS29aSWh2Y05BUUVMQlFBRGdnSUJBSjJiajhqRUVYNXBxL2U4NXgxTQpYQ2RRaTVKRE5MQXRIMzh1OFQ3YTJWOW5yNGw1TnBEdCtzbXNxeEx4ZGs4dG1CZmh4Q3lBT0NGQkhtWWNzT1FpCnd6OGxLdjdUUTdYejNJZWZqdGVZRkI2S1dBWUdpRmR6VGdjT1J6N2I0N2hEbHdLYndVY1BRcmp0cUp6WE1wUVAKdmhZbGRWelhreThXSjF5K3ppSVZ5MDc0YVFGV09nQnhrekF3cVBCdUZoak1wSXcrdlYrZnEvdUFkb1R6cHRRNwoxeHpPa29OVzhjWk83TnVKSlphUWxna0lqOE9LTHRCK1ptSU0wNGZCeDJMSDEzcXFaRzNwY3M3dFFNdERIY0VwCjdzV2NOL1h4akRGT1NacHM1UC9QUnQ2ZjB1U3ZLOXVKaTJid1IyUDFLdjh3RWhvdlhqRGRzTEhaczBtZnMyU0wKSEJjTTRQb1FvYzBaV2ZSS0JWSnZqSitBUWRSYXJKdnFzL3F3L0h4TU54VHJtTzBaWC8xQkNheUNYNmwwQkl5WgpPWDdZeVR3VDI2djJjS2NNQVJZMU1LZmt5Z2sxSnA1UHNmMk5XbXc2MjJzcnY3akNzWW8rUlJXYzR4bGVOWFFvCkVSeGpRaFpBbzlBUnczTlRpNWVidFVLYTJlNXl3YWc1VnZhSTR1dVJpMnBSVDN2NUVEd2NYTGlEOHAxQUxGNmwKQjhvM0U1NE0xclZmSms5TlVtVE03YThscjd0ekhNMVJpcE9RMHdDSjQybW93NElLaVlNV3UrTkVpYnVlVGU0SQoyTHV4MnZnRVBnRDhPTzQzeEsybnlWYW82bGM5Z1ZqR2lvQy9XY1BMa0REdC9zL1JtTkpmNjhHc2V3TWtEZFJ1ClNCMnM5czlicjYzbk9xTFIxWGRkT3BDSQotLS0tLUVORCBDRVJUSUZJQ0FURS0tLS0tCg==",
                    "clusterName": "IFTT Cluster",
                    "clusterProvider": "AZURE",
                    "apiServerId": "6dae42f8-4368-4678-94ff-3960e28e3630",
                    "tenantId": "5bff8b06-5db8-4c9c-976e-a18993eb699a",
                    "region": "eastus"
                },
                "userSelectedManagedServices": [
                    [
                        "AzureManagedService",
                        "AKS"
                    ]
                ],
                "enabled": false
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "Mohammed Hisham",
                    "updatedTime": 1696492981221,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "Mohammed Hisham",
                    "updatedTime": 1696492981221,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "Mohammed Hisham",
                    "updatedTime": 1696492981221,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": {
                    "optimization": {
                        "type": "KubernetesOptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Mohammed Hisham",
                            "updatedTime": 1696492981221,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        },
                        "optimizationFocus": {
                            "type": "KubernetesOptimizationFocusItem",
                            "updatedUser": "Mohammed Hisham",
                            "updatedTime": 1696492981221,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "focus": "COST",
                            "maxMemoryIncreasePct": null,
                            "maxCPUIncreasePct": null,
                            "maxLatencyIncreasePct": 0
                        }
                    },
                    "enableVerticalScaling": {
                        "updatedUser": "Mohammed Hisham",
                        "updatedTime": 1696492981221,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "enableHorizontalScaling": {
                        "horizontalScalingConfig": {
                            "updatedUser": "Mohammed Hisham",
                            "updatedTime": 1696492981221,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        },
                        "minReplicas": null,
                        "maxReplicas": null,
                        "replicaMultiplier": null,
                        "horizontalScalingConfigMode": false
                    },
                    "enablePredictiveScaling": {
                        "updatedUser": "Mohammed Hisham",
                        "updatedTime": 1696492981221,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "autonomousActionWithoutTraffic": null,
                    "isProd": {
                        "updatedUser": "Mohammed Hisham",
                        "updatedTime": 1696492981221,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true
                    }
                },
                "ecsSpecificDetail": null,
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Mohammed Hisham",
                            "updatedTime": 1696492981221,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [
                    "APP"
                ],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1696492981250,
            "updatedTime": 1701684271458,
            "createdUser": "Mohammed Hisham",
            "updatedUser": "Tapan Manu",
            "providerAccountId": null,
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "xyg3dimf",
            "name": "test dev env",
            "accountDetails": {
                "cloudProvider": "GCP",
                "credentialsDetail": {
                    "id": "b52fb000-8073-4c3c-9d08-f7cd0c60145e",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWV5cQUWVU6ee6HI89+MxmUkL/1DGGD2Usu/iHNfwgQ1Jv/CYEykC+PmbJnq922Fp1zCPxCTYQVBQu1pZB5/4FebN8MO6Dmk7n/HuhnWVcErg",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENTLESS",
                "encryptionKey": null,
                "projectId": "322323",
                "regions": [
                    "asia-east1"
                ],
                "userSelectedManagedServices": null,
                "enabled": true
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "Benjamin",
                    "updatedTime": 1702942554143,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "Benjamin",
                    "updatedTime": 1702942554143,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "Benjamin",
                    "updatedTime": 1702942554143,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": null,
                "ecsSpecificDetail": null,
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Benjamin",
                            "updatedTime": 1702942554143,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1702942554239,
            "updatedTime": 1702942554239,
            "createdUser": "Benjamin",
            "updatedUser": "Benjamin",
            "providerAccountId": null,
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "yeujuqd2",
            "name": "EKS",
            "accountDetails": {
                "cloudProvider": "KUBERNETES",
                "credentialsDetail": {
                    "id": "d41b4092-546a-4ff7-970d-8018cca7d910",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWbQkRcXcLMyCDfwaW0IZApK5j1Gx6B/XUmcVUxkgl1Sh",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENT_BASED",
                "encryptionKey": "QoEGPa6pVmeaoIvySVE+kx7BFq06WzzoUjJgaJr1oFEKniBf8zFTLmM112Pjh+ig",
                "metadata": {
                    "clusterUrl": null,
                    "caCertData": null,
                    "clusterName": "EKS",
                    "clusterProvider": "AWS",
                    "region": null
                },
                "userSelectedManagedServices": [
                    [
                        "AwsManagedService",
                        "EKS"
                    ]
                ],
                "enabled": false
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "snt(API Key)",
                    "updatedTime": 1695277701972,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "snt(API Key)",
                    "updatedTime": 1695277701972,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "snt(API Key)",
                    "updatedTime": 1695277701972,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": {
                    "optimization": {
                        "type": "KubernetesOptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "snt(API Key)",
                            "updatedTime": 1695277701972,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        },
                        "optimizationFocus": {
                            "type": "KubernetesOptimizationFocusItem",
                            "updatedUser": "snt(API Key)",
                            "updatedTime": 1695277701972,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "focus": "COST",
                            "maxMemoryIncreasePct": null,
                            "maxCPUIncreasePct": null,
                            "maxLatencyIncreasePct": 0
                        }
                    },
                    "enableVerticalScaling": {
                        "updatedUser": "snt(API Key)",
                        "updatedTime": 1695277701972,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "enableHorizontalScaling": {
                        "horizontalScalingConfig": {
                            "updatedUser": "snt(API Key)",
                            "updatedTime": 1695277701972,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        },
                        "minReplicas": null,
                        "maxReplicas": null,
                        "replicaMultiplier": null,
                        "horizontalScalingConfigMode": false
                    },
                    "enablePredictiveScaling": {
                        "updatedUser": "snt(API Key)",
                        "updatedTime": 1695277701972,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "autonomousActionWithoutTraffic": null,
                    "isProd": {
                        "updatedUser": "snt(API Key)",
                        "updatedTime": 1698731220974,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    }
                },
                "ecsSpecificDetail": null,
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "snt(API Key)",
                            "updatedTime": 1695277701972,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [
                    "APP"
                ],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1695277702025,
            "updatedTime": 1701686541769,
            "createdUser": "snt(API Key)",
            "updatedUser": "Tapan Manu",
            "providerAccountId": "yeujuqd2",
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "498xynxa",
            "name": "GKE",
            "accountDetails": {
                "cloudProvider": "KUBERNETES",
                "credentialsDetail": {
                    "id": "2c1b9a98-d40e-444e-8659-7a0fed3f70a9",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWbQkRcXcLMyCDfwaW0IZApK5j1Gx6B/XUmcVUxkgl1Sh",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENT_BASED",
                "encryptionKey": "YKCjJqIKNN3Jri1p6Y2118qdkOuDBjdGVi1tPoWfXOvyqrYEShtQPFMIy5e8BAeS",
                "metadata": {
                    "clusterUrl": null,
                    "caCertData": null,
                    "clusterName": "GKE",
                    "clusterProvider": "GCP",
                    "region": null
                },
                "userSelectedManagedServices": [
                    [
                        "GcpManagedService",
                        "GKE"
                    ]
                ],
                "enabled": false
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "Tatum Smith",
                    "updatedTime": 1699474853417,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "Tatum Smith",
                    "updatedTime": 1699474853417,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "Tatum Smith",
                    "updatedTime": 1699474853417,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": {
                    "optimization": {
                        "type": "KubernetesOptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Tatum Smith",
                            "updatedTime": 1699474853417,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        },
                        "optimizationFocus": {
                            "type": "KubernetesOptimizationFocusItem",
                            "updatedUser": "Tatum Smith",
                            "updatedTime": 1699474853417,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "focus": "COST",
                            "maxMemoryIncreasePct": null,
                            "maxCPUIncreasePct": null,
                            "maxLatencyIncreasePct": 0
                        }
                    },
                    "enableVerticalScaling": {
                        "updatedUser": "Tatum Smith",
                        "updatedTime": 1699474853417,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "enableHorizontalScaling": {
                        "horizontalScalingConfig": {
                            "updatedUser": "Tatum Smith",
                            "updatedTime": 1699474853417,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        },
                        "minReplicas": null,
                        "maxReplicas": null,
                        "replicaMultiplier": null,
                        "horizontalScalingConfigMode": false
                    },
                    "enablePredictiveScaling": {
                        "updatedUser": "Tatum Smith",
                        "updatedTime": 1699474853417,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "autonomousActionWithoutTraffic": null,
                    "isProd": {
                        "updatedUser": "Tatum Smith",
                        "updatedTime": 1699474853417,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true
                    }
                },
                "ecsSpecificDetail": null,
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Tatum Smith",
                            "updatedTime": 1699474853417,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [
                    "APP"
                ],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1699474853438,
            "updatedTime": 1701684241803,
            "createdUser": "Tatum Smith",
            "updatedUser": "Tapan Manu",
            "providerAccountId": "498xynxa",
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "p9tqxxvn",
            "name": "EKS-test",
            "accountDetails": {
                "cloudProvider": "KUBERNETES",
                "credentialsDetail": {
                    "id": "dd12c0a0-c415-4cf1-9ff5-1b61b60192be",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWbQkRcXcLMyCDfwaW0IZApK5j1Gx6B/XUmcVUxkgl1Sh",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENT_BASED",
                "encryptionKey": "SGF8GB3WMSkvHuCZAKssrz/3sPEE2kp3JLKYef0wiWYZc49O0IrpcwoLSex1eaHs",
                "metadata": {
                    "clusterUrl": null,
                    "caCertData": null,
                    "clusterName": "EKS-test",
                    "clusterProvider": "AWS",
                    "region": null
                },
                "userSelectedManagedServices": [
                    [
                        "AwsManagedService",
                        "EKS"
                    ]
                ],
                "enabled": false
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "Anoosha Clarance",
                    "updatedTime": 1696239695725,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "Anoosha Clarance",
                    "updatedTime": 1696239695725,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "Anoosha Clarance",
                    "updatedTime": 1696239695725,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": {
                    "optimization": {
                        "type": "KubernetesOptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Anoosha Clarance",
                            "updatedTime": 1696239695725,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        },
                        "optimizationFocus": {
                            "type": "KubernetesOptimizationFocusItem",
                            "updatedUser": "Anoosha Clarance",
                            "updatedTime": 1696239695725,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "focus": "COST",
                            "maxMemoryIncreasePct": null,
                            "maxCPUIncreasePct": null,
                            "maxLatencyIncreasePct": 0
                        }
                    },
                    "enableVerticalScaling": {
                        "updatedUser": "Anoosha Clarance",
                        "updatedTime": 1696239695725,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "enableHorizontalScaling": {
                        "horizontalScalingConfig": {
                            "updatedUser": "Anoosha Clarance",
                            "updatedTime": 1696239695725,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        },
                        "minReplicas": null,
                        "maxReplicas": null,
                        "replicaMultiplier": null,
                        "horizontalScalingConfigMode": false
                    },
                    "enablePredictiveScaling": {
                        "updatedUser": "Anoosha Clarance",
                        "updatedTime": 1696239695725,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "autonomousActionWithoutTraffic": {
                        "updatedUser": "Tapan Manu",
                        "updatedTime": 1676769925448,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true
                    },
                    "isProd": {
                        "updatedUser": "snt(API Key)",
                        "updatedTime": 1698816165857,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    }
                },
                "ecsSpecificDetail": null,
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Anoosha Clarance",
                            "updatedTime": 1696239695725,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [
                    "APP"
                ],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1696239695751,
            "updatedTime": 1701684272724,
            "createdUser": "Anoosha Clarance",
            "updatedUser": "Tapan Manu",
            "providerAccountId": "p9tqxxvn",
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "5r5xtom0",
            "name": "dev-gcp-arch1",
            "accountDetails": {
                "cloudProvider": "GCP",
                "credentialsDetail": {
                    "id": "28d1e09b-40dc-49f5-af95-b8bcaa37ec72",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWV5cQUWVU6ee6HI89+MxmUkL/1DGGD2Usu/iHNfwgQ1Jv/CYEykC+PmbJnq922Fp17+hMs1a33o8FQAxljiOHD2GDwlLBqylgdGQXrEKWdxtLEDHO9/nryf+XpkkaM5CWSrafjxOB3zWPD3IYq0Hzd47FtFcZ4x0Kg+QloAfnugDnS58fCfVXq8oefk4MoUuCLA/SYwoVLhKEXU4k5nl2EtGofc2vF2mk/6e4K6F4H7AAyrj9zN3HaWNMayw1OLV4WOiEf8ds92J1AiGOemclCxMMVaWqUqKiwGq/oRVtXJlIpo9fz2yjnLCITtix5gRjKAoeCIFyhW6zK2pd69f0LcWNc0djBFaeTZmQ/4HksJYuDzwnusMa+ZlW8Mp4lbtnbL2tvycUO6mezRfWsddWoneRQUrsD1PSGqL8Bx1iQEh11Jk9zrh38fC7zB1w3N5E8zBl2bGU2jFgLCzDecNXYV+IZrowQ/LvxMCjSS3/FYQJA4AyOzd4yQKhz6YpXhHCxkxfmpxfuw/ZykldiTKNpJhrIo+3C8asqXHbRNGSHYVL8u98b4zVsvQlPUJtkOp2XYcnLxR+K566WiwqKQci+v14lEgbGa8zVOwDjKMkJ4xnjjyFawnyp9iae1u46KTfJjjR+mDqp7V6GMCDtaeRsnw/h6XFIguOrPSxQJ5hD8EblO9efXUFYNYlvJL9XrFXzlw2J49Dgl4uE4Ub8IxOcZWArck/zyRfM2UjMIgSq9qEvMVMrK5qKyxtRk5wMcKpso7IuabCiHB9VX/UqUAnR7n7ibC+MLcgL0igtSqh/Sc84lw/gGRGkNEQkKlDZADA5KrrXZLwOQoqoSpaLEInWVsTTvUHgRDKV62/iBkyNrI+GfKFB0tQmKwN+Tk18xVL+lGGvAPHye0OTL6fVQm88BHpP4ozVHtY7QZTCwbWAMLhBYC+4/8qAC1OhgOsf054efQ2j1mGXyN23xU9nk9x3D9XWpeUkN4mBLKFVafiHtgFagDn4v3pE2eh/scHxKbXZBpO2iYupJ2Mhhf1QPaE5kJpJ/wweZXCcPWE99Ivu3w63tAtuiycEVvo/SOsfQ4Bt/6H6/DOAB3j2JgRC1EVmGquy3jyCYT4Kc0wFSm3VsP5zLnL6bsiku1xSSBvqFoPXHTD+35+75UKtfEQc4vc4X2Ttks4SfqAy5QkKWB1IpYqtZ/INjfP1g/RVqqBiZnNMZ9OGoN45GqhmldFSCExBKzuisgkqOTf28nspbebhRoBCDyVGwxjVHZ7gtZYWcBLz7CdE+0BT75Wn3loIP6IrCTBBW8q4UcksO63JzJxHfHADPmKQkBG8zoGHWRtJJ455LR/1ODASXrN7RcBKVntbNniRXd4FGNh8U0agl7ec68SrtkMSnrtoq0gy5ioJ7z6N6ZQVWTp0Ag73kPUSOqqAhOG0uLs1J8/VglVOU/02NPVM4oHwcfvEHNeAhnml5tDBHRGQaRMgzw5wYGraug+WWgzcV6skc+cVcncyYwFrIFR910TrrPBQj3x8aPX01RA/e6BzFZkE4YdpgPQQoW3aJxew2GnyFLAeKaWtBAMywjXkhK4Zt9N0WXl0Bp9cOG4JMrZzKKcPkEAVOoJdXevoIiFMIW6gsKWWXjWJk13Xy28aSIzTaDlbr4nNgO2V2KijCu3c5GC5AXAOSCyFP0ATivTf8Ta/d/7uE+Q0ZehzMb6/TabdPEyzodzjci9tk/1t9dTZCe/9u6ODg9DsdaYGBxxNyuWbujv3j9IdhAsX/QioyfBxwbc0wlMOQf2LBwS3PnOcj1WXpyWjtdoqSBXz2zoux+giEo9YS2z6XbP7JkR/3zGYI1L3sJLfIEdax2enQOk8ZSWQd2a/J4p8GJqBC3LTjXa6WUBdWV4USoLRUIrF3E5z5B3GcgQmHMqQrr+e6nkkFcCKKmYytfKkoyUt5U66NbwjgdnDkGCR4McfBvtuKs+BPQYDZDeBBbLMxDZrmb8tYG8zEqiKhU641roqLR41xYH+EFWAAPYW6CRChjH6YEikkaPnYVX/esLSEfof+YA7xRGVjnG9yEL1OguEXoAfGOTVfdcxvkucFatD/+wnt87z+m6nEk3GgZFggD4RLMYFjcv61mbaH/I76/Joacep68hzxLjxQAe1pM6XaHGxbsRuS0p0cpaZ3VOdsKoxlPirXw3bfnNh6ulA1CPF38wN2DJPvdCc8hUN+kUvnBqf4Im4QRztbE7GY/nChsuSjEr7l1ESZaYQdppU3RHXO9KYak84xBHE2WM7OFR99K6QQlpq+L3ut0eesbWWlzWjvq8qjsp/8hRgy3M/HhWJvwfPBUaPf/o7Ff4vP0T00VqzlvycGmd3op6KzEewC3B95tgLyiYFJ+G53shvf4J1W8ydA7bZ3alZ102P4zcCvXfEmnIJ9KSJ738sG70cXWTZR7qJ+5hbGT3NkhFq6eftkrc0Ou6b89giZaEqWRgeNTxOT4HFQ1ozrhZp9HUOM/dq6V4+vFKDbUvmIlP9vD7jUWEFZyVrRcJE0JzBR0lS/QI/W1EUFgWW24OepW125SNlJ+J0hBzRH15GbTkArLsPsEwPYSCsWXl0nyecrzHMnfbpwyFyjqj5y4CX4b6O5oC6lOdrx3I2eHXTlgbxyrp4XBG5h1aOjDvyZmBq+rYVzvSXLtGiw1oHdntoSJ6gTRktYBqJsr4mf8RwCSLj7+NQIvRU4Dw1ofq4REOzWGCSvtxav+mtV7MWv7OTVTA6Je5qXjHRWdit0aFwHinI+2N8mnlYa9pt38O05+/Cr5J+JxffR0N3vAepXZws8oCSlh2MD/aMZ9V8Bn0oU8O8keXN410HJYSsKMxagLoVMsAQPVadJUKmRDEWBdNX0/R+HHD+AbAplhhlEMOXhBH+0mWNMhDhb/c2dnPMBz66vOhkLeg9QurvLqcO+n047Q1bzCg1smnycfpkKiQvkLa9RpJyJn9sh+/npOV3pKnbLxSzQ12MRmwIua+v19dfCKR+JLT6OeAdWElMCiUOjHfDXggBTrSKs2SlqwnUiIvVpPV4gPWZuf/iyJbWijZJ3qw9T6rRrLFh/LiwVwdN8yP3LkY3g7VDKiuGMC/vQWnDfXIt9R57tvccRL0vqAhBeS6HMMqLt6+RcXNF+7iI8lRheWqdRwasp8Fttfit92dliTkOIJISc9Y4w3MX3CWMXqb7wCkECMuUsP6N4A2u4Az36TEjwB/Zb7JKnJxHlUgW6vKS3gUYGhi9avbh/eK8XiV2VmIuqUCWueyZMD+Uvbgb4LGqutWDxXqdJ/tCo9sJ4L143CGC0063UOskDbrjNpvF6/nA==",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENTLESS",
                "encryptionKey": null,
                "projectId": "dev-gcp-394616",
                "regions": [
                    "us-central1"
                ],
                "userSelectedManagedServices": null,
                "enabled": true
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "Archana Indira Devi",
                    "updatedTime": 1694483289618,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "Archana Indira Devi",
                    "updatedTime": 1694483289618,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "Archana Indira Devi",
                    "updatedTime": 1694483289618,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": null,
                "ecsSpecificDetail": null,
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Archana Indira Devi",
                            "updatedTime": 1694483289618,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1694483289650,
            "updatedTime": 1702662354855,
            "createdUser": "Archana Indira Devi",
            "updatedUser": "Praveen Prakash",
            "providerAccountId": "5r5xtom0",
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "swxz3k7o",
            "name": "gcp-test-qa1",
            "accountDetails": {
                "cloudProvider": "GCP",
                "credentialsDetail": {
                    "id": "e358e5cf-9cf5-4d37-9878-220273e30eec",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWV5cQUWVU6ee6HI89+MxmUkL/1DGGD2Usu/iHNfwgQ1Jv/CYEykC+PmbJnq922Fp17+hMs1a33o8FQAxljiOHD2GDwlLBqylgdGQXrEKWdxtLEDHO9/nryf+XpkkaM5CWUYEAdbrlbA8d2/UbO9/CYPfdit936lf7QJNqqctVB+5nS58fCfVXq8oefk4MoUuCFkJ5VcrGfDxYDK+GdHYWw7IusyHgRpaLORpOvbHxeC+vFdiHmc7qRyn2q1nWyk34ydBPxxeeuci97Nkn4ucJP9MMVaWqUqKiwGq/oRVtXJlIpo9fz2yjnLCITtix5gRjKAoeCIFyhW6zK2pd69f0LcWNc0djBFaeTZmQ/4HksJYuDzwnusMa+ZlW8Mp4lbtnQKtMNj2Myw07tjl9lCV3f6YXfTQx/ymgY+n+8470Il4M57c/bP88JYtVDWN1vl8CcblQu/m79UxuAnSi8kW9nnKqkRlYn0HYXsgWUAHO9F6t3fyOSlrirOECs2F/zPrrtDM/LEj2t1rLRHPeNaGi7e+A8Aoc6OTOpBpysj5eNhNl/73gVZtcEB/iTL1/9htrqmBn0UyuOE7dTpzazSSD3xTpTtLu3zfbD2HvK0JXfndYsVMt/BMCpwmhbMNtiVCflixjcRG1y/hzw6Qw+1Rrf4ykqgbdsnkpxOiglYhlgThr+Ib1kEkeZaw0xauPnMyQ7F4KSkEmxLm04/xw/qcKnAM/EqGSQTP4zlFBMLgUQgaBYbP5JiZYcV++dFIdjGDTvbD6Vehl5jfltbdNjIztsAEpgn/MA3X0UVDee8P+Du1JdyBv5wlvIPPYKZT9rhHQHZ7FY9KY6CswdQ4MVHBDn6pejmA0edJUrKtYY14reNwxWVkoeVdUpFViLqQagfKQkSKJCBQZH9v8QP6EBDsWpKqRzuzJV9AVCoA3YFHm7IOdNP+VHj7gKr341T1uuMpn3UcuYe1mSVcFAG16Amvkn2PDJZ5VJrDeVhmWl2r4m3cPWgjqKEk1cP0xv3Wfwi6jB3nTtTwrOdfUd1Fr0oWK70GJGfKouR2CGarHeYJTNVV/6mPBIkm/+EeU358asiqtVoviFP3/kbQeRtR/i8RQ4tGBAt6V/uFxIBys5GxTaLZ9hFjB+kZY9x79+Mi8/sTIBa9oUR3D+4RUzhR8cJT66B8LL5HA2aYfxN1x8UQs7VyGqrzXMQqr0I8kun4Is4PMDm36V5gqhCiun/Rhnqa4vy5bD7Ah/NGE9FKf77Qv7FcL4WGvRvYgdLv5ZJUyMZEgUxnGjwVNDQ/rq7bGfClmt2OcZC3rlGML41NTx1aQNwRpw051qSCWZE7tciA0Lio1bCmQUUwmBA6ZsTfw6gloP/20ZDG8De0xz19mlw6eFRDMVOobA2GyQq3hS3v8wNv1JBSRvngukLanD43Iv9ymfZobpO4WI/Dv6+rd6tSUGIE4XLSs/H78UgEczJomZEOU7axONjPwG82HY8IDI1h0cA=",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENTLESS",
                "encryptionKey": null,
                "projectId": "sedai-gcp-test",
                "regions": [
                    "us-central1"
                ],
                "userSelectedManagedServices": null,
                "enabled": false
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "Monica Poovizhi",
                    "updatedTime": 1693988281849,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "Monica Poovizhi",
                    "updatedTime": 1693988281849,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "Monica Poovizhi",
                    "updatedTime": 1693988281849,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": null,
                "ecsSpecificDetail": null,
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Monica Poovizhi",
                            "updatedTime": 1693988281849,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1693988281886,
            "updatedTime": 1694537491664,
            "createdUser": "Monica Poovizhi",
            "updatedUser": "Tapan Manu",
            "providerAccountId": "swxz3k7o",
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "yiduzhbd",
            "name": "Azure Kubernetes",
            "accountDetails": {
                "cloudProvider": "KUBERNETES",
                "credentialsDetail": {
                    "id": "6b8ed605-ae73-4405-b24e-c21450bc7ffe",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWbQkRcXcLMyCDfwaW0IZApK5j1Gx6B/XUmcVUxkgl1Sh",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENT_BASED",
                "encryptionKey": "xhCCpDJazxzfbFIvOlDNEwdEl01C5n5JBI6nJ7xwOwOqTFUHDCK4CqkdKeoaoKfy",
                "metadata": {
                    "clusterUrl": null,
                    "caCertData": null,
                    "clusterName": "Azure Kubernetes",
                    "clusterProvider": "AZURE",
                    "apiServerId": null,
                    "tenantId": null,
                    "region": null
                },
                "userSelectedManagedServices": [
                    [
                        "AzureManagedService",
                        "AKS"
                    ]
                ],
                "enabled": true
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "Aby Jacob",
                    "updatedTime": 1699249780303,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "Aby Jacob",
                    "updatedTime": 1699249780303,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "Aby Jacob",
                    "updatedTime": 1699249780303,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": {
                    "optimization": {
                        "type": "KubernetesOptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Aby Jacob",
                            "updatedTime": 1699249780303,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        },
                        "optimizationFocus": {
                            "type": "KubernetesOptimizationFocusItem",
                            "updatedUser": "Aby Jacob",
                            "updatedTime": 1699249780303,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "focus": "COST",
                            "maxMemoryIncreasePct": null,
                            "maxCPUIncreasePct": null,
                            "maxLatencyIncreasePct": 0
                        }
                    },
                    "enableVerticalScaling": {
                        "updatedUser": "Aby Jacob",
                        "updatedTime": 1699249780303,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "enableHorizontalScaling": {
                        "horizontalScalingConfig": {
                            "updatedUser": "Aby Jacob",
                            "updatedTime": 1699249780303,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        },
                        "minReplicas": null,
                        "maxReplicas": null,
                        "replicaMultiplier": null,
                        "horizontalScalingConfigMode": false
                    },
                    "enablePredictiveScaling": {
                        "updatedUser": "Aby Jacob",
                        "updatedTime": 1699249780303,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "autonomousActionWithoutTraffic": null,
                    "isProd": {
                        "updatedUser": "Aby Jacob",
                        "updatedTime": 1699249780303,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true
                    }
                },
                "ecsSpecificDetail": null,
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Aby Jacob",
                            "updatedTime": 1699249780303,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [
                    "APP"
                ],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1699249780336,
            "updatedTime": 1699249780336,
            "createdUser": "Aby Jacob",
            "updatedUser": "Aby Jacob",
            "providerAccountId": "yiduzhbd",
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "vhm81mb3",
            "name": "EKS",
            "accountDetails": {
                "cloudProvider": "KUBERNETES",
                "credentialsDetail": {
                    "id": "c49a4e6d-1b60-49d4-a951-2f5cad7ec854",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWbQkRcXcLMyCDfwaW0IZApK5j1Gx6B/XUmcVUxkgl1Sh",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENT_BASED",
                "encryptionKey": "6QhawdhE33Pst0XMeyEMo3uQZ0Hn5rfGhni0zJToyU1U94V+yU48LMQEUZ5Nry5u",
                "metadata": {
                    "clusterUrl": null,
                    "caCertData": null,
                    "clusterName": "EKS",
                    "clusterProvider": "AWS",
                    "region": null
                },
                "userSelectedManagedServices": [
                    [
                        "AwsManagedService",
                        "EKS"
                    ]
                ],
                "enabled": false
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "Laya Prasad",
                    "updatedTime": 1698404098294,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "Laya Prasad",
                    "updatedTime": 1698404098294,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "Laya Prasad",
                    "updatedTime": 1698404098294,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": {
                    "optimization": {
                        "type": "KubernetesOptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Laya Prasad",
                            "updatedTime": 1698404098294,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        },
                        "optimizationFocus": {
                            "type": "KubernetesOptimizationFocusItem",
                            "updatedUser": "Laya Prasad",
                            "updatedTime": 1698404098294,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "focus": "COST",
                            "maxMemoryIncreasePct": null,
                            "maxCPUIncreasePct": null,
                            "maxLatencyIncreasePct": 0
                        }
                    },
                    "enableVerticalScaling": {
                        "updatedUser": "Laya Prasad",
                        "updatedTime": 1698404098294,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "enableHorizontalScaling": {
                        "horizontalScalingConfig": {
                            "updatedUser": "Laya Prasad",
                            "updatedTime": 1698404098294,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        },
                        "minReplicas": null,
                        "maxReplicas": null,
                        "replicaMultiplier": null,
                        "horizontalScalingConfigMode": false
                    },
                    "enablePredictiveScaling": {
                        "updatedUser": "Laya Prasad",
                        "updatedTime": 1698404098294,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "autonomousActionWithoutTraffic": null,
                    "isProd": {
                        "updatedUser": "Laya Prasad",
                        "updatedTime": 1698404098294,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true
                    }
                },
                "ecsSpecificDetail": null,
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Laya Prasad",
                            "updatedTime": 1698404098294,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [
                    "APP"
                ],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1698404098304,
            "updatedTime": 1701684252559,
            "createdUser": "Laya Prasad",
            "updatedUser": "Tapan Manu",
            "providerAccountId": "vhm81mb3",
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "rnsvetqc",
            "name": "AWS-snt-storage-test",
            "accountDetails": {
                "cloudProvider": "AWS",
                "credentialsDetail": {
                    "id": "f152dff3-3525-4a3f-bdda-051c6b5fc287",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWbQkRcXcLMyCDfwaW0IZApJDR1kKhZngLWL6ewoA6hguQdWstWPnbHbGfgo0p1QB4bAtk29xYiJs8FdKPm0IWhBycUZXfD3sLM0ElVfwOxDgyri96VL9n0JMZTxGmLJG8Q==",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENTLESS",
                "encryptionKey": null,
                "userSelectedManagedServices": null,
                "enabled": false
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "Sreejith narayanan",
                    "updatedTime": 1697180007843,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "Sreejith narayanan",
                    "updatedTime": 1697180007843,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "Sreejith narayanan",
                    "updatedTime": 1697180007843,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": {
                    "optimization": {
                        "type": "ServerlessOptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Sreejith narayanan",
                            "updatedTime": 1697180007843,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        },
                        "optimizationFocus": {
                            "type": "ServerlessOptimizationFocusItem",
                            "updatedUser": "Sreejith narayanan",
                            "updatedTime": 1697180007843,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "focus": "COST_AND_DURATION",
                            "autoOptMaxCostChangePct": null,
                            "autoOptMaxLatencyChangePct": null
                        },
                        "provisionedConcurrencyOptimization": {
                            "updatedUser": "Sreejith narayanan",
                            "updatedTime": 1697180007843,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        },
                        "autonomousConcurrency": {
                            "updatedUser": "Sreejith narayanan",
                            "updatedTime": 1697180007843,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        },
                        "telemetryLogging": {
                            "updatedUser": "Sreejith narayanan",
                            "updatedTime": 1697180007843,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        }
                    }
                },
                "kubeSpecificDetail": null,
                "ecsSpecificDetail": {
                    "optimization": {
                        "type": "ECSOptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Sreejith narayanan",
                            "updatedTime": 1697180007843,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "MANUAL"
                        },
                        "optimizationFocus": {
                            "type": "ECSOptimizationFocusItem",
                            "updatedUser": "Sreejith narayanan",
                            "updatedTime": 1697180007843,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "focus": "COST",
                            "maxMemoryIncreasePct": null,
                            "maxCPUIncreasePct": null,
                            "maxLatencyIncreasePct": 0
                        }
                    },
                    "enableVerticalScaling": {
                        "updatedUser": "Sreejith narayanan",
                        "updatedTime": 1697180007843,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true,
                        "minCpu": null,
                        "minMemory": null
                    },
                    "enableHorizontalScaling": {
                        "updatedUser": "Sreejith narayanan",
                        "updatedTime": 1697180007843,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true,
                        "minReplicas": 2,
                        "maxReplicas": null,
                        "replicaIncrement": null
                    },
                    "enablePredictiveScaling": {
                        "updatedUser": "Sreejith narayanan",
                        "updatedTime": 1697180007843,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "enableServiceAutoscalingConfiguration": {
                        "updatedUser": "Sreejith narayanan",
                        "updatedTime": 1697180007843,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "autonomousActionWithoutTraffic": {
                        "updatedUser": "Sreejith narayanan",
                        "updatedTime": 1697180007843,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "isProd": {
                        "updatedUser": "Sreejith narayanan",
                        "updatedTime": 1697180007843,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true
                    }
                },
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Sreejith narayanan",
                            "updatedTime": 1697180007843,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [
                    "SERVERLESS_FUNCTION",
                    "APP"
                ],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1697180007866,
            "updatedTime": 1701689489496,
            "createdUser": "Sreejith narayanan",
            "updatedUser": "Tapan Manu",
            "providerAccountId": "07212576755433",
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "vljbebod",
            "name": "testest",
            "accountDetails": {
                "cloudProvider": "GCP",
                "credentialsDetail": {
                    "id": "57839bb8-b146-46ad-bb1d-bb7536763df9",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWV5cQUWVU6ee6HI89+MxmUkL/1DGGD2Usu/iHNfwgQ1Jv/CYEykC+PmbJnq922Fp1z5JCJP3KOLVXUh2sF38FnQ=",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENTLESS",
                "encryptionKey": null,
                "projectId": "218471",
                "regions": [
                    "us-central1"
                ],
                "userSelectedManagedServices": null,
                "enabled": false
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "snt(API Key)",
                    "updatedTime": 1698339799528,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "snt(API Key)",
                    "updatedTime": 1698339799528,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "snt(API Key)",
                    "updatedTime": 1698339799528,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": null,
                "ecsSpecificDetail": null,
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "snt(API Key)",
                            "updatedTime": 1698339799528,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1698339799554,
            "updatedTime": 1701684254623,
            "createdUser": "snt(API Key)",
            "updatedUser": "Tapan Manu",
            "providerAccountId": "vljbebod",
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "d586clav",
            "name": "SEDAI-GKE-LABS-001",
            "accountDetails": {
                "cloudProvider": "KUBERNETES",
                "credentialsDetail": {
                    "id": "c48c1c9a-8733-4f26-ab41-18bfff6b66ee",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWbQkRcXcLMyCDfwaW0IZApK5j1Gx6B/XUmcVUxkgl1Sh",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENT_BASED",
                "encryptionKey": "3PtS895yqdqjwCka5mhiPMFG0qHSwj8vN/G1rVGVRlYLhalIZhuBmpcwdoZBuYoR",
                "metadata": {
                    "clusterUrl": null,
                    "caCertData": null,
                    "clusterName": "SEDAI-GKE-LABS-001",
                    "clusterProvider": "GCP",
                    "region": null
                },
                "userSelectedManagedServices": [
                    [
                        "GcpManagedService",
                        "GKE"
                    ]
                ],
                "enabled": true
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "Praveen Prakash",
                    "updatedTime": 1692646069698,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "Praveen Prakash",
                    "updatedTime": 1692646069698,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "Akash Vijayan",
                    "updatedTime": 1697091270822,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": {
                    "optimization": {
                        "type": "KubernetesOptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Praveen Prakash",
                            "updatedTime": 1692646069698,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        },
                        "optimizationFocus": {
                            "type": "KubernetesOptimizationFocusItem",
                            "updatedUser": "Praveen Prakash",
                            "updatedTime": 1692646069698,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "focus": "COST",
                            "maxMemoryIncreasePct": null,
                            "maxCPUIncreasePct": null,
                            "maxLatencyIncreasePct": 0
                        }
                    },
                    "enableVerticalScaling": {
                        "updatedUser": "Praveen Prakash",
                        "updatedTime": 1692646069698,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "enableHorizontalScaling": {
                        "horizontalScalingConfig": {
                            "updatedUser": "Praveen Prakash",
                            "updatedTime": 1692646069698,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        },
                        "minReplicas": null,
                        "maxReplicas": null,
                        "replicaMultiplier": null,
                        "horizontalScalingConfigMode": false
                    },
                    "enablePredictiveScaling": {
                        "updatedUser": "Praveen Prakash",
                        "updatedTime": 1692646069698,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "autonomousActionWithoutTraffic": null,
                    "isProd": {
                        "updatedUser": "Praveen Prakash",
                        "updatedTime": 1692646069698,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true
                    }
                },
                "ecsSpecificDetail": null,
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Praveen Prakash",
                            "updatedTime": 1692646069698,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [
                    "APP"
                ],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1692646069784,
            "updatedTime": 1694662933374,
            "createdUser": "Praveen Prakash",
            "updatedUser": "Archana Indira Devi",
            "providerAccountId": "d586clav",
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "ozm0bkoz",
            "name": "EKS",
            "accountDetails": {
                "cloudProvider": "KUBERNETES",
                "credentialsDetail": {
                    "id": "528a2385-3c05-475e-8888-003ceea1f4cc",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWbQkRcXcLMyCDfwaW0IZApK5j1Gx6B/XUmcVUxkgl1Sh",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENT_BASED",
                "encryptionKey": "SSoKFfklPo5B4yoNYseshGUJUtpDs2i6AhVBNEO/KJStEH9OpJrQdJJTGi4uM7nS",
                "metadata": {
                    "clusterUrl": null,
                    "caCertData": null,
                    "clusterName": "EKS",
                    "clusterProvider": "AWS",
                    "region": null
                },
                "userSelectedManagedServices": [
                    [
                        "AwsManagedService",
                        "EKS"
                    ]
                ],
                "enabled": true
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": null,
                "slo": null,
                "releaseIntelligence": null,
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": null,
                "ecsSpecificDetail": null,
                "appSpecificDetail": null,
                "supportedResourceTypes": null,
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1704279216055,
            "updatedTime": 1704279216055,
            "createdUser": "Sedai SuperAdmin (API Key)",
            "updatedUser": "Sedai SuperAdmin (API Key)",
            "providerAccountId": "ozm0bkoz",
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "chor0ojo",
            "name": "sedai-labs-01-us-east-1-SmartAgent",
            "accountDetails": {
                "cloudProvider": "KUBERNETES",
                "credentialsDetail": {
                    "id": "9a859ba0-2c0e-4f66-b733-1769c2cc0193",
                    "externalCredentialsId": null,
                    "credentials": null,
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENT_BASED",
                "encryptionKey": "LVLv0ssHg+QEeXF2fntiE1smrXr3RgnyHS/hngWw/0Sp5dCZO3MX8pLL2TzOHmet",
                "metadata": {
                    "clusterUrl": null,
                    "caCertData": null,
                    "clusterName": "sedai-labs-01-us-east-1",
                    "clusterProvider": "AWS",
                    "region": null
                },
                "userSelectedManagedServices": [
                    [
                        "AwsManagedService",
                        "EKS"
                    ]
                ],
                "enabled": false
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "Sedai SuperAdmin",
                    "updatedTime": 1667509605956,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "OFF"
                },
                "slo": {
                    "updatedUser": "Vinod Sethumadhavan",
                    "updatedTime": 1666976020187,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "OFF"
                },
                "releaseIntelligence": {
                    "updatedUser": "Sedai SuperAdmin",
                    "updatedTime": 1667509613730,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "OFF"
                },
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": {
                    "optimization": {
                        "type": "KubernetesOptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Aby Jacob",
                            "updatedTime": 1673879852426,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "MANUAL"
                        },
                        "optimizationFocus": {
                            "type": "KubernetesOptimizationFocusItem",
                            "updatedUser": "SYSTEM",
                            "updatedTime": 1691755133308,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "focus": "COST",
                            "maxMemoryIncreasePct": null,
                            "maxCPUIncreasePct": null,
                            "maxLatencyIncreasePct": 0
                        }
                    },
                    "enableVerticalScaling": {
                        "updatedUser": "Savitha Selvaraj",
                        "updatedTime": 1669249277668,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "enableHorizontalScaling": {
                        "horizontalScalingConfig": {
                            "updatedUser": "Savitha Selvaraj",
                            "updatedTime": 1669249277668,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        },
                        "minReplicas": null,
                        "maxReplicas": null,
                        "replicaMultiplier": null,
                        "horizontalScalingConfigMode": false
                    },
                    "enablePredictiveScaling": {
                        "updatedUser": "Vinod Sethumadhavan",
                        "updatedTime": 1666976020187,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "autonomousActionWithoutTraffic": null,
                    "isProd": {
                        "updatedUser": "SYSTEM",
                        "updatedTime": 1685095772247,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true
                    }
                },
                "ecsSpecificDetail": null,
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Vinod Sethumadhavan",
                            "updatedTime": 1666976020187,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "OFF"
                        }
                    }
                },
                "supportedResourceTypes": [
                    "APP"
                ],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1666976020207,
            "updatedTime": 1691755133308,
            "createdUser": null,
            "updatedUser": "SYSTEM",
            "providerAccountId": "chor0ojo",
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "hpssgqyb",
            "name": "Azure Kubernetes aby",
            "accountDetails": {
                "cloudProvider": "KUBERNETES",
                "credentialsDetail": {
                    "id": "96caed90-05e2-4652-9e67-007c9e7e3cec",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWbQkRcXcLMyCDfwaW0IZApK5j1Gx6B/XUmcVUxkgl1Sh",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENT_BASED",
                "encryptionKey": "XYSkoT/PYIxKK7QbNvLOAkgAnTPZDT/pptG1WAYyC8GHx3taam9h+RNQfwcBEPxG",
                "metadata": {
                    "clusterUrl": null,
                    "caCertData": null,
                    "clusterName": "Azure Kubernetes aby",
                    "clusterProvider": "AZURE",
                    "apiServerId": null,
                    "tenantId": null,
                    "region": null
                },
                "userSelectedManagedServices": [
                    [
                        "AzureManagedService",
                        "AKS"
                    ]
                ],
                "enabled": false
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "Aby Jacob",
                    "updatedTime": 1696840577533,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "Aby Jacob",
                    "updatedTime": 1696840577533,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "Aby Jacob",
                    "updatedTime": 1696840577533,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": {
                    "optimization": {
                        "type": "KubernetesOptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Aby Jacob",
                            "updatedTime": 1696840577533,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        },
                        "optimizationFocus": {
                            "type": "KubernetesOptimizationFocusItem",
                            "updatedUser": "Aby Jacob",
                            "updatedTime": 1696840577533,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "focus": "COST",
                            "maxMemoryIncreasePct": null,
                            "maxCPUIncreasePct": null,
                            "maxLatencyIncreasePct": 0
                        }
                    },
                    "enableVerticalScaling": {
                        "updatedUser": "Aby Jacob",
                        "updatedTime": 1696840577533,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "enableHorizontalScaling": {
                        "horizontalScalingConfig": {
                            "updatedUser": "Aby Jacob",
                            "updatedTime": 1696840577533,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        },
                        "minReplicas": null,
                        "maxReplicas": null,
                        "replicaMultiplier": null,
                        "horizontalScalingConfigMode": false
                    },
                    "enablePredictiveScaling": {
                        "updatedUser": "Aby Jacob",
                        "updatedTime": 1696840577533,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "autonomousActionWithoutTraffic": null,
                    "isProd": {
                        "updatedUser": "Aby Jacob",
                        "updatedTime": 1696840577533,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true
                    }
                },
                "ecsSpecificDetail": null,
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Aby Jacob",
                            "updatedTime": 1696840577533,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [
                    "APP"
                ],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1696840577604,
            "updatedTime": 1701684265063,
            "createdUser": "Aby Jacob",
            "updatedUser": "Tapan Manu",
            "providerAccountId": "hpssgqyb",
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "fftklkii",
            "name": "sedai-gcp-test-gke-us-central1",
            "accountDetails": {
                "cloudProvider": "KUBERNETES",
                "credentialsDetail": {
                    "id": "4ed5afc0-03b2-4e79-a186-70af29b695e4",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWbQkRcXcLMyCDfwaW0IZApK5j1Gx6B/XUmcVUxkgl1Sh",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENT_BASED",
                "encryptionKey": "jyTqS7/YRaVzRzN25eaY2K8PRFTmEin/iwiIZDe4plPSFrbakL9gVkxg6YoKQeHS",
                "metadata": {
                    "clusterUrl": null,
                    "caCertData": null,
                    "clusterName": "sedai-gcp-test-gke-us-central1",
                    "clusterProvider": "GCP",
                    "region": null
                },
                "userSelectedManagedServices": [
                    [
                        "GcpManagedService",
                        "GKE"
                    ]
                ],
                "enabled": true
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "Pooja Malik",
                    "updatedTime": 1697344787375,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "OFF"
                },
                "slo": {
                    "updatedUser": "Dijeesh Padinharethil",
                    "updatedTime": 1691055586212,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "Dijeesh Padinharethil",
                    "updatedTime": 1691055586212,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": {
                    "optimization": {
                        "type": "KubernetesOptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Dijeesh Padinharethil",
                            "updatedTime": 1691055586212,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        },
                        "optimizationFocus": {
                            "type": "KubernetesOptimizationFocusItem",
                            "updatedUser": "SYSTEM",
                            "updatedTime": 1691755133308,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "focus": "COST",
                            "maxMemoryIncreasePct": null,
                            "maxCPUIncreasePct": null,
                            "maxLatencyIncreasePct": 0
                        }
                    },
                    "enableVerticalScaling": {
                        "updatedUser": "Dijeesh Padinharethil",
                        "updatedTime": 1691055586212,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "enableHorizontalScaling": {
                        "horizontalScalingConfig": {
                            "updatedUser": "Dijeesh Padinharethil",
                            "updatedTime": 1691055586212,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        },
                        "minReplicas": null,
                        "maxReplicas": null,
                        "replicaMultiplier": null,
                        "horizontalScalingConfigMode": false
                    },
                    "enablePredictiveScaling": {
                        "updatedUser": "Dijeesh Padinharethil",
                        "updatedTime": 1691055586212,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "autonomousActionWithoutTraffic": {
                        "updatedUser": "Tapan Manu",
                        "updatedTime": 1676769925448,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true
                    },
                    "isProd": {
                        "updatedUser": "Dijeesh Padinharethil",
                        "updatedTime": 1691055586212,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    }
                },
                "ecsSpecificDetail": null,
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Dijeesh Padinharethil",
                            "updatedTime": 1691055586212,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [
                    "APP"
                ],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1691055586539,
            "updatedTime": 1697100824436,
            "createdUser": "Dijeesh Padinharethil",
            "updatedUser": "Tapan Manu",
            "providerAccountId": "fftklkii",
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "sctfpt1c",
            "name": "kubernetes-cluster",
            "accountDetails": {
                "cloudProvider": "KUBERNETES",
                "credentialsDetail": {
                    "id": "2925bffd-10fc-4c17-8701-4dba6e013839",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWbQkRcXcLMyCDfwaW0IZApK5j1Gx6B/XUmcVUxkgl1Sh",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENT_BASED",
                "encryptionKey": "7hXJ1zAM4eumj/Lpvc77kui8u0T4XmPec6YoGROa0olg+/yMkCi5hqdL3tWqlPi2",
                "metadata": {
                    "clusterUrl": null,
                    "caCertData": null,
                    "clusterName": "sedai-labs-02-us-east-1",
                    "clusterProvider": "AWS",
                    "region": null
                },
                "userSelectedManagedServices": [
                    [
                        "AwsManagedService",
                        "EKS"
                    ]
                ],
                "enabled": true
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "Vinod Sethumadhavan",
                    "updatedTime": 1679048444219,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "Vinod Sethumadhavan",
                    "updatedTime": 1679048444219,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "Vinod Sethumadhavan",
                    "updatedTime": 1679048444219,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": {
                    "optimization": {
                        "type": "KubernetesOptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Vinod Sethumadhavan",
                            "updatedTime": 1679048444219,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        },
                        "optimizationFocus": {
                            "type": "KubernetesOptimizationFocusItem",
                            "updatedUser": "Tapan Manu",
                            "updatedTime": 1690951963961,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "focus": "COST",
                            "maxMemoryIncreasePct": null,
                            "maxCPUIncreasePct": null,
                            "maxLatencyIncreasePct": 50
                        }
                    },
                    "enableVerticalScaling": {
                        "updatedUser": "Vinod Sethumadhavan",
                        "updatedTime": 1679048444219,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "enableHorizontalScaling": {
                        "horizontalScalingConfig": {
                            "updatedUser": "Vinod Sethumadhavan",
                            "updatedTime": 1679048444219,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        },
                        "minReplicas": null,
                        "maxReplicas": null,
                        "replicaMultiplier": null,
                        "horizontalScalingConfigMode": false
                    },
                    "enablePredictiveScaling": {
                        "updatedUser": "Vinod Sethumadhavan",
                        "updatedTime": 1679048444219,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "autonomousActionWithoutTraffic": null,
                    "isProd": {
                        "updatedUser": "SYSTEM",
                        "updatedTime": 1685095772247,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true
                    }
                },
                "ecsSpecificDetail": null,
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Vinod Sethumadhavan",
                            "updatedTime": 1679048444219,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [
                    "APP"
                ],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1679048444242,
            "updatedTime": 1694587951014,
            "createdUser": "Vinod Sethumadhavan",
            "updatedUser": "Pooja Malik",
            "providerAccountId": "sctfpt1c",
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "txtnyzcj",
            "name": "AWS benji - delete 2",
            "accountDetails": {
                "cloudProvider": "AWS",
                "credentialsDetail": {
                    "id": "d932cb45-26f1-44ad-bf11-dfbfefa634cb",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWbQkRcXcLMyCDfwaW0IZApJDR1kKhZngLWL6ewoA6hguHjqcxuaIJr1eFUQgfwMEfA==",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENTLESS",
                "encryptionKey": null,
                "userSelectedManagedServices": null,
                "enabled": true
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "Benjamin",
                    "updatedTime": 1696530174833,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "Benjamin",
                    "updatedTime": 1696530174833,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "Benjamin",
                    "updatedTime": 1696530174833,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": {
                    "optimization": {
                        "type": "ServerlessOptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Benjamin",
                            "updatedTime": 1696530174833,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        },
                        "optimizationFocus": {
                            "type": "ServerlessOptimizationFocusItem",
                            "updatedUser": "Benjamin",
                            "updatedTime": 1696530174833,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "focus": "COST_AND_DURATION",
                            "autoOptMaxCostChangePct": null,
                            "autoOptMaxLatencyChangePct": null
                        },
                        "provisionedConcurrencyOptimization": {
                            "updatedUser": "Benjamin",
                            "updatedTime": 1696530174833,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        },
                        "autonomousConcurrency": {
                            "updatedUser": "Benjamin",
                            "updatedTime": 1696530174833,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        },
                        "telemetryLogging": {
                            "updatedUser": "Benjamin",
                            "updatedTime": 1696530174833,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        }
                    }
                },
                "kubeSpecificDetail": null,
                "ecsSpecificDetail": {
                    "optimization": {
                        "type": "ECSOptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Benjamin",
                            "updatedTime": 1696530174833,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "MANUAL"
                        },
                        "optimizationFocus": {
                            "type": "ECSOptimizationFocusItem",
                            "updatedUser": "Benjamin",
                            "updatedTime": 1696530174833,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "focus": "COST",
                            "maxMemoryIncreasePct": null,
                            "maxCPUIncreasePct": null,
                            "maxLatencyIncreasePct": 0
                        }
                    },
                    "enableVerticalScaling": {
                        "updatedUser": "Benjamin",
                        "updatedTime": 1696530174833,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true,
                        "minCpu": null,
                        "minMemory": null
                    },
                    "enableHorizontalScaling": {
                        "updatedUser": "Benjamin",
                        "updatedTime": 1696530174833,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true,
                        "minReplicas": 2,
                        "maxReplicas": null,
                        "replicaIncrement": null
                    },
                    "enablePredictiveScaling": {
                        "updatedUser": "Benjamin",
                        "updatedTime": 1696530174833,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "enableServiceAutoscalingConfiguration": {
                        "updatedUser": "Benjamin",
                        "updatedTime": 1696530174833,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "autonomousActionWithoutTraffic": {
                        "updatedUser": "Benjamin",
                        "updatedTime": 1696530174833,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "isProd": {
                        "updatedUser": "Benjamin",
                        "updatedTime": 1696530174833,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true
                    }
                },
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Benjamin",
                            "updatedTime": 1696530174833,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [
                    "SERVERLESS_FUNCTION",
                    "APP"
                ],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1696530174870,
            "updatedTime": 1696530174870,
            "createdUser": "Benjamin",
            "updatedUser": "Benjamin",
            "providerAccountId": null,
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "dtpramrk",
            "name": "AWS-snt-storage-test2",
            "accountDetails": {
                "cloudProvider": "AWS",
                "credentialsDetail": {
                    "id": "d67f3057-7156-4216-a37b-4a628a6c644d",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWbQkRcXcLMyCDfwaW0IZApJDR1kKhZngLWL6ewoA6hguQdWstWPnbHbGfgo0p1QB4U24V0/Kfn/Gs1X0CiYaT9JvRXcSCHp78DgZ48kQ9X/uxB/ZM/4FfJUkVjccJHZ+Yl74l3goF4+pVkYXkXpKFMA=",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENTLESS",
                "encryptionKey": null,
                "userSelectedManagedServices": null,
                "enabled": false
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "Sreejith narayanan",
                    "updatedTime": 1697194292225,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "Sreejith narayanan",
                    "updatedTime": 1697194292225,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "Sreejith narayanan",
                    "updatedTime": 1697194292225,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": {
                    "optimization": {
                        "type": "ServerlessOptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Sreejith narayanan",
                            "updatedTime": 1697194292225,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        },
                        "optimizationFocus": {
                            "type": "ServerlessOptimizationFocusItem",
                            "updatedUser": "Sreejith narayanan",
                            "updatedTime": 1697194292225,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "focus": "COST_AND_DURATION",
                            "autoOptMaxCostChangePct": null,
                            "autoOptMaxLatencyChangePct": null
                        },
                        "provisionedConcurrencyOptimization": {
                            "updatedUser": "Sreejith narayanan",
                            "updatedTime": 1697194292225,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        },
                        "autonomousConcurrency": {
                            "updatedUser": "Sreejith narayanan",
                            "updatedTime": 1697194292225,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        },
                        "telemetryLogging": {
                            "updatedUser": "Sreejith narayanan",
                            "updatedTime": 1697194292225,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        }
                    }
                },
                "kubeSpecificDetail": null,
                "ecsSpecificDetail": {
                    "optimization": {
                        "type": "ECSOptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Sreejith narayanan",
                            "updatedTime": 1697194292225,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "MANUAL"
                        },
                        "optimizationFocus": {
                            "type": "ECSOptimizationFocusItem",
                            "updatedUser": "Sreejith narayanan",
                            "updatedTime": 1697194292225,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "focus": "COST",
                            "maxMemoryIncreasePct": null,
                            "maxCPUIncreasePct": null,
                            "maxLatencyIncreasePct": 0
                        }
                    },
                    "enableVerticalScaling": {
                        "updatedUser": "Sreejith narayanan",
                        "updatedTime": 1697194292225,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true,
                        "minCpu": null,
                        "minMemory": null
                    },
                    "enableHorizontalScaling": {
                        "updatedUser": "Sreejith narayanan",
                        "updatedTime": 1697194292225,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true,
                        "minReplicas": 2,
                        "maxReplicas": null,
                        "replicaIncrement": null
                    },
                    "enablePredictiveScaling": {
                        "updatedUser": "Sreejith narayanan",
                        "updatedTime": 1697194292225,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "enableServiceAutoscalingConfiguration": {
                        "updatedUser": "Sreejith narayanan",
                        "updatedTime": 1697194292225,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "autonomousActionWithoutTraffic": {
                        "updatedUser": "Sreejith narayanan",
                        "updatedTime": 1697194292225,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "isProd": {
                        "updatedUser": "Sreejith narayanan",
                        "updatedTime": 1697194292225,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true
                    }
                },
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Sreejith narayanan",
                            "updatedTime": 1697194292225,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [
                    "SERVERLESS_FUNCTION",
                    "APP"
                ],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1697194292263,
            "updatedTime": 1701689485226,
            "createdUser": "Sreejith narayanan",
            "updatedUser": "Tapan Manu",
            "providerAccountId": "072125767554",
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "kglftnmo",
            "name": "AWS-test2",
            "accountDetails": {
                "cloudProvider": "AWS",
                "credentialsDetail": {
                    "id": "00f9520a-4dc2-49ca-ba7f-354f36d93df7",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWbQkRcXcLMyCDfwaW0IZApJDR1kKhZngLWL6ewoA6hguZAYl3DShhwBgD+MmYMtdoeAOO5UTI2/c6Ixpokm7cdDgtP88Xif2WVOiI8aSrEYh",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENTLESS",
                "encryptionKey": null,
                "userSelectedManagedServices": null,
                "enabled": false
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "snt(API Key)",
                    "updatedTime": 1698054448419,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "snt(API Key)",
                    "updatedTime": 1698054448419,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "snt(API Key)",
                    "updatedTime": 1698054448419,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": {
                    "optimization": {
                        "type": "ServerlessOptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "snt(API Key)",
                            "updatedTime": 1698054448419,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        },
                        "optimizationFocus": {
                            "type": "ServerlessOptimizationFocusItem",
                            "updatedUser": "snt(API Key)",
                            "updatedTime": 1698054448419,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "focus": "COST_AND_DURATION",
                            "autoOptMaxCostChangePct": null,
                            "autoOptMaxLatencyChangePct": null
                        },
                        "provisionedConcurrencyOptimization": {
                            "updatedUser": "snt(API Key)",
                            "updatedTime": 1698054448419,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        },
                        "autonomousConcurrency": {
                            "updatedUser": "snt(API Key)",
                            "updatedTime": 1698054448419,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        },
                        "telemetryLogging": {
                            "updatedUser": "snt(API Key)",
                            "updatedTime": 1698054448419,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        }
                    }
                },
                "kubeSpecificDetail": null,
                "ecsSpecificDetail": {
                    "optimization": {
                        "type": "ECSOptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "snt(API Key)",
                            "updatedTime": 1698054448419,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "MANUAL"
                        },
                        "optimizationFocus": {
                            "type": "ECSOptimizationFocusItem",
                            "updatedUser": "snt(API Key)",
                            "updatedTime": 1698054448419,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "focus": "COST",
                            "maxMemoryIncreasePct": null,
                            "maxCPUIncreasePct": null,
                            "maxLatencyIncreasePct": 0
                        }
                    },
                    "enableVerticalScaling": {
                        "updatedUser": "snt(API Key)",
                        "updatedTime": 1698054448419,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true,
                        "minCpu": null,
                        "minMemory": null
                    },
                    "enableHorizontalScaling": {
                        "updatedUser": "snt(API Key)",
                        "updatedTime": 1698054448419,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true,
                        "minReplicas": 2,
                        "maxReplicas": null,
                        "replicaIncrement": null
                    },
                    "enablePredictiveScaling": {
                        "updatedUser": "snt(API Key)",
                        "updatedTime": 1698054448419,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "enableServiceAutoscalingConfiguration": {
                        "updatedUser": "snt(API Key)",
                        "updatedTime": 1698054448419,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "autonomousActionWithoutTraffic": {
                        "updatedUser": "snt(API Key)",
                        "updatedTime": 1698760958643,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "isProd": {
                        "updatedUser": "snt(API Key)",
                        "updatedTime": 1698674123029,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    }
                },
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "snt(API Key)",
                            "updatedTime": 1698054448419,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [
                    "SERVERLESS_FUNCTION",
                    "APP"
                ],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1698054448431,
            "updatedTime": 1701689496992,
            "createdUser": "snt(API Key)",
            "updatedUser": "Tapan Manu",
            "providerAccountId": null,
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "sgthtror",
            "name": "VM dummyAccount",
            "accountDetails": {
                "cloudProvider": "CUSTOM",
                "credentialsDetail": {
                    "id": "fe1446bc-5277-4d97-8b3d-da91a59ee955",
                    "externalCredentialsId": null,
                    "credentials": null,
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENTLESS",
                "encryptionKey": null,
                "userSelectedManagedServices": null,
                "enabled": false
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "Monica Poovizhi",
                    "updatedTime": 1701233080069,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "Monica Poovizhi",
                    "updatedTime": 1701233080069,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "Monica Poovizhi",
                    "updatedTime": 1701233080069,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": null,
                "ecsSpecificDetail": null,
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Monica Poovizhi",
                            "updatedTime": 1701233080069,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1701233080135,
            "updatedTime": 1701686946638,
            "createdUser": "Monica Poovizhi",
            "updatedUser": "Tapan Manu",
            "providerAccountId": "sgthtror",
            "credentialsStore": "INTERNAL",
            "dummyAccount": true
        },
        {
            "id": "3mnqkd7k",
            "name": "Integration-EKS",
            "accountDetails": {
                "cloudProvider": "KUBERNETES",
                "credentialsDetail": {
                    "id": "c8ecd55f-ceff-45d1-9da0-d5431393fd2e",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWbQkRcXcLMyCDfwaW0IZApK5j1Gx6B/XUmcVUxkgl1Sh",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENT_BASED",
                "encryptionKey": "WIctDQmktvaDPC50X5stJ3WDO6ajIg2/5uyyq2e+6LwUYqeueLjXEDfwt7XIfhqw",
                "metadata": {
                    "clusterUrl": null,
                    "caCertData": null,
                    "clusterName": "Integration-EKS",
                    "clusterProvider": "SELF_MANAGED"
                },
                "userSelectedManagedServices": null,
                "enabled": true
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "Sreejith narayanan",
                    "updatedTime": 1688021993740,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "Sreejith narayanan",
                    "updatedTime": 1688021993740,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "Sreejith narayanan",
                    "updatedTime": 1688021993740,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": {
                    "optimization": {
                        "type": "KubernetesOptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Sreejith narayanan",
                            "updatedTime": 1688021993740,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        },
                        "optimizationFocus": {
                            "type": "KubernetesOptimizationFocusItem",
                            "updatedUser": "Pooja Malik",
                            "updatedTime": 1689977805720,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "focus": "COST",
                            "maxMemoryIncreasePct": null,
                            "maxCPUIncreasePct": null,
                            "maxLatencyIncreasePct": 0
                        }
                    },
                    "enableVerticalScaling": {
                        "updatedUser": "Sreejith narayanan",
                        "updatedTime": 1688021993740,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "enableHorizontalScaling": {
                        "horizontalScalingConfig": {
                            "updatedUser": "Sreejith narayanan",
                            "updatedTime": 1688021993740,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "status": false
                        },
                        "minReplicas": null,
                        "maxReplicas": null,
                        "replicaMultiplier": null,
                        "horizontalScalingConfigMode": false
                    },
                    "enablePredictiveScaling": {
                        "updatedUser": "Sreejith narayanan",
                        "updatedTime": 1688021993740,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": false
                    },
                    "autonomousActionWithoutTraffic": null,
                    "isProd": {
                        "updatedUser": "Sreejith narayanan",
                        "updatedTime": 1688021993740,
                        "scope": "ACCOUNT_DEFAULT",
                        "softDeleted": false,
                        "status": true
                    }
                },
                "ecsSpecificDetail": null,
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Sreejith narayanan",
                            "updatedTime": 1688021993740,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [
                    "APP"
                ],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1688021994837,
            "updatedTime": 1694542493439,
            "createdUser": "Sreejith narayanan",
            "updatedUser": "Pooja Malik",
            "providerAccountId": "3mnqkd7k",
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        },
        {
            "id": "blcxlidc",
            "name": "Azure",
            "accountDetails": {
                "cloudProvider": "AZURE",
                "credentialsDetail": {
                    "id": "9d4a52ca-e395-4c38-a7f3-9139cb692c1e",
                    "externalCredentialsId": null,
                    "credentials": "rC0RQZ8stQsW9knzy5zKWfmXV7ePqsgb9CZ5PHgNfPNGyPo9doXF4BJxbOdwYWOfGC0qzOAqctVhIjVnw04TgeSbd14P6j4qeAPVNQ79wO5AkK+34l0kAGUYT2Wh28mHFStZ64h32IpUww89DaQty9W5lhAmnDwJyK8XohrgP5kK2DohMzGazbkclIFELy8QjFbuS7L/Rmsnasxta9sHuQ==",
                    "credentialsStore": "INTERNAL"
                },
                "integrationType": "AGENTLESS",
                "encryptionKey": null,
                "subscriptionId": "abb3c293-f595-4468-843d-82f49d0cd956",
                "tenantId": "5bff8b06-5db8-4c9c-976e-a18993eb699a",
                "userSelectedManagedServices": null,
                "enabled": true
            },
            "defaultResourceConfig": {
                "type": "CompositeResourceConfigDetail",
                "availability": {
                    "updatedUser": "Aby Jacob",
                    "updatedTime": 1701250786465,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "AVAILABILITY",
                    "configMode": "MANUAL"
                },
                "slo": {
                    "updatedUser": "Aby Jacob",
                    "updatedTime": 1701250786465,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "SLO",
                    "configMode": "AUTO"
                },
                "releaseIntelligence": {
                    "updatedUser": "Aby Jacob",
                    "updatedTime": 1701250786465,
                    "scope": "ACCOUNT_DEFAULT",
                    "softDeleted": false,
                    "configCategory": "RELEASE_INTELLIGENCE",
                    "configMode": "MANUAL"
                },
                "serverlessSpecificDetail": null,
                "kubeSpecificDetail": null,
                "ecsSpecificDetail": null,
                "appSpecificDetail": {
                    "optimization": {
                        "type": "OptimizationResourceConfigCategoryDetail",
                        "optimizationConfig": {
                            "updatedUser": "Aby Jacob",
                            "updatedTime": 1701250786465,
                            "scope": "ACCOUNT_DEFAULT",
                            "softDeleted": false,
                            "configCategory": "OPTIMIZATION",
                            "configMode": "AUTO"
                        }
                    }
                },
                "supportedResourceTypes": [],
                "optimization": null,
                "optimizationCategoryConfigMode": null
            },
            "createdTime": 1701250786566,
            "updatedTime": 1701250786566,
            "createdUser": "Aby Jacob",
            "updatedUser": "Aby Jacob",
            "providerAccountId": "blcxlidc",
            "credentialsStore": "INTERNAL",
            "dummyAccount": false
        }
    ],
    "host": "sedai-test-api-worker-0.sedai-test-api-service-worker.sedai-test.svc.cluster.local",
    "requestTime": 1704409881687,
    "timeTakenInMillis": 0,
    "errorCode": null
}
"""
import json

data = json.loads(data)

fields = {
    "result.id": "account.id",
    "result.name": "account.name",
    "result.zips": "account.zips"
}


# keys = list(fields.keys())
# names = list(fields.values())

# def nest_keys(keys):
#     nested = {}
#     for key in keys:
#         parts = key.split('.')
#         if len(parts) == 1:
#             nested[key] = None
#         else:
#             key = parts[0]
#             value = nest_keys(['.'.join(parts[1:])])
#             if key in nested:
#                 nested[key].update(value)
#             else:
#                 nested[key] = value
#     return nested

# key_map = nest_keys(keys)
# names_map = nest_keys(names)

# def transform(obj, key_map):
#     if type(obj) is list:
#         for item in obj:
#             transform(item, key_map)
#     elif type(obj) is dict:
#         # remove all keys that are not in the key_map
#         for key in list(obj.keys()):
#             if key not in key_map:
#                 del obj[key]
#             else:
#                 transform(obj[key], key_map[key])

#     return obj

# data = transform(data, key_map)

# # # rename from keys to names
# # def rename(obj, names_map, key_map):
# #     if type(obj) is list:
# #         for item in obj:
# #             rename(item, names_map, key_map)
# #     elif type(obj) is dict:
# #         for key in list(obj.keys()):
# #             if key in key_map:
# #                 obj[names_map[key]] = obj.pop(key)
# #             rename(obj[key], names_map[key], key_map[key])

# #     return obj

# # data = rename(data, names_map, key_map)
# data


# nested iteration through object 
# and print the key as a path
def print_keys(obj, path=''):
    if type(obj) is list:
        for item in obj:
            print_keys(item, path)
    elif type(obj) is dict:
        for key in obj.keys():
            if path == '':
                print_keys(obj[key], key)
            else:
                print_keys(obj[key], path + '.' + key)

    else:
        print(path, fields[path] if path in fields else None)


data

# %%

from types import SimpleNamespace

dat = '{"name": "John Smith", "hometown": {"name": "New York", "id": 123}}'
dat = json.loads(dat)
dat = {"a": {"b": [1, 2, 3]}}
x = SimpleNamespace(**dat)


# %%

def transform(obj, keys):
    key_map = __nest_keys(keys)
    model = __transform(obj, key_map)
    # return __to_model(model)
    return model


# From https://stackoverflow.com/a/72778143
def __to_model(d):
    # If d is a list, apply __to_model to each element of the list
    if isinstance(d, list):
        return [__to_model(x) for x in d]
    # if d is a  simple type, return it
    if not isinstance(d, dict):
        return d
    # If d is a dict, apply __to_model to each value of the dict
    x = SimpleNamespace()
    _ = [setattr(x, k,
                 __to_model(v) if isinstance(v, dict)
                 else [__to_model(e) for e in v] if isinstance(v, list)
                 else v) for k, v in d.items()]
    return x


def __nest_keys(keys):
    nested = {}
    for key in keys:
        parts = key.split('.')
        if len(parts) == 1:
            nested[key] = None
        else:
            key = parts[0]
            value = __nest_keys(['.'.join(parts[1:])])
            if key in nested:
                nested[key].update(value)
            else:
                nested[key] = value
    return nested


def __transform(obj, key_map):
    if type(obj) is list:
        for item in obj:
            __transform(item, key_map)
    elif type(obj) is dict:
        # remove all keys that are not in the key_map
        for key in list(obj.keys()):
            if key not in key_map:
                del obj[key]
            else:
                __transform(obj[key], key_map[key])

    return obj


keys = [
    "id",
    "name",
    "accountDetails.cloudProvider",
    "accountDetails.integrationType",
    "accountDetails.userSelectedManagedServices",
]
data = """[
{
                "userSelectedManagedServices": [
                    [
                        "GcpManagedService",
                        "GKE"
                    ]
                ],
            }
            ]
"""
data = json.loads(data)
transform(data, keys)


# %%


def __to_model(d):
    # If d is a list, apply __to_model to each element of the list
    if isinstance(d, list):
        return [__to_model(x) for x in d]
    # if d is a  simple type, return it
    if not isinstance(d, dict):
        return d
    # If d is a dict, apply __to_model to each value of the dict
    x = SimpleNamespace()
    _ = [setattr(x, k,
                 __to_model(v) if isinstance(v, dict)
                 else [__to_model(e) for e in v] if isinstance(v, list)
                 else v) for k, v in d.items()]
    return x


sd = __to_model(data)

# %%
sd.__dict__

# %%
sd.to_json = lambda: print(sd)
sd.to_json()

# %%
a = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]
a.tst = lambda: print(a)
a.tst()
