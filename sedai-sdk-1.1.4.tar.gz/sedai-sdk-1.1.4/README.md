# For Development:

- Checkout the code
- Open the project in pycharm
- From command line, run (don't ignore the leading dot)

	. ./setup_dev.sh

- For viewing the docs: 

  	pdoc --no-show-source sedai


- Create file `test/.env` and add:

  	SEDAI_API_TOKEN=<TEST_API_TOKEN>
  	SEDAI_BASE_URL=https://test.sedai.cloud

- Run the tests and generate coverage report in `test/test_report/index.html`

  	cd test
  	pytest --cov-report term-missing  --cov-report html:test_report --cov=sedai .

