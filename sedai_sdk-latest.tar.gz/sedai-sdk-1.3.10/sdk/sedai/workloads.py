import math
from typing import List, Optional, Dict

from sedai.__impl import api, log
from sedai.__impl.pagination import PaginatedResponse
from sedai.pagination import PaginationConfig, PageIterator, DEFAULT_PAGINATION_CONFIG


class KubernetesContainerSpec:
    """This class represents a specification for a container in a Kubernetes workload."""
    name: str
    """    
    Name of the container.
    """
    image:  str
    """    
    Image used for the container.
    """
    cpu_limit:  Optional[str] = None
    """
    CPU limit for the container.
    """
    cpu_request:  Optional[str] = None
    """
    CPU request for the container.
    """
    memory_limit_bytes:  Optional[int] = None
    """
    Memory limit for the container in bytes.
    """
    memory_request_bytes:  Optional[int] = None
    """
    Memory request for the container in bytes.
    """

    def __init__(
            self,
            name: str,
            image: str,
            cpu_limit: Optional[str] = None,
            cpu_request: Optional[str] = None,
            memory_limit_bytes: Optional[int] = None,
            memory_request_bytes: Optional[int] = None
    ):
            """@private"""
            self.name = name
            self.image = image
            self.cpu_limit = cpu_limit
            self.cpu_request = cpu_request
            self.memory_limit_bytes = memory_limit_bytes
            self.memory_request_bytes = memory_request_bytes


class SedaiKubeWorkload:
    """
    Represents the base class for all Kubernetes workloads in Sedai.

    This class defines the common attributes and behavior shared across different types
    of Kubernetes workloads, such as name, namespace, cluster details, and container specifications.

    It serves as the foundation for more specialized workload classes, such as
    `SedaiScalableKubeWorkload`, which extends this class to include scalability-related fields
    like replica counts, labels, and annotations.
    """

    name: str
    """
    Name of the Kubernetes workload.
    """
    inference_type: str
    """
    Type of kubernetes workload.
    """
    namespace:  str
    """
    Namespace in which the workload is deployed.
    """
    cluster_name: str
    """
    Name of the Kubernetes cluster.
    """
    instance_ids: Optional[list[str]] = None
    """
    List of instance IDs associated with the workload.
    """
    load_balancer_ids: Optional[list[str]] = None
    """
    List of load balancer IDs associated with the workload.
    """
    node_id_vs_replica_count: Optional[dict[str, int]] = None
    """
    Mapping node IDs to the number of replicas running on each node.
    """
    container_specs: Optional[List[KubernetesContainerSpec]] = None
    """
    List of container specifications for the workload.
    """
    desired_replicas: Optional[int] = None
    """
    The number of desired replicas for the workload.
    """

    def __init__(
            self,
            name: Optional[str] = None,
            inference_type: Optional[str] = None,
            instance_ids: Optional[List[str]] = None,
            namespace: Optional[str] = None,
            cluster_name: Optional[str] = None,
            load_balancer_ids: Optional[List[str]] = None,
            node_id_vs_replica_count: Optional[dict[str, int]] = None,
            container_specs: Optional[List[KubernetesContainerSpec]] = None,
            desired_replicas: Optional[int] = None
    ):
        """@private"""
        self.name = name
        self.inference_type = inference_type
        self.instance_ids = instance_ids
        self.namespace = namespace
        self.cluster_name = cluster_name
        self.load_balancer_ids = load_balancer_ids
        self.node_id_vs_replica_count = node_id_vs_replica_count
        self.container_specs = container_specs
        self.desired_replicas = desired_replicas


class SedaiScalableKubeWorkload(SedaiKubeWorkload):
    """
    This class represents various scalable Kubernetes workload types,
    including `ReplicationController`, `Deployment`, `ReplicaSet`, `Rollout`, and `StatefulSet`.

    Extends the `SedaiKubeWorkload` base class by adding fields related to scalability,
    such as the number of ready, updated, and available pod replicas. Also includes
    additional metadata like labels and annotations.
    """

    ready_replicas: Optional[int] = None
    """
    Number of pod replicas currently Ready to serve requests.
    """
    updated_replicas: Optional[int] = None
    """
    The number of pod replicas that have been updated to match the latest workload revision.
    """
    available_replicas: Optional[int] = None
    """
    Number of updated pod replicas available to users, not terminating and past minimum ready time.
    """
    labels: Optional[dict[str, int]] = None
    """
    Labels associated with the workload.
    """
    annotations: Optional[dict[str, int]] = None
    """
    Annotations associated with the workload.
    """

    def __init__(
            self,
            ready_replicas: Optional[int] = None,
            updated_replicas: Optional[int] = None,
            available_replicas: Optional[int] = None,
            labels: Optional[dict[str, int]] = None,
            annotations: Optional[dict[str, int]] = None,
            **kwargs
    ):
        """@private"""
        super().__init__(**kwargs)
        self.ready_replicas = ready_replicas
        self.updated_replicas = updated_replicas
        self.available_replicas = available_replicas
        self.labels = labels
        self.annotations = annotations

def get_all_kube_workloads(
        account_id : str,
        namespace: str = None,
        pagination_config: Optional[PaginationConfig] = None,
) -> PageIterator[List[SedaiKubeWorkload]]:

    """
    Returns all Kubernetes workloads for a given account ID.

    :param account_id: The ID of the account for which to fetch workloads.
    :param namespace: Optional namespace to filter workloads. If `None`, all namespaces are considered.
    :param pagination_config: The pagination configuration for fetching kubernetes workload. Refer to `sedai.pagination.PaginationConfig` for more details
        about the available options. If no pagination_config is given it will use the default pagination configuration,
        `sedai.pagination.DEFAULT_PAGINATION_CONFIG`.
    :return: List of `SedaiKubeWorkload` instances, or `None` if no workloads exist.
    """
    log(f"Fetching all Kubernetes workloads for account: {account_id}")

    params = dict()
    if namespace is not None:
        params['namespace'] = namespace

    if pagination_config is None:
        pagination_config = DEFAULT_PAGINATION_CONFIG

    sedai_scalable_kube_workload_types = [
        "KUBERNETES_REPLICATIONCONTROLLER",
        "KUBERNETES_DEPLOYMENT",
        "KUBERNETES_REPLICASET",
        "KUBERNETES_ROLLOUT",
        "KUBERNETES_STATEFULSET"
    ]

    def page_loader(
            params: Dict,
            pagination_config: PaginationConfig
    ) -> PaginatedResponse:

        all_workloads = []
        endpoint = f'/api/site/{account_id}/clusters/apps/paged'

        params = params if params is not None else {}

        if pagination_config.page_size is not None:
            params['pageSize'] = pagination_config.page_size
        if pagination_config.start is not None:
            params['start'] = pagination_config.start - 1  # Convert to 0-based index for API
        else:
            params['start'] = 0
        if pagination_config.order_by is not None:
            params['orderBy'] = pagination_config.order_by
        if pagination_config.order_dir is not None:
            params['orderDir'] = pagination_config.order_dir

        request = api.GetRequest(endpoint, params=params)
        response = api.do_get(request)

        if response['status'] != 'OK':
            log(f"Failed to fetch workloads : {response['message']}")
            raise Exception(f"Failed to fetch workloads : {response['message']}")

        workload_list = response['result']['content']
        if workload_list is None or len(workload_list) == 0:
            log("No workloads found")
            return None

        log(f"Workloads fetched successfully for account: {account_id}")
        for workload in workload_list:
            resource_details = workload.get('resourceDetails', None)
            if resource_details is None:
                log("Resource details are missing in the workload data.", workload['name'])
                continue
            name = resource_details.get('name', None)
            inference_type = resource_details.get('inferenceType', None)
            instance_ids = resource_details.get('instanceIds', [])
            namespace = resource_details.get('namespace', None)
            cluster_name = resource_details.get('clusterName', None)
            load_balancer_ids = resource_details.get('loadBalancerIds', [])
            node_id_vs_replica_count = resource_details.get('nodeIdVsReplicaCount', {})
            desired_replicas = resource_details.get('desiredReplicas', None)

            container_spec = resource_details.get('containerSpecs', [])
            container_spec_list = []
            if container_spec is not None:
                for container in container_spec:
                    container_name = container.get('name', None)
                    image = container.get('image', None)
                    cpu_limit = container.get('cpuLimit', None)
                    cpu_request = container.get('cpuRequest', None)
                    memory_limit = container.get('memoryLimitBytes', None)
                    memory_request = container.get('memoryRequestBytes', None)
                    container_spec_list.append(
                        KubernetesContainerSpec(
                            name=container_name,
                            image=image,
                            cpu_limit=cpu_limit,
                            cpu_request=cpu_request,
                            memory_limit_bytes=memory_limit,
                            memory_request_bytes=memory_request
                        )
                    )

            if inference_type in sedai_scalable_kube_workload_types:
                workload = SedaiScalableKubeWorkload(
                    name=name,
                    inference_type=inference_type,
                    instance_ids=instance_ids,
                    namespace=namespace,
                    cluster_name=cluster_name,
                    load_balancer_ids=load_balancer_ids,
                    node_id_vs_replica_count=node_id_vs_replica_count,
                    container_specs=container_spec_list,
                    desired_replicas=desired_replicas,
                    ready_replicas=resource_details.get('readyReplicas', None),
                    updated_replicas=resource_details.get('updatedReplicas', None),
                    available_replicas=resource_details.get('availableReplcas', None),
                    labels=resource_details.get('labels', {}),
                    annotations=resource_details.get('annotations', {})
                )
            else:
                workload = SedaiKubeWorkload(
                    name=name,
                    inference_type=inference_type,
                    instance_ids=instance_ids,
                    namespace=namespace,
                    cluster_name=cluster_name,
                    load_balancer_ids=load_balancer_ids,
                    node_id_vs_replica_count=node_id_vs_replica_count,
                    desired_replicas=desired_replicas,
                    container_specs=container_spec_list
                )
            all_workloads.append(workload)


        total_pages = response['result']['totalPages']
        next_page = None
        if response['result']['last'] is False:
            next_page = response['result']['number'] + 2

        return PaginatedResponse(
            content=all_workloads,
            total_pages=total_pages,
            next_page= next_page
        )

    return PageIterator(
        params = params,
        page_loader = page_loader,
        page_config=pagination_config
    )





