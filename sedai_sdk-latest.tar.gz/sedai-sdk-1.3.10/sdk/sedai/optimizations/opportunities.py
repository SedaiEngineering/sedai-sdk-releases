from types import SimpleNamespace
from typing import List
from warnings import warn

from sedai.__impl import api, log
from sedai.__impl.model_converter import transform
from sedai.account import search_accounts_by_id
from sedai.optimizations.models import NodegroupDetails
from sedai.optimizations.optimizations import (
    NodegroupOptimization,
    ResourceOptimization,
    _get_resource_optimization_from_opt_obj,
)
from sedai.util import __get_paginated_response

__OPPORTUNITIES_LEVELS = ["account", "cluster"]
__PAGINATION_FIELDS = ['nextPage', 'totalCount']


class ResourceOpportunity:
    """
    Details of potential resource optimization opportunities.
    This may also include opportunities for resources that are set to autonomous.
    """

    account_id: str
    """
    Account ID of the resource for which the optimization was proposed.
    """
    resource_name: str
    """
    Name of the resource for which the optimization was proposed.
    """

    def __init__(self, src: dict):
        """@private"""
        self.src = src
        self.__parse__()

    def __parse__(self):
        self.account_id = self.src.get('accountId', None)
        self.resource_name = self.src.get('resource_name', None)


class ClusterOpportunity(ResourceOpportunity):
    """
    Details of all potential optimization opportunities for a cluster.
    """
    cost_projection_summary: SimpleNamespace
    """
    Summary of the estimated cost projection for this cluster.
    This field is currently deprecated as of 1.3.2 and will be removed in a future version.
    """
    nodegroup_optimization: NodegroupOptimization
    """
    Details of nodegroup optimizations recommended for this cluster.
    """
    workload_optimizations: List[ResourceOptimization]
    """
    Details of workload optimizations recommended for this cluster.
    """
    node_cost_projection_summary : SimpleNamespace
    """
    Summary of the estimated cost projection for this node.
    Contains the following fields:
        - `currentAverageMonthlyCost`: Average monthly cost as per the current configuration.
        - `predictedAverageMonthlyCost`: Average monthly cost as per the predicted configuration.
        - `predictedAverageMonthlySavings`: Average monthly savings as per the predicted configuration.
    """
    workload_cost_projection_summary : SimpleNamespace
    """
    Summary of the estimated cost projection for this workload.
    Contains the following fields:
        - `currentAverageMonthlyCost`: Average monthly cost as per the current configuration.
        - `predictedAverageMonthlyCost`: Average monthly cost as per the predicted configuration.
        - `predictedAverageMonthlySavings`: Average monthly savings as per the predicted configuration.
    """


    def __init__(self, src: dict):
        self.nodegroup_optimization = NodegroupOptimization()
        self.workload_optimizations = []
        super().__init__(src)

    def __parse__(self):
        super().__parse__()

        isV2 = self.src.__contains__('workloadOptimization')

        if isV2:
            node_recommendation = self.src['nodeOptimization']
            workload_recommendation = self.src['workloadOptimization']

            self.report_id = node_recommendation.get('reportId',None)
            self.workload_optimization_id = workload_recommendation.get('workloadOptimizationId',None)

            honoring_node_pool_config = node_recommendation.get('honoringNodepools', None)
            ignoring_node_pool_config =node_recommendation.get('ignoringNodepools',None)

            if honoring_node_pool_config is not None:
                for node in honoring_node_pool_config:
                    current = node['nodeGroupConfiguration']['current']
                    nodegroup_name = node.get('nodeGroupConfiguration',{}).get('nodepoolName', None)
                    instanceType = current.get('instanceType', None)
                    memory_bytes = current.get('totalMemoryCapacity', {}).get('value',None)
                    num_nodes = current.get('desiredNodeCount', None)
                    auto_scaling_config = current.get('autoScalingConfiguration', None)
                    vcpus = current.get('totalCpuCapacity',None)

                    min_num_nodes = None
                    max_num_nodes = None
                    if isinstance(auto_scaling_config, str):
                        min_num_nodes, max_num_nodes = auto_scaling_config.split("-")

                    nodegroup = NodegroupDetails(
                        name=nodegroup_name,
                        instance_type=instanceType,
                        memory_bytes=memory_bytes,
                        vcpus=vcpus,
                        num_nodes=num_nodes,
                        min_num_nodes=min_num_nodes,
                        max_num_nodes=max_num_nodes,
                    )
                    self.nodegroup_optimization.original_nodegroup_config.nodegroups.append(nodegroup)

                    optimal = node['nodeGroupConfiguration']['optimal']
                    optimal_instanceType = optimal.get('instanceType', None)
                    optimal_memory_bytes = optimal.get('totalMemoryCapacity', {}).get('value', None)
                    optimal_num_nodes = optimal.get('desiredNodeCount', None)
                    optimal_auto_scaling_config = optimal.get('autoScalingConfiguration', None)
                    optimal_vcpus = optimal.get('totalCpuCapacity', None)

                    min_num_nodes = None
                    max_num_nodes = None
                    if isinstance(optimal_auto_scaling_config, str):
                        min_num_nodes, max_num_nodes = optimal_auto_scaling_config.split("-")

                    optimal_nodegroup = NodegroupDetails(
                        name=nodegroup_name,
                        instance_type=optimal_instanceType,
                        memory_bytes=optimal_memory_bytes,
                        vcpus=optimal_vcpus,
                        num_nodes=optimal_num_nodes,
                        min_num_nodes=min_num_nodes,
                        max_num_nodes=max_num_nodes,
                    )
                    self.nodegroup_optimization.recommended_nodegroup_config_original.nodegroups.append(
                        optimal_nodegroup
                    )

            if ignoring_node_pool_config is not None:
                for node in ignoring_node_pool_config:
                    optimal = node['nodeGroupConfiguration']['optimal']
                    nodegroup_name = node.get('nodeGroupConfiguration', {}).get('nodepoolName', None)
                    instanceType = optimal.get('instanceType', None)
                    memory_bytes = optimal.get('totalMemoryCapacity', {}).get('value', None)
                    num_nodes = optimal.get('desiredNodeCount', None)
                    auto_scaling_config = optimal.get('autoScalingConfiguration', None)
                    vcpus = optimal.get('totalCpuCapacity', None)

                    min_num_nodes = None
                    max_num_nodes = None
                    if isinstance(auto_scaling_config, str):
                        min_num_nodes, max_num_nodes = auto_scaling_config.split("-")

                    nodegroup = NodegroupDetails(
                        name=nodegroup_name,
                        instance_type=instanceType,
                        memory_bytes=memory_bytes,
                        vcpus=vcpus,
                        num_nodes=num_nodes,
                        min_num_nodes=min_num_nodes,
                        max_num_nodes=max_num_nodes,
                    )
                    self.nodegroup_optimization.recommended_nodegroup_config_optimal.nodegroups.append(
                        nodegroup
                    )
            cost_fields = [
                'currentAverageMonthlyCost',
                'predictedAverageMonthlyCost',
                'predictedAverageMonthlySavings',
            ]

            self.node_cost_projection_summary = transform(node_recommendation, cost_fields)
            self.workload_cost_projection_summary = transform(workload_recommendation, cost_fields)

        else:
            self.report_id = self.src['reportId']

            optimization_recommendations = self.src['optimizationRecommendations']
            self.workload_optimization_id = optimization_recommendations['proposed']['workloads'][
                'workloadOptimizationId'
            ]
            curr_nodegroups_conf = optimization_recommendations['current']
            rec_curr_nodegroups_conf = optimization_recommendations['proposed']['honourNodeGroups']
            rec_ignore_nodegroups_conf = optimization_recommendations['proposed']['ignoreNodeGroups']

            curr_nodegroups = None
            rec_curr_nodegroups = None
            rec_optimal_nodegroups = None

            if curr_nodegroups_conf is not None:
                curr_nodegroups = curr_nodegroups_conf['nodeGroups']

            if rec_curr_nodegroups_conf is not None:
                rec_curr_nodegroups = rec_curr_nodegroups_conf['nodeGroups']

            if rec_ignore_nodegroups_conf is not None:
                rec_optimal_nodegroups = rec_ignore_nodegroups_conf['nodeGroups']

            if curr_nodegroups is not None:
                for ng in curr_nodegroups:
                    nodegroup_name = ng.get('nodeGroupName', None)
                    instanceType = ng.get('instanceType', None)
                    memory_bytes = ng.get('memoryInBytes', None)
                    num_nodes = ng.get('numberOfNodes', None)
                    min_num_nodes = ng.get('minNumOfNodes', None)
                    max_num_nodes = ng.get('maxNumOfNodes', None)

                    vcpus = ng.get('vcpus', None)
                    nodegroup = NodegroupDetails(
                        name=nodegroup_name,
                        instance_type=instanceType,
                        memory_bytes=memory_bytes,
                        vcpus=vcpus,
                        num_nodes=num_nodes,
                        min_num_nodes=min_num_nodes,
                        max_num_nodes=max_num_nodes,
                    )
                    self.nodegroup_optimization.original_nodegroup_config.nodegroups.append(nodegroup)

            if rec_curr_nodegroups is not None:
                for ng in rec_curr_nodegroups:
                    nodegroup_name = ng.get('nodeGroupName', None)
                    instanceType = ng.get('instanceType', None)
                    memory_bytes = ng.get('memoryInBytes', None)
                    vcpus = ng.get('vcpus', None)
                    num_nodes = ng.get('numberOfNodes', None)
                    min_num_nodes = ng.get('minNumOfNodes', None)
                    max_num_nodes = ng.get('maxNumOfNodes', None)

                    nodegroup = NodegroupDetails(
                        name=nodegroup_name,
                        instance_type=instanceType,
                        memory_bytes=memory_bytes,
                        vcpus=vcpus,
                        num_nodes=num_nodes,
                        min_num_nodes=min_num_nodes,
                        max_num_nodes=max_num_nodes,
                    )
                    self.nodegroup_optimization.recommended_nodegroup_config_original.nodegroups.append(
                        nodegroup
                    )

            if rec_optimal_nodegroups is not None:
                for ng in rec_optimal_nodegroups:
                    nodegroup_name = ng.get('nodeGroupName', None)
                    instanceType = ng.get('instanceType', None)
                    memory_bytes = ng.get('memoryInBytes', None)
                    vcpus = ng.get('vcpus', None)
                    num_nodes = ng.get('numberOfNodes', None)
                    min_num_nodes = ng.get('minNumOfNodes', None)
                    max_num_nodes = ng.get('maxNumOfNodes', None)

                    nodegroup = NodegroupDetails(
                        name=nodegroup_name,
                        instance_type=instanceType,
                        memory_bytes=memory_bytes,
                        vcpus=vcpus,
                        num_nodes=num_nodes,
                        min_num_nodes=min_num_nodes,
                        max_num_nodes=max_num_nodes,
                    )
                    self.nodegroup_optimization.recommended_nodegroup_config_optimal.nodegroups.append(
                        nodegroup
                    )

            cost_fields = [
                'currentMonthlyCost',
                'currentAverageMonthlyCost',
                'predictedMonthlyCost.total',
                'predictedAverageMonthlyCost',
                'predictedMonthlySavings',
                'predictedAverageMonthlySavings',
            ]
            self.cost_projection_summary = transform(self.src['costProjectionSummary'], cost_fields)


def get_opportunities(level, id):
    """
    Retrieves recommendations from the Sedai API.\n
    Returns:
        dict: A dictionary containing the recommendation data.
    """
    if level not in __OPPORTUNITIES_LEVELS:
        raise Exception(f"Invalid opportunities level: {level}")

    if level == "account":
        account = search_accounts_by_id(id)
        if len(account) == 0:
            log("Account with id: " + id + " does not exist")
            return False
        request = api.PostRequest(f'/api/cluster/optimization/summarylist', payload={"accountIds": id})

    elif level == "cluster":
        request = api.PostRequest(f'/api/cluster/optimization/summarylist?clusterId={id}', payload={})

    response = api.do_post(request)
    if response['status'] != 'OK':
        log(f"Failed to get opportunities: {response['message']}")
        return None
    else:
        log(f"Successfully got opportunities")
        return response['result']


def get_cluster_opportunities(
    cluster_id: str,
    optimization_targets: List[str] = None,
    include_workload_optimization : bool = None,

) -> ClusterOpportunity:
    """
    Returns details of available optimization opportunities for a cluster.
    :param cluster_id: ID of the cluster to retrieve opportunities for.
    :param optimization_targets: Optimization targets to consider. Possible options are `NODE`, `WORK_LOAD`.
        This field is deprecated as of 1.3.2 and will be removed in a future version.
    :param include_workload_optimization: This param accepts a boolean variable instead of `optimization_targets`.
        When False (default), the API returns independent recommendations:
            `workload_optimizations`: Workload-Level Opportunities (e.g., scaling pods/deployments).
            `nodegroup_optimization`: Node Group-Level Opportunities (e.g., resizing node groups).
        When True, the API returns a Combined Workload + Node Group Opportunity instead, which provides a unified strategy optimizing both together for maximum efficiency.
    :return: Details of potential optimization opportunities for the given cluster.
    """
    cluster_opp_summary = get_opportunities('cluster', cluster_id)
    if not cluster_opp_summary or len(cluster_opp_summary['content']) == 0:
        log(f"No opportunities for cluster {cluster_id}")
        return None
    cluster_type = cluster_opp_summary['content'][0]['clusterType']
    account_id = cluster_opp_summary['content'][0]['accountId']
    cluster_name = cluster_opp_summary['content'][0]['name']

    params = dict()
    params['clusterId'] = cluster_id
    params['type'] = cluster_type

    if optimization_targets is None or (len(optimization_targets) == 0):
        params['includeBothTargets'] = include_workload_optimization
        request = api.GetRequest(
            f'/api/cluster/optimization/cost/v2/{account_id}', params=params, doseq=True
        )
    elif len(optimization_targets) > 0:
        warn(
            "This field is deprecated as of 1.3.2 and will be removed in a future version.",
            DeprecationWarning,
            stacklevel=2,
        )
        params['target'] = optimization_targets
        request = api.GetRequest(
            f'/api/cluster/optimization/cost/{account_id}', params=params, doseq=True
        )
    else:
        return None

    response = api.do_get(request)
    if response['status'] != 'OK' or response['result'] is None:
        log(f"Failed to get opportunities: {response['message']}")
        return None

    log(f"Successfully retrieved opportunities for cluster {cluster_id}")
    opportunities_obj = response['result']

    if optimization_targets is None or len(optimization_targets) == 0:
        if opportunities_obj.get('nodeOptimization',None) is None:
            log(f"No Optimization available for cluster : {cluster_id}")
            return None

    else:
        if opportunities_obj['optimizationRecommendations'] is None:
            log(f"No optimizations available for cluster: {cluster_id}")
            return None

    cluster_opp = ClusterOpportunity(opportunities_obj)
    cluster_opp.account_id = account_id
    cluster_opp.resource_name = cluster_name

    # populate workload optimizations
    params = dict()
    params['clusterOptimizationProjectionReportId'] = cluster_opp.report_id
    endpoint = f'/api/cluster/optimization/cost/{account_id}/{cluster_opp.workload_optimization_id}'

    wl_optimizations = []
    for opts_page in __get_paginated_response(endpoint, params):
        for wl_opt_obj in opts_page:
            original_resource_state = wl_opt_obj['currResourceConfigState']
            recommended_resource_state = wl_opt_obj['recommendedResourceConfigState']
            wl_optimization = _get_resource_optimization_from_opt_obj(
                wl_opt_obj, original_resource_state, recommended_resource_state
            )
            wl_optimizations.append(wl_optimization)
    cluster_opp.workload_optimizations = wl_optimizations
    return cluster_opp
