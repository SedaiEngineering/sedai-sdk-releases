############################################################################################################
# This file contains the classes and methods to parse and serialize the settings of the resources
# The settings are parsed from the JSON response from the API and then serialized back to JSON to be sent to the API
# The classes are used to store the settings of the resources and the methods are used to parse and serialize the settings
import copy

from sedai.__impl import api


# The classes are as follows:
# BaseSettings: This class is the base class for all the settings classes. It contains the common settings for all the resources
# APPSettings: This class contains the settings for the App resource
# ServerlessSettings: This class contains the settings for the Serverless resource
# ContainerAppSettings: This class contains the settings for the Container App resource
# KubeAppSettings: This class contains the settings for the Kubernetes App resource
# ECSAppSettings: This class contains the settings for the ECS App resource
# BucketSettings: This class contains the settings for the Bucket resource
# VolumeSettings: This class contains the settings for the Volume resource

# The type_map dictionary is used to map the resource type to the corresponding settings class
# The Settings class contains the settings for all the resources
# The parse method is used to parse the settings from the JSON response
# The serialize method is used to serialize the settings to JSON to be sent to the API
############################################################################################################


############################################################################################################
# BaseSettings
############################################################################################################
class BaseSettings:
    """
    Base configuration settings for all resources. All resoruces managed by Sedai will have these settings.
    """

    availabilityMode: str
    """
    The availability mode of the resource. This setting determines if Sedai should autonomously manage the availability of the resource.
    Possible values: `OFF`, `MANUAL`, `AUTO`
    
    - `OFF`: Sedai will not manage the availability of the resource.
    - `MANUAL`: Sedai will give recommendations for the availability of the resource, but the user has to manually apply the recommendations.
    - `AUTO`: Sedai will autonomously manage the availability of the resource.
    """
    optimizationMode: str
    """
    The optimization mode of the resource. This setting determines if Sedai should autonomously optimize the resource.
    Possible values: `OFF`, `MANUAL`, `AUTO`
    
    - `OFF`: Sedai will not optimize the resource. This is also referred to as "DataPilot" mode.
    - `MANUAL`: Sedai will give recommendations for the optimization of the resource, but the user has to manually apply the recommendations. 
    This mode is also referred to as "CoPilot" mode. The user has to manually approve the recommendations.
    - `AUTO`: Sedai will autonomously optimize the resource. This is also referred to as "AutoPilot" mode.
    
    """

    releaseIntelligenceMode: str
    """
    The release intelligence mode of the resource. This setting determines if Sedai should autonomously manage the releases of the resource.
    Possible values: `OFF`, `MANUAL`
    
    - `OFF`: Sedai will not monitor and score code and application releases.
    - `MANUAL`: Sedai will monitor and score code and application releases. A release score and a score card will be generated"
    """

    sloMode: str
    """
    Deprecated, Do not use.
    """

    sedaiSyncEnabled: bool
    """
    When Sedai Sync is enabled for a resource, Sedai will automatically sync the resource with the latest configuration.
    """

    def __init__(self, src):
        """@private"""
        self.src = src
        self.__parse__()

    def __parse__(self):
        self.availabilityMode = self.src['availability']['configMode']
        self.sloMode = self.src['slo']['configMode']
        self.releaseIntelligenceMode = self.src['releaseIntelligence']['configMode']
        self.sedaiSyncEnabled = self.src['sedaiSync']['enabled']
        self.optimizationMode = self.src['optimization']['setting']['configMode']

    def __serialize__(self):
        self.src['availability']['configMode'] = self.availabilityMode
        self.src['slo']['configMode'] = self.sloMode
        self.src['releaseIntelligence']['configMode'] = self.releaseIntelligenceMode
        self.src['sedaiSync']['enabled'] = self.sedaiSyncEnabled
        self.src['optimization']['setting']['configMode'] = self.optimizationMode
        return self.src


############################################################################################################
# APPSettings
############################################################################################################
class APPSettings(BaseSettings):
    """
    Settings for all appplication resources managed by Sedai. Applications could be web applictions or microservices behind
    a load balancer or identified by tags or labels. In containerized environments, applications could be workloads running
    in a container, pod, or a service.
    """
    __type = "AppCommonResourceSettingDetail"
    isProd: bool
    """
    Is this resource or application in production. If an application is not a production application, Sedai can
    take more aggressive actions to optimize the application. In aggresive mode, some thresholds are relaxed. Also in 
    non-prod mode, Sedai can act even if certain metrics are not available.
    """

    horizontalScaling_enabled: bool
    """
    Enable horizontal scaling for the application. Horizontal scaling is the process of adding or removing instances of an application to handle the load.
    """
    horizontalScaling_minReplicas: int
    """
    The minimum number of replicas for the application. This is the minimum number of instances that should be running at all times.
    """
    horizontalScaling_maxReplicas: int
    """
    The maximum number of replicas for the application. This is the maximum number of instances that can be running at any given time.
    """

    def __parse__(self):
        super().__parse__()
        self.isProd = self.src['isProd']['enabled']
        self.horizontalScaling_enabled = self.src['enableHorizontalScaling']['enabled']
        self.horizontalScaling_minReplicas = self.src['enableHorizontalScaling']['minReplicas']
        self.horizontalScaling_maxReplicas = self.src['enableHorizontalScaling']['maxReplicas']

    def __serialize__(self):
        super().__serialize__()
        self.src['isProd']['enabled'] = self.isProd
        self.src['enableHorizontalScaling']['enabled'] = self.horizontalScaling_enabled
        self.src['enableHorizontalScaling']['minReplicas'] = self.horizontalScaling_minReplicas
        self.src['enableHorizontalScaling']['maxReplicas'] = self.horizontalScaling_maxReplicas
        return self.src


############################################################################################################
# ServerlessSettings
############################################################################################################
class ServerlessSettings(BaseSettings):
    __type = "ServerlessFunctionResourceSettingDetail"
    optimizationFocus: str
    """
    The optimization focus for the serverless function. The optimization focus determines the goal of the optimization.
    Possible values: `COST`, `DURATION`, `COST_AND_DURATION`
    - `COST`: Optimize the cost of the function.
    - `DURATION`: Optimize the duration of the function.
    - `COST_AND_DURATION`: Optimize both the cost and duration of the function. 
    """
    optimization_concurrencyMode: str
    """
    Should Sedai optimize the concurrency of the function. 
    Possible values: `OFF`, `MANUAL`, `AUTO`
    - `OFF`: Sedai will not optimize the concurrency of the function.
    - `MANUAL`: Sedai will give recommendations for the concurrency of the function, but the user has to manually apply the recommendations.
    - `AUTO`: Sedai will autonomously optimize the concurrency of the function.
    
    When set to `AUTO`. The actuak course of action will be determined wether the Lambda is a versioned or unversioned function.
    For versioned functions, Sedai will manage concurrecy by managing the provisioned concurrency. 
    For unversioned functions, Sedai will add an extenstion to the Lambda and use it to manage the cold starts.
    
    """
    optimization_maxCostChangePercentage: int
    """
    When Sedai is optimizing for performance, what is the maximum percentage change in cost that is acceptable.
    """
    optimization_maxLatencyChangePercentage: int
    """
    When Sedai is optimizing for cost, what is the maximum percentage change in latency that is acceptable.
    """
    telemetryLoggingEnabled: bool
    """
    Do not use. This setting is deprecated.
    """

    def __parse__(self):
        super().__parse__()
        self.optimizationFocus = self.src['optimization']['optimizationFocus']['focus']
        self.optimization_maxLatencyChangePercentage = self.src['optimization']['optimizationFocus'][
            'autoOptMaxLatencyChangePct']
        self.optimization_maxCostChangePercentage = self.src['optimization']['optimizationFocus'][
            'autoOptMaxCostChangePct']
        self.optimization_concurrencyMode = self.src['optimization']['concurrency']['configMode']
        self.telemetryLoggingEnabled = self.src['telemetryLogging']['enabled']

    def __serialize__(self):
        super().__serialize__()
        self.src['optimization']['optimizationFocus']['focus'] = self.optimizationFocus
        self.src['optimization']['concurrency']['configMode'] = self.optimization_concurrencyMode
        self.src['optimization']['optimizationFocus'][
            'autoOptMaxLatencyChangePct'] = self.optimization_maxLatencyChangePercentage
        self.src['optimization']['optimizationFocus'][
            'autoOptMaxCostChangePct'] = self.optimization_maxCostChangePercentage
        self.src['telemetryLogging']['enabled'] = self.telemetryLoggingEnabled
        return self.src


############################################################################################################
# ContainerAppSettings
############################################################################################################
class ContainerAppSettings(APPSettings):
    """
    Common settings for all containerized applications. Containerized applications could be running in a container, pod, or a service.
    """
    autonomousActionWithoutTraffic: bool
    """
    If an application is marked as not in production (with `isProd` set to false), , Sedai can take more aggressive
     actions to optimize the application even if performance or traffic metrics are not available.
    """

    optimization_Focus: str
    """
    The optimization focus for the containerized application. The optimization focus determines the goal of the optimization.
    Possible values: `COST`, `DURATION`, `COST_AND_DURATION`
    - `COST`: Optimize the cost of the application.
    - `DURATION`: Optimize the duration of the application.
    - `COST_AND_DURATION`: Optimize both the cost and duration of the application.
    
    """

    optimization_maxLatencyIncreasePct: int
    """
    When Sedai is optimizing for cost, what is the maximum percentage increase in latency that is acceptable.
    """
    optimization_maxCPUIncreasePct: int
    """
    When Sedai is optimizing for performance, what is the maximum percentage increase in CPU that is acceptable.
    """
    optimization_maxMemoryIncreasePct: int
    """
    When Sedai is optimizing for performance, what is the maximum percentage increase in memory that is acceptable.
    """

    verticalScaling_enabled: bool
    """
    Enable vertical scaling for the application. Vertical scaling is the process of increasing or decreasing the resources of an instance of an application.
    """
    predictiveScaling_enabled: bool
    """
    Enable predictive scaling for the application. Predictive scaling is the process of predicting the load, performance
    and resource requirements of an application based on the application's seasonalit models and scaling the
    resources accordingly.
    """

    def __parse__(self):
        super().__parse__()
        self.verticalScaling_enabled = self.src['enableVerticalScaling']['enabled']
        self.predictiveScaling_enabled = self.src['enablePredictiveScaling']['enabled']
        self.autonomousActionWithoutTraffic = self.src['autonomousActionWithoutTraffic']['enabled']
        self.optimization_Focus = self.src['optimization']['optimizationFocus']['focus']
        self.optimization_maxMemoryIncreasePct = self.src['optimization']['optimizationFocus']['maxMemoryIncreasePct']
        self.optimization_maxCPUIncreasePct = self.src['optimization']['optimizationFocus']['maxCPUIncreasePct']
        self.optimization_maxLatencyIncreasePct = self.src['optimization']['optimizationFocus']['maxLatencyIncreasePct']

    def __serialize__(self):
        super().__serialize__()
        self.src['enableVerticalScaling']['enabled'] = self.verticalScaling_enabled
        self.src['enablePredictiveScaling']['enabled'] = self.predictiveScaling_enabled
        self.src['autonomousActionWithoutTraffic']['enabled'] = self.autonomousActionWithoutTraffic
        self.src['optimization']['optimizationFocus']['focus'] = self.optimization_Focus
        self.src['optimization']['optimizationFocus']['maxMemoryIncreasePct'] = self.optimization_maxMemoryIncreasePct
        self.src['optimization']['optimizationFocus']['maxCPUIncreasePct'] = self.optimization_maxCPUIncreasePct
        self.src['optimization']['optimizationFocus']['maxLatencyIncreasePct'] = self.optimization_maxLatencyIncreasePct
        return self.src


############################################################################################################
# KubeAppSettings
############################################################################################################
class KubeAppSettings(ContainerAppSettings):
    """
    Settings for all Kubernetes applications managed by Sedai. Kubernetes applications are containerized applications
    running in a Kubernetes cluster. This could be a pod, deployment, or a service such as a deployment, statefulset, or daemonset.
    """
    __type = "KubernetesAppResourceSettingDetail"
    isOperationAllowed: bool
    """
    Is the operation allowed for the Kubernetes application. If the operation is not allowed, Sedai will not be able to
    take any actions on the application."""
    horizontalScaling_replicaMultiplier: int
    """
    The replica multiplier for the Kubernetes application. The replica multiplier is the factor by which the number of
    replicas of the application should be multiplied to handle the load."""

    verticalScaling_minPerContainerCpuInCores: float
    """
    The minimum CPU required per container in the Kubernetes application. This is the minimum amount of CPU that should be allocated to each container."""
    """
    verticalScaling_minPerContainerMemoryInBytes: float
    The minimum memory required per container in the Kubernetes application. This is the minimum amount of memory that should be allocated to each container.
    """

    def __parse__(self):
        super().__parse__()
        self.isOperationAllowed = self.src['isOperationAllowed']['enabled']
        self.horizontalScaling_replicaMultiplier = self.src['enableHorizontalScaling']['replicaMultiplier']
        self.verticalScaling_minPerContainerCpuInCores = self.src['enableVerticalScaling']['minPerContainerCpuInCores']
        self.verticalScaling_minPerContainerMemoryInBytes = self.src['enableVerticalScaling'][
            'minPerContainerMemoryInBytes']

    def __serialize__(self):
        super().__serialize__()
        self.src['isOperationAllowed']['enabled'] = self.isOperationAllowed
        self.src['replicaMultiplier'] = self.horizontalScaling_replicaMultiplier
        self.src['enableVerticalScaling']['minPerContainerCpuInCores'] = self.verticalScaling_minPerContainerCpuInCores
        self.src['enableVerticalScaling'][
            'minPerContainerMemoryInBytes'] = self.verticalScaling_minPerContainerMemoryInBytes
        return self.src


############################################################################################################
# ECSAppSettings
############################################################################################################
class ECSAppSettings(ContainerAppSettings):
    """
    Settings for all ECS applications managed by Sedai. ECS applications are containerized applications running in an ECS cluster.
    This could be a task, service, or a container running in an ECS cluster.
    """
    __type = "ECSAppResourceSettingDetail"
    serviceAutoscalingEnabled: bool
    """
    Enable service autoscaling for the ECS application. Service autoscaling is the process of automatically scaling the
    resources of the service based on the load and performance metrics of the service.
    """
    verticalScaling_minCpu: float
    """
    The minimum CPU required for the ECS application. This is the minimum amount of CPU that should be allocated to the application.
    """
    verticalScaling_minMemory: float
    """
    The minimum memory required for the ECS application. This is the minimum amount of memory that should be allocated to the application.
    """

    def __parse__(self):
        super().__parse__()
        self.serviceAutoscalingEnabled = self.src['enableServiceAutoscalingConfiguration']['enabled']
        self.verticalScaling_minCpu = self.src['enableVerticalScaling']['minCpu']
        self.verticalScaling_minMemory = self.src['enableVerticalScaling']['minMemory']

    def __serialize__(self):
        super().__serialize__()
        self.src['enableServiceAutoscalingConfiguration']['enabled'] = self.serviceAutoscalingEnabled
        self.src['enableVerticalScaling']['minCpu'] = self.verticalScaling_minCpu
        self.src['enableVerticalScaling']['minMemory'] = self.verticalScaling_minMemory
        return self.src


############################################################################################################
# BucketSettings
############################################################################################################
class BucketSettings(BaseSettings):
    """
    Settings for all storage buckets managed by Sedai. Storage buckets are used to store self.src and files in the cloud.
    """
    __type = "StorageBucketeResourceSettingDetail"

    def __parse__(self):
        super().__parse__()

    def __serialize__(self):
        super().__serialize__()
        return self.src


class VolumeSettings(BaseSettings):
    """
    Settings for all storage volumes managed by Sedai. Storage volumes are used to store self.src and files in the cloud.
    """
    __type = "StorageVolumeResourceSettingDetail"

    def __parse__(self):
        super().__parse__()

    def __serialize__(self):
        super().__serialize__()
        return self.src


type_map = {
    "AppCommonResourceSettingDetail": APPSettings,
    "ServerlessFunctionResourceSettingDetail": ServerlessSettings,
    "KubernetesAppResourceSettingDetail": KubeAppSettings,
    "ECSAppResourceSettingDetail": ECSAppSettings,
    "StorageBucketeResourceSettingDetail": BucketSettings,
    "StorageVolumeResourceSettingDetail": VolumeSettings
}
"""
@private
"""


############################################################################################################
# Settings
############################################################################################################
class Settings:
    """
    Settings for all resources managed by Sedai. This setting configuration is for a set of resources, grouped
    either in a group in Sedai or at the level of the account or cluster.
    """
    app_settings: APPSettings
    """
    The settings for all application resources.
    """
    serverless_settings: ServerlessSettings
    """
    The settings for all serverless resources.
    """
    kube_app_settings: KubeAppSettings
    """
    The settings for all Kubernetes application resources.
    """
    ecs_app_settings: ECSAppSettings
    """
    The settings for all ECS application resources.
    """
    bucket_settings: BucketSettings
    """
    The settings for all storage bucket resources.
    """
    volume_settings: VolumeSettings
    """
    The settings for all storage volume resources.
    """

    def __init__(self, src):
        """
        @private
        """
        self.src = src
        self.__parse__()

    def __parse__(self):
        """
        @private
        """
        for key, value in self.src.items():
            if key == "appCommonSettings":
                self.app_settings = APPSettings(value)
                self.app_settings.__parse__()
            elif key == "serverlessSettings":
                self.serverless_settings = ServerlessSettings(value)
                self.serverless_settings.__parse__()
            elif key == "kubeSettings":
                self.kube_app_settings = KubeAppSettings(value)
                self.kube_app_settings.__parse__()
            elif key == "ecsSettings":
                self.ecs_app_settings = ECSAppSettings(value)
                self.ecs_app_settings.__parse__()
            elif key == "bucketSettings":
                self.bucket_settings = BucketSettings(value)
                self.bucket_settings.__parse__()
            elif key == "volumeSettings":
                self.volume_settings = VolumeSettings(value)
                self.volume_settings.__parse__()

    def __serialize__(self):
        """
        @private
        """
        __src = copy.deepcopy(self.src)
        for key, value in __src.items():
            if key == "appCommonSettings":
                __merge_dict_recursive__(__src[key], self.app_settings.__serialize__())
            elif key == "serverlessSettings":
                __merge_dict_recursive__(__src[key], self.serverless_settings.__serialize__())
            elif key == "kubeSettings":
                __merge_dict_recursive__(__src[key], self.kube_app_settings.__serialize__())
            elif key == "ecsSettings":
                __merge_dict_recursive__(__src[key], self.ecs_app_settings.__serialize__())
            elif key == "bucketSettings":
                __merge_dict_recursive__(__src[key], self.bucket_settings.__serialize__())
            elif key == "volumeSettings":
                __merge_dict_recursive__(__src[key], self.volume_settings.__serialize__())

        return __src


def __merge_dict_recursive__(dict1, dict2):
    for key, value in dict2.items():
        if key in dict1:
            if isinstance(value, dict):
                __merge_dict_recursive__(dict1[key], value)
            else:
                dict1[key] = value
        else:
            dict1[key] = value


############################################################################################################
# Managing resource, group and account settings
############################################################################################################

def get_resource_settings(resource_id):
    """
    Get the settings for a resource with the given resource ID.
    The returned settings object will be of the appropriate type based on the type of the resource.

    :param resource_id: The ID of the resource.
    :return: The settings for the resource.
    """
    request = api.GetRequest('/api/settingsV2/topology/configs/resource', params={'resourceId': resource_id})
    response = api.do_get(request)
    settings_json = response['result']['attributes']['setting']
    type = settings_json['type']
    setting_obj = type_map[type](settings_json)
    setting_obj.__parse__()
    return setting_obj


def update_resource_settings(resource_id, settings):
    """
    Update the settings for a resource with the given resource ID.
    The settings object should be of the appropriate type based on the type of the resource.

    :param resource_id: The ID of the resource.
    :param settings: The settings for the resource.
    :return: True if the settings were updated successfully, False otherwise.
    :raises: Exception if the settings could not be updated.

    """
    payload = {
        'resourceId': resource_id,
        'setting': settings.__serialize__(),
        'overriden': True
    }
    request = api.PostRequest('/api/settingsV2/topology/configs/resource', payload=payload)
    response = api.do_post(request)
    if response['status'] != 'OK':
        raise Exception(f"Failed to update resource settings: {response['message']}")
    return True


def get_group_settings(group_id):
    """
    Get the settings for a group with the given group ID.
    :param group_id: The ID of the group.
    :return: A settings object containing the settings for the group.
    """
    try:
        request = api.GetRequest('/api/settingsV2/topology/configs/group', params={'groupId': group_id})
        response = api.do_get(request)
        settings_json = response['result']['setting']
        setting_obj = Settings(settings_json)
        setting_obj.__parse__()
        return setting_obj
    except Exception as e:
        raise Exception(f"Failed to get group settings; you may have to initialize the group settings first: {e}")


def update_group_settings(group_id, settings):
    """
    Update the settings for a group with the given group ID.
    :param group_id: The ID of the group.
    :param settings: The settings for the group.
    :return: True if the settings were updated successfully, False otherwise.
    :raises: Exception if the settings could not be updated.
    """
    payload = settings.__serialize__()

    request = api.PostRequest(f'/api/settingsV2/topology/configs/group/{group_id}', payload=payload)
    response = api.do_post(request)
    if response['status'] != 'OK':
        raise Exception(f"Failed to update group settings: {response['message']}")
    return True


def initialize_group_settings(group_id):
    """
    Initialize the settings for a group with the given group ID. When a group is
    created, the settings for the group need to be initialized before they can be updated.
    :param group_id: The ID of the group.
    :return: True if the settings were initialized successfully, False otherwise.
    :raises: Exception if the settings could not be initialized.
    """
    request = api.PostRequest(f'/api/settingsV2/topology/group/init?groupId={group_id}', payload={})
    response = api.do_post(request)
    if response['status'] != 'OK':
        raise Exception(f"Failed to initialize group settings: {response['message']}")
    return True


def enable_group_for_settings(group_id: str) -> bool:
    """
    Enables the settings for a group with the given group ID.

    :param group_id: The ID of the group.
    :return: True if the settings were enabled successfully, False otherwise.
    :raises: Exception if the settings could not be enabled.
    """
    request = api.PostRequest(
        f'/api/sedaigroup/enable/group?isActive=true&groupId={group_id}', payload={}
    )
    response = api.do_post(request)
    if response['status'] != 'OK':
        raise Exception(f"Failed to enable group settings: {response['message']}")
    return True


def disable_group_for_settings(group_id: str) -> bool:
    """
    Disables the settings for a group with the given group ID.

    :param group_id: The ID of the group.
    :return: True if the settings were disabled successfully, False otherwise.
    :raises: Exception if the settings could not be disabled.
    """
    request = api.PostRequest(
        f'/api/sedaigroup/enable/group?isActive=false&groupId={group_id}', payload={}
    )
    response = api.do_post(request)
    if response['status'] != 'OK':
        raise Exception(f"Failed to disable group settings: {response['message']}")
    return True


def get_account_settings(account_id):
    """
    Get the settings for an account with the given account ID.
    :param account_id: The ID of the account.
    :return: The settings for the account.

    """
    request = api.GetRequest('/api/settingsV2/topology/configs/account', params={'accountId': account_id})
    response = api.do_get(request)
    settings_json = response['result']['attributes']['setting']
    setting_obj = Settings(settings_json)
    setting_obj.__parse__()
    return setting_obj


def update_account_settings(account_id, settings):
    """
    Update the settings for an account with the given account ID.
    :param account_id: The ID of the account.
    :param settings: The settings for the account.
    :return: True if the settings were updated successfully, False otherwise.
    :raises: Exception if the settings could not be updated.
    """
    payload = settings.__serialize__()

    request = api.PostRequest(
        f'/api/settingsV2/topology/configs/account/{account_id}', payload=payload
    )
    response = api.do_post(request)
    if response['status'] != 'OK':
        raise Exception(f"Failed to update account settings: {response['message']}")
    return True


def __disable_monitoring(settings: BaseSettings):
    settings.kube_app_settings.releaseIntelligenceMode = 'OFF'
    settings.app_settings.releaseIntelligenceMode = 'OFF'
    settings.bucket_settings.releaseIntelligenceMode = 'OFF'
    settings.volume_settings.releaseIntelligenceMode = 'OFF'
    settings.serverless_settings.releaseIntelligenceMode = 'OFF'
    settings.ecs_app_settings.releaseIntelligenceMode = 'OFF'


def disable_account_monitoring(account_id: str):
    """
    Disable monitoring for an account with the given account ID.
    :param account_id: The ID of the account.
    """
    acc_settings = get_account_settings(account_id)
    __disable_monitoring(acc_settings)
    return update_account_settings(account_id=account_id, settings=acc_settings)


def disable_group_monitoring(group_id: str):
    """
    Disable monitoring for the group with the given group ID.
    :param group_id: The ID of the group.
    """
    group_settings = get_group_settings(group_id=group_id)
    __disable_monitoring(group_settings)
    return update_group_settings(group_id=group_id, settings=group_settings)


def disable_resource_monitoring(resource_id: str):
    """
    Disable monitoring for a resource with the given resource ID.
    :param resource_id: The ID of the resource.
    """
    res_settings = get_resource_settings(resource_id)
    res_settings.releaseIntelligenceMode = "OFF"
    return update_resource_settings(resource_id=resource_id, settings=res_settings)
