import time

from sedai.user import get_profile
from sedai.__impl import api, log
from typing import Iterator, List

"""@private"""


def __get_user_and_time():
    profile = get_profile()
    user_id = profile.displayName
    # Get current time
    time_stamp = int(time.time() * 1000)
    return user_id, time_stamp


def __add_created(obj):
    user_id, time_stamp = __get_user_and_time()
    obj.createdBy = user_id
    obj.createdOn = time_stamp
    return obj


def __add_modified(obj):
    user_id, time_stamp = __get_user_and_time()
    obj.modifiedBy = user_id
    obj.modifiedOn = time_stamp
    return obj


def __get_paginated_response(
    endpoint,
    params=None,
    page_size=50,
    num_pages=None,
    order_by=None,
    order_dir=None,
) -> Iterator[List]:
    """
    @private
    Returns an iterator representing the paginated response of calling the given endpoint with the provided params.
    Note that the API response must be of type org.sedai.edison.api.model.common.OrderedPagedResponse.
    """
    if params is None:
        params = dict()

    page_start = 0
    if page_size is not None:
        params['pageSize'] = page_size
    if order_by is not None:
        params['order_by'] = order_by
    if order_dir is not None:
        params['order_dir'] = order_dir

    while page_start is not None:
        if num_pages is not None and page_start >= num_pages:
            return None

        params['start'] = page_start

        request = api.GetRequest(endpoint, params=params)
        response = api.do_get(request)
        if response['status'] != 'OK' or response['result'] is None:
            log(
                f"Request to URL {endpoint} failed with response: {response['message']}",
                level="ERROR",
            )
            return None

        yield response['result']['content']
        page_start = None
        if response['page'] is not None:
            page_start = response['page']['nextPage']
        elif 'last' in response and response['result']['last'] is False:
            page_start = response['result']['number'] + 1
