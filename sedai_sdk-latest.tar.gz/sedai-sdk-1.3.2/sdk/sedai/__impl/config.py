import os

__keys = [
    "SEDAI_BASE_URL",
    "SEDAI_API_TOKEN",
    "SEDAI_API_KEY",
    "LOG_LEVEL",
    "PROXY_URL"
]
__config = None


def load_config(overrrid_file=None):
    config = __load_config_from_env()
    # If there is a .env file, override the config with the values from the file
    config = __load_config_from_env_file(config)
    # If there is a file passed in_config, override the config with the values from the file
    if overrrid_file is not None:
        config = __load_config_from_env_file(config, file=overrrid_file)
    return config


def get_config():
    global __config
    if __config is None:
        __config = load_config()
    return __config


def get_base_url():
    return get_config()["SEDAI_BASE_URL"]

def get_proxy_url():
    config = get_config()
    if "PROXY_URL" in config:
        return get_config()["PROXY_URL"]
    return None


def get_api_token():
    api_token = None
    config = get_config()
    # Get one of SEDAI_API_TOKEN or SEDAI_API_KEY
    if "SEDAI_API_TOKEN" in config and config["SEDAI_API_TOKEN"] is not None:
        api_token = config["SEDAI_API_TOKEN"]
    elif "SEDAI_API_KEY" in config and config["SEDAI_API_KEY"] is not None:
        api_token = config["SEDAI_API_KEY"]
    return api_token
    

def __load_config_from_env():
    config = {}
    for key in __keys:
        config[key] = os.environ.get(key)
    return config


def __load_config_from_env_file(config, file='.env'):
    if os.path.isfile(file):
        with open(file) as f:
            for line in f:
                if line.startswith("#"):
                    continue
                splits = line.strip().split("=")
                if len(splits) != 2:
                    continue
                key, value = splits
                if key in __keys:
                    config[key] = value
    return config
