from types import SimpleNamespace
from typing import Any, Dict, List, Optional


class ResourceConfig:
    """
    The configuration of a resource monitored by Sedai.
    """

    def __init__(self):
        pass


class WorkloadConfig(ResourceConfig):
    """
    Configuration for a Kubernetes workload.
    """

    replicas: int
    """
    Replica count for this workload.
    """

    def __init__(self, replicas: int):
        """@private"""
        self.replicas = replicas


class KubeContainerConfig(ResourceConfig):
    """
    Container configuration of a Kubernetes resource monitored by Sedai.
    """

    memory_request: Optional[SimpleNamespace]
    """
    Minimum memory requested for the container if set.
    """
    memory_limit: Optional[SimpleNamespace]
    """
    Maximum memory allowed for the container if set.
    """
    cpu_request: Optional[SimpleNamespace]
    """
    Minimum CPU units requested for the container if set.
    """
    cpu_limit: Optional[SimpleNamespace]
    """
    Maximum CPU units allowed for the container if set.
    """

    def __init__(
        self,
        mem_req: Optional[SimpleNamespace],
        mem_limit: Optional[SimpleNamespace],
        cpu_req: Optional[SimpleNamespace],
        cpu_limit: Optional[SimpleNamespace],
    ):
        """@private"""
        self.memory_request = mem_req
        self.memory_limit = mem_limit
        self.cpu_request = cpu_req
        self.cpu_limit = cpu_limit


class NodegroupDetails:
    """
    Details of a single nodegroup for hosting a cluster.
    """

    name: str
    """
    Name of the node group.
    """
    instance_type: str
    """
    Instance type for this node group.
    """
    memory_bytes: float
    """
    Memory for this node group.
    """
    vcpus: int
    """
    VCPUs for this node group.
    """
    num_nodes: int
    """
    Number of nodes in this node group.
    """
    min_num_nodes: int
    """
    Minimum number of nodes in this node group.
    """
    max_num_nodes: int
    """
    Maximum number of nodes in this node group.
    """

    def __init__(
        self,
        name: str = None,
        instance_type: str = None,
        memory_bytes: float = None,
        vcpus: int = None,
        num_nodes: int = None,
        min_num_nodes: int = None,
        max_num_nodes: int = None,
    ):
        """@private"""
        self.name = name
        self.instance_type = instance_type
        self.memory_bytes = memory_bytes
        self.vcpus = vcpus
        self.num_nodes = num_nodes
        self.min_num_nodes = min_num_nodes
        self.max_num_nodes = max_num_nodes


class NodegroupConfig(ResourceConfig):
    """
    The nodegroup configuration for hosting a cluster.
    """

    nodegroups: List[NodegroupDetails]
    """
    List of nodegroups for this cluster.
    """

    def __init__(self):
        """@private"""
        self.nodegroups = []


class NodegroupDetails:
    """
    Details of a single nodegroup for hosting a cluster.
    """

    name: str
    """
    Name of the node group.
    """
    instance_type: str
    """
    Instance type for this node group.
    """
    memory_bytes: float
    """
    Memory for this node group.
    """
    vcpus: int
    """
    VCPUs for this node group.
    """
    num_nodes: int
    """
    Number of nodes in this node group.
    """
    min_num_nodes: int
    """
    Minimum number of nodes in this node group.
    """
    max_num_nodes: int
    """
    Maximum number of nodes in this node group.
    """

    def __init__(
        self,
        name: str = None,
        instance_type: str = None,
        memory_bytes: float = None,
        vcpus: int = None,
        num_nodes: int = None,
        min_num_nodes: int = None,
        max_num_nodes: int = None,
    ):
        """@private"""
        self.name = name
        self.instance_type = instance_type
        self.memory_bytes = memory_bytes
        self.vcpus = vcpus
        self.num_nodes = num_nodes
        self.min_num_nodes = min_num_nodes
        self.max_num_nodes = max_num_nodes


class S3IntelligentTieringConfig:
    """
    Configuration for S3 intelligent tiering.
    """

    config_id: str
    """
    The ID of the configuration.
    """

    prefix: str
    """
    The prefix for the configuration.
    """

    tags: Dict[str, str]
    """
    The tags for the configuration.
    """

    archive_threshold_days: Dict[str, int]
    """
    The archive threshold in days for the configuration.
    """

    def __init__(
        self,
        config_id: str,
        prefix: str,
        tags: Dict[str, str],
        archive_threshold_days: Dict[str, int],
    ):
        """@private"""
        self.config_id = config_id
        self.prefix = prefix
        self.tags = tags
        self.archive_threshold_days = archive_threshold_days


class S3LifecycleRule:
    """
    Configuration for S3 lifecycle rules.
    """

    rule_id: str
    """
    The ID of the rule.
    """

    enabled: bool
    """
    Whether the rule is enabled.
    """

    transitions: List[Dict[str, Any]]
    """
    The transitions for the rule.
    """

    def __init__(self, rule_id: str, enabled: bool, transitions: List[Dict[str, Any]]):
        """@private"""
        self.rule_id = rule_id
        self.enabled = enabled
        self.transitions = transitions


class S3BucketConfig:
    """
    Configuration for an S3 bucket.
    """

    bucket_name: str
    """
    The name of the bucket.
    """

    intelligent_tiering_configs: List[S3IntelligentTieringConfig]
    """
    The intelligent tiering configurations for the bucket.
    """

    lifecycle_rules: List[S3LifecycleRule]
    """
    The lifecycle rules for the bucket.
    """

    def __init__(
        self,
        bucket_name: str,
        intelligent_tiering_configs: List[S3IntelligentTieringConfig],
        lifecycle_rules: List[SimpleNamespace],
    ):
        """@private"""
        self.bucket_name = bucket_name
        self.intelligent_tiering_configs = intelligent_tiering_configs
        self.lifecycle_rules = lifecycle_rules


class EBSVolumeConfig:
    """
    Configuration for an EBS volume.
    """

    volume_type: str
    """
    The type of the volume.
    """

    size_gb: int
    """
    The size of the volume in GB.
    """

    iops: int
    """
    The IOPS of the volume.
    """

    throughput: int
    """
    The throughput of the volume.
    """

    def __init__(
        self,
        volume_type: str,
        size_gb: int,
        iops: int,
        throughput: int,
    ):
        """@private"""
        self.volume_type = volume_type
        self.size_gb = size_gb
        self.iops = iops
        self.throughput = throughput


class ECSContainerConfig:
    """
    Configuration for an ECS container.
    """

    container_name: str
    """
    The name of the container.
    """

    container_image: str
    """
    The image of the container.
    """

    memory_soft_limit: int
    """
    The soft memory limit of the container.
    """

    memory_hard_limit: int
    """
    The hard memory limit of the container.
    """

    cpu_soft_limit: int
    """
    The soft CPU limit of the container.
    """

    def __init__(
        self,
        container_name: str,
        container_image: str,
        memory_soft_limit: int,
        memory_hard_limit: int,
        cpu_soft_limit: int,
    ):
        """@private"""
        self.container_name = container_name
        self.container_image = container_image
        self.memory_soft_limit = memory_soft_limit
        self.memory_hard_limit = memory_hard_limit
        self.cpu_soft_limit = cpu_soft_limit


class ECSResourceConfig:
    """
    Configuration for an ECS resource.
    """

    desired_count: int
    """
    The desired count of the resource.
    """

    running_count: int
    """
    The running count of the resource.
    """

    task_cpu_hard_limit_units: Optional[float]
    """
    The hard CPU limit of the task.
    """

    task_memory_hard_limit_mib: Optional[float]
    """
    The hard memory limit of the task.
    """

    container_configs: List[ECSContainerConfig]
    """
    The container configurations for the resource.
    """

    def __init__(
        self,
        desired_count: int,
        running_count: int,
        task_cpu_hard_limit_units: Optional[float],
        task_memory_hard_limit_mib: Optional[float],
        container_configs: List[ECSContainerConfig],
    ):
        """@private"""
        self.desired_count = desired_count
        self.running_count = running_count
        self.task_cpu_hard_limit_units = task_cpu_hard_limit_units
        self.task_memory_hard_limit_mib = task_memory_hard_limit_mib
        self.container_configs = container_configs


class KubeResourceConfig:
    """
    Configuration for a Kubernetes resource.
    """

    def __init__(self, container_configs: Dict[str, KubeContainerConfig], replicas: int):
        """@private"""
        self.container_configs = container_configs
        self.replicas = replicas


class LambdaResourceConfig:
    """
    Configuration for a Serverless Lambda resource.
    """

    memory_size: int
    """
    The memory size configured for the Lambda function.
    """

    timeout: int
    """
    The timeout configured for the Lambda function.
    """

    reserved_concurrency: Optional[int]
    """
    The reserved concurrency of the Lambda function if configured.
    """

    provisioned_concurrency: Optional[int]
    """
    The provisioned concurrency of the Lambda function if configured.
    """

    def __init__(
        self,
        memory_size: int,
        timeout: int,
        reserved_concurrency: Optional[int],
        provisioned_concurrency: Optional[int],
    ):
        """@private"""
        self.memory_size = memory_size
        self.timeout = timeout
        self.reserved_concurrency = reserved_concurrency
        self.provisioned_concurrency = provisioned_concurrency
