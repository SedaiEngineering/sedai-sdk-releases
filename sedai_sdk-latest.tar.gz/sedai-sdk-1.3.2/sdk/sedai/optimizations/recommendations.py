import math
from datetime import datetime
from typing import Dict, List, Optional
from warnings import warn

from sedai.__impl import api, log
from sedai.optimizations.operations import Operation, get_operation
from sedai.pagination import PageIterator, PaginatedResponse, PaginationConfig

__RECOMMENDATION_STATUS_TO_OP_STATUS = {
    "EXECUTING": ["SUBMITTED", "READY_TO_EXECUTE"],
    "PROPOSED": ["PROPOSED"],
    "EXPIRED": ["EXPIRED"],
}
__RECOMMENDATION_STATUS_TO_OP_EXEC_STATUS = {
    'FAILED': ['FAILED'],
    'USER_REJECTED': ['USER_DROPPED'],
    'UNSAFE_TO_ACT': ['DROPPED'],
    'SUCCESSFUL': ['SUCCESSFUL'],
    'PAUSED': ['PAUSED'],
    'EXECUTING': ['RESUME', 'PAUSED', 'RUNNING'],
}
__OP_EXEC_STATUS_TO_RECOMMENDATION_STATUS = {
    op_exec_item: rec_status
    for rec_status, op_exec_items in __RECOMMENDATION_STATUS_TO_OP_EXEC_STATUS.items()
    for op_exec_item in op_exec_items
}
__OP_STATUS_TO_RECOMMENDATION_STATUS = {
    op_status: rec_status
    for rec_status, op_statuses in __RECOMMENDATION_STATUS_TO_OP_STATUS.items()
    for op_status in op_statuses
}
__ALLOWED_PROBLEM_DOMAINS = ['AVAILABILITY', 'EFFICIENCY']


class Recommendation:
    """
    Represents a recommendation generated in Sedai.
    """

    resource_id: str
    """
    The Sedai ID of the resource for which the recommendation is generated.
    """

    resource_name: str
    """
    The name of the resource for which the recommendation is generated.
    """

    recommendation_type: str
    """
    The type of recommendation. This could be 
    - `AVAILABILITY`: A recommendation to resolve availability issues.
    - `EFFICIENCY`: A recommendation to optimize the resource for cost or performance.
    """

    action_name: str
    """
    The recommended action to be taken.
    """

    account_id: str
    """
    The Sedai ID of the account to which the resource belongs.
    """

    account_name: str
    """
    The name of the account to which the resource belongs.
    """

    region_id: str
    """
    The ID of the region in which the resource is located.
    """

    created_time: datetime
    """
    The time at which the recommendation was generated.
    """

    expiry_time: datetime
    """
    The time at which the recommendation expires.
    """

    status: str
    """
    The status of the recommendation. This could be one of the following:
    - `EXECUTING`: The recommendation is currently being executed.
    - `PROPOSED`: The recommendation is proposed.
    - `EXPIRED`: The recommendation has expired.
    - `FAILED`: The recommendation execution has failed.
    - `USER_REJECTED`: The user has rejected the recommendation.
    - `UNSAFE_TO_ACT`: The recommendation is unsafe to act on.
    - `SUCCESSFUL`: The recommendation execution has been successful.
    - `PAUSED`: The recommendation execution has been paused.
    """

    operation: Optional[Operation]
    """
    Details of the operation associated with this recommendation. This field is only populated if the
    `include_operation_details` parameter is set to `True` in the `get_recommendations` function.
    """

    def __init__(
        self,
        resource_id: str,
        resource_name: str,
        recommendation_type: str,
        action_name: str,
        account_id: str,
        account_name: str,
        region_id: str,
        created_time: datetime,
        expiry_time: datetime,
        status: str = None,
        operation: Optional[Operation] = None,
    ):
        """@private"""
        self.resource_id = resource_id
        self.resource_name = resource_name
        self.recommendation_type = recommendation_type
        self.action_name = action_name
        self.account_id = account_id
        self.account_name = account_name
        self.region_id = region_id
        self.created_time = created_time
        self.expiry_time = expiry_time
        self.status = status
        self.operation = operation


def get_recommendations(
    account_ids: Optional[List[str]] = None,
    resource_id: Optional[str] = None,
    starttime: Optional[datetime] = None,
    endtime: Optional[datetime] = None,
    recommendation_status: Optional[List[str]] = None,
    recommendation_types: Optional[List[str]] = None,
    pagination_config: Optional[PaginationConfig] = None,
    include_operation_details: Optional[bool] = False,
    action_name: Optional[str] = None,
) -> PageIterator[Recommendation]:
    """
    Returns a `sedai.pagination.PageIterator` of all recommendations available in Sedai.

    :param account_ids: Optional list of Sedai account IDs for which recommendations are to be fetched. If None, recommendations for all accounts are fetched.
    :param resource_id: The Sedai ID of the resource for which recommendations are to be fetched. If None, recommendations for all resources are fetched.
    :param starttime: Optional start time for the recommendations to be fetched.
    :param endtime: Optional end time for the recommendations to be fetched. If None, the current time is considered as the end time.
    :param recommendation_status: Optional list of recommendation statuses to filter the recommendations by. Possible values are
        - `EXECUTING`: The recommendation is currently being executed.
        - `PROPOSED`: The recommendation is proposed.
        - `EXPIRED`: The recommendation has expired.
        - `FAILED`: The recommendation execution has failed.
        - `USER_REJECTED`: The user has rejected the recommendation.
        - `UNSAFE_TO_ACT`: The recommendation is unsafe to act on.
        - `SUCCESSFUL`: The recommendation execution has been successful.
        - `PAUSED`: The recommendation execution has been paused.

        If no status is provided, all recommendations are fetched.
    :param recommendation_types: Optional list of recommendation types to filter the recommendations by. Possible values are
        - `AVAILABILITY`: A recommendation to resolve availability issues.
        - `EFFICIENCY`: A recommendation to optimize the resource for cost or performance.

        If no recommendation type is provided, all recommendation types are fetched.
    :param pagination_config: The pagination configuration for fetching recommendations. Refer to `sedai.pagination.PaginationConfig` for more details
        about the available options. If None, the first page of recommendations is fetched, and the function returns a list of recommendations
        as dictionaries instead of a `sedai.pagination.PageIterator` object. For default pagination configuration,
        use `sedai.pagination.DEFAULT_PAGINATION_CONFIG`.
    :param include_operation_details: Optional boolean flag to indicate whether to include details of the operation associated with the
        recommendation. If set to `True`, the operation details are included in the `operation` field of the `Recommendation` object. Default is `False`.
    :param action_name: Optional name of the action for which recommendations are to be fetched. If None, recommendations for all actions
        are fetched.
    :return: A `sedai.pagination.PageIterator` of `Recommendation` objects representing the recommendations.
    """
    params = dict()

    if recommendation_types is None:
        recommendation_types = __ALLOWED_PROBLEM_DOMAINS
    else:
        for rec_type in recommendation_types:
            if rec_type not in __ALLOWED_PROBLEM_DOMAINS:
                raise ValueError(
                    f"Invalid recommendation type: {rec_type}. Allowed values are {__ALLOWED_PROBLEM_DOMAINS}"
                )

    params['problemDomain'] = ','.join(recommendation_types)

    if account_ids is not None:
        params['accountId'] = ','.join(account_ids)

    if starttime is not None:
        starttime_epoch_ms = starttime.timestamp() * 1000
        params['startTime'] = int(round(starttime_epoch_ms))

    if endtime is not None:
        endtime_epoch_ms = endtime.timestamp() * 1000
        params['endTime'] = int(round(endtime_epoch_ms))

    if resource_id is not None:
        params['resourceId'] = resource_id

    if recommendation_status is not None:
        operation_status = set()
        operation_execution_status = set()

        for status in recommendation_status:
            if status in __RECOMMENDATION_STATUS_TO_OP_STATUS:
                operation_status.update(__RECOMMENDATION_STATUS_TO_OP_STATUS[status])
            if status in __RECOMMENDATION_STATUS_TO_OP_EXEC_STATUS:
                operation_execution_status.update(__RECOMMENDATION_STATUS_TO_OP_EXEC_STATUS[status])

        params['operationStatus'] = ','.join(operation_status)
        params['operationExecutionStatus'] = ','.join(operation_execution_status)

    if action_name is not None:
        params['actionName'] = action_name

    # to maintain backward compatibility
    if pagination_config is None:
        warn(
            "The default behavior of get_recommendations is changing. Please provide a pagination.PaginationConfig object or pagination.DEFAULT_PAGINATION_CONFIG object to paginate the results.",
            DeprecationWarning,
            stacklevel=2,
        )
        request = api.GetRequest('/api/ui/recommendations/allrecommendationsv3', params=params)
        response = api.do_get(request)
        if response['status'] != 'OK':
            log(f"Failed to get recommendation: {response['message']}")
            return None
        else:
            log(f"Successfully got recommendation")
            return response['result']

    def page_loader(params: Dict, pagination_config: PaginationConfig):
        endpoint = '/api/ui/recommendations/allrecommendationsv3'
        params = params if params is not None else {}

        if pagination_config.page_size is not None:
            params['pageSize'] = pagination_config.page_size
        if pagination_config.start is not None:
            params['start'] = pagination_config.start
        if pagination_config.order_by is not None:
            params['orderBy'] = pagination_config.order_by
        if pagination_config.order_dir is not None:
            params['orderDir'] = pagination_config.order_dir

        request = api.GetRequest(endpoint, params=params)
        response = api.do_get(request)

        if response['status'] != 'OK':
            log(f"Failed to get recommendations: {response['message']}")
            raise Exception(f"Failed to get recommendations: {response['message']}")

        recommendations_response = response['result']['recommendations']
        content = []
        for recommendation in recommendations_response:
            op_status = recommendation['operationStatus']
            recommendation_status = None
            if op_status in __OP_STATUS_TO_RECOMMENDATION_STATUS:
                recommendation_status = __OP_STATUS_TO_RECOMMENDATION_STATUS[op_status]
            op_exec_status = recommendation['operationExecutionStatus']
            if op_exec_status in __OP_EXEC_STATUS_TO_RECOMMENDATION_STATUS:
                recommendation_status = __OP_EXEC_STATUS_TO_RECOMMENDATION_STATUS[op_exec_status]

            activity = Recommendation(
                resource_id=recommendation['resourceId'],
                resource_name=recommendation['resourceName'],
                recommendation_type=recommendation['problemDomain'],
                action_name=recommendation['actionName'],
                account_id=recommendation['accountId'],
                account_name=recommendation['accountName'],
                region_id=recommendation['regionId'],
                created_time=datetime.fromtimestamp(recommendation['signalCreatedTime'] / 1000),
                expiry_time=datetime.fromtimestamp(recommendation['expiryTime'] / 1000),
                status=recommendation_status,
            )

            if include_operation_details:
                operation_id = recommendation['operationUuid']
                operation = get_operation(operation_id)
                activity.operation = operation

            content.append(activity)

        total_pages = math.ceil(response['page']['totalCount'] / response['page']['pageSize'])

        return PaginatedResponse(
            content=content,
            next_page=response['page']['nextPage'],
            total_pages=total_pages,
        )

    return PageIterator(
        params=params,
        page_loader=page_loader,
        page_config=pagination_config,
    )
