"""Aggression mode for Kube and ECS resources.

Backend mapping
---------------
This is the SDK counterpart of the server-side Java enum
``org.sedai.models.common.optimization.OptimizationMode`` (file:
``sedai-models/src/main/java/org/sedai/models/common/optimization/OptimizationMode.java``) and
the wire JSON key ``optimizationMode`` on Kube/ECS resource-setting DTOs. The SDK renames the
concept to ``AggressionMode`` / ``aggressionMode`` because the Python name ``optimizationMode``
is already taken on :class:`sedai.settings.BaseSettings` for the autonomy level
(``DATA_PILOT`` / ``CO_PILOT`` / ``AUTO`` — see :class:`sedai.settings.SettingsConfigMode`).

If you landed here by grepping for ``OptimizationMode`` (the backend name): this module is it.
Values and wire format are unchanged — only the Python-side identifier differs.

What it models
--------------
How aggressively Sedai optimizes a Kube or ECS resource. The three values form an escalation
ordering: PROD < EXPEDITE < TURBO.

- :attr:`AggressionMode.PROD` — safety first. The legacy ``isProd == True``.
- :attr:`AggressionMode.EXPEDITE` — labelled "Expedite" in the UI. The legacy ``isProd == False``.
- :attr:`AggressionMode.TURBO` — labelled "Speed" in the UI. Aggressive-plus. Kube-only today.

Why ``isProd`` is deprecated
----------------------------
The legacy wire-level ``isProd`` boolean is two-valued and therefore cannot represent TURBO.
The SDK keeps the deprecated :attr:`sedai.settings.ContainerAppSettings.isProd` setter working by
mirroring the server's ``OptimizationMode.fromIsProd(isProd, current)`` rule: ``True`` always
becomes :attr:`PROD`, and ``False`` becomes :attr:`EXPEDITE` unless the resource is already in
:attr:`TURBO` (in which case TURBO is preserved — same no-op the server does, so bulk scripts
that round-trip ``isProd`` through TURBO resources never silently demote them). The setter emits
a :class:`DeprecationWarning` to steer callers toward :attr:`aggressionMode`.
"""

from __future__ import annotations

from enum import Enum


class AggressionMode(Enum):
    """How aggressively Sedai optimizes a Kube/ECS resource.

    Backend name: ``OptimizationMode`` (Java enum
    ``org.sedai.models.common.optimization.OptimizationMode``). See the module docstring for why
    the SDK renames it.

    Enum values are the exact server-side wire strings, so ``AggressionMode("TURBO")``
    round-trips a response payload with no mapping.
    """

    PROD = "PROD"
    EXPEDITE = "EXPEDITE"
    TURBO = "TURBO"

    @classmethod
    def from_wire(cls, value: str | AggressionMode | None) -> AggressionMode | None:
        """Normalize a value from a server response to an :class:`AggressionMode`.

        ``None`` passes through so callers can distinguish "field absent" from "field present".
        Already-enum values pass through. Strings are matched case-insensitively against the enum
        names (``"turbo"`` and ``" TURBO "`` both resolve to :attr:`TURBO`).
        """
        if value is None or isinstance(value, cls):
            return value
        if isinstance(value, str):
            try:
                return cls[value.strip().upper()]
            except KeyError:
                pass
        raise ValueError(
            f"Not a valid AggressionMode: {value!r}. Expected one of {[m.value for m in cls]}."
        )

    @classmethod
    def from_is_prod(cls, is_prod: bool) -> AggressionMode:
        """Legacy ``isProd`` boolean to mode. ``True -> PROD``, ``False -> EXPEDITE``.

        Cannot produce :attr:`TURBO` — a TURBO resource whose state is reconstructed only from
        its ``isProd`` boolean is indistinguishable from EXPEDITE.
        """
        return cls.PROD if is_prod else cls.EXPEDITE

    def to_is_prod(self) -> bool:
        """Legacy ``isProd`` boolean view of the mode. ``PROD -> True``, else ``False``.

        Lossy for :attr:`TURBO`: both EXPEDITE and TURBO map to ``False``, matching the server's
        ``getIsProd()`` write-through facade (``KubernetesAppResourceSettingDetail.getIsProd()``
        in ``sedai-models``).
        """
        return self is AggressionMode.PROD
