# +
# import requests
# from sed.tenants.tenants import get_auth_header
import json
from urllib.parse import urlencode

from sedai.__impl import config, log, urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

if config.get_proxy_url() is not None:
    http = urllib3.ProxyManager(proxy_url=config.get_proxy_url())
else:
    http = urllib3.PoolManager(cert_reqs='CERT_NONE')


class GetRequest:
    def __init__(self, endpoint, params=None, **kwargs):
        if params:
            # url encode the params and add to the endpoint
            params = urlencode(params, **kwargs)
            if '?' in endpoint:
                endpoint = f"{endpoint}&{params}"
            else:
                endpoint = f"{endpoint}?{params}"
        self.endpoint = endpoint


class PostRequest:
    def __init__(self, endpoint, payload, params=None, headers=None):
        if params:
            # url encode the params and add to the endpoint
            params = urlencode(params)
            if '?' in endpoint:
                endpoint = f"{endpoint}&{params}"
            else:
                endpoint = f"{endpoint}?{params}"
        self.endpoint = endpoint
        self.payload = payload
        self.headers = headers


class DeleteRequest:
    def __init__(self, endpoint, payload=None):
        self.endpoint = endpoint
        self.payload = payload


class APIException(Exception):
    pass


def do_get(request: GetRequest):
    base_url = config.get_base_url()
    token = config.get_api_token()
    headers = {"Authorization": f"Bearer {token}"}
    get_url = f"{base_url}{request.endpoint}"

    try:
        response = http.request('GET', get_url, headers=headers, timeout=120)
        # Status code should be 200

        if response.status != 200:
            raise APIException(f"Status code {response.status} != 200")
        # Convert response to json
        data = response.data.decode('utf-8')
        return json.loads(data)
    # Catch exceptions
    # Except for other exceptions
    except Exception as e:  # noqa: BLE001 - intentional catch-all boundary; logs/wraps and degrades gracefully
        log(f'API call failed : {e}')
        raise APIException('API Failed due to:', e)


def do_post(request: PostRequest):
    base_url = config.get_base_url()
    token = config.get_api_token()
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    # merge custom headers if any
    if getattr(request, "headers", None):
        headers.update(request.headers)
    post_url = f"{base_url}{request.endpoint}"

    try:
        payload = request.payload
        if type(payload) in (dict, list):
            payload = json.dumps(payload, indent=4)

        response = http.request('POST', post_url, headers=headers, body=payload, timeout=120)
        # Status code should be 200

        if response.status != 200:
            raise APIException(f"Status code {response.status} != 200")
        # Convert response to json
        data = response.data.decode('utf-8')
        return json.loads(data)
    # # Catch exceptions
    # except http.HTTPError as e:
    #     log('The server couldn\'t fulfill the request.')
    #     log('Error code: ', e.code)
    #     raise APIException('The server couldn\'t fulfill the request.', e)
    # # Except for other exceptions
    except Exception as e:  # noqa: BLE001 - intentional catch-all boundary; logs/wraps and degrades gracefully
        log(f'API call failed : {e}')
        raise APIException('API Failed due to:', e)


def do_delete(request: DeleteRequest):
    base_url = config.get_base_url()
    token = config.get_api_token()
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    delete_url = f"{base_url}{request.endpoint}"

    try:
        payload = request.payload
        if type(payload) in (dict, list):
            payload = json.dumps(payload, indent=4)

        response = http.request('DELETE', delete_url, headers=headers, body=payload, timeout=120)
        # Status code should be 200

        if response.status != 200:
            raise APIException(f"Status code {response.status} != 200")
        # Convert response to json
        data = response.data.decode('utf-8')
        return json.loads(data)
    # # Catch exceptions
    # except urllib3.HTTPError as e:
    #     log('The server couldn\'t fulfill the request.')
    #     log('Error code: ', e.code)
    #     raise APIException('The server couldn\'t fulfill the request.', e)
    # # Except for other exceptions
    except Exception as e:  # noqa: BLE001 - intentional catch-all boundary; logs/wraps and degrades gracefully
        log(f'API call failed : {e}')
        raise APIException('API Failed due to:', e)
