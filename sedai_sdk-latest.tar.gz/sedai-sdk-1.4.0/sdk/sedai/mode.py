"""Optimization-mode change surface for Kube and ECS resources.

Programmatic equivalent of the Sedai UI's "Speed / Expedite / Safety" tile and the
`ModeChangeReviewModal` that confirms guardrail resets before switching modes. The three
`change_*_mode` wrappers hit the dedicated `/api/settingsV2/topology/configs/{resource,group,account}/mode`
endpoints — NOT the generic `update_*_settings` write path — because those endpoints run
side effects that the generic settings save does not:

1. Write the target mode's sizing-guardrail defaults into the tier's settings row.
2. Clear any guardrail the target mode does not declare (``null`` in ``modeDefaults``).
3. Emit a mode-change audit entry.

If a script flips ``aggressionMode`` through ``update_resource_settings`` instead, the mode
field changes but the guardrails do NOT reset — the resource ends up with the new mode's
label and the old mode's custom guardrails. That's usually wrong. The wrappers in this
module are the correct path for a mode switch.

The safety flag
---------------
Every ``change_*_mode`` takes ``ignore_guardrail_reset: bool = False``. When ``False``
(the default), the wrapper first fetches ``modeDefaults`` and the current resource settings,
computes the guardrail diff, and raises :class:`GuardrailResetRequiresAcknowledgementError`
with the diff attached when the switch would overwrite or clear any guardrail. Bulk scripts
inspect the diff, decide to proceed, and re-call with ``ignore_guardrail_reset=True``.
The UI's modal acknowledges on behalf of the clicking user; SDK-as-script is stricter.

Backend wire format
-------------------
The mode endpoints take query parameters, not JSON bodies: ``?resourceId=…&mode=TURBO`` on
the resource variant; the account/group variants also carry ``resourceType=KUBE|ECS``.
Response shape is :class:`~sedai.util.BaseResponse` wrapping a boolean.

Related
-------
- :mod:`sedai.aggression_mode` — the three-valued mode enum used across this module.
- :mod:`sedai.settings` — the generic settings read/write path, which preserves mode on write
  but does NOT apply the side effects described above.
"""

from __future__ import annotations

import warnings
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from sedai.__impl import api
from sedai.aggression_mode import AggressionMode
from sedai.measurement import K8sCpuValue, MemoryValue, MetricUnit, MetricValue


class ResourceType(Enum):
    """Resource type for the group/account mode wrappers.

    Mirrors the server's ``ResourceSettingsType`` for the two values ``/configs/*/mode``
    accepts. The resource-tier wrapper doesn't need this — the server derives the type from
    the resource id itself.
    """

    KUBE = "KUBE"
    ECS = "ECS"


@dataclass
class KubeModeGuardrailDefaults:
    """Vertical-sizing guardrails a mode declares as its defaults.

    Mirrors the vertical-sizing half of the server-side
    ``org.sedai.models.resourcesettings.KubeModeGuardrailDefaults`` (``sedai-models``). Field
    names, nested value types, and ``None``-semantics match the Java DTO one-for-one so the
    wire payload from ``GET /api/settingsV2/topology/configs/modeDefaults`` lands straight
    into this dataclass.

    A ``None`` value means the mode declares no default for that guardrail, and switching to
    the mode will CLEAR an existing override — NOT the same as "attribute missing from the
    response." See the module docstring and the server-side DTO javadoc.

    The server DTO also carries three horizontal-scaling fields (``minReplicas``,
    ``maxReplicas``, ``replicaMultiplier``). No mode populates them in current configuration,
    and the server's apply code writes replicas via plain null-setters with no cleared-value
    sentinel — so a mode change never changes stored replica bounds. The SDK drops them to
    match what the UI shows (vertical-sizing only) and to keep the preview diff honest.
    """

    minPerContainerCpu: K8sCpuValue | None = None
    maxPerContainerCpu: K8sCpuValue | None = None
    minPerContainerMemory: MemoryValue | None = None
    maxPerContainerMemory: MemoryValue | None = None

    @classmethod
    def __parse__(cls, src: dict[str, Any] | None) -> KubeModeGuardrailDefaults | None:
        if src is None:
            return None
        return cls(
            minPerContainerCpu=K8sCpuValue.__parse__(src.get("minPerContainerCpu")),
            maxPerContainerCpu=K8sCpuValue.__parse__(src.get("maxPerContainerCpu")),
            minPerContainerMemory=MemoryValue.__parse__(
                src.get("minPerContainerMemory"), MetricUnit.BYTES
            ),
            maxPerContainerMemory=MemoryValue.__parse__(
                src.get("maxPerContainerMemory"), MetricUnit.BYTES
            ),
        )


@dataclass
class ModeChangeDiff:
    """What a mode switch will do to the resource's current guardrails.

    - ``keeps``: guardrails whose current value matches what the target mode declares, or
      guardrails the target mode leaves alone (same value, no change).
    - ``overwrites``: ``{field: (current_value, target_value)}`` for guardrails the target
      mode declares a different value for.
    - ``clears``: ``{field: current_value}`` for guardrails the target mode declares ``None``
      for AND the resource has a current value for. These will be reset on the switch.
    """

    keeps: dict[str, Any] = field(default_factory=dict)
    overwrites: dict[str, tuple[Any, Any]] = field(default_factory=dict)
    clears: dict[str, Any] = field(default_factory=dict)

    @property
    def has_destructive_changes(self) -> bool:
        """True when the switch will overwrite or clear any guardrail."""
        return bool(self.overwrites) or bool(self.clears)

    def summary(self) -> str:
        parts: list[str] = []
        if self.overwrites:
            for f, (old, new) in self.overwrites.items():
                parts.append(f"{f}: {old!r} -> {new!r}")
        if self.clears:
            for f, old in self.clears.items():
                parts.append(f"{f}: {old!r} -> cleared")
        return "; ".join(parts) if parts else "no guardrail changes"


class GuardrailResetRequiresAcknowledgementError(Exception):
    """Raised when a ``change_*_mode`` call would overwrite or clear guardrails
    and the caller did not pass ``ignore_guardrail_reset=True``.

    The :class:`ModeChangeDiff` is attached on ``.diff`` so scripts can inspect what
    would change without re-fetching.
    """

    def __init__(self, diff: ModeChangeDiff, target_mode: AggressionMode):
        self.diff = diff
        self.target_mode = target_mode
        super().__init__(
            f"Switching to {target_mode.value} would reset guardrails ({diff.summary()}). "
            f"Re-call with ignore_guardrail_reset=True to proceed."
        )


class TurboNotSupportedForResourceTypeError(ValueError):
    """Raised when :attr:`AggressionMode.TURBO` is requested for a resource type that
    does not support it.

    TURBO is Kube-only today, mirroring the Sedai UI — only Kube resources show the "Speed"
    tile; ECS resources still only support PROD and EXPEDITE. The SDK enforces this at the
    boundary, before any mutating HTTP call, so bulk scripts fail loudly rather than relying
    on the server to silently store an inert mode or return a cryptic error.

    ``resource_id`` is the id of the offending resource (``None`` at the group/account tiers,
    where the caller supplied the resource type directly). ``resource_type`` is the actual
    type as seen by the SDK — the settings class name for the resource tier, or the
    :class:`ResourceType` value for group/account.
    """

    def __init__(self, resource_id: str | None, resource_type: str):
        self.resource_id = resource_id
        self.resource_type = resource_type
        locator = f" (resource_id={resource_id})" if resource_id else ""
        super().__init__(
            f"TURBO mode is not supported for {resource_type} resources{locator}. "
            "Use AggressionMode.PROD or AggressionMode.EXPEDITE for non-Kube resources."
        )


class BulkGuardrailResetRequiresAcknowledgementError(Exception):
    """Raised by :func:`change_resource_mode_bulk` when ANY resource in the batch would
    have destructive guardrail changes and the caller did not acknowledge.

    All-or-nothing: no POSTs fire. The per-resource diff map is attached on ``.destructive``
    so scripts can inspect, carve out the destructive ids, and retry — either with
    ``ignore_guardrail_reset=True`` on the full batch, or per-id after human review.
    """

    def __init__(self, destructive: dict[str, ModeChangeDiff]):
        self.destructive = destructive
        ids = sorted(destructive.keys())
        preview = ids[:3] + (["..."] if len(ids) > 3 else [])
        super().__init__(
            f"{len(destructive)} resource(s) would have destructive guardrail changes: "
            f"{preview}. Inspect .destructive (dict[id -> ModeChangeDiff]) and re-call "
            "with ignore_guardrail_reset=True — or carve out the destructive ids."
        )


@dataclass
class BulkModeChangeResult:
    """Outcome of :func:`change_resource_mode_bulk`.

    - ``results``: ``{resource_id: True}`` when the server saved the mode, ``False`` when
      the server returned ``result=false`` (resource has no settings block).
    - ``errors``: ``{resource_id: Exception}`` for resources where the POST raised. A failed
      resource is NOT in ``results`` — the two dicts partition the input items.
    - ``diffs``: ``{resource_id: ModeChangeDiff}`` populated on the ``ack=False`` path so
      callers can see the preview even on the happy path. Empty on ``ack=True``.
    """

    results: dict[str, bool] = field(default_factory=dict)
    errors: dict[str, Exception] = field(default_factory=dict)
    diffs: dict[str, ModeChangeDiff] = field(default_factory=dict)

    @property
    def succeeded(self) -> set[str]:
        """Resource ids where the server saved the mode (``result=True``)."""
        return {rid for rid, ok in self.results.items() if ok}

    @property
    def failed(self) -> set[str]:
        """Resource ids where the POST raised an exception."""
        return set(self.errors.keys())


# --------------------------------------------------------------------------------------- #
# Reads
# --------------------------------------------------------------------------------------- #


def get_mode_defaults() -> dict[AggressionMode, KubeModeGuardrailDefaults | None]:
    """Fetch the Kube guardrail defaults declared by every optimization mode.

    Global per installation — no tier or account parameter, because ``OptimizationConfig``
    itself is global, so mode defaults are identical at every tier. A ``None`` value for a
    mode means the mode declares no defaults at all; a ``None`` field inside a mode's
    :class:`KubeModeGuardrailDefaults` means that mode declares no default for that one
    guardrail (switching to it will CLEAR the guardrail).

    Wraps ``GET /api/settingsV2/topology/configs/modeDefaults``.
    """
    request = api.GetRequest("/api/settingsV2/topology/configs/modeDefaults")
    response = api.do_get(request)
    if response["status"] != "OK":
        raise RuntimeError(
            f"Failed to get mode defaults: {response.get('message') or 'no message from server'}"
        )
    result: dict[str, dict[str, Any] | None] = response["result"] or {}
    parsed: dict[AggressionMode, KubeModeGuardrailDefaults | None] = {}
    for mode_wire, defaults in result.items():
        try:
            mode = AggressionMode.from_wire(mode_wire)
        except ValueError:
            # Forward-compat: a future server release may ship a fourth OptimizationMode.
            # Skip-and-warn so get_mode_defaults keeps working for the modes this SDK knows,
            # instead of raising ValueError and breaking every preview.
            warnings.warn(
                f"Server returned unknown optimization mode {mode_wire!r} in modeDefaults; "
                "ignoring. Update sedai-sdk-python to recognize new modes.",
                RuntimeWarning,
                stacklevel=2,
            )
            continue
        parsed[mode] = KubeModeGuardrailDefaults.__parse__(defaults)
    return parsed


def preview_mode_change(resource_id: str, target_mode: AggressionMode | str) -> ModeChangeDiff:
    """Compute what a mode switch would do to the resource's current guardrails.

    Pure read — no side effects. Fetches the resource settings and the global mode defaults
    once each, then diffs guardrail-by-guardrail against ``modeDefaults[target_mode]``.
    Analogous to the UI's ``buildModeChangeRows`` but structured for programmatic consumers.

    For batch previews, prefer :func:`change_resource_mode_bulk` which fetches
    ``modeDefaults`` once per batch instead of once per preview.
    """
    target = _normalize_mode(target_mode)
    defaults_by_mode = get_mode_defaults()
    return _preview_with_defaults(resource_id, target, defaults_by_mode)


def _preview_with_defaults(
    resource_id: str,
    target: AggressionMode,
    defaults_by_mode: dict[AggressionMode, KubeModeGuardrailDefaults | None],
) -> ModeChangeDiff:
    """Compute a mode-change diff using a pre-fetched ``modeDefaults`` map.

    Shared between :func:`preview_mode_change` (one defaults fetch per call) and
    :func:`change_resource_mode_bulk` (one defaults fetch per batch). Target mode is
    pre-normalized — this function doesn't validate it.
    """
    # Imported here to keep the module graph tidy — settings.py pulls aggression_mode, and we
    # don't want a cycle for a function that's only on the preview path.
    from sedai.settings import get_resource_settings

    current = get_resource_settings(resource_id)
    target_defaults = defaults_by_mode.get(target)

    diff = ModeChangeDiff()
    if target_defaults is None:
        return diff

    # Four vertical-sizing guardrails. Classification mirrors the server-side
    # ModeGuardrailDefaults.java:120 declaredOrCleared semantics exactly:
    #   - current has a "real bound" (wrapper.value > 0) AND target declares nothing  → clear
    #       (server writes CLEARED_VALUE = -1 so the writer doesn't skip the key)
    #   - current is "unset" (None, or wrapper.value is None, or wrapper.value <= 0)   → keep
    #       (server leaves it alone — nothing to clear)
    #
    # Replicas are not part of the mode-defaults contract (see KubeModeGuardrailDefaults
    # docstring) and do not appear in the diff at all. _is_unset mirrors the server's
    # hasRealBound check and catches wire-wrapped-null and the -1 sentinel.
    for field_name, current_value, target_value in _guardrail_pairs(current, target_defaults):
        if _is_unset(current_value):
            diff.keeps[field_name] = current_value
        elif target_value is None:
            diff.clears[field_name] = current_value
        elif current_value != target_value:
            diff.overwrites[field_name] = (current_value, target_value)
        else:
            diff.keeps[field_name] = current_value

    return diff


def _is_unset(value: Any) -> bool:
    """Mirror the server's hasRealBound check in ModeGuardrailDefaults.java:124.

    A guardrail value is "unset" from the server's point of view when:
    - It's Python ``None`` (the attribute was absent on the wire)
    - It's a :class:`MetricValue` wrapper with inner ``value`` of ``None``
      (the wire sent ``{"value": null, "metricUnit": ..., "type": ...}``)
    - It's a :class:`MetricValue` wrapper with inner ``value <= 0``
      (the server's ``CLEARED_VALUE`` sentinel is ``-1``; any non-positive is treated
      as "unset" by every downstream reader)

    """
    if value is None:
        return True
    if isinstance(value, MetricValue):
        return value.value is None or value.value <= 0
    return False


def _guardrail_pairs(current: Any, target: KubeModeGuardrailDefaults):
    """Yield ``(field_name, current_value, target_value)`` for the four vertical-sizing
    guardrails the SDK models on :class:`KubeModeGuardrailDefaults`: CPU min/max and memory
    min/max per container.

    Replicas are not part of the mode-defaults contract (see the class docstring) so they
    do not appear here and never end up in the preview diff.

    Factored out so the diff logic is trivially testable without needing a live settings object.
    """
    yield (
        "verticalScaling_minPerContainerCpu",
        getattr(current, "verticalScaling_minPerContainerCpu", None),
        target.minPerContainerCpu,
    )
    yield (
        "verticalScaling_maxPerContainerCpu",
        getattr(current, "verticalScaling_maxPerContainerCpu", None),
        target.maxPerContainerCpu,
    )
    yield (
        "verticalScaling_minPerContainerMemory",
        getattr(current, "verticalScaling_minPerContainerMemory", None),
        target.minPerContainerMemory,
    )
    yield (
        "verticalScaling_maxPerContainerMemory",
        getattr(current, "verticalScaling_maxPerContainerMemory", None),
        target.maxPerContainerMemory,
    )


# --------------------------------------------------------------------------------------- #
# Writes — the three /mode endpoints
# --------------------------------------------------------------------------------------- #


def change_resource_mode(
    resource_id: str,
    mode: AggressionMode | str,
    *,
    ignore_guardrail_reset: bool = False,
) -> bool:
    """Apply an optimization-mode change to a single Kube or ECS resource.

    Atomically overwrites the resource-tier sizing-guardrail defaults with the target
    mode's declared values and CLEARS any guardrail the mode does not declare. This is
    different from writing ``aggressionMode`` through ``update_resource_settings``, which
    stores the mode without touching guardrails — usually the wrong thing for a mode switch.

    :param resource_id: Target resource id.
    :param mode: Target mode — :class:`AggressionMode` enum or wire string.
    :param ignore_guardrail_reset: When ``False`` (default) and the switch would
        overwrite or clear a guardrail, raises :class:`GuardrailResetRequiresAcknowledgementError`
        with the diff attached before posting. Set to ``True`` to proceed.
    :return: ``True`` when the mode was saved, ``False`` when the resource has no
        settings block.
    :raises GuardrailResetRequiresAcknowledgementError: when the switch would reset
        guardrails and the caller did not acknowledge.
    """
    from sedai.settings import ResourceSettingsNotFoundError

    target = _normalize_mode(mode)
    try:
        if target is AggressionMode.TURBO:
            _ensure_resource_supports_turbo(resource_id)
        _preflight_guardrail_check(resource_id, target, ignore_guardrail_reset)
    except ResourceSettingsNotFoundError:
        # Cold resource — mirror the documented "False when no settings block" contract
        # without wasting a POST round-trip. The first GET that detected the cold state
        # already told us everything; no further HTTP needed.
        return False

    request = api.PostRequest(
        "/api/settingsV2/topology/configs/resource/mode",
        payload={},
        params={"resourceId": resource_id, "mode": target.value},
    )
    return _dispatch_mode_change(request, "resource mode")


def change_group_mode(
    group_id: str,
    resource_type: ResourceType,
    mode: AggressionMode | str,
    *,
    ignore_guardrail_reset: bool = False,
) -> bool:
    """Apply an optimization-mode change at the group tier.

    Same side effects as :func:`change_resource_mode`, applied to the group-tier settings row
    for the given :class:`ResourceType`. Groups and resources carrying their own overrides
    are unaffected — the settings cascade handles the rest.

    :param resource_type: ``ResourceType.KUBE`` or ``ResourceType.ECS``. Required because
        the group tier is multi-type.
    :raises NotImplementedError: when ``ignore_guardrail_reset=False``. Preview is not
        implemented at the group tier yet, so the safety contract cannot be honored — the
        SDK refuses rather than silently proceeding. Set ``ignore_guardrail_reset=True`` to
        acknowledge and continue.
    """
    target = _normalize_mode(mode)
    _reject_turbo_on_non_kube_tier(target, resource_type)
    if ignore_guardrail_reset is False:
        raise NotImplementedError(
            "Preview is not implemented at the group tier. Set "
            "ignore_guardrail_reset=True to acknowledge that this call will overwrite "
            "group-tier guardrail defaults unconditionally."
        )

    request = api.PostRequest(
        "/api/settingsV2/topology/configs/group/mode",
        payload={},
        params={
            "groupId": group_id,
            "resourceType": resource_type.value,
            "mode": target.value,
        },
    )
    return _dispatch_mode_change(request, "group mode")


def change_resource_mode_bulk(
    items: list[tuple[str, AggressionMode | str]],
    resource_type: ResourceType,
    *,
    ignore_guardrail_reset: bool = False,
) -> BulkModeChangeResult:
    """Apply a mode change to many resources of the same type in one batch.

    ``resource_type`` is mandatory: a bulk batch is homogeneous by design — every item must
    be the same type. This mirrors :func:`change_group_mode` / :func:`change_account_mode`
    (which already take an explicit :class:`ResourceType`), and it eliminates per-resource
    type-check round-trips.

    What gets amortised vs. calling :func:`change_resource_mode` in a loop:

    - ``get_mode_defaults()`` is fetched **once per batch** instead of once per item on the
      ``ignore=False`` path. For a 500-resource batch that drops 500 identical global
      fetches to 1.
    - The TURBO-on-non-Kube check is O(1) at the batch boundary, not an HTTP call per item.

    Behaviour:

    - All modes normalise up front; an invalid mode in any item raises :class:`ValueError`
      before any HTTP fires.
    - ``resource_type=ResourceType.ECS`` with any TURBO item raises
      :class:`TurboNotSupportedForResourceTypeError` at the batch boundary — no POSTs fire.
    - ``ignore_guardrail_reset=False`` (default): every resource's preview runs against the
      shared defaults. If ANY resource would have destructive guardrail changes, raises
      :class:`BulkGuardrailResetRequiresAcknowledgementError` with the per-id diff map
      attached — no POSTs fire. All-or-nothing safety.
    - ``ignore_guardrail_reset=True`` or non-destructive: each resource is POSTed serially.
      Per-item failures (server 500, resource not found, etc.) land in the returned
      :class:`BulkModeChangeResult`'s ``.errors`` map so the batch completes instead of
      aborting on the first bad id.

    :param items: ordered list of ``(resource_id, mode)`` pairs. ``mode`` is an
        :class:`AggressionMode` enum or its wire string.
    :param resource_type: required. :class:`ResourceType.KUBE` or
        :class:`ResourceType.ECS`. Every item in ``items`` must be of this type — mixed
        batches are not supported.
    :param ignore_guardrail_reset: safety flag, same semantics as the single-item wrapper.
    :return: :class:`BulkModeChangeResult` with per-id outcomes.
    """
    if not items:
        return BulkModeChangeResult()

    normalized: list[tuple[str, AggressionMode]] = [
        (rid, _normalize_mode(mode)) for rid, mode in items
    ]

    # TURBO-on-non-Kube rejection — O(1) at the batch boundary, no HTTP needed since the
    # caller told us the resource type explicitly.
    has_turbo = any(mode is AggressionMode.TURBO for _, mode in normalized)
    if has_turbo and resource_type is not ResourceType.KUBE:
        raise TurboNotSupportedForResourceTypeError(None, resource_type.value)

    from sedai.settings import ResourceSettingsNotFoundError

    result = BulkModeChangeResult()
    cold_ids: set[str] = set()

    if not ignore_guardrail_reset:
        # P1 amortisation: 500 items -> 1 modeDefaults GET instead of 500.
        defaults_by_mode = get_mode_defaults()
        for rid, mode in normalized:
            try:
                result.diffs[rid] = _preview_with_defaults(rid, mode, defaults_by_mode)
            except ResourceSettingsNotFoundError:
                # Cold resource — short-circuit this item. No POST, no server round-trip.
                # Mirrors the single-item contract ("False when no settings block").
                cold_ids.add(rid)
                result.results[rid] = False
        destructive = {rid: d for rid, d in result.diffs.items() if d.has_destructive_changes}
        if destructive:
            raise BulkGuardrailResetRequiresAcknowledgementError(destructive)

    for rid, mode in normalized:
        if rid in cold_ids:
            continue  # already recorded as False — no POST needed
        request = api.PostRequest(
            "/api/settingsV2/topology/configs/resource/mode",
            payload={},
            params={"resourceId": rid, "mode": mode.value},
        )
        try:
            result.results[rid] = _dispatch_mode_change(request, "resource mode")
        except Exception as e:  # noqa: BLE001 - per-item errors collected, batch continues
            result.errors[rid] = e

    return result


def change_account_mode(
    account_id: str,
    resource_type: ResourceType,
    mode: AggressionMode | str,
    *,
    ignore_guardrail_reset: bool = False,
) -> bool:
    """Apply an optimization-mode change at the account tier.

    Same side effects as :func:`change_resource_mode`, applied to the account-tier settings
    row for the given :class:`ResourceType`. This is the primary UI path — the Speed tile at
    account scope.

    :raises NotImplementedError: when ``ignore_guardrail_reset=False``. Preview is not
        implemented at the account tier yet, so the safety contract cannot be honored — the
        SDK refuses rather than silently proceeding. Set ``ignore_guardrail_reset=True`` to
        acknowledge and continue.
    """
    target = _normalize_mode(mode)
    _reject_turbo_on_non_kube_tier(target, resource_type)
    if ignore_guardrail_reset is False:
        raise NotImplementedError(
            "Preview is not implemented at the account tier. Set "
            "ignore_guardrail_reset=True to acknowledge that this call will overwrite "
            "account-tier guardrail defaults unconditionally."
        )

    request = api.PostRequest(
        "/api/settingsV2/topology/configs/account/mode",
        payload={},
        params={
            "accountId": account_id,
            "resourceType": resource_type.value,
            "mode": target.value,
        },
    )
    return _dispatch_mode_change(request, "account mode")


# --------------------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------------------- #


def _normalize_mode(mode: AggressionMode | str) -> AggressionMode:
    target = AggressionMode.from_wire(mode)
    if target is None:
        raise ValueError(
            "mode must be an AggressionMode or its wire string (PROD / EXPEDITE / TURBO)"
        )
    return target


def _preflight_guardrail_check(
    resource_id: str, target: AggressionMode, acknowledged: bool
) -> None:
    """Preview the mode change and raise when the caller hasn't acknowledged a destructive switch."""
    if acknowledged:
        return
    diff = preview_mode_change(resource_id, target)
    if diff.has_destructive_changes:
        raise GuardrailResetRequiresAcknowledgementError(diff, target)


def _ensure_resource_supports_turbo(resource_id: str) -> None:
    """Reject a TURBO request on a non-Kube resource at the SDK boundary.

    Fetches the resource settings and checks the concrete type against
    :class:`sedai.settings.KubeAppSettings`. ECS and every other settings class raise
    :class:`TurboNotSupportedForResourceTypeError` before any mutating HTTP call fires —
    mirrors the Sedai UI, which only shows the "Speed" tile on Kube resources.
    """
    from sedai.settings import KubeAppSettings, get_resource_settings

    settings = get_resource_settings(resource_id)
    if not isinstance(settings, KubeAppSettings):
        raise TurboNotSupportedForResourceTypeError(resource_id, type(settings).__name__)


def _reject_turbo_on_non_kube_tier(target: AggressionMode, resource_type: ResourceType) -> None:
    """At the group/account tier the caller tells us the resource type, so no fetch is needed.

    Raises :class:`TurboNotSupportedForResourceTypeError` for any TURBO request against a
    non-Kube tier.
    """
    if target is AggressionMode.TURBO and resource_type is not ResourceType.KUBE:
        raise TurboNotSupportedForResourceTypeError(None, resource_type.value)


def _dispatch_mode_change(request: api.PostRequest, what: str) -> bool:
    response = api.do_post(request)
    if response["status"] != "OK":
        raise RuntimeError(
            f"Failed to apply {what}: {response.get('message') or 'no message from server'}"
        )
    result = response.get("result")
    return bool(result)
