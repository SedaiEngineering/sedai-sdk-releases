import math
from enum import Enum
from typing import ClassVar, Optional

from sedai.__impl import api, log
from sedai.optimizations import AzureDiskConfig, EBSVolumeConfig, GCPDiskConfig, VolumeConfig
from sedai.pagination import PageIterator, PaginatedResponse, PaginationConfig
from sedai.settings import SettingsConfigMode


class ResourceOpportunityStatus(Enum):
    """
    This enum class, ResourceOpportunityStatus, defines possible statuses for a resource optimization opportunity:
    Use this enum to represent and check the evaluation status of a resource in optimization workflows.

    - `NOT_EVALUATED`: The resource has not yet been evaluated for optimization opportunities.
    - `NO_OPPORTUNITY`: No optimization opportunity is available for the resource.
    - `OPPORTUNITY_AVAILABLE`: An optimization opportunity is available for the resource.
    """

    NOT_EVALUATED = "NOT_EVALUATED"
    NO_OPPORTUNITY = "NO_OPPORTUNITY"
    OPPORTUNITY_AVAILABLE = "OPPORTUNITY_AVAILABLE"

    def __str__(self) -> str:
        return self.value


class MetricValue:
    """
    Represents metric specifications by associating numeric values with their corresponding units.

    When printed, the object displays the machine-friendly representation of the metric.
    All attributes can also be accessed directly using the dot (.) operator.
    """

    value: float
    """
    The raw value for the metric.
    """
    unit: str
    """
    Unit of the metric value.
    """
    machine_friendly_representation: str
    """
    Readable representation with value and unit.
    """

    def __init__(self, src: dict):
        """@private"""
        self.value = src.get("value")
        self.unit = src.get("metricUnit")
        self.machine_friendly_representation = src.get("machineFriendlyRepresentation")

    def __str__(self):
        return self.machine_friendly_representation


def _metric_value(src: dict | None) -> Optional["MetricValue"]:
    return MetricValue(src) if src else None


_logged_messages: set[str] = set()


def _log_once(message: str):
    # A sweep can return the same unexpected value on hundreds of rows; log it once.
    if message not in _logged_messages:
        _logged_messages.add(message)
        log(message)


def _parse_enum(enum_class: type[Enum], value):
    if value is None:
        return None
    try:
        return enum_class(value)
    except ValueError:
        _log_once(f"Unknown {enum_class.__name__} value : {value}")
        return None


class OpportunityTag:
    """
    A tag on a cloud resource, as a key and value pair.
    """

    key: str
    """
    The tag key.
    """
    value: str
    """
    The tag value.
    """

    def __init__(self, src: dict):
        """@private"""
        self.key = src.get("key")
        self.value = src.get("value")


class OpportunityDetails:
    """
    Base class for showing Opportunity details for a resource.

    """

    sedai_resource_id: str
    """
    Id used in Sedai corresponding to the resource mentioned.
    """
    provider_resource_id: str | None
    """
    Id of the resource in the cloud provider, such as an EC2 instance ID or an Azure resource path.
    May be None for some resources.
    """
    resource_name: str
    """
    Name of the resource.
    """
    monthly_cost_impact_pct: float
    """
    Monthly cost impact percentage.
    """
    monthly_cost_impact: float
    """
    Monthly cost impact.
    """
    pre_ops_monthly_cost: float
    """
    Monthly cost before the optimization.
    """
    post_ops_monthly_cost: float
    """
    Monthly cost after the optimization.
    """
    opportunity_status: ResourceOpportunityStatus | None
    """
    Whether an optimization opportunity is available for the resource.
    """
    config_mode: SettingsConfigMode | None
    """
    The mode the resource is currently in: `DATA_PILOT`, `CO_PILOT` or `AUTO`.
    """
    tags: list[OpportunityTag] | None
    """
    The resource's tags from the cloud provider. Only filled in when tags are requested, such as with
    `include_tags=True` in `get_opportunities_for_resources`: then a list, empty if the resource has
    no tags. Otherwise None.
    """

    def __init__(self, src: dict):
        """@private"""
        self.sedai_resource_id = src.get("sedaiResourceId")
        self.provider_resource_id = src.get("providerResourceId")
        self.resource_name = src.get("resourceName")
        self.monthly_cost_impact_pct = src.get("monthlyCostImpactPct")
        self.monthly_cost_impact = src.get("monthlyCostImpact")
        self.pre_ops_monthly_cost = src.get("preOpsMonthlyCost")
        self.post_ops_monthly_cost = src.get("postOpsMonthlyCost")
        self.opportunity_status = _parse_enum(
            ResourceOpportunityStatus, src.get("resourceOpportunityStatus")
        )
        self.config_mode = _parse_enum(SettingsConfigMode, src.get("configMode"))
        tags = src.get("tags")
        self.tags = [OpportunityTag(tag) for tag in tags if tag] if tags is not None else None


class VolumeOpportunityDetails(OpportunityDetails):
    """
    Represents an optimization opportunity for a disk: an AWS EBS volume, an Azure disk
    or a GCP persistent disk.
    Captures details about the current and recommended disk configuration and the pricing impact.
    """

    __type = "VolumeOptimizationOpportunityModel"

    current_config: VolumeConfig | None = None
    """
    Current config for the resource: an `EBSVolumeConfig`, `AzureDiskConfig` or `GCPDiskConfig`.
    """
    recommended_config: VolumeConfig | None = None
    """
    Recommended config for the resource: an `EBSVolumeConfig`, `AzureDiskConfig` or `GCPDiskConfig`.
    """

    __instance_type_map: ClassVar[dict] = {
        "AzureDiskConfigState": AzureDiskConfig,
        "EBSVolumeConfigState": EBSVolumeConfig,
        "GCPDiskConfigState": GCPDiskConfig,
    }

    def __init__(self, src: dict):
        super().__init__(src)
        self.__parse__(src)

    def __parse__(self, src: dict):
        current = src.get("currentConfig") or {}
        recommended = src.get("recommendedConfig") or {}

        config_type = current.get("type") or recommended.get("type")
        if config_type is None:
            return
        if config_type not in self.__instance_type_map:
            _log_once(f"Unsupported volume type : {config_type}")
            return

        config_class = self.__instance_type_map[config_type]

        if src.get("currentConfig"):
            self.current_config = config_class(src["currentConfig"])

        if src.get("recommendedConfig"):
            self.recommended_config = config_class(src["recommendedConfig"])


class InstanceConfig:
    """
    Details of the instance.
    """

    instance_names: list[str] = None
    """
    Names of the instances.
    """
    current_type: str | None = None
    """
    Current instance type.
    """
    recommended_type: str | None = None
    """
    Recommended instance type after optimization. May be None; the VM's recommended instance type
    is also available as `VMOpportunityDetails.recommended_instance_type`.
    """
    account: str | None = None
    """
    Account name to which the instance belongs.
    """
    region: str | None = None
    """
    Region where the instance is deployed.
    """
    quantity: int = 0
    """
    Number of instances of the given type.
    """
    pre_cpu: Optional["MetricValue"] = None
    """
    CPU values before optimization.
    """
    post_cpu: Optional["MetricValue"] = None
    """
    CPU values after optimization.
    """
    pre_memory: Optional["MetricValue"] = None
    """
    Memory values before optimization.
    """
    post_memory: Optional["MetricValue"] = None
    """
    Memory values after optimization.
    """
    pre_max_network_bandwidth: str | None = None
    """
    Maximum network bandwidth before optimization.
    """
    post_max_network_bandwidth: str | None = None
    """
    Maximum network bandwidth after optimization.
    """
    pre_ebs_throughput: str | None = None
    """
    EBS throughput before optimization.
    """
    post_ebs_throughput: str | None = None
    """
    EBS throughput after optimization.
    """
    pre_max_ebs_bandwidth: Optional["MetricValue"] = None
    """
    Maximum EBS bandwidth before optimization.
    """
    post_max_ebs_bandwidth: Optional["MetricValue"] = None
    """
    Maximum EBS bandwidth after optimization.
    """
    pre_instance_family: str | None = None
    """
    Instance family before optimization.
    """
    post_instance_family: str | None = None
    """
    Instance family after optimization.
    """
    pre_cpu_clockspeed: float | None = None
    """
    CPU clock speed in GHz before optimization.
    """
    post_cpu_clockspeed: float | None = None
    """
    CPU clock speed in GHz after optimization.
    """

    def __set__region(self, region):

        region_split = region.split("/")
        if len(region_split) == 2:
            self.region = region_split[1]
        else:
            self.region = region

    def __init__(self, src: dict):
        """@private"""
        self.instance_names = src.get("instanceNames")
        self.current_type = src.get("currentType")
        self.recommended_type = src.get("recommendedType")
        self.account = src.get("account")
        self.quantity = src.get("quantity")
        self.pre_cpu = _metric_value(src.get("preCpu"))
        self.post_cpu = _metric_value(src.get("postCpu"))
        self.pre_memory = _metric_value(src.get("preMemory"))
        self.post_memory = _metric_value(src.get("postMemory"))
        self.pre_max_network_bandwidth = src.get("preMaxNetworkBandwidth")
        self.post_max_network_bandwidth = src.get("postMaxNetworkBandwidth")
        self.pre_ebs_throughput = src.get("preEbsThroughput")
        self.post_ebs_throughput = src.get("postEbsThroughput")
        self.pre_max_ebs_bandwidth = _metric_value(src.get("preMaxEBSBandwidth"))
        self.post_max_ebs_bandwidth = _metric_value(src.get("postMaxEBSBandwidth"))
        self.pre_instance_family = src.get("preInstanceFamily")
        self.post_instance_family = src.get("postInstanceFamily")
        self.pre_cpu_clockspeed = src.get("preCpuClockspeed")
        self.post_cpu_clockspeed = src.get("postCpuClockspeed")
        self.__set__region(src.get("region") or "")


class VMOpportunityDetails(OpportunityDetails):
    """
    Represents an optimization opportunity for virtual machines (VMs).
    Captures details about current and recommended instance types, pricing impact,
    and related instance configurations.
    """

    __type = "VMOptimizationOpportunityModel"

    current_instance_type: str
    """
    Current VM instance type.
    """
    recommended_instance_type: str
    """
    Recommended VM instance type after optimization.
    """
    pre_on_demand_pricing: float
    """
    Current on-demand pricing cost (before optimization).
    """
    post_on_demand_pricing: float
    """
    On-demand pricing cost after applying the recommended instance type.
    """
    estimated_on_demand_pricing_impact: float
    """
    Estimated cost savings (or increase) in on-demand pricing due to optimization.
    """
    instance_configs: list[InstanceConfig] = None
    """
    List of instance configuration details before and after optimization.
    """

    def __init__(self, src: dict):
        super().__init__(src)
        self.current_instance_type = src.get("currentInstanceType")
        self.recommended_instance_type = src.get("recommendedInstanceType")
        self.pre_on_demand_pricing = src.get("preOnDemandPricing")
        self.post_on_demand_pricing = src.get("postOnDemandPricing")
        self.estimated_on_demand_pricing_impact = src.get("estimatedOnDemandPricingImpact")
        self.instance_configs = self.instance_configs = [
            InstanceConfig(cfg) for cfg in (src.get("instanceConfigs") or []) if cfg
        ]


__type_map = {
    "VolumeOptimizationOpportunityModel": VolumeOpportunityDetails,
    "VMOptimizationOpportunityModel": VMOpportunityDetails,
    "BaseOptimizationOpportunityModel": OpportunityDetails,
}


def _parse_opportunity(src: dict | None) -> OpportunityDetails | None:
    if not isinstance(src, dict):
        _log_once(f"Skipping opportunity that is not an object : {src!r}")
        return None
    opportunity_class = __type_map.get(src.get("type"))
    if opportunity_class is None:
        _log_once(f"Unsupported opportunity type : {src.get('type')}")
        return None
    return opportunity_class(src)


def get_opportunity_for_resource(
    provider_resource_id: str,
) -> OpportunityDetails | None:
    """
    Fetches optimization opportunities for a given resource, such as VMs and volumes.

    :param provider_resource_id: The unique identifier of the resource in cloud provider for which optimization opportunities are to be retrieved.

    :return: An instance of the opportunity details for the specified resource.
             Depending on the resource type, this will be `VMOpportunityDetails`, `VolumeOpportunityDetails`,
             or `OpportunityDetails` (cost and savings only) for other resource types.
    """
    params = {}
    params['providerResourceId'] = provider_resource_id
    request = api.GetRequest(
        '/api/autonomousOpportunities/individualResource', params=params, doseq=True
    )
    response = api.do_get(request)
    if response['status'] != 'OK' or response['result'] is None:
        log("Failed to fetch opportunity")
        return None

    return _parse_opportunity(response['result'])


def get_opportunities_for_resources(
    provider_resource_ids: list[str],
    account_ids: list[str] | None = None,
    group_ids: list[str] | None = None,
    config_modes: list[SettingsConfigMode] | None = None,
    include_tags: bool = False,
    pagination_config: PaginationConfig | None = None,
) -> PageIterator[OpportunityDetails]:
    """
    Fetches optimization opportunities for many resources at once.

    Each item returned is one of:

    - `VMOpportunityDetails` for virtual machines, with current and recommended instance types and pricing.
    - `VolumeOpportunityDetails` for disks, with current and recommended disk configuration.
    - `OpportunityDetails` for all other resource types, such as Kubernetes workloads, storage buckets
      and databases, with cost and savings only.

    Use `isinstance` to tell them apart. `VMOpportunityDetails` and `VolumeOpportunityDetails` are
    subclasses of `OpportunityDetails`, so check for them first.

    Only resources that currently have an optimization opportunity are returned. Resources without one
    are left out, so you can get fewer results than the IDs you passed. You can also get more: a
    resource connected to Sedai through more than one account appears once per account, each time with
    a different `sedai_resource_id`.

    This API must be enabled for your tenant. If it is not, the call fails with HTTP status 403;
    contact Sedai support to enable it.

    :param provider_resource_ids: The resources' IDs in your cloud provider, in the provider's own format. For example:
        - AWS EC2 instance: `i-0abc1234567890def`
        - AWS EBS volume: `vol-0abc1234567890def`
        - Azure: `/subscriptions/{subscription}/resourceGroups/{group}/providers/Microsoft.Compute/virtualMachines/{name}`
        - GCP: `https://www.googleapis.com/compute/v1/projects/{project}/zones/{zone}/instances/{name}`

        **An empty list does not filter by ID.** It returns opportunities for all resources, narrowed only
        by the other filters. To get every opportunity in an account, pass an empty list with `account_ids`.
        On large tenants this is also much faster than filtering by ID.
    :param account_ids: Optional list of Sedai account IDs. Only resources in these accounts are returned.
    :param group_ids: Optional list of Sedai group IDs. Only resources in these groups are returned.
    :param config_modes: Optional list of `sedai.settings.SettingsConfigMode` values. Only resources currently
        in one of these modes are returned.
    :param include_tags: If True, each result's `tags` is a list of the resource's tags from the cloud
        provider, empty if it has none. Defaults to False, which leaves `tags` as None.
    :param pagination_config: Optional `sedai.pagination.PaginationConfig`. Pages are numbered from 1.
        If None, a new `PaginationConfig()` is used: 20 results per page, fetching all pages. Each request
        repeats the filtering on the server, so for large results a bigger `page_size` (such as 100) is
        faster. This API does not support sorting, so `order_by` and `order_dir` are ignored. The
        configuration you pass is not changed, so it can be reused.
    :return: A `sedai.pagination.PageIterator` of `VMOpportunityDetails`, `VolumeOpportunityDetails` and
        `OpportunityDetails` objects.
    :raises TypeError: If `provider_resource_ids` is None or a single string rather than a list.
    :raises ValueError: If `pagination_config.start` or `pagination_config.num_pages` is less than 1.
    """
    if provider_resource_ids is None or isinstance(provider_resource_ids, str):
        # A string would be split into characters, and None would mean "no ID filter".
        raise TypeError(
            "provider_resource_ids must be a list of IDs; for one resource, pass ['<id>']. "
            "An empty list returns opportunities for all resources."
        )

    body = {'providerResourceIds': list(provider_resource_ids)}
    if account_ids is not None:
        body['accountIds'] = account_ids
    if group_ids is not None:
        body['groupIds'] = group_ids
    if config_modes is not None:
        body['configModes'] = [mode.value for mode in config_modes]
    if include_tags:
        body['includeTags'] = True

    if pagination_config is None:
        pagination_config = PaginationConfig()

    def page_loader(body: dict, pagination_config: PaginationConfig) -> PaginatedResponse:
        # Pagination goes in the URL; the API ignores it in the body. The API's start is a
        # 0-based page index, while PaginationConfig.start counts from 1.
        api_start = pagination_config.start - 1
        params = {'start': api_start}
        if pagination_config.page_size is not None:
            params['pageSize'] = pagination_config.page_size
        request = api.PostRequest('/api/autonomousOpportunities/batch', payload=body, params=params)
        try:
            response = api.do_post(request)
        except api.APIException as e:
            # api.do_post reports the HTTP status only in its message.
            if 'Status code 403' not in str(e):
                raise
            raise api.APIException(
                "Failed to get opportunities for resources: HTTP 403. The bulk opportunities API "
                "(feature flag BULK_OPPORTUNITIES_API_ENABLED) is probably not enabled for this "
                f"tenant; contact Sedai support to enable it. Cause: {e}"
            ) from e

        if response.get('status') != 'OK':
            log(f"Failed to get opportunities for resources: {response.get('message')}")
            raise RuntimeError(
                f"Failed to get opportunities for resources: {response.get('message')}"
            )

        content = []
        for row in (response.get('result') or {}).get('content') or []:
            opportunity = _parse_opportunity(row)
            if opportunity is not None:
                if include_tags and opportunity.tags is None:
                    opportunity.tags = []  # the API sends null for a resource with no tags
                content.append(opportunity)

        page = response.get('page') or {}
        next_page = page.get('nextPage')
        total_count = page.get('totalCount')
        page_size = page.get('pageSize')
        return PaginatedResponse(
            content=content,
            # Back to 1-based; the API's nextPage is 0-based and None on the last page.
            next_page=next_page + 1 if next_page is not None else None,
            total_pages=math.ceil(total_count / page_size) if total_count and page_size else 0,
        )

    return PageIterator(params=body, page_loader=page_loader, page_config=pagination_config)
