from types import SimpleNamespace
from typing import Any


class ResourceConfig:
    """
    The configuration of a resource monitored by Sedai.
    """

    def __init__(self):
        pass


class WorkloadConfig(ResourceConfig):
    """
    Configuration for a Kubernetes workload.
    """

    replicas: int
    """
    Replica count for this workload.
    """

    def __init__(self, replicas: int):
        """@private"""
        self.replicas = replicas


class KubeContainerConfig(ResourceConfig):
    """
    Container configuration of a Kubernetes resource monitored by Sedai.

    Each CPU and memory value is an object with two attributes, or None when the container doesn't
    set that value:

    - `value`: the amount, as a number.
    - `metricUnit`: the unit `value` is in, for example `BYTES` for memory and `CORES` for CPU.
      Check it before comparing or converting values.

    For example, `config.memory_request.value` is the container's memory request.
    """

    memory_request: SimpleNamespace | None
    """
    Minimum memory requested for the container if set.
    """
    memory_limit: SimpleNamespace | None
    """
    Maximum memory allowed for the container if set.
    """
    cpu_request: SimpleNamespace | None
    """
    Minimum CPU units requested for the container if set.
    """
    cpu_limit: SimpleNamespace | None
    """
    Maximum CPU units allowed for the container if set.
    """

    def __init__(
        self,
        mem_req: SimpleNamespace | None,
        mem_limit: SimpleNamespace | None,
        cpu_req: SimpleNamespace | None,
        cpu_limit: SimpleNamespace | None,
    ):
        """@private"""
        self.memory_request = mem_req
        self.memory_limit = mem_limit
        self.cpu_request = cpu_req
        self.cpu_limit = cpu_limit


class NodegroupDetails:
    """
    Details of a single nodegroup for hosting a cluster.
    """

    name: str
    """
    Name of the node group.
    """
    instance_type: str
    """
    Instance type for this node group.
    """
    memory_bytes: float
    """
    Memory for this node group.
    """
    vcpus: int
    """
    VCPUs for this node group.
    """
    num_nodes: int
    """
    Number of nodes in this node group.
    """
    min_num_nodes: int
    """
    Minimum number of nodes in this node group.
    """
    max_num_nodes: int
    """
    Maximum number of nodes in this node group.
    """

    def __init__(
        self,
        name: str | None = None,
        instance_type: str | None = None,
        memory_bytes: float | None = None,
        vcpus: int | None = None,
        num_nodes: int | None = None,
        min_num_nodes: int | None = None,
        max_num_nodes: int | None = None,
    ):
        """@private"""
        self.name = name
        self.instance_type = instance_type
        self.memory_bytes = memory_bytes
        self.vcpus = vcpus
        self.num_nodes = num_nodes
        self.min_num_nodes = min_num_nodes
        self.max_num_nodes = max_num_nodes


class NodegroupConfig(ResourceConfig):
    """
    The nodegroup configuration for hosting a cluster.
    """

    nodegroups: list[NodegroupDetails]
    """
    List of nodegroups for this cluster.
    """

    def __init__(self):
        """@private"""
        self.nodegroups = []


class NodegroupDetails:
    """
    Details of a single nodegroup for hosting a cluster.
    """

    name: str
    """
    Name of the node group.
    """
    instance_type: str
    """
    Instance type for this node group.
    """
    memory_bytes: float
    """
    Memory for this node group.
    """
    vcpus: int
    """
    VCPUs for this node group.
    """
    num_nodes: int
    """
    Number of nodes in this node group.
    """
    min_num_nodes: int
    """
    Minimum number of nodes in this node group.
    """
    max_num_nodes: int
    """
    Maximum number of nodes in this node group.
    """

    def __init__(
        self,
        name: str | None = None,
        instance_type: str | None = None,
        memory_bytes: float | None = None,
        vcpus: int | None = None,
        num_nodes: int | None = None,
        min_num_nodes: int | None = None,
        max_num_nodes: int | None = None,
    ):
        """@private"""
        self.name = name
        self.instance_type = instance_type
        self.memory_bytes = memory_bytes
        self.vcpus = vcpus
        self.num_nodes = num_nodes
        self.min_num_nodes = min_num_nodes
        self.max_num_nodes = max_num_nodes


class S3IntelligentTieringConfig:
    """
    Configuration for S3 intelligent tiering.
    """

    config_id: str
    """
    The ID of the configuration.
    """

    prefix: str
    """
    The prefix for the configuration.
    """

    tags: dict[str, str]
    """
    The tags for the configuration.
    """

    archive_threshold_days: dict[str, int]
    """
    The archive threshold in days for the configuration.
    """

    def __init__(
        self,
        config_id: str,
        prefix: str,
        tags: dict[str, str],
        archive_threshold_days: dict[str, int],
    ):
        """@private"""
        self.config_id = config_id
        self.prefix = prefix
        self.tags = tags
        self.archive_threshold_days = archive_threshold_days


class S3LifecycleRule:
    """
    Configuration for S3 lifecycle rules.
    """

    rule_id: str
    """
    The ID of the rule.
    """

    enabled: bool
    """
    Whether the rule is enabled.
    """

    transitions: list[dict[str, Any]]
    """
    The transitions for the rule.
    """

    def __init__(self, rule_id: str, enabled: bool, transitions: list[dict[str, Any]]):
        """@private"""
        self.rule_id = rule_id
        self.enabled = enabled
        self.transitions = transitions


class S3BucketConfig:
    """
    Configuration for an S3 bucket.
    """

    bucket_name: str
    """
    The name of the bucket.
    """

    intelligent_tiering_configs: list[S3IntelligentTieringConfig]
    """
    The intelligent tiering configurations for the bucket.
    """

    lifecycle_rules: list[S3LifecycleRule]
    """
    The lifecycle rules for the bucket.
    """

    def __init__(
        self,
        bucket_name: str,
        intelligent_tiering_configs: list[S3IntelligentTieringConfig],
        lifecycle_rules: list[SimpleNamespace],
    ):
        """@private"""
        self.bucket_name = bucket_name
        self.intelligent_tiering_configs = intelligent_tiering_configs
        self.lifecycle_rules = lifecycle_rules


class GCPBucketConfig:
    """
    Configuration of a Google Cloud Storage bucket.
    """

    autoclass_enabled: bool | None
    """
    Whether Autoclass is turned on. Autoclass moves objects between storage classes automatically,
    based on how often they are read.
    """

    terminal_storage_class: str | None
    """
    The coldest storage class Autoclass may move objects to (for example `NEARLINE` or `ARCHIVE`).
    None when Sedai has not recorded one, which is usual while Autoclass is off.
    """

    lifecycle_rules: list[dict[str, Any]]
    """
    The bucket's lifecycle rules, as Sedai records them. Empty when the bucket has none.
    """

    def __init__(self, src: dict):
        """@private"""
        autoclass = src.get("autoclassConfig") or {}
        self.autoclass_enabled = autoclass.get("enabled")
        self.terminal_storage_class = autoclass.get("terminalStorageClass")
        self.lifecycle_rules = list(src.get("lifecycleRules") or [])


class VolumeConfig(ResourceConfig):
    """
    Configuration for a volume.
    """

    size_gb: int
    """
    The size of the volume in GB.
    """

    iops: int
    """
    The IOPS of the volume.
    """

    throughput: int
    """
    The throughput of the volume.
    """

    def __init__(self, src: dict):
        """@private"""
        super().__init__()
        self.size_gb = src.get("sizeInGB")
        self.iops = src.get("iops")
        self.throughput = src.get("throughput")


class EBSVolumeConfig(VolumeConfig):
    """
    Configuration for an EBS volume.
    Extends `VolumeConfig` with additional attributes specific to EBS.
    """

    __type = "EBSVolumeConfigState"

    volume_type: str
    """
    The type of the volume.
    """

    def __init__(self, src: dict):
        """@private"""
        super().__init__(src)
        self.volume_type = src.get("volumeType")


class AzureDiskConfig(VolumeConfig):
    """
    Azure-specific configuration for a disk.

    Extends `VolumeConfig` with additional attributes specific to Azure,
    such as disk type and performance tier.
    """

    __type = "AzureDiskConfigState"

    disk_type: str
    """
    The type of the Azure disk (for example `PREMIUM_LRS` or `STANDARD_LRS`).
    """

    tier: str
    """
    The performance tier of the Azure disk (e.g., P4, P10, P20, E10).
    """

    def __init__(self, src: dict):
        super().__init__(src)
        self.disk_type = src.get("diskType")
        self.tier = src.get("tier")


class GCPDiskConfig(VolumeConfig):
    """
    GCP-specific configuration for a persistent disk.

    Extends `VolumeConfig` with additional attributes specific to GCP,
    such as disk type and replication.
    """

    __type = "GCPDiskConfigState"

    disk_type: str
    """
    The type of the GCP disk (e.g., PD_STANDARD, PD_BALANCED, HYPERDISK_BALANCED).
    """

    replication: str
    """
    How the GCP disk is replicated (e.g., ZONAL).
    """

    def __init__(self, src: dict):
        """@private"""
        super().__init__(src)
        self.disk_type = src.get("diskType")
        self.replication = src.get("replication")


class VMInstanceSpec:
    """
    The instance type of a virtual machine and what that type provides.
    """

    instance_type: str | None
    """
    The instance type (for example `t3a.medium`).
    """

    vcpus: int | None
    """
    The number of virtual CPUs. 0 or None when Sedai could not look up the instance type.
    """

    memory_mib: int | None
    """
    Memory in MiB (for example 4096 for a 4 GiB instance). None when Sedai could not look up the
    instance type.
    """

    instance_family: str | None
    """
    The instance family (for example `General purpose`).
    """

    cpu_architecture: list[str]
    """
    The CPU architectures, as the cloud provider names them (for example `["x86_64"]` on AWS,
    `["x86"]` on Google Cloud). Empty when not known.
    """

    cpu_clock_speed_ghz: float | None
    """
    The CPU clock speed in GHz. None when Sedai does not record it, for example for Google Cloud
    machine types.
    """

    max_network_bandwidth: str | None
    """
    The network bandwidth, as the cloud provider describes it (for example `Up to 5 Gigabit`). None
    when Sedai does not record it, for example for Google Cloud machine types.
    """

    ebs_throughput: str | None
    """
    The EBS throughput, as AWS describes it (for example `Up to 2085 Mbps`). None for other cloud
    providers.
    """

    def __init__(self, src: dict):
        """@private"""
        self.instance_type = src.get("instanceType")
        self.vcpus = src.get("defaultVCpus")
        self.memory_mib = src.get("maxMemory")
        self.instance_family = src.get("instanceFamily")
        self.cpu_architecture = list(src.get("cpuArchitecture") or [])
        self.cpu_clock_speed_ghz = src.get("cpuClockSpeed")
        self.max_network_bandwidth = src.get("maxNetworkBandwidth")
        self.ebs_throughput = src.get("ebsThroughput")


class ECSContainerConfig:
    """
    Configuration for an ECS container.
    """

    container_name: str
    """
    The name of the container.
    """

    container_image: str
    """
    The image of the container.
    """

    memory_soft_limit: int
    """
    The soft memory limit of the container.
    """

    memory_hard_limit: int
    """
    The hard memory limit of the container.
    """

    cpu_soft_limit: int
    """
    The soft CPU limit of the container.
    """

    def __init__(
        self,
        container_name: str,
        container_image: str,
        memory_soft_limit: int,
        memory_hard_limit: int,
        cpu_soft_limit: int,
    ):
        """@private"""
        self.container_name = container_name
        self.container_image = container_image
        self.memory_soft_limit = memory_soft_limit
        self.memory_hard_limit = memory_hard_limit
        self.cpu_soft_limit = cpu_soft_limit


class ECSResourceConfig:
    """
    Configuration for an ECS resource.
    """

    desired_count: int
    """
    The desired count of the resource.
    """

    running_count: int
    """
    The running count of the resource.
    """

    task_cpu_hard_limit_units: float | None
    """
    The hard CPU limit of the task.
    """

    task_memory_hard_limit_mib: float | None
    """
    The hard memory limit of the task.
    """

    container_configs: list[ECSContainerConfig]
    """
    The container configurations for the resource.
    """

    def __init__(
        self,
        desired_count: int,
        running_count: int,
        task_cpu_hard_limit_units: float | None,
        task_memory_hard_limit_mib: float | None,
        container_configs: list[ECSContainerConfig],
    ):
        """@private"""
        self.desired_count = desired_count
        self.running_count = running_count
        self.task_cpu_hard_limit_units = task_cpu_hard_limit_units
        self.task_memory_hard_limit_mib = task_memory_hard_limit_mib
        self.container_configs = container_configs


class KubeResourceConfig:
    """
    Configuration for a Kubernetes resource.
    """

    def __init__(self, container_configs: dict[str, KubeContainerConfig], replicas: int):
        """@private"""
        self.container_configs = container_configs
        self.replicas = replicas


class KubeHpaMetric:
    """
    One metric a Kubernetes HorizontalPodAutoscaler (HPA) scales on, with its target.
    """

    source: str | None
    """
    Where the metric comes from: `RESOURCE`, `CONTAINER_RESOURCE`, `PODS`, `OBJECT` or `EXTERNAL`.
    """

    resource_name: str | None
    """
    The resource measured (for example `cpu` or `memory`). Set for `RESOURCE` and
    `CONTAINER_RESOURCE` metrics, None otherwise.
    """

    container_name: str | None
    """
    The container measured. Set for `CONTAINER_RESOURCE` metrics, None otherwise.
    """

    metric_name: str | None
    """
    The metric's name. Set for `PODS`, `OBJECT` and `EXTERNAL` metrics, None otherwise.
    """

    target_type: str | None
    """
    How the target is expressed: `Utilization`, `AverageValue` or `Value`. It says which of the
    three target fields below applies.
    """

    target_average_utilization: int | None
    """
    The target average utilization, as a percentage (for example 85). Only meaningful when
    `target_type` is `Utilization`; Sedai may report 0 otherwise.
    """

    target_average_value: float | None
    """
    The target average value. Only meaningful when `target_type` is `AverageValue`.
    """

    target_value: float | None
    """
    The target value. Only meaningful when `target_type` is `Value`.
    """

    def __init__(self, src: dict):
        """@private"""
        self.source = src.get("metricSourceName")
        self.resource_name = src.get("resourceName")
        self.container_name = src.get("containerName")
        self.metric_name = src.get("metricName")
        self.target_type = src.get("targetMetricType")
        self.target_average_utilization = src.get("targetAverageUtilization")
        self.target_average_value = src.get("targetAverageValue")
        self.target_value = src.get("targetValue")


class KubeHpaSpec:
    """
    The settings of a Kubernetes HorizontalPodAutoscaler (HPA): how far it may scale a workload,
    and what it scales on.
    """

    min_replicas: int | None
    """
    The fewest replicas the autoscaler keeps.
    """

    max_replicas: int | None
    """
    The most replicas the autoscaler may add.
    """

    metrics: list[KubeHpaMetric]
    """
    The metrics the autoscaler scales on, with their targets. Empty when Sedai has recorded none.
    """

    def __init__(self, src: dict):
        """@private"""
        self.min_replicas = src.get("minReplicas")
        self.max_replicas = src.get("maxReplicas")
        self.metrics = [KubeHpaMetric(metric) for metric in src.get("metrics") or [] if metric]


class LambdaResourceConfig:
    """
    Configuration for a Serverless Lambda resource.
    """

    memory_size: int
    """
    The memory size configured for the Lambda function.
    """

    timeout: int
    """
    The timeout configured for the Lambda function.
    """

    reserved_concurrency: int | None
    """
    The reserved concurrency of the Lambda function if configured.
    """

    provisioned_concurrency: int | None
    """
    The provisioned concurrency of the Lambda function if configured.
    """

    def __init__(
        self,
        memory_size: int,
        timeout: int,
        reserved_concurrency: int | None,
        provisioned_concurrency: int | None,
    ):
        """@private"""
        self.memory_size = memory_size
        self.timeout = timeout
        self.reserved_concurrency = reserved_concurrency
        self.provisioned_concurrency = provisioned_concurrency
