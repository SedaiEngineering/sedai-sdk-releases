from types import SimpleNamespace

from sedai.__impl import api, log
from sedai.optimizations.models import (
    AzureDiskConfig,
    EBSVolumeConfig,
    ECSContainerConfig,
    ECSResourceConfig,
    GCPBucketConfig,
    KubeContainerConfig,
    KubeHpaSpec,
    KubeResourceConfig,
    LambdaResourceConfig,
    NodegroupDetails,
    S3BucketConfig,
    S3IntelligentTieringConfig,
    S3LifecycleRule,
    VMInstanceSpec,
)


class Operation:
    """
    Base class for all operations.
    """

    action: str
    """
    The action that the operation is performing.
    """

    raw: dict | None = None
    """
    Everything Sedai sent for this operation, as a dictionary. Set only when this version of the SDK
    does not recognise the operation's type, so that its before and after values are still
    available; `raw["type"]` names the type. None for every type listed in this module, whose values
    are in the typed fields instead. The keys are Sedai's own and are not part of the SDK's
    interface, so they may change between Sedai releases.
    """

    def __init__(self, src: dict, /):
        """@private"""
        self._src = src
        self.__parse__()

    def __parse__(self):
        self.action = self._src["actionName"]


class KubeNodePoolOperation(Operation):
    """
    Represents a Kubernetes node pool operation.
    """

    current_state: NodegroupDetails
    """
    The current configuration of the node pool.
    """

    proposed_state: NodegroupDetails
    """
    The proposed configuration of the node pool.
    """

    def __parse__(self):
        super().__parse__()
        current_state = self._src["oneSignal"]["currentState"]
        proposed_state = self._src["oneSignal"]["proposedState"]
        self.current_state = (
            NodegroupDetails(
                instance_type=current_state["instanceType"],
                memory_bytes=current_state["memoryInBytes"],
                num_nodes=current_state["numberOfNodes"],
                vcpus=current_state["vcpus"],
                min_num_nodes=None,
                max_num_nodes=None,
            )
            if current_state
            else None
        )
        self.proposed_state = (
            NodegroupDetails(
                instance_type=proposed_state["instanceType"],
                memory_bytes=proposed_state["memoryInBytes"],
                num_nodes=proposed_state["numberOfNodes"],
                vcpus=proposed_state["vcpus"],
                min_num_nodes=None,
                max_num_nodes=None,
            )
            if proposed_state
            else None
        )


class S3BucketOperation(Operation):
    """
    Represents an S3 bucket operation.
    """

    bucket_name: str
    """
    The name of the S3 bucket.
    """

    current_state: S3BucketConfig
    """
    The current configuration of the S3 bucket.
    """

    proposed_state: S3BucketConfig
    """
    The proposed configuration of the S3 bucket.
    """

    def __parse__(self):
        super().__parse__()
        self.bucket_name = self._src["bucketName"]
        self.current_state = S3BucketConfig(
            bucket_name=self._src["bucketName"],
            intelligent_tiering_configs=[
                S3IntelligentTieringConfig(
                    config_id=config["configId"],
                    prefix=config["prefix"],
                    tags=config["tags"],
                    archive_threshold_days=config["archiveThresholdInDays"],
                )
                for config in self._src["configStates"]
                .get("current", {})
                .get("intelligentTieringConfigs", [])
            ],
            lifecycle_rules=[
                S3LifecycleRule(
                    rule_id=rule["id"],
                    enabled=rule["enabled"],
                    transitions=rule["transitions"],
                )
                for rule in self._src["configStates"].get("current", {}).get("lifecycleRules", [])
            ],
        )
        self.proposed_state = S3BucketConfig(
            bucket_name=self._src["bucketName"],
            intelligent_tiering_configs=[
                S3IntelligentTieringConfig(
                    config_id=config["configId"],
                    prefix=config["prefix"],
                    tags=config["tags"],
                    archive_threshold_days=config["archiveThresholdInDays"],
                )
                for config in self._src["configStates"]
                .get("proposed", {})
                .get("intelligentTieringConfigs", [])
            ],
            lifecycle_rules=[
                S3LifecycleRule(
                    rule_id=rule["id"],
                    enabled=rule["enabled"],
                    transitions=rule["transitions"],
                )
                for rule in self._src["configStates"].get("proposed", {}).get("lifecycleRules", [])
            ],
        )


class EBSTypeTuningOperation(Operation):
    """
    Represents an EBS volume type tuning operation.
    """

    current_state: EBSVolumeConfig
    """
    The current configuration of the EBS volume.
    """

    proposed_state: EBSVolumeConfig
    """
    The proposed configuration of the EBS volume.
    """

    def __parse__(self):
        super().__parse__()
        original_config = self._src["configStates"]["originalConfig"]
        target_config = self._src["configStates"]["targetConfig"]
        self.current_state = EBSVolumeConfig(original_config) if original_config else None
        self.proposed_state = EBSVolumeConfig(target_config) if target_config else None


class VMStorageRightSizingOperation(Operation):
    """
    Represents a VM storage right sizing operation.
    """

    resource_name: str
    """
    The name of the resource.
    """

    current_disk_size_gb: int
    """
    The current disk size in GB.
    """

    proposed_disk_size_gb: int
    """
    The proposed disk size in GB.
    """

    def __parse__(self):
        super().__parse__()
        self.resource_name = self._src["oneSignal"]["resourceName"]
        self.current_disk_size_gb = self._src["oneSignal"]["currentDiskSizeInGB"]
        self.proposed_disk_size_gb = self._src["oneSignal"]["proposedDiskSizeInGB"]


class VMRightSizingOperation(Operation):
    """
    Represents an operation that changes a virtual machine's instance type, such as rightsizing and
    rolling it back. Sedai also uses this type to put an instance back to an earlier instance type
    (action `HARD_RESET`) and to resize an instance to an instance type someone asked for
    (`RESIZE_INSTANCE`). `action` says which.
    """

    instance_ids: list[str]
    """
    The IDs of the instances the operation changes, as Sedai records them. On AWS these are the EC2
    instance IDs (for example `i-0abc123def4567890`); on other clouds they can be Sedai's own
    resource IDs.
    """

    current_state: VMInstanceSpec | None
    """
    The instance type before the operation.
    """

    proposed_state: VMInstanceSpec | None
    """
    The instance type the operation changes to.
    """

    def __parse__(self):
        super().__parse__()
        self.instance_ids = list(self._src.get("instanceIds") or [])
        current_spec = self._src.get("currentSpec")
        proposed_spec = self._src.get("proposedSpec")
        self.current_state = VMInstanceSpec(current_spec) if current_spec else None
        self.proposed_state = VMInstanceSpec(proposed_spec) if proposed_spec else None


class AzureDiskTypeTuningOperation(Operation):
    """
    Represents an Azure disk type tuning operation, which changes the disk type and performance
    tier.
    """

    current_state: AzureDiskConfig | None
    """
    The disk's configuration before the operation.
    """

    proposed_state: AzureDiskConfig | None
    """
    The disk configuration the operation changes to.
    """

    def __parse__(self):
        super().__parse__()
        config_states = self._src.get("configStates") or {}
        original_config = config_states.get("originalConfig")
        target_config = config_states.get("targetConfig")
        self.current_state = AzureDiskConfig(original_config) if original_config else None
        self.proposed_state = AzureDiskConfig(target_config) if target_config else None


class GCPBucketAutoclassOperation(Operation):
    """
    Represents a Google Cloud Storage bucket operation that turns on Autoclass.
    """

    bucket_name: str | None
    """
    The name of the bucket.
    """

    current_state: GCPBucketConfig | None
    """
    The bucket's configuration before the operation.
    """

    proposed_state: GCPBucketConfig | None
    """
    The bucket configuration the operation changes to.
    """

    def __parse__(self):
        super().__parse__()
        self.bucket_name = self._src.get("bucketName")
        config_states = self._src.get("configStates") or {}
        current = config_states.get("current")
        proposed = config_states.get("proposed")
        self.current_state = GCPBucketConfig(current) if current else None
        self.proposed_state = GCPBucketConfig(proposed) if proposed else None


class ECSClusterOperation(Operation):
    """
    Represents an ECS cluster operation.
    """

    current_nodegroups: list[NodegroupDetails]
    """
    The current node groups in the ECS cluster.
    """

    proposed_nodegroups: list[NodegroupDetails]
    """
    The proposed node groups in the ECS cluster.
    """

    def __parse__(self):
        super().__parse__()
        self.current_nodegroups = [
            NodegroupDetails(
                name=nodegroup["nodeGroupName"],
                instance_type=nodegroup["instanceType"],
                memory_bytes=nodegroup["memoryInBytes"],
                num_nodes=nodegroup["numberOfNodes"],
            )
            for nodegroup in self._src["currentNodeGroups"]
        ]
        self.proposed_nodegroups = [
            NodegroupDetails(
                name=nodegroup["nodeGroupName"],
                instance_type=nodegroup["instanceType"],
                memory_bytes=nodegroup["memoryInBytes"],
                num_nodes=nodegroup["numberOfNodes"],
            )
            for nodegroup in self._src["recommNodeGroups"]
        ]


class ECSAppOperation(Operation):
    """
    Represents an ECS app operation.
    """

    current_state: ECSResourceConfig
    """
    The current configuration of the ECS app.
    """

    proposed_state: ECSResourceConfig
    """
    The proposed configuration of the ECS app.
    """

    def __parse__(self):
        super().__parse__()
        ecs_config = self._src["ecsResourceConfigStateWrapper"]
        old_config_state = ecs_config["oldECSResourceConfigState"] if ecs_config else None
        new_config_state = ecs_config["newECSResourceConfigState"] if ecs_config else None
        self.current_state = (
            ECSResourceConfig(
                desired_count=old_config_state["desiredCount"],
                running_count=old_config_state["runningCount"],
                task_cpu_hard_limit_units=old_config_state["taskCpuHardLimitInUnits"],
                task_memory_hard_limit_mib=old_config_state["taskMemoryHardLimitInMiB"],
                container_configs=[
                    ECSContainerConfig(
                        container_name=container["containerName"],
                        container_image=container["containerImage"],
                        memory_soft_limit=container["memorySoftLimit"],
                        memory_hard_limit=container["memoryHardLimit"],
                        cpu_soft_limit=container["cpuSoftLimit"],
                    )
                    for container in old_config_state["containerLimits"]
                ],
            )
            if old_config_state
            else None
        )
        self.proposed_state = (
            ECSResourceConfig(
                desired_count=new_config_state["desiredCount"],
                running_count=new_config_state["runningCount"],
                task_cpu_hard_limit_units=new_config_state["taskCpuHardLimitInUnits"],
                task_memory_hard_limit_mib=new_config_state["taskMemoryHardLimitInMiB"],
                container_configs=[
                    ECSContainerConfig(
                        container_name=container["containerName"],
                        container_image=container["containerImage"],
                        memory_soft_limit=container["memorySoftLimit"],
                        memory_hard_limit=container["memoryHardLimit"],
                        cpu_soft_limit=container["cpuSoftLimit"],
                    )
                    for container in new_config_state["containerLimits"]
                ],
            )
            if new_config_state
            else None
        )


def _kube_container_value(container: dict, name: str) -> SimpleNamespace | None:
    """One CPU or memory value of a container, such as `memoryRequest`, in the same shape
    `get_resource_optimizations` gives: an object with `value` and `metricUnit`. None when the
    server says the container doesn't set it (`<name>NotSet`) or leaves it out."""
    value = container.get(f"{name}Value")
    if container.get(f"{name}NotSet") or value is None:
        return None
    if not isinstance(value, dict):
        # The server declares these as objects, so this isn't expected. Hand over what it sent, as
        # get_resource_optimizations does, rather than report a value that is there as not set.
        return value
    return SimpleNamespace(value=value.get("value"), metricUnit=value.get("metricUnit"))


def _kube_container_config(container: dict) -> KubeContainerConfig:
    return KubeContainerConfig(
        mem_req=_kube_container_value(container, "memoryRequest"),
        mem_limit=_kube_container_value(container, "memoryLimit"),
        cpu_req=_kube_container_value(container, "cpuRequest"),
        cpu_limit=_kube_container_value(container, "cpuLimit"),
    )


class KubeAppOperation(Operation):
    """
    Represents a Kubernetes app operation.
    """

    original_config: KubeResourceConfig
    """
    The original configuration of the Kubernetes app.
    """

    proposed_config: KubeResourceConfig
    """
    The proposed configuration of the Kubernetes app.
    """

    original_hpa: KubeHpaSpec | None
    """
    The app's HorizontalPodAutoscaler (HPA) settings before the operation. None when Sedai recorded
    no autoscaler for the app.
    """

    proposed_hpa: KubeHpaSpec | None
    """
    The HorizontalPodAutoscaler (HPA) settings after the operation, when the operation sets them.
    When it is None, `action` tells you what that means:

    - After `KUBERNETES_DELETE_HPA`, `KUBERNETES_DELETE_HPA_AND_PERFORM_RIGHTSIZING`,
      `USER_DRIVEN_ROLLBACK_KUBERNETES_DELETE_HPA_AND_PERFORM_RIGHTSIZING` or
      `USER_DRIVEN_ROLLBACK_TO_PREVIOUS_RELEASE`, the app has no autoscaler: the operation removes
      the one in `original_hpa`, if there was one. (A rollback to a previous release that had an
      autoscaler has `proposed_hpa` set.)
    - After any other action, for example a plain rightsizing, the autoscaler is left as it was, so
      `original_hpa` still applies.

    These four actions are Sedai's own list, which may grow in later Sedai versions.
    """

    def __parse__(self):
        super().__parse__()
        original_hpa = self._src.get("origKubeHorizontalPodAutoscalerSpec")
        proposed_hpa = self._src.get("proposedKubeHorizontalPodAutoscalerSpec")
        self.original_hpa = KubeHpaSpec(original_hpa) if original_hpa else None
        self.proposed_hpa = KubeHpaSpec(proposed_hpa) if proposed_hpa else None
        self.original_config = KubeResourceConfig(
            container_configs={
                container_name: _kube_container_config(container)
                for container_name, container in self._src["originalConfig"]
                .get("kubeContainerConfigStateMap", {})
                .items()
            },
            replicas=self._src["originalConfig"].get("replicas", None),
        )
        self.proposed_config = KubeResourceConfig(
            container_configs={
                container_name: _kube_container_config(container)
                for container_name, container in self._src["proposedConfig"]
                .get("kubeContainerConfigStateMap", {})
                .items()
            },
            replicas=self._src["proposedConfig"].get("replicas", None),
        )


class ServerlessFunctionOperation(Operation):
    """
    An operation on a serverless function.
    """

    function_name: str
    """
    The name of the serverless function.
    """

    original_config: LambdaResourceConfig
    """
    The original configuration of the serverless function.
    """

    proposed_config: LambdaResourceConfig
    """
    The proposed configuration of the serverless function.
    """

    def __parse__(self):
        super().__parse__()
        self.function_name = self._src["functionName"]

        original_config = self._src["originalConfig"]
        proposed_config = self._src["proposedConfig"]

        self.original_config = (
            LambdaResourceConfig(
                memory_size=original_config["memorySize"],
                timeout=original_config["timeout"],
                reserved_concurrency=original_config["reservedConcurrency"],
                provisioned_concurrency=original_config["provisionedConcurrency"],
            )
            if original_config
            else None
        )
        self.proposed_config = (
            LambdaResourceConfig(
                memory_size=proposed_config["memorySize"],
                timeout=proposed_config["timeout"],
                reserved_concurrency=proposed_config["reservedConcurrency"],
                provisioned_concurrency=proposed_config["provisionedConcurrency"],
            )
            if proposed_config
            else None
        )


class MemoryOperation(ServerlessFunctionOperation):
    """
    An operation on a serverless function to scale memory.
    """

    initial_memory: int
    """
    The initial memory of the Lambda function.
    """

    new_memory: int
    """
    The new memory of the Lambda function.
    """

    def __parse__(self):
        super().__parse__()
        self.initial_memory = self._src["initialMemory"]
        self.new_memory = self._src["newMemory"]


class ScaleDownMemoryOperation(MemoryOperation):
    """
    Represents a scale down memory operation.
    """

    def __parse__(self):
        super().__parse__()


class ScaleUpMemoryOperation(MemoryOperation):
    """
    Represents a scale up memory operation.
    """

    def __parse__(self):
        super().__parse__()


class TimeoutOperation(ServerlessFunctionOperation):
    """
    An operation on a serverless function to scale timeout.
    """

    initial_timeout: int
    """
    The initial timeout of the Lambda function.
    """

    new_timeout: int
    """
    The new timeout of the Lambda function.
    """

    def __parse__(self):
        super().__parse__()
        self.initial_timeout = self._src["initialTimeout"]
        self.new_timeout = self._src["newTimeout"]


class IncreaseTimeoutOperation(TimeoutOperation):
    """
    Represents an increase timeout operation.
    """

    def __parse__(self):
        super().__parse__()


class DecreaseTimeoutOperation(TimeoutOperation):
    """
    Represents a decrease timeout operation.
    """

    def __parse__(self):
        super().__parse__()


class IncreaseReservedConcurrencyOperation(ServerlessFunctionOperation):
    """
    An operation to increase the reserved concurrency of a Lambda function.
    """

    initial_reserved_concurrency: int
    """
    The initial reserved concurrency of the Lambda function.
    """

    new_reserved_concurrency: int | None
    """
    The new reserved concurrency of the Lambda function.
    """

    def __parse__(self):
        super().__parse__()
        self.initial_reserved_concurrency = self._src["initialReservedConcurrency"]
        self.new_reserved_concurrency = self._src["newReservedConcurrency"]


class DecreaseReservedConcurrencyOperation(ServerlessFunctionOperation):
    """
    Represents a decrease reserved concurrency operation.
    """

    initial_reserved_concurrency: int
    """
    The initial reserved concurrency of the Lambda function.
    """

    new_reserved_concurrency: int | None
    """
    The new reserved concurrency of the Lambda function.
    """

    def __parse__(self):
        super().__parse__()
        self.initial_reserved_concurrency = self._src["initialReservedConcurrency"]
        self.new_reserved_concurrency = self._src["newReservedConcurrency"]


class IncreaseProvisionedConcurrencyOperation(ServerlessFunctionOperation):
    """
    An operation to increase the provisioned concurrency of a Lambda function.
    """

    initial_provisioned_concurrency: int
    """
    The initial provisioned concurrency of the Lambda function.
    """

    new_provisioned_concurrency: int | None
    """
    The new provisioned concurrency of the Lambda function.
    """

    function_version: str
    """
    The version of the Lambda function.
    """

    def __parse__(self):
        super().__parse__()
        self.initial_provisioned_concurrency = self._src["initialProvisionedConcurrency"]
        self.new_provisioned_concurrency = self._src["newProvisionedConcurrency"]
        self.function_version = self._src["functionVersion"]


class DecreaseProvisionedConcurrencyOperation(ServerlessFunctionOperation):
    """
    Represents a decrease provisioned concurrency operation.
    """

    initial_provisioned_concurrency: int
    """
    The initial provisioned concurrency of the Lambda function.
    """

    new_provisioned_concurrency: int | None
    """
    The new provisioned concurrency of the Lambda function.
    """

    function_version: str
    """
    The version of the Lambda function.
    """

    def __parse__(self):
        super().__parse__()
        self.initial_provisioned_concurrency = self._src["initialProvisionedConcurrency"]
        self.new_provisioned_concurrency = self._src["newProvisionedConcurrency"]
        self.function_version = self._src["functionVersion"]


__OPERATION_TYPE_MAP = {
    "KubeNodePoolOperation": KubeNodePoolOperation,
    "S3BucketOperation": S3BucketOperation,
    "EBSTypeTuningOperation": EBSTypeTuningOperation,
    "VMStorageRightSizingOperation": VMStorageRightSizingOperation,
    "RightSizingOperation": VMRightSizingOperation,
    "AzureDiskTypeTuningOperation": AzureDiskTypeTuningOperation,
    "GCPBucketAutoclassOperation": GCPBucketAutoclassOperation,
    "ECSClusterOperation": ECSClusterOperation,
    "ECSAppOperation": ECSAppOperation,
    "KubernetesAppOperation": KubeAppOperation,
    "ScaleDownMemoryOperation": ScaleDownMemoryOperation,
    "ScaleUpMemoryOperation": ScaleUpMemoryOperation,
    "IncreaseTimeoutOperation": IncreaseTimeoutOperation,
    "DecreaseTimeoutOperation": DecreaseTimeoutOperation,
    "IncreaseReservedConcurrencyOperation": IncreaseReservedConcurrencyOperation,
    "DecreaseReservedConcurrencyOperation": DecreaseReservedConcurrencyOperation,
    "IncreaseProvisionedConcurrencyOperation": IncreaseProvisionedConcurrencyOperation,
    "DecreaseProvisionedConcurrencyOperation": DecreaseProvisionedConcurrencyOperation,
}


def get_operation(operation_id):
    """
    @private
    """
    endpoint = f"/api/operations/{operation_id}"
    request = api.GetRequest(endpoint)
    response = api.do_get(request)

    if response["status"] != "OK":
        log(f"Failed to fetch operation: {response['message']}")

    op_details = response["result"]
    operation_type = op_details["operation"]["type"]
    op_class = __OPERATION_TYPE_MAP.get(operation_type, Operation)
    operation = op_class(op_details["operation"])
    if op_class is Operation:
        operation.raw = op_details["operation"]
    return operation
