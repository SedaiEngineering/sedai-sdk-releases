import copy
from collections import deque
from collections.abc import Callable
from typing import Generic, TypeVar

from sedai.__impl import log
from sedai.__impl.pagination import PaginatedResponse

T = TypeVar("T")
"""
@private
"""


class PaginationConfig:
    """
    The pagination configuration for retrieving elements from a paginated API.
    Functions that support pagination accept this configuration as a named argument
    and return a `PageIterator` object that iterates over elements in the collection, by
    retrieving pages from the API based on the parameters set in this configuration.
    The configuration you pass is not changed, so it can be reused for any number of calls.
    """

    page_size: int | None
    """
    The number of elements to fetch in a single page. Defaults to 20.
    """

    start: int | None
    """
    The page to start fetching from, counting from 1: `1` is the first page, `2` the second, and so
    on. If None, fetching starts at the first page. A value below 1 raises `ValueError`.
    """

    order_by: str | None
    """
    The field to order the results by.
    """

    order_dir: str | None
    """
    The direction to order the results by. Can be either `ASC` or `DESC`.
    """

    num_pages: int | None
    """
    The number of pages to fetch, beginning at `start`. If None, all pages are fetched. A value below
    1 raises `ValueError`.
    """

    def __init__(
        self,
        page_size: int | None = 20,
        start: int | None = None,
        order_by: str | None = None,
        order_dir: str | None = None,
        num_pages: int | None = None,
    ):
        """@private"""
        self.page_size = page_size
        self.start = start
        self.order_by = order_by
        self.order_dir = order_dir
        self.num_pages = num_pages


DEFAULT_PAGINATION_CONFIG = PaginationConfig(page_size=20)
"""
The default pagination configuration. Fetches 20 elements per page until all pages are fetched.
"""


class PageIterator(Generic[T]):
    """
    An iterator that fetches collections of elements in pages.
    The iterator makes subsequent API requests to fetch pages of elements until
    your code hits 'break', the end of the collection is reached, or the specified
    number of pages are fetched.
    """

    total_pages: int
    """
    The total number of pages in the collection.
    """

    def __init__(
        self,
        params: dict,
        page_loader: Callable[[dict, PaginationConfig], PaginatedResponse],
        page_config: PaginationConfig,
    ):
        """@private"""
        if page_config.start is not None and page_config.start < 1:
            raise ValueError("pagination_config.start must be 1 or more: pages are counted from 1")
        if page_config.num_pages is not None and page_config.num_pages < 1:
            raise ValueError("pagination_config.num_pages must be 1 or more")
        # Work on a copy: the iterator moves start forward page by page, and the caller's config
        # (often the shared DEFAULT_PAGINATION_CONFIG) must stay as it was so it can be reused.
        page_config = copy.copy(page_config)
        if page_config.start is None:
            page_config.start = 1
        self.__params = params
        self.__page_loader = page_loader
        self.__page_config = page_config
        self.__elements = deque()
        self.__pages_fetched = 0
        self.total_pages = 0

        # fetch first page
        self.__next_page()

    def __iter__(self):
        return self

    def __next__(self) -> T:
        if not self.has_next():
            raise StopIteration

        return self.__elements.popleft()

    def __has_next_element(self):
        return len(self.__elements) > 0

    def __has_next_page(self):
        # num_pages counts the pages fetched, not a page number, so it holds for any start.
        return self.__page_config.start is not None and (
            self.__page_config.num_pages is None
            or self.__pages_fetched < self.__page_config.num_pages
        )

    def __next_page(self):
        requested_page = self.__page_config.start
        response = self.__page_loader(self.__params, self.__page_config)
        self.__pages_fetched += 1
        if response is None:
            # Some page loaders return None instead of an empty page at the end of the collection.
            self.__page_config.start = None
            return
        self.total_pages = response.total_pages
        next_page = response.next_page
        if next_page is not None and next_page <= requested_page:
            # Empty pages no longer end iteration, so stop here rather than loop forever on an
            # API that does not move forward.
            log(f"Stopping pagination: next page {next_page} does not follow page {requested_page}")
            next_page = None
        self.__page_config.start = next_page
        self.__elements.extend(response.content)

    def has_next(self):
        """
        Returns True if there is another element. Fetches pages as needed to find out, since a page
        can come back empty while the API still reports more pages.
        """
        # An empty page is not the end of the collection while the API still reports a next page
        # (for example, when every row on a page was skipped during parsing), so keep fetching.
        while not self.__has_next_element() and self.__has_next_page():
            self.__next_page()
        return self.__has_next_element()
