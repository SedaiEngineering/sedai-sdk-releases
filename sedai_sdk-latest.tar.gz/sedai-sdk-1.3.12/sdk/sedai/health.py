from datetime import datetime
from typing import List, Optional

from sedai.__impl import api, log
from sedai.util import parse_timestamp


class AgentJobHealth:
    """
    Represents the health status of an individual job running in an agent.
    """

    job_id: str
    """Identifier of the job."""
    message: str
    """Status message for the job."""
    last_refreshed_on: datetime
    """Timestamp when the job was last refreshed."""
    health_check_time: datetime
    """Timestamp of the last health check."""
    refresh_interval: int
    """Interval in milliseconds between job refreshes."""
    is_healthy: bool
    """Whether the job is currently healthy."""
    job_status: str
    """Latest status of the job."""
    last_healthy_on: datetime
    """Timestamp when the job was last healthy."""

    def __init__(self, src: dict):
        """@private"""
        self.__parse__(src)

    def __parse__(self, src: dict):
        self.job_id = src.get("jobId")

        self.message = src.get("message")
        self.last_refreshed_on = parse_timestamp(src.get("lastRefreshedOn"))
        self.health_check_time = parse_timestamp(src.get("healthCheckTime"))
        self.refresh_interval = src.get("refreshInterval")
        self.is_healthy = src.get("healthy")
        self.job_status = src.get("jobStatus")
        self.last_healthy_on = parse_timestamp(src.get("lastHealthyOn"))


class AgentHealthDetails:
    """
    Contains detailed health information for all jobs running in an agent.
    """

    job_health_list: List[AgentJobHealth]
    """List of health statuses for each job in the agent."""

    def __init__(self, src: dict):
        """@private"""
        self.__parse__(src)

    def __parse__(self, src: dict):
        self.job_health_list = [AgentJobHealth(j) for j in (src.get("jobHealthList") or [])]


class AgentHealth:
    """
    Represents the overall health status of a deployed Sedai agent.
    """

    account_id: str
    """Sedai account ID associated with this agent."""
    account_name: str
    """Name of the account."""
    name: str
    """Name of the agent."""
    is_healthy: bool
    """Whether the agent is currently healthy."""
    connection_type: str
    """Connection type used by the agent."""
    version: str
    """Current version of the agent."""
    spec_controller_version: Optional[str]
    """Version of the kube spec controller if available."""
    upgrade_needed: bool
    """Whether the agent needs to be upgraded."""
    last_supported_version: str
    """Last supported version of the agent."""
    desired_version: str
    """Desired version for the agent."""
    is_agent_available: bool
    """Whether the agent is available."""
    live_connection_status: bool
    """Whether the agent has an active live connection."""
    details: AgentHealthDetails
    """Detailed health information for the agent's jobs."""

    def __init__(self, src: dict):
        """@private"""
        self.__parse__(src)

    def __parse__(self, src: dict):
        self.account_id = src.get("accountId")
        self.account_name = src.get("accountName")
        self.name = src.get("name")
        self.is_healthy = src.get("healthy")

        self.connection_type = src.get("connectionType")

        self.version = src.get("version")
        self.spec_controller_version = src.get("specControllerVersion")
        self.upgrade_needed = src.get("upgradeNeeded")
        self.last_supported_version = src.get("lastSupportedVersion")
        self.desired_version = src.get("desiredVersion")
        self.is_agent_available = src.get("agentAvailable")
        self.live_connection_status = src.get("liveConnectionStatus")

        details_raw = src.get("details")
        self.details = AgentHealthDetails(details_raw) if details_raw is not None else None


def get_agent_health() -> Optional[List[AgentHealth]]:
    """
    Get the health status of all deployed Sedai agents.

    :return: A list of AgentHealth objects, or None if the request fails.

    Each AgentHealth object contains:

    - **account_id** — Sedai account ID
    - **account_name** — account name
    - **name** — agent name
    - **is_healthy** — whether the agent is healthy
    - **connection_type** — ``AgentConnectionType.WS`` or ``AgentConnectionType.REST``
    - **version** — current agent version
    - **spec_controller_version** — spec controller version
    - **upgrade_needed** — whether the agent needs upgrading
    - **last_supported_version** — last supported version
    - **desired_version** — desired version
    - **is_agent_available** — whether the agent is available
    - **live_connection_status** — live connection status
    - **details** — ``AgentHealthDetails`` with a ``job_health_list`` of ``AgentJobHealth`` objects
    - **last_email_sent_time** — last notification email time
    - **created_time** — record creation time
    - **updated_time** — record last update time

    Sample code:

    .. code-block:: python

        from sedai import health

        agents = health.get_agent_health()
        if agents:
            for agent in agents:
                print(f"{agent.name}: healthy={agent.is_healthy}, version={agent.version}")
                if agent.details:
                    for job in agent.details.job_health_list:
                        print(f"  Job {job.job_id}: healthy={job.is_healthy}")

    """
    request = api.GetRequest('/api/health/agents')
    response = api.do_get(request)
    if response['status'] == 'OK' and response['result'] is not None:
        return [AgentHealth(item) for item in response['result']]
    else:
        log(f"Failed to fetch agent health: {response.get('message')}")
        return None
