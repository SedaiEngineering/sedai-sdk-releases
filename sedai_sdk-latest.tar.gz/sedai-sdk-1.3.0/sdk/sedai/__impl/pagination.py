from typing import Any, List


class PaginatedResponse:
    def __init__(self, content: List[Any], next_page: int, total_pages: int = None):
        """
        @private
        :param content: The content of the current page.
        :param next_page: The 1-based index of the next page to fetch. If None, no more pages are available.
        :param total_pages: The total number of pages in the collection.
        """
        self.content = content
        self.next_page = next_page
        self.total_pages = total_pages
