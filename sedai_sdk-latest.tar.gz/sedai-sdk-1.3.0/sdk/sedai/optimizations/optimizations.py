from datetime import datetime
from types import SimpleNamespace
from typing import Dict, List, Optional

from sedai.__impl import api, log
from sedai.__impl.model_converter import transform
from sedai.optimizations.models import KubeContainerConfig, NodegroupConfig, WorkloadConfig
from sedai.util import __get_paginated_response


class NodegroupOptimization:
    """
    Optimizations for the nodegroup configuration of a cluster.
    """

    original_nodegroup_config: NodegroupConfig
    """
    The original nodegroup configuration for this cluster.
    """
    recommended_nodegroup_config_original: NodegroupConfig
    """
    Recommendations for the original nodegroup configuration for this cluster.
    """
    recommended_nodegroup_config_optimal: NodegroupConfig
    """
    Recommended optimal nodegroup configuration for this cluster.
    """

    def __init__(self):
        self.original_nodegroup_config = NodegroupConfig()
        self.recommended_nodegroup_config_original = NodegroupConfig()
        self.recommended_nodegroup_config_optimal = NodegroupConfig()


class ResourceOptimization:
    """
    Details of an optimization proposed for a resource.
    """

    resource_name: str
    """
    Name of the resource for which the optimization was proposed.
    """
    resource_id: str
    """
    ID of the resource for which the optimization was proposed.
    """
    account_id: str
    """
    Account ID of the resource for which the optimization was proposed.
    """
    optimization_time: Optional[datetime]
    """
    Time at which the optimization was performed for completed optimizations.
    """

    def __init__(
        self,
        resource_name: str,
        resource_id: str,
        account_id: str,
        optimization_time: Optional[datetime] = None,
    ):
        """@private"""
        self.resource_name = resource_name
        self.resource_id = resource_id
        self.account_id = account_id
        self.optimization_time = optimization_time


class KubeResourceOptimization(ResourceOptimization):
    """
    Details of an optimization proposed for a Kubernetes resource.
    """

    original_container_config: Dict[str, KubeContainerConfig]
    """
    The original container configuration of the Kubernetes resource.
    """
    recommended_container_config: Dict[str, KubeContainerConfig]
    """
    Optimized container configuration recommended by Sedai.
    """
    original_workload_config: WorkloadConfig
    """
    The original workload configuration of the Kubernetes resource.
    """
    recommended_workload_config: WorkloadConfig
    """
    Optimized workload configuration recommended by Sedai.
    """

    def __init__(
        self,
        resource_name: str,
        resource_id: str,
        account_id: str,
        original_config: Dict,
        recommended_config: Dict,
        optimization_time: Optional[datetime] = None,
    ):
        self.original_container_config = dict()
        self.recommended_container_config = dict()

        # TODO: Temporarily resolving name from ID
        if resource_name is None and resource_id is not None:
            resource_name = resource_id.split("/")[-1]

        super().__init__(
            resource_name=resource_name,
            resource_id=resource_id,
            account_id=account_id,
            optimization_time=optimization_time,
        )

        pre_container_config_map = original_config['kubeContainerConfigStateMap']
        post_container_config_map = recommended_config['kubeContainerConfigStateMap']
        for name, pre_config in pre_container_config_map.items():
            pre_cpu_limit = None
            pre_cpu_req = None
            pre_mem_limit = None
            pre_mem_req = None
            post_cpu_limit = None
            post_cpu_req = None
            post_mem_limit = None
            post_mem_req = None
            container_config_fields = ['value', 'metricUnit']
            post_config = post_container_config_map[name]

            if not pre_config['cpuRequestNotSet']:
                pre_cpu_req = transform(pre_config['cpuRequestValue'], container_config_fields)
            if not pre_config['cpuLimitNotSet']:
                pre_cpu_limit = transform(pre_config['cpuLimitValue'], container_config_fields)
            if not pre_config['memoryRequestNotSet']:
                pre_mem_req = transform(pre_config['memoryRequestValue'], container_config_fields)
            if not pre_config['memoryLimitNotSet']:
                pre_mem_limit = transform(pre_config['memoryLimitValue'], container_config_fields)

            if not post_config['cpuRequestNotSet']:
                post_cpu_req = transform(post_config['cpuRequestValue'], container_config_fields)
            if not post_config['cpuLimitNotSet']:
                post_cpu_limit = transform(post_config['cpuLimitValue'], container_config_fields)
            if not post_config['memoryRequestNotSet']:
                post_mem_req = transform(post_config['memoryRequestValue'], container_config_fields)
            if not post_config['memoryLimitNotSet']:
                post_mem_limit = transform(post_config['memoryLimitValue'], container_config_fields)
            pre_container_config = KubeContainerConfig(
                pre_mem_req, pre_mem_limit, pre_cpu_req, pre_cpu_limit
            )
            post_container_config = KubeContainerConfig(
                post_mem_req, post_mem_limit, post_cpu_req, post_cpu_limit
            )
            self.original_container_config[name] = pre_container_config
            self.recommended_container_config[name] = post_container_config

        pre_replicas = original_config['replicas']
        recommended_replicas = recommended_config['replicas']
        self.original_workload_config = WorkloadConfig(pre_replicas)
        self.recommended_workload_config = WorkloadConfig(recommended_replicas)


def _get_resource_optimization_from_opt_obj(
    opt_obj: Dict, original_config: Dict, recommended_config: Dict
) -> ResourceOptimization:
    resource_name = opt_obj['resourceName']
    resource_id = opt_obj['resourceId']
    account_id = opt_obj['accountId']
    config_type = original_config['type']
    optimization_time = None
    if 'optimizationTime' in opt_obj:
        optimization_time = (
            datetime.fromtimestamp(opt_obj['optimizationTime'] / 1000.0)
            if opt_obj['optimizationTime'] is not None
            else None
        )

    if config_type == "KubeResourceConfigState":
        optimization = KubeResourceOptimization(
            resource_name=resource_name,
            resource_id=resource_id,
            account_id=account_id,
            original_config=original_config,
            recommended_config=recommended_config,
            optimization_time=optimization_time,
        )
    else:
        optimization = ResourceOptimization(
            resource_name=resource_name,
            resource_id=resource_id,
            account_id=account_id,
            optimization_time=optimization_time,
        )
        optimization.original_resource_config = transform(original_config)
        optimization.recommended_resource_config = transform(recommended_config)

    return optimization


def get_resource_optimizations(
    account_id: str = None,
    resource_id: str = None,
    starttime: datetime = None,
    endtime: datetime = None,
    sort_by: str = None,
    sort_dir: str = None,
) -> List[ResourceOptimization]:
    """
    Get details of completed optimizations.
    :param account_id: Optional account ID to query for optimizations recommended
     for the given account.
    :param resource_id: Optional resource ID to query for optimizations recommended
     for the given resource.
    :param starttime: Retrieve optimizations performed after the given starttime.
    :param endtime: Retrieve optimizations performed before the given endtime.
    :param sort_by: Attribute to sort the retrieved optimizations by. Possible options are
        - `optimization_time`: The time at which the optimization was performed.
        - `cpu_change_core`: Change in CPU cores.
        - `cpu_change_vcpu`: Change in VCPUs.
        - `memory_change_mib`: Change in memory in MiBs.
        - `storage_change_gib`: Change in storage size in GiBs.
    :param sort_dir: Sort direction for retrieving optimizations. Possible options are `ASC` and `DESC`.
    """

    params = dict()
    if starttime:
        starttime_epoch_ms = starttime.timestamp() * 1000
        params['startTime'] = int(round(starttime_epoch_ms))
    if endtime:
        endtime_epoch_ms = endtime.timestamp() * 1000
        params['endTime'] = int(round(endtime_epoch_ms))
    if resource_id:
        params['resourceId'] = resource_id
    if account_id:
        params['accountId'] = account_id

    ORDER_BY_ATTRIBUTES = dict()
    ORDER_BY_ATTRIBUTES['optimization_time'] = 'post_release_time'
    ORDER_BY_ATTRIBUTES['cpu_change_core'] = 'cpu_change_core'
    ORDER_BY_ATTRIBUTES['cpu_change_vcpu'] = 'cpu_change_vcpu'
    ORDER_BY_ATTRIBUTES['memory_change_mib'] = 'memory_change_mib'
    ORDER_BY_ATTRIBUTES['storage_change_gib'] = 'storage_change_gib'

    if sort_by is not None:
        if sort_by not in ORDER_BY_ATTRIBUTES:
            raise ValueError(f"Invalid order_by attribute {sort_by}")

        sort_by = ORDER_BY_ATTRIBUTES[sort_by]

    endpoint = '/api/cumulative/report/optimizations/details'
    optimizations = list()

    for optimizations_page in __get_paginated_response(
        endpoint, params, order_by=sort_by, order_dir=sort_dir
    ):
        for optimization_obj in optimizations_page:
            original_config = optimization_obj['preConfigState']
            recommended_config = optimization_obj['postConfigState']
            recommendation = _get_resource_optimization_from_opt_obj(
                optimization_obj, original_config, recommended_config
            )
            optimizations.append(recommendation)

    return optimizations


def get_recommended_resource_state(resource_id: str) -> SimpleNamespace:
    """
    Get the latest available recommended state for a given resource.
    This is the state that Sedai automatically syncs resources to if Sedai Sync is enabled for that resource.
    :param resource_id: ID of the resource to retrieve the recommended state for.
    :return: The latest recommended resource state if available.
    """
    request = api.GetRequest(
        '/api/site/sedaisync/proposedconfig', params={"resourceId": resource_id}
    )
    response = api.do_get(request)

    if response['status'] != 'OK':
        log(f"Failed to get latest proposed sync state: {response['message']}")
        return None
    else:
        return transform(response['result'])
