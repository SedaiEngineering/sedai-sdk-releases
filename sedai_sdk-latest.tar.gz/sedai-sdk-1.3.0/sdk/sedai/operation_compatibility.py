from typing import Dict, List, Optional

from sedai import pagination
from sedai.__impl import api, log


class OperationBlocker:
    """
    Represents a barrier preventing a resource from being eligible for Sedai operation.
    """

    factor: str
    """
    Factor preventing the resource from being operation-friendly.
    """
    suggested_actions: List[str]
    """
    Suggested solutions to resolve the barrier.
    """
    active: bool
    """
    Whether the barrier is active.
    """

    def __init__(self, factor: str, suggested_actions: List[str], active: bool):
        """@private"""
        self.factor = factor
        self.suggested_actions = suggested_actions
        self.active = active


class OperationCompatibility:
    """
    The compatibility of a resource for Sedai operation. Certain barriers may prevent the resource from being eligible
    for Sedai operation. Resolve barriers to make resources operation-friendly.
    """

    resource_id: str
    """
    The Sedai id of the resource.
    """
    resource_name: str
    """
    Name of the resource.
    """
    is_compatible: bool
    """
    Whether the resource is eligible for Sedai action.
    """
    availability_mode: str
    """
    The availability mode of the resource.
    """
    optimization_mode: str
    """
    The optimization mode of the resource.
    """
    num_blockers: int
    """
    Number of barriers potentially preventing the resource from being eligible for Sedai operation.
    """
    num_positive_factors: int
    """
    Number of factors that make the resource eligible for Sedai operation.
    """
    positive_factors: Optional[List[str]]
    """
    Factors that make the resource eligible for Sedai operation.
    """
    blockers: Optional[List[OperationBlocker]]
    """
    Barriers potentially preventing the resource from being eligible for Sedai operation.
    """

    def __init__(
        self,
        resource_id: str,
        resource_name: str,
        is_compatible: bool,
        availability_mode: str,
        optimization_mode: str,
        num_blockers: int,
        num_positive_factors: int,
        positive_factors: Optional[List[str]],
        blockers: Optional[List[OperationBlocker]],
    ):
        """@private"""
        self.resource_id = resource_id
        self.resource_name = resource_name
        self.is_compatible = is_compatible
        self.availability_mode = availability_mode
        self.optimization_mode = optimization_mode
        self.num_blockers = num_blockers
        self.num_positive_factors = num_positive_factors
        self.positive_factors = positive_factors
        self.blockers = blockers


def get_operation_compatibility(
    account_ids: Optional[List[str]] = None,
    optimization_modes: Optional[List[str]] = None,
    availability_modes: Optional[List[str]] = None,
    is_compatible: Optional[bool] = False,
    include_factors: Optional[bool] = False,
    pagination_config: Optional[pagination.PaginationConfig] = None,
) -> pagination.PageIterator[OperationCompatibility]:
    """
    Get the eligibility status for resources to be operated on by Sedai, including any barriers preventing operation.
    Returns the operation compatibility for resources, and the number of positive and negative factors that
    determine the eligibility of the resource for Sedai operation. Optionally include details about these factors,
    and suggested actions to resolve barriers by passing `include_factors=True`.
    :param account_ids: Optional list of account ids to get eligibility for. If None, all accounts are considered.
    :param optimization_modes: Optional list of optimization modes. Possible values are
        - `DATA_PILOT`: Sedai will not optimize the resource.
        - `CO_PILOT`: Sedai will give recommendations for the optimization of the resource, but the user has to manually apply the recommendations.
        - `AUTO`: Sedai will attempt to autonomously optimize the resource.

    If None, all optimization modes are retrieved.
    :param availability_modes: Optional list of availability modes. Possible values are
        - `DATA_PILOT`: Sedai will not optimize the resource.
        - `CO_PILOT`: Sedai will give recommendations for the optimization of the resource, but the user has to manually apply the recommendations.
        - `AUTO`: Sedai will attempt to autonomously optimize the resource.

    If None, all availability modes are retrieved.
    :param is_compatible: Retrieve resources that are eligible for Sedai operation by passing `True`. By default, only retrieves resources that are ineligible.
    :param include_factors: Include details about factors that make the resource eligible or ineligible for Sedai operation. Default is False.
        If True, the 'positiveFactors' and 'blockers' fields will be populated with details.
    :param pagination_config: Optional pagination configuration. By default, uses the default pagination configuration- `sedai.pagination.DEFAULT_PAGINATION_CONFIG`.
    :return: A `sedai.pagination.PageIterator` of `OperationCompatibility` objects representing the eligibility status of each resource.
    """
    params = dict()

    if account_ids is None:
        account_ids = []

    if optimization_modes is not None:
        params['optimizationModes'] = ','.join(optimization_modes)

    if availability_modes is not None:
        params['availabilityModes'] = ','.join(availability_modes)

    if is_compatible is not None:
        params['isAutonomousEligible'] = is_compatible

    if pagination_config is None:
        pagination_config = pagination.DEFAULT_PAGINATION_CONFIG

    def page_loader(params: Dict, page_config: pagination.PaginationConfig):
        endpoint = '/api/reports/autonomous/score/overall/summary'
        params = params if params is not None else {}

        if pagination_config.start is not None:
            params['start'] = pagination_config.start - 1  # 0-based index for this API
        else:
            params['start'] = 0

        if pagination_config.page_size is not None:
            params['pageSize'] = pagination_config.page_size
        if pagination_config.order_by is not None:
            params['orderBy'] = pagination_config.order_by
        if pagination_config.order_dir is not None:
            params['orderDir'] = pagination_config.order_dir

        request = api.PostRequest(endpoint, params=params, payload=account_ids)
        response = api.do_post(request)
        if response['status'] != 'OK' or response['result'] is None:
            log(f"Failed to get compatibility details: {response['message']}")
            raise Exception(f"Failed to get compatibility details: {response['message']}")

        result = response['result']
        page = result['content']
        compatibility_details = []
        for action_eligibility in page:
            blockers = None
            positive_factors = None

            if include_factors:
                resource_id = action_eligibility['resourceId']
                details_request = api.GetRequest(
                    endpoint='/api/reports/autonomous/resource/details',
                    params=dict(resourceId=resource_id),
                )
                details_response = api.do_get(details_request)
                if details_response['status'] == "OK" and details_response['result'] is not None:
                    resource_eligibility_details = details_response['result']
                    blockers = [
                        OperationBlocker(
                            factor=blocker['autonomousFactor'],
                            suggested_actions=blocker['suggestedActions'],
                            active=blocker['active'],
                        )
                        for blocker in resource_eligibility_details['blockers']
                    ]
                    positive_factors = resource_eligibility_details['positiveFactors']
                else:
                    log(f"Failed to get eligibility details for resource {resource_id}")

            eligibility = OperationCompatibility(
                resource_id=action_eligibility['resourceId'],
                resource_name=action_eligibility['name'],
                is_compatible=action_eligibility['autonomousEligible'],
                availability_mode=action_eligibility['availabilityMode'],
                optimization_mode=action_eligibility['optimizationMode'],
                num_blockers=action_eligibility['blockerCount'],
                num_positive_factors=action_eligibility['positiveFactorCount'],
                positive_factors=positive_factors,
                blockers=blockers,
            )

            compatibility_details.append(eligibility)

        total_pages = result['totalPages']
        next_page = None
        if result['last'] is False:
            next_page = result['number'] + 2  # 0-based index for this API

        return pagination.PaginatedResponse(
            content=compatibility_details,
            next_page=next_page,
            total_pages=total_pages,
        )

    return pagination.PageIterator(
        params=params,
        page_loader=page_loader,
        page_config=pagination_config,
    )
