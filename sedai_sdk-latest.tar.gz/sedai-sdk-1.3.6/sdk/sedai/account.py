from sedai.__impl import api, log
from sedai.__impl.model_converter import transform
from typing import Optional
from sedai.credentials import SedaiCredentials

__account_fields = [
    "id",
    "name",
    "providerAccountId",
    "accountDetails.cloudProvider",
    "accountDetails.integrationType"]

CLOUD_PROVIDERS = ["AWS", "AZURE", "GCP", "KUBERNETES"]
INTEGRATION_TYPES = ["AGENTLESS", "AGENT_BASED"]
CLUSTER_PROVIDERS = ["AWS", "AZURE", "GCP", "SELF_MANAGED"]


def get_all_accounts():
    """
    Get all accounts that are integrated with Sedai
    :return: A list of accounts
    Each account is an object with the following fields:

    - **id** - the account id in Sedai
    - **name** - the name of the account as specified by the user
    - **providerAccountId** - the account id in the cloud provider
    -  **accountDetails.cloudProvider** - the cloud provider of the account. Values are: `AWS`,
     `AZURE`, `GCP`, `KUBERNETES`, `VMWARE`
    - **accountDetails.integrationType** - the type of integration. Values are: `AGENTLESS`, `AGENT_BASED`

    Sample code:
    .. code-block:: python

            models.to_json(account.get_all_accounts())

    Output:
    .. code-block:: json

            [
                {
                    "id": "5f4f5d3a-9c6e-4b3e-8a5a-1e4b6b5b2a7e",
                    "name": "test env",
                    "accountDetails": {
                        "cloudProvider": "AWS",
                        "integrationType": "AGENTLESS"
                    }
                }
            ]

    """
    request = api.GetRequest('/api/site/accounts')
    response = api.do_get(request)
    if response['status'] == 'OK' and response['result'] is not None:
        return transform(response['result'], __account_fields)


def search_accounts_by_provider_account_id(provider_account_id):
    """
    Search for all accounts that are integrated with Sedai that match the given provider account id
    :param provider_account_id: The providerAccountId of the account to search for
    :return: A list of accounts that match the given providerAccountId. Output is in the same structure
     as :py:func:`get_all_accounts`
    """
    accounts = get_all_accounts()
    return transform(list(filter(lambda x: x.providerAccountId == provider_account_id, accounts)))


def search_accounts_by_name(name):
    """
    Search for all accounts that are integrated with Sedai that match the given name
    :param name: The name of the account to search for
    :return: A list of accounts that match the given name\. Output is in the same structure
     as :py:func:`get_all_accounts`
    """
    accounts = get_all_accounts()
    return transform(list(filter(lambda x: x.name == name, accounts)))


def search_accounts_by_id(id):
    """
    Search for all accounts that are integrated with Sedai that match the given id
    :param id: The accountId of the account to search for
    :return: A list of accounts that match the given id\. Output is in the same structure
     as :py:func:`get_all_accounts`
    """
    # accounts = get_all_accounts()
    request = api.GetRequest('/api/site/accounts/' + id)
    response = api.do_get(request)
    if response['status'] == 'OK' and response['result'] is not None:
        return transform(list(response['result']), __account_fields)
    # return transform(list(filter(lambda x: x.id == id, accounts)))


def create_account(
    name: str,
    cloud_provider: str,
    credentials: SedaiCredentials,
    integration_type: str,
    cluster_provider: Optional[str] = None,
    cluster_url: Optional[str] = None,
    ca_certificate: Optional[str] = None,
):
    """
    Create an account in Sedai
    :param name: The name of the account
    :param cloud_provider: Cloud provider of the account. Valid values are: `AWS`, `AZURE`, `GCP`, `KUBERNETES`
    :param credentials: Credentials for the account. See :ref:`credentials` for more details
    :param integration_type: Type of integration for Kubernetes accounts. Valid values are: `AGENTLESS`, `AGENT_BASED`
    :param cluster_provider: Cluster provider for Kubernetes accounts. Required when adding Kubernetes clusters. Valid values are: `AWS`, `AZURE`, `GCP`, `SELF_MANAGED`
    :param cluster_url: URL of the Kubernetes cluster. Required when adding agentless Kubernetes clusters.
    :param ca_certificate: Optional Certifying Authority Certificate for connecting agentlessly to Kubernetes clusters.
    :return: True if the account was created successfully, False otherwise
    """
    if cloud_provider not in CLOUD_PROVIDERS:
        raise ValueError("Invalid cloud provider: " + cloud_provider)
    if integration_type not in INTEGRATION_TYPES:
        raise ValueError("Invalid integration type: " + integration_type)

    metadata = {}
    if cloud_provider == "KUBERNETES":
        if cluster_provider not in CLUSTER_PROVIDERS:
            raise ValueError("cluster_provider is required for Kubernetes accounts. Valid values are: " + ", ".join(
                CLUSTER_PROVIDERS))
        if integration_type == "AGENTLESS" and credentials is None:
            from sedai.credentials import AwsRoleCredentials
            credentials = AwsRoleCredentials(role_arn=None, external_id=None)

        if cluster_url is not None:
            metadata["clusterUrl"] = cluster_url

        if ca_certificate is not None:
            metadata["caCertData"] = ca_certificate

        metadata["clusterProvider"] = cluster_provider
        metadata["clusterName"] = name

    # Check if an account with the same name already exists
    accounts = search_accounts_by_name(name)
    if len(accounts) > 0:
        log("Account with name: " + name + " already exists")
        return False

    payload = {
        "accountDetails": {
            "cloudProvider": cloud_provider,
            "integrationType": integration_type,
            "enabled": True,
            "metadata": metadata,
            "credentialsDetail": {
                "credentials": credentials.to_dict()
            }
        },
        "name": name
    }

    request = api.PostRequest('/api/site/accounts', payload)
    response = api.do_post(request)
    if response['status'] != 'OK':
        log(f"Failed to create account: {response['message']}")
        return ""
    else:
        log(f"Successfully created account: {name}")
        return response['result']['accountId']


def update_account(
    id: str,
    name: Optional[str] = None,
    cloud_provider: Optional[str] = None,
    credentials: Optional[SedaiCredentials] = None,
    integration_type: Optional[str] = None,
    cluster_provider: Optional[str] = None,
    cluster_url: Optional[str] = None,
    ca_certificate: Optional[str] = None,
):
    """
    Update an account in Sedai
    :param id: The id of the account
    :param name: The name of the account
    :param cloud_provider: Cloud provider of the account. Valid values are: `AWS`, `AZURE`, `GCP`, `KUBERNETES`
    :param credentials: Credentials for the account. See :ref:`credentials` for more details
    :param integration_type: Type of integration for Kubernetes accounts. Valid values are: `AGENTLESS`, `AGENT_BASED`
    :param cluster_provider: Cluster provider for Kubernetes accounts. Required when adding Kubernetes clusters. Valid values are: `AWS`, `AZURE`, `GCP`, `SELF_MANAGED`
    :param cluster_url: URL of the Kubernetes cluster. Required when adding agentless Kubernetes clusters.
    :param ca_certificate: Optional Certifying Authority Certificate for connecting agentlessly to Kubernetes clusters.
    :return: True if the account was updated successfully, False otherwise
    """
    accounts = search_accounts_by_id(id)
    if len(accounts) == 0:
        log("No account with id: " + id)
        raise ValueError("No account with id: " + id)

    existing_account = accounts[0]
    if name is None:
        name = existing_account.Name
    if cloud_provider is None:
        cloud_provider = existing_account.accountDetails.cloudProvider
    if integration_type is None:
        integration_type = existing_account.accountDetails.integrationType

    if cloud_provider not in CLOUD_PROVIDERS:
        raise ValueError("Invalid cloud provider: " + cloud_provider)
    if integration_type not in INTEGRATION_TYPES:
        raise ValueError("Invalid integration type: " + integration_type)

    metadata = {}
    if cloud_provider == "KUBERNETES":
        if cluster_provider not in CLUSTER_PROVIDERS:
            raise ValueError("cluster_provider is required for Kubernetes accounts. Valid values are: " + ", ".join(
                CLUSTER_PROVIDERS))
        if integration_type == "AGENTLESS" and credentials is None:
            from sedai.credentials import AwsRoleCredentials
            credentials = AwsRoleCredentials(role_arn=None, external_id=None)

        if cluster_url is not None:
            metadata["clusterUrl"] = cluster_url

        if ca_certificate is not None:
            metadata["caCertData"] = ca_certificate

        if cluster_provider is not None:
            metadata["clusterProvider"] = cluster_provider

        if name is not None:
            metadata["clusterName"] = name

    payload = {
        "accountDetails": {
            "cloudProvider": cloud_provider,
            "integrationType": integration_type,
            "enabled": True,
            "metadata": metadata,
        },
        "name": name,
        "id": id
    }

    if credentials is not None:
        payload["accountDetails"]["credentialsDetail"] = {
            "credentials": credentials.to_dict()
        }

    request = api.PostRequest('/api/site/accounts', payload)
    response = api.do_post(request)
    
    if response['status'] != 'OK':
        log(f"Failed to update account: {response['message']}")
        return ""
    else:
        log(f"Successfully updated account: {name}")
        return response['result']['accountId']


def delete_account(name):
    """
    Delete an account in Sedai - Note: Name would not be unique
    :param name: Name of the account to delete
    :return: True if the account was deleted successfully, False otherwise
    """
    accounts = search_accounts_by_name(name)
    if len(accounts) == 0:
        log("No account with name: " + name)
        return False
    if len(accounts) > 1:
        log("Multiple accounts with name: " + name)
        return False
    account = accounts[0]
    request = api.DeleteRequest('/api/site/accounts/' + account.id)
    response = api.do_delete(request)
    if response['status'] != 'OK':
        log(f"Failed to delete account: {response['message']}")
        return False
    else:
        log(f"Successfully deleted account: {name}")
        return True


def delete_account_by_id(id):
    """
    Delete an account in Sedai
    :param id: Id of the account to delete
    :return: True if the account was deleted successfully, False otherwise
    """
    request = api.DeleteRequest('/api/site/accounts/' + id)
    response = api.do_delete(request)
    if response['status'] != 'OK':
        log(f"Failed to delete account: {response['message']}")
        return False
    else:
        log(f"Successfully deleted account: {id}")
        return True


def test_connection(account_id):
    """
    Test the connection to the account
    :param account_id: The Sedai account id
    :return: True if the connection was successful, False otherwise
    """

    payload = {
      "accountId": account_id
    }

    request = api.PostRequest('/api/site/account/' + account_id + '/testConnection', payload)
    response = api.do_post(request)
    if response['status'] != 'OK':
        log(f"Failed to test connection: {response['message']}")
        return False
    elif not response['result']['connectionStatus']:
        log(f"Test connection failed: {response['result']['reason']}")
        return False
    else:
        log(f"Successfully tested connection for account: {account_id}")
        return True


def get_agent_installation_command(name):
    """
    Get the agent installation command for the given account
    :param name: Name of tMhe account
    :return: The agent installation command details
    Contains the following fields:
    - **accountId** - The Sedai account id
    - **apiKey** - The Sedai API key used for the command
    - **kubeInstallCmd** - The kubectl command to install the agent on Kubernetes clusters
    - **helmInstallCmd** - The helm command to install the agent on Kubernetes clusters

    Output:
    .. code-block:: json

        {
            "accountId": "n9dngzfd",
            "apiKey": "eyJhbGciOiJSUzI1NiJ9...[Truncated]",
            "kubeInstallCmd": "kubectl apply -f “https://[Truncated. URL for the YAML file]“",
            "helmInstallCmd": "helm upgrade --install sedai-smart-agent-abc oci://[...] --version 1.21.36 -f “https://[Truncated. URL for the YAML file]“]"
        }

    """
    accounts = search_accounts_by_name(name)
    if len(accounts) == 0:
        log("No account with name: " + name)
        return False
    if len(accounts) > 1:
        log("Multiple accounts with name: " + name)
        return False
    account = accounts[0]
    request = api.GetRequest('/api/agent/accounts/' + account.id + '/agent-installation-cmds')
    response = api.do_get(request)
    if response['status'] == 'OK' and response['result'] is not None:
        return transform(response['result'])
