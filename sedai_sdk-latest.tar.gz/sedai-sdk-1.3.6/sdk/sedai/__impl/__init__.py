from sedai.__impl import config

_logger = None


def __initLogger(_config):
    import logging
    import sys

    log_level = _config.get('LOG_LEVEL', 'INFO')
    if log_level is None:
        log_level = 'INFO'

    numeric_level = getattr(logging, log_level.upper(), None)
    if not isinstance(numeric_level, int):
        numeric_level = logging.INFO
    logging.basicConfig(level=numeric_level, stream=sys.stdout)
    global _logger
    _logger = logging.getLogger("INIT")



def log(message, level="INFO"):
    global _logger
    if level == "INFO":
        _logger.info(message)
    elif level == "DEBUG":
        _logger.debug(message)
    elif level == "ERROR":
        _logger.error(message)
    elif level == "WARNING":
        _logger.warning(message)
    else:
        _logger.info(message)



def init():

    # print("Initializing SDK")
    _config = config.get_config()
    __initLogger(_config)
    global _logger
    log("SDK Initialized Successfully")


init()
