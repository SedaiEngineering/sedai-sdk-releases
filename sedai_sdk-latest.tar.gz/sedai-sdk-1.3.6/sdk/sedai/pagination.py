from typing import Dict, Optional, Generic, TypeVar
from sedai.__impl import log
from collections import deque
from collections.abc import Callable
from sedai.__impl.pagination import PaginatedResponse

T = TypeVar("T")
"""
@private
"""


class PaginationConfig:
    """
    The pagination configuration for retrieving elements from a paginated API.
    Functions that support pagination accept this configuration as a named argument
    and return a `PageIterator` object that iterates over elements in the collection, by
    retrieving pages from the API based on the parameters set in this configuration.
    """

    page_size: Optional[int]
    """
    The number of elements to fetch in a single page. Defaults to 20.
    """

    start: Optional[int]
    """
    The page number to start fetching from.
    """

    order_by: Optional[str]
    """
    The field to order the results by.
    """

    order_dir: Optional[str]
    """
    The direction to order the results by. Can be either `ASC` or `DESC`.
    """

    num_pages: Optional[int]
    """
    The number of pages to fetch. If None, all pages are fetched.
    """

    def __init__(
        self,
        page_size: Optional[int] = 20,
        start: Optional[int] = None,
        order_by: Optional[str] = None,
        order_dir: Optional[str] = None,
        num_pages: Optional[int] = None,
    ):
        """@private"""
        self.page_size = page_size
        self.start = start
        self.order_by = order_by
        self.order_dir = order_dir
        self.num_pages = num_pages


DEFAULT_PAGINATION_CONFIG = PaginationConfig(page_size=20)
"""
The default pagination configuration. Fetches 20 elements per page until all pages are fetched.
"""


class PageIterator(Generic[T]):
    """
    An iterator that fetches collections of elements in pages.
    The iterator makes subsequent API requests to fetch pages of elements until
    your code hits 'break', the end of the collection is reached, or the specified
    number of pages are fetched.
    """

    total_pages: int
    """
    The total number of pages in the collection.
    """

    def __init__(
        self,
        params: Dict,
        page_loader: Callable[[Dict, PaginationConfig], PaginatedResponse],
        page_config: PaginationConfig,
    ):
        """@private"""
        self.__params = params
        self.__page_loader = page_loader
        self.__page_config = page_config
        self.__elements = deque()
        self.total_pages = 0

        # fetch first page
        self.__next_page()

    def __iter__(self):
        return self

    def __next__(self) -> T:
        if self.__has_next_element():
            return self.__elements.popleft()

        if not self.__has_next_page():
            raise StopIteration

        self.__next_page()

        if len(self.__elements) == 0:
            log(f"Failed to fetch next page for {self.__endpoint}")
            raise Exception("Failed to fetch next page, no results found")

        return self.__next__()

    def __has_next_element(self):
        return len(self.__elements) > 0

    def __has_next_page(self):
        return self.__page_config.start is not None and (
            self.__page_config.num_pages is None
            or self.__page_config.start <= self.__page_config.num_pages
        )

    def __next_page(self):
        response = self.__page_loader(self.__params, self.__page_config)
        self.total_pages = response.total_pages
        self.__page_config.start = response.next_page
        self.__elements.extend(response.content)

    def has_next(self):
        return self.__has_next_element() or self.__has_next_page()
