from setuptools import setup

setup(
    name='sedai-sdk',
    version='1.3.21',
    # The SDK uses PEP 604 unions (e.g. `X | None`) evaluated at import time
    # (sedai/settings.py, sedai/optimizations/individual_resource_opportunities.py),
    # so it requires Python 3.10+.
    python_requires='>=3.10',
    packages=[
        'sedai',
        'sedai.optimizations',
        'sedai.health',
        'sedai.__impl',
        'sedai.__impl.jsonpath',
        'sedai.__impl.urllib3',
        'sedai.__impl.urllib3.contrib',
        'sedai.__impl.urllib3.util',
    ],
    install_requires=[
        # List your dependencies here
    ],
)
