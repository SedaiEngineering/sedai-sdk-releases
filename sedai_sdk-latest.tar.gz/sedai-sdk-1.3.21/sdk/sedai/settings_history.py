from datetime import datetime, timezone
from enum import Enum
from typing import Any

from sedai.__impl import is_debug_enabled, log
from sedai.util import __get_paginated_response


class SettingsEventType(Enum):
    """
    Represents the type of event.

    This enum categorizes the different types of changes that can occur to settings
    for resources, groups or accounts.
    """

    CUSTOM_SETTINGS_CREATE = "CUSTOM_SETTINGS_CREATE"
    """
    Custom settings for this resource/group/account created.
    """
    CUSTOM_SETTINGS_UPDATE = "CUSTOM_SETTINGS_UPDATE"
    """
    Custom settings for this resource/group/account updated.
    """
    CUSTOM_SETTINGS_RESET = "CUSTOM_SETTINGS_RESET"
    """
    Custom settings for this resource/group/account reset.
    """


class SettingChangeDetails:
    """
    Represents the details of the change made in some field for a particular setting type.
    """

    setting_key: str
    """
    The setting field that was modified.
    """
    description: str
    """
    Description of the setting modified.
    """
    initial_value: Any
    """
    Original value before modification.
    """
    new_value: Any
    """
    Final value after modification.
    """

    def __init__(self, setting_key: str, description: str, initial_value: Any, new_value: Any):
        """
        @private
        """
        self.setting_key = setting_key
        self.description = description
        self.initial_value = initial_value
        self.new_value = new_value


class SettingsChangeEvent:
    """
    Represents a change in the settings for an entity (resource, group or account), including the type
    of change, who made the change, when it occured and what specific settings were modified.
    """

    event_type: SettingsEventType
    """
    Type of modification.
    """
    updated_user: str
    """
    Which user performed the modification.
    """
    updated_time: datetime
    """
    Time at which the modification was performed.
    """
    updated_settings: list[SettingChangeDetails]
    """
    List of modified fields.
    """

    def __init__(self, event_type):
        """
        @private
        """
        self.event_type = event_type
        self.updated_user = None
        self.updated_time = None
        self.updated_settings = []


def get_resource_settings_history(
    resource_id: str, start_time: datetime | None = None, end_time: datetime | None = None
) -> list[SettingsChangeEvent]:
    """
    Retrieve the history of settings changes for a particular resource.
    """
    endpoint = '/api/settingsV2/topology/logs/resource'
    params = {}
    params['resourceId'] = resource_id

    if start_time is not None:
        starttime_epoch_ms = start_time.timestamp() * 1000
        params['startTime'] = round(starttime_epoch_ms)

    if end_time is not None:
        endtime_epoch_ms = end_time.timestamp() * 1000
        params['endTime'] = round(endtime_epoch_ms)

    settings_history = []
    for logs_page in __get_paginated_response(endpoint, params):
        for log_obj in logs_page:
            changes = log_obj['changes']
            if changes is not None:
                events = _parse_log_events(log_obj)
                settings_history.extend(events)

    return settings_history


def get_group_settings_history(
    group_id: str, start_time: datetime | None = None, end_time: datetime | None = None
) -> list[SettingsChangeEvent]:
    """
    Retrieve the history of settings changes for a particular group.
    """
    endpoint = '/api/settingsV2/topology/logs/group'
    params = {}
    params['groupId'] = group_id

    if start_time is not None:
        starttime_epoch_ms = start_time.timestamp() * 1000
        params['startTime'] = round(starttime_epoch_ms)

    if end_time is not None:
        endtime_epoch_ms = end_time.timestamp() * 1000
        params['endTime'] = round(endtime_epoch_ms)

    settings_history = []
    for logs_page in __get_paginated_response(endpoint, params):
        for log_obj in logs_page:
            changes = log_obj['changes']
            if changes is not None:
                events = _parse_log_events(log_obj)
                settings_history.extend(events)

    return settings_history


def get_account_settings_history(
    account_id: str, start_time: datetime | None = None, end_time: datetime | None = None
) -> list[SettingsChangeEvent]:
    """
    Retrieve the history of settings changes for a particular account.
    """
    endpoint = '/api/settingsV2/topology/logs/account'
    params = {}
    params['accountId'] = account_id

    if start_time is not None:
        starttime_epoch_ms = start_time.timestamp() * 1000
        params['startTime'] = round(starttime_epoch_ms)

    if end_time is not None:
        endtime_epoch_ms = end_time.timestamp() * 1000
        params['endTime'] = round(endtime_epoch_ms)

    settings_history = []
    for logs_page in __get_paginated_response(endpoint, params):
        for log_obj in logs_page:
            changes = log_obj['changes']
            if changes is not None:
                events = _parse_log_events(log_obj)
                settings_history.extend(events)

    return settings_history


def _parse_log_events(log_obj: dict) -> list[SettingsChangeEvent]:
    events = []
    updated_time_epoch = log_obj['updatedTime']
    logged_time = (
        datetime.fromtimestamp(updated_time_epoch / 1000.0, tz=timezone.utc)
        if updated_time_epoch is not None
        else None
    )
    changes = log_obj['changes']
    if is_debug_enabled():
        log(
            f"Parsing settings log: updatedTime={updated_time_epoch}, "
            f"change_keys={list(changes.keys()) if changes else None}",
            level="DEBUG",
        )
    if changes is None:
        return events

    setting_type_to_event_map = {}
    for change_key, change_obj in changes.items():
        if change_key == "attributes_change":
            attribute_change_event = _parse_attribute_changes(change_obj)
            attribute_change_event.updated_time = logged_time
            events.append(attribute_change_event)
        else:
            _process_settings_change(change_key, change_obj, setting_type_to_event_map)

    for event in setting_type_to_event_map.values():
        if event.updated_time is None:
            event.updated_time = logged_time
        events.append(event)

    if is_debug_enabled():
        log(
            f"Parsed {len(events)} settings event(s); "
            f"updated_settings counts={[len(e.updated_settings) for e in events]}",
            level="DEBUG",
        )
    return events


def _parse_attribute_changes(change_obj: dict) -> SettingsChangeEvent:
    event = None
    ATTRIBUTE_FIELDS_IGNORED = ['group_id', 'resource_id']

    if change_obj['before'] is not None and change_obj['after'] is not None:
        event = SettingsChangeEvent(event_type=SettingsEventType.CUSTOM_SETTINGS_UPDATE)
        for key, original_value in change_obj['before'].items():
            if key in ATTRIBUTE_FIELDS_IGNORED:
                continue

            new_value = change_obj['after'][key]
            if original_value != new_value:
                settings_change = SettingChangeDetails(
                    setting_key=key,
                    description=None,
                    initial_value=original_value,
                    new_value=new_value,
                )
                event.updated_settings.append(settings_change)

    elif change_obj["before"] is not None:
        event = SettingsChangeEvent(event_type=SettingsEventType.CUSTOM_SETTINGS_RESET)
        for key, original_value in change_obj['before'].items():
            if key in ATTRIBUTE_FIELDS_IGNORED:
                continue

            settings_change = SettingChangeDetails(
                setting_key=key,
                description=None,
                initial_value=original_value,
                new_value=None,
            )
            event.updated_settings.append(settings_change)

    else:
        event = SettingsChangeEvent(event_type=SettingsEventType.CUSTOM_SETTINGS_CREATE)
        for key, new_value in change_obj['after'].items():
            if key in ATTRIBUTE_FIELDS_IGNORED:
                continue

            settings_change = SettingChangeDetails(
                setting_key=key,
                description=None,
                initial_value=None,
                new_value=new_value,
            )
            event.updated_settings.append(settings_change)

    return event


def _process_settings_change(
    change_key: str, change_obj: dict, setting_type_to_event_map: dict
) -> SettingsChangeEvent:
    setting_type, setting_key = change_key.rsplit('.', 1)

    # Derive the event type and which side of the diff carries the metadata value.
    # All sub-keys of a single setting_type share the same before/after nullness
    # (all created, all updated, or all reset), so any key yields the same type.
    if change_obj['before'] is not None and change_obj['after'] is not None:
        default_event_type = SettingsEventType.CUSTOM_SETTINGS_UPDATE
        metadata_value = change_obj.get('after', None)
    elif change_obj['before'] is not None:
        default_event_type = SettingsEventType.CUSTOM_SETTINGS_RESET
        metadata_value = change_obj.get('before', None)
    else:
        default_event_type = SettingsEventType.CUSTOM_SETTINGS_CREATE
        metadata_value = change_obj.get('after', None)

    # Store the event immediately so metadata keys (updatedUser/updatedTime) arriving
    # before the field-change key attach to the same event instead of being lost.
    change_event = setting_type_to_event_map.get(setting_type)
    if change_event is None:
        change_event = SettingsChangeEvent(event_type=default_event_type)
        setting_type_to_event_map[setting_type] = change_event

    if setting_key == "updatedUser":
        change_event.updated_user = metadata_value
        return change_event
    elif setting_key == "updatedTime":
        change_event.updated_time = _parse_time_from_str(metadata_value)
        return change_event

    settings_change = SettingChangeDetails(
        setting_key=change_key,
        description=change_obj.get('description', None),
        initial_value=change_obj.get('before', None),
        new_value=change_obj.get('after', None),
    )
    change_event.updated_settings.append(settings_change)
    return change_event


def _parse_time_from_str(time_str: str):
    if time_str is None:
        return None

    return datetime.strptime(time_str, "%Y-%m-%d %H:%M:%S.%f").replace(tzinfo=timezone.utc)
