############################################################################################################
# This file contains the classes and methods to parse and serialize the settings of the resources
# The settings are parsed from the JSON response from the API and then serialized back to JSON to be sent to the API
# The classes are used to store the settings of the resources and the methods are used to parse and serialize the settings
import copy
from enum import Enum
from typing import ClassVar

from sedai.__impl import api
from sedai.measurement import ECSCpuValue, K8sCpuValue, MemoryValue, MetricUnit

# The classes are as follows:
# BaseSettings: This class is the base class for all the settings classes. It contains the common settings for all the resources
# APPSettings: This class contains the settings for the App resource
# ServerlessSettings: This class contains the settings for the Serverless resource
# ContainerAppSettings: This class contains the settings for the Container App resource
# KubeAppSettings: This class contains the settings for the Kubernetes App resource
# ECSAppSettings: This class contains the settings for the ECS App resource
# BucketSettings: This class contains the settings for the Bucket resource
# VolumeSettings: This class contains the settings for the Volume resource

# The type_map dictionary is used to map the resource type to the corresponding settings class
# The Settings class contains the settings for all the resources
# The parse method is used to parse the settings from the JSON response
# The serialize method is used to serialize the settings to JSON to be sent to the API
############################################################################################################


def __get_dict__(src, key):
    """@private Read src[key] as a dict, normalizing a missing OR explicitly-null value to {}."""
    return src.get(key) or {}


def __ensure_dict__(src, key):
    """@private Like __get_dict__, but also writes the normalized value back to src[key]."""
    value = __get_dict__(src, key)
    src[key] = value
    return value


def __serialize_metric__(value, value_type, default_unit=None):
    """@private Serialize a guardrail, accepting either a value + unit object or a bare number."""
    coerced = value_type.__coerce__(value, default_unit)
    return None if coerced is None else coerced.__serialize__()


def __metric_scalar__(value, value_type, unit, default_unit=None):
    """@private Read a guardrail as a bare number in `unit`, for the deprecated scalar accessors."""
    coerced = value_type.__coerce__(value, default_unit)
    return None if coerced is None else coerced.value_in(unit)


class SettingsConfigMode(Enum):
    """
    Supported Setting modes.

    Possible values:
    - `DATA_PILOT`: Provides recommendations for availability and optimization.
    - `CO_PILOT`: Provides recommendations but requires manual action.
    - `AUTO`: Manages the resource autonomously.

    Deprecated values:
    - `OFF`
    - `MANUAL`
    """

    DATA_PILOT = "DATA_PILOT"
    CO_PILOT = "CO_PILOT"
    AUTO = "AUTO"
    OFF = "OFF"
    MANUAL = "MANUAL"


############################################################################################################
# BaseSettings
############################################################################################################
class BaseSettings:
    """
    Base configuration settings for all resources. All resources managed by Sedai will have these settings.
    """

    __CONFIG_MODES: ClassVar[list] = [
        SettingsConfigMode.DATA_PILOT,
        SettingsConfigMode.CO_PILOT,
        SettingsConfigMode.AUTO,
    ]

    availabilityMode: SettingsConfigMode
    """
    The availability mode of the resource. This setting determines if Sedai should autonomously manage the availability of the resource.
    Possible values: `DATA_PILOT`, `CO_PILOT`, `AUTO`
    
    - `DATA_PILOT`:This mode enables Sedai to monitor cloud resources, analyze performance metrics,
                    and predict optimization opportunities without taking any direct action. 
    - `CO_PILOT`: This mode allows Sedai to make recommendations based on its analysis, but requires manual approval before any actions are taken. 
    - `AUTO`: Sedai proactively detects optimization opportunities, automatically determines the best course of action, and executes changes on your behalf.
    """
    optimizationMode: SettingsConfigMode
    """
    The optimization mode of the resource. This setting determines if Sedai should autonomously optimize the resource.
    Possible values: `DATA_PILOT`, `CO_PILOT`, `AUTO`
    
    - `DATA_PILOT`:This mode enables Sedai to monitor cloud resources, analyze performance metrics,
                    and predict optimization opportunities without taking any direct action. 
    - `CO_PILOT`: This mode allows Sedai to make recommendations based on its analysis, but requires manual approval before any actions are taken. 
    - `AUTO`: Sedai proactively detects optimization opportunities, automatically determines the best course of action, and executes changes on your behalf.
    
    """

    releaseIntelligenceMode: SettingsConfigMode
    """
    Deprecated, Do not use.
    """

    sloMode: SettingsConfigMode
    """
    Deprecated, Do not use.
    """

    sedaiSyncEnabled: bool
    """
    When Sedai Sync is enabled for a resource, Sedai will automatically sync the resource with the latest configuration.
    """

    def __init__(self, src):
        """@private"""
        self.src = src
        self.__parse__()

    def __to_enum__(self, value: str | SettingsConfigMode) -> SettingsConfigMode | None:
        if isinstance(value, SettingsConfigMode):
            return value

        if value is None:
            return None

        return SettingsConfigMode(value)

    def __to_str__(self, value: str | SettingsConfigMode) -> str:
        if isinstance(value, str) or value is None:
            return value
        return value.value

    def __parse__(self):
        self.availabilityMode = self.__to_enum__(self.src['availability']['configMode'])
        self.optimizationMode = self.__to_enum__(self.src['optimization']['setting']['configMode'])
        self.releaseIntelligenceMode = self.__to_enum__(
            self.src['releaseIntelligence']['configMode']
        )
        self.sloMode = self.__to_enum__(self.src['slo']['configMode'])
        # sedaiSync can be null for resource types that don't support it (e.g. RDS), rather than
        # an object with enabled=False
        self.sedaiSyncEnabled = (self.src.get('sedaiSync') or {}).get('enabled', False)

    def __serialize__(self):
        self.__validate__()
        self.src['availability']['configMode'] = self.__to_str__(self.availabilityMode)
        self.src['optimization']['setting']['configMode'] = self.__to_str__(self.optimizationMode)
        self.src['slo']['configMode'] = self.__to_str__(self.sloMode)
        self.src['releaseIntelligence']['configMode'] = self.__to_str__(
            self.releaseIntelligenceMode
        )
        if self.src.get('sedaiSync') is not None:
            self.src['sedaiSync']['enabled'] = self.sedaiSyncEnabled
        return self.src

    def __validate__(self):

        if self.__to_enum__(self.optimizationMode) not in self.__CONFIG_MODES:
            raise ValueError(
                f"Invalid optimization mode: {self.optimizationMode}. "
                f"Allowed modes are: {self.__CONFIG_MODES}"
            )

        if self.__to_enum__(self.availabilityMode) not in self.__CONFIG_MODES:
            raise ValueError(
                f"Invalid availability mode: {self.optimizationMode}. "
                f"Allowed modes are: {self.__CONFIG_MODES}"
            )


############################################################################################################
# APPSettings
############################################################################################################
class APPSettings(BaseSettings):
    """
    Settings for all application resources managed by Sedai. Applications could be web applications or microservices behind
    a load balancer or identified by tags or labels. In containerized environments, applications could be workloads running
    in a container, pod, or a service.
    """

    __CONFIG_MODES: ClassVar[set] = {SettingsConfigMode.DATA_PILOT, SettingsConfigMode.CO_PILOT}
    __type = "AppCommonResourceSettingDetail"

    isProd: bool
    """
    Is this resource or application in production. If an application is not a production application, Sedai can
    take more aggressive actions to optimize the application. In aggressive mode, some thresholds are relaxed. Also in 
    non-prod mode, Sedai can act even if certain metrics are not available.
    """

    horizontalScaling_enabled: bool
    """
    Enable horizontal scaling for the application. Horizontal scaling is the process of adding or removing instances of an application to handle the load.
    """
    horizontalScaling_minReplicas: int
    """
    The minimum number of replicas for the application. This is the minimum number of instances that should be running at all times.
    """
    horizontalScaling_maxReplicas: int
    """
    The maximum number of replicas for the application. This is the maximum number of instances that can be running at any given time.
    """

    def __parse__(self):
        super().__parse__()
        self.isProd = self.src['isProd']['enabled']
        self.horizontalScaling_enabled = self.src['enableHorizontalScaling']['enabled']
        self.horizontalScaling_minReplicas = self.src['enableHorizontalScaling']['minReplicas']
        self.horizontalScaling_maxReplicas = self.src['enableHorizontalScaling']['maxReplicas']

    def __serialize__(self):
        super().__serialize__()
        self.src['isProd']['enabled'] = self.isProd
        self.src['enableHorizontalScaling']['enabled'] = self.horizontalScaling_enabled
        self.src['enableHorizontalScaling']['minReplicas'] = self.horizontalScaling_minReplicas
        self.src['enableHorizontalScaling']['maxReplicas'] = self.horizontalScaling_maxReplicas
        return self.src

    def __validate__(self):
        if isinstance(self, ContainerAppSettings):
            return

        if self.__to_enum__(self.optimizationMode) not in self.__CONFIG_MODES:
            raise ValueError(
                f"Invalid optimization mode: {self.optimizationMode}. "
                f"Allowed modes are: {self.__CONFIG_MODES}"
            )

        if self.__to_enum__(self.availabilityMode) not in self.__CONFIG_MODES:
            raise ValueError(
                f"Invalid availability mode: {self.optimizationMode}. "
                f"Allowed modes are: {self.__CONFIG_MODES}"
            )


############################################################################################################
# ServerlessSettings
############################################################################################################
class ServerlessSettings(BaseSettings):
    __type = "ServerlessFunctionResourceSettingDetail"
    optimizationFocus: str
    """
    The optimization focus for the serverless function. The optimization focus determines the goal of the optimization.
    Possible values: `COST`, `DURATION`, `COST_AND_DURATION`
    - `COST`: Optimize the cost of the function.
    - `DURATION`: Optimize the duration of the function.
    - `COST_AND_DURATION`: Optimize both the cost and duration of the function. 
    """
    optimization_concurrencyMode: SettingsConfigMode
    """
    Should Sedai optimize the concurrency of the function. 
    Possible values: `OFF`, `AUTO`
    - `OFF`: Sedai will not optimize the concurrency of the function.
    - `AUTO`: Sedai will autonomously optimize the concurrency of the function.
    
    When set to `AUTO`. The actual course of action will be determined whether the Lambda is a versioned or unversioned function.
    For versioned functions, Sedai will manage concurrency by managing the provisioned concurrency. 
    For unversioned functions, Sedai will add an extension to the Lambda and use it to manage the cold starts.
    
    """
    optimization_maxCostChangePercentage: int
    """
    When Sedai is optimizing for performance, what is the maximum percentage change in cost that is acceptable.
    """
    optimization_maxLatencyChangePercentage: int
    """
    When Sedai is optimizing for cost, what is the maximum percentage change in latency that is acceptable.
    """
    telemetryLoggingEnabled: bool
    """
    Do not use. This setting is deprecated.
    """

    __AVAILABILITY_MODES: ClassVar[set] = {
        SettingsConfigMode.DATA_PILOT,
        SettingsConfigMode.AUTO,
        SettingsConfigMode.CO_PILOT,
    }
    __OPTIMIZATION_MODES: ClassVar[set] = {SettingsConfigMode.DATA_PILOT, SettingsConfigMode.AUTO}
    __CONCURRENCY_MODES: ClassVar[set] = {SettingsConfigMode.OFF, SettingsConfigMode.AUTO}

    def __parse__(self):
        super().__parse__()
        self.optimizationFocus = self.src['optimization']['optimizationFocus']['focus']
        self.optimization_maxLatencyChangePercentage = self.src['optimization'][
            'optimizationFocus'
        ]['autoOptMaxLatencyChangePct']
        self.optimization_maxCostChangePercentage = self.src['optimization']['optimizationFocus'][
            'autoOptMaxCostChangePct'
        ]
        self.optimization_concurrencyMode = self.__to_enum__(
            self.src['optimization']['concurrency']['configMode']
        )
        self.telemetryLoggingEnabled = self.src['telemetryLogging']['enabled']

    def __serialize__(self):
        self.__validate__()
        super().__serialize__()
        self.src['optimization']['optimizationFocus']['focus'] = self.optimizationFocus
        self.src['optimization']['concurrency']['configMode'] = self.__to_str__(
            self.optimization_concurrencyMode
        )
        self.src['optimization']['optimizationFocus']['autoOptMaxLatencyChangePct'] = (
            self.optimization_maxLatencyChangePercentage
        )
        self.src['optimization']['optimizationFocus']['autoOptMaxCostChangePct'] = (
            self.optimization_maxCostChangePercentage
        )
        self.src['telemetryLogging']['enabled'] = self.telemetryLoggingEnabled
        return self.src

    def __validate__(self):
        if self.__to_enum__(self.optimizationMode) not in self.__OPTIMIZATION_MODES:
            raise ValueError(
                f"Invalid optimization mode for ServerlessSettings: {self.optimizationMode}. "
                f"Allowed modes are: {self.__OPTIMIZATION_MODES}"
            )

        if self.__to_enum__(self.availabilityMode) not in self.__AVAILABILITY_MODES:
            raise ValueError(
                f"Invalid availability mode for ServerlessSettings: {self.availabilityMode}. "
                f"Allowed modes are: {self.__AVAILABILITY_MODES}"
            )

        if self.__to_enum__(self.optimization_concurrencyMode) not in self.__CONCURRENCY_MODES:
            raise ValueError(
                f"Invalid concurrency mode for ServerlessSettings: {self.optimization_concurrencyMode}. "
                f"Allowed modes are: {self.__CONCURRENCY_MODES}"
            )


############################################################################################################
# ContainerAppSettings
############################################################################################################
class ContainerAppSettings(APPSettings):
    """
    Common settings for all containerized applications. Containerized applications could be running in a container, pod, or a service.
    """

    autonomousActionWithoutTraffic: bool
    """
    If an application is marked as not in production (with `isProd` set to false), , Sedai can take more aggressive
     actions to optimize the application even if performance or traffic metrics are not available.
    """

    optimization_Focus: str
    """
    The optimization focus for the containerized application. The optimization focus determines the goal of the optimization.
    Possible values: `COST`, `DURATION`, `COST_AND_DURATION`
    - `COST`: Optimize the cost of the application.
    - `DURATION`: Optimize the duration of the application.
    - `COST_AND_DURATION`: Optimize both the cost and duration of the application.
    
    """

    optimization_maxLatencyIncreasePct: int
    """
    When Sedai is optimizing for cost, what is the maximum percentage increase in latency that is acceptable.
    """
    optimization_maxCPUIncreasePct: int
    """
    When Sedai is optimizing for performance, what is the maximum percentage increase in CPU that is acceptable.
    """
    optimization_maxMemoryIncreasePct: int
    """
    When Sedai is optimizing for performance, what is the maximum percentage increase in memory that is acceptable.
    """

    verticalScaling_enabled: bool
    """
    Enable vertical scaling for the application. Vertical scaling is the process of increasing or decreasing the resources of an instance of an application.
    """
    predictiveScaling_enabled: bool
    """
    Enable predictive scaling for the application. Predictive scaling is the process of predicting the load, performance
    and resource requirements of an application based on the application's seasonalit models and scaling the
    resources accordingly.
    """

    def __parse__(self):
        super().__parse__()
        self.verticalScaling_enabled = self.src['enableVerticalScaling']['enabled']
        self.predictiveScaling_enabled = self.src['enablePredictiveScaling']['enabled']
        self.autonomousActionWithoutTraffic = self.src['autonomousActionWithoutTraffic']['enabled']
        self.optimization_Focus = self.src['optimization']['optimizationFocus']['focus']
        self.optimization_maxMemoryIncreasePct = self.src['optimization']['optimizationFocus'][
            'maxMemoryIncreasePct'
        ]
        self.optimization_maxCPUIncreasePct = self.src['optimization']['optimizationFocus'][
            'maxCPUIncreasePct'
        ]
        self.optimization_maxLatencyIncreasePct = self.src['optimization']['optimizationFocus'][
            'maxLatencyIncreasePct'
        ]

    def __serialize__(self):
        super().__serialize__()
        self.src['enableVerticalScaling']['enabled'] = self.verticalScaling_enabled
        self.src['enablePredictiveScaling']['enabled'] = self.predictiveScaling_enabled
        self.src['autonomousActionWithoutTraffic']['enabled'] = self.autonomousActionWithoutTraffic
        self.src['optimization']['optimizationFocus']['focus'] = self.optimization_Focus
        self.src['optimization']['optimizationFocus']['maxMemoryIncreasePct'] = (
            self.optimization_maxMemoryIncreasePct
        )
        self.src['optimization']['optimizationFocus']['maxCPUIncreasePct'] = (
            self.optimization_maxCPUIncreasePct
        )
        self.src['optimization']['optimizationFocus']['maxLatencyIncreasePct'] = (
            self.optimization_maxLatencyIncreasePct
        )
        return self.src


############################################################################################################
# KubeAppSettings
############################################################################################################
class KubeAppSettings(ContainerAppSettings):
    """
    Settings for all Kubernetes applications managed by Sedai. Kubernetes applications are containerized applications
    running in a Kubernetes cluster. This could be a pod, deployment, or a service such as a deployment, statefulset, or daemonset.
    """

    __type = "KubernetesAppResourceSettingDetail"
    isOperationAllowed: bool
    """
    Is the operation allowed for the Kubernetes application. If the operation is not allowed, Sedai will not be able to
    take any actions on the application."""

    horizontalScaling_replicaMultiplier: int
    """
    The replica multiplier for the Kubernetes application. The replica multiplier is the factor by which the number of
    replicas of the application should be increased to handle the load."""

    verticalScaling_minPerContainerCpu: K8sCpuValue | None
    """
    The minimum CPU required per container in the Kubernetes application. This is the minimum amount of CPU
    that should be allocated to each container. `None` means no minimum is configured.

    The guardrail carries its unit alongside its value, so it can be expressed in whichever unit is
    natural for it - assigning a bare number is taken to mean cores.

    .. code-block:: python

            from sedai.measurement import K8sCpuValue, MetricUnit

            settings.verticalScaling_minPerContainerCpu = K8sCpuValue(250, MetricUnit.MILLICORES)
            settings.verticalScaling_minPerContainerCpu = 0.25  # same guardrail, in cores
    """
    verticalScaling_minPerContainerMemory: MemoryValue | None
    """
    The minimum memory required per container in the Kubernetes application. This is the minimum amount of
    memory that should be allocated to each container. `None` means no minimum is configured.
    Assigning a bare number is taken to mean bytes.
    """

    verticalScaling_maxPerContainerCpu: K8sCpuValue | None
    """
    The maximum CPU allowed per container in the Kubernetes application. Sedai will not increase CPU beyond
    this limit. `None` means no maximum is configured. Assigning a bare number is taken to mean cores.
    """
    verticalScaling_maxPerContainerMemory: MemoryValue | None
    """
    The maximum memory allowed per container in the Kubernetes application. Sedai will not increase memory
    beyond this limit. `None` means no maximum is configured. Assigning a bare number is taken to mean bytes.
    """

    optimizePvcDeployments: bool
    """
    Enable optimization for PVC-based deployments in the Kubernetes application. When enabled, Sedai will optimize
    deployments that use Persistent Volume Claims (PVCs), which typically require special handling during scaling
    operations due to volume attachment constraints.
    """

    verticalScaling_enableCpuLimitModification: bool
    """
    Allow Sedai to modify the CPU limit (not just the request) when vertically scaling containers.
    """
    verticalScaling_doNotDownsizeCpuLimit: bool
    """
    Guardrail: never reduce a container's CPU limit, even if the CPU request is being reduced.
    """
    verticalScaling_doNotDownsizeMemoryLimit: bool
    """
    Guardrail: never reduce a container's memory limit, even if the memory request is being reduced.
    """
    verticalScaling_honorCpuRequestLimitRatio: bool
    """
    Guardrail: preserve the existing ratio between CPU request and CPU limit when scaling.
    """
    verticalScaling_honorMemoryRequestLimitRatio: bool
    """
    Guardrail: preserve the existing ratio between memory request and memory limit when scaling.
    """

    enableVerticalPodAutoscaler: bool
    """
    Enable Sedai's integration with the Kubernetes Vertical Pod Autoscaler (VPA) for this application.
    """
    enableAvailabilityActionOnOptimizedResourceOnly: bool
    """
    Guardrail: restrict availability (protective) actions to resources Sedai has already optimized,
    rather than allowing them on any resource.
    """
    isInPlacePodResizing: bool
    """
    Allow Sedai to use in-place pod resizing (resize CPU/memory without restarting the pod) where supported,
    instead of always restarting the pod to apply a change.
    """
    smartSchedulerOptIn: bool
    """
    Opt this application into Sedai's smart scheduler.
    """
    gpu_enableMig: bool
    """
    Enable Multi-Instance GPU (MIG) awareness for this application's GPU recommendations.
    """
    gpu_enableFractionalGpu: bool
    """
    Enable fractional GPU awareness for this application's GPU recommendations.
    """

    def __parse__(self):
        super().__parse__()
        self.isOperationAllowed = self.src['isOperationAllowed']['enabled']
        self.horizontalScaling_replicaMultiplier = self.src['enableHorizontalScaling'][
            'replicaMultiplier'
        ]
        self.verticalScaling_minPerContainerCpu = K8sCpuValue.__parse__(
            self.src['enableVerticalScaling'].get('minPerContainerCpu')
        )
        self.verticalScaling_minPerContainerMemory = MemoryValue.__parse__(
            self.src['enableVerticalScaling'].get('minPerContainerMemory')
        )
        self.verticalScaling_maxPerContainerCpu = K8sCpuValue.__parse__(
            self.src['enableVerticalScaling'].get('maxPerContainerCpu')
        )
        self.verticalScaling_maxPerContainerMemory = MemoryValue.__parse__(
            self.src['enableVerticalScaling'].get('maxPerContainerMemory')
        )
        self.verticalScaling_enableCpuLimitModification = self.src['enableVerticalScaling'].get(
            'enableCpuLimitModification', False
        )
        self.verticalScaling_doNotDownsizeCpuLimit = self.src['enableVerticalScaling'].get(
            'doNotDownsizeCpuLimit', False
        )
        self.verticalScaling_doNotDownsizeMemoryLimit = self.src['enableVerticalScaling'].get(
            'doNotDownsizeMemoryLimit', False
        )
        self.verticalScaling_honorCpuRequestLimitRatio = self.src['enableVerticalScaling'].get(
            'honorCpuRequestLimitRatio', False
        )
        self.verticalScaling_honorMemoryRequestLimitRatio = self.src['enableVerticalScaling'].get(
            'honorMemoryRequestLimitRatio', False
        )
        self.optimizePvcDeployments = self.src['optimizePvcDeployments']['enabled']
        # these fields can be missing or explicitly null on older settings - see __get_dict__.
        self.enableVerticalPodAutoscaler = __get_dict__(
            self.src, 'enableVerticalPodAutoscaler'
        ).get('enabled', False)
        self.enableAvailabilityActionOnOptimizedResourceOnly = __get_dict__(
            self.src, 'enableAvailabilityActionOnOptimizedResourceOnly'
        ).get('enabled', False)
        self.isInPlacePodResizing = __get_dict__(self.src, 'isInPlacePodResizing').get(
            'enabled', False
        )
        self.smartSchedulerOptIn = __get_dict__(self.src, 'smartSchedulerOptIn').get(
            'enabled', False
        )
        gpu = __get_dict__(self.src, 'gpu')
        self.gpu_enableMig = gpu.get('enableMig', False)
        self.gpu_enableFractionalGpu = gpu.get('enableFractionalGpu', False)

    def __serialize__(self):
        super().__serialize__()
        self.src['isOperationAllowed']['enabled'] = self.isOperationAllowed
        self.src['enableHorizontalScaling']['replicaMultiplier'] = (
            self.horizontalScaling_replicaMultiplier
        )
        self.src['enableVerticalScaling']['minPerContainerCpu'] = __serialize_metric__(
            self.verticalScaling_minPerContainerCpu, K8sCpuValue
        )
        self.src['enableVerticalScaling']['minPerContainerMemory'] = __serialize_metric__(
            self.verticalScaling_minPerContainerMemory, MemoryValue
        )
        self.src['enableVerticalScaling']['maxPerContainerCpu'] = __serialize_metric__(
            self.verticalScaling_maxPerContainerCpu, K8sCpuValue
        )
        self.src['enableVerticalScaling']['maxPerContainerMemory'] = __serialize_metric__(
            self.verticalScaling_maxPerContainerMemory, MemoryValue
        )
        self.src['enableVerticalScaling']['enableCpuLimitModification'] = (
            self.verticalScaling_enableCpuLimitModification
        )
        self.src['enableVerticalScaling']['doNotDownsizeCpuLimit'] = (
            self.verticalScaling_doNotDownsizeCpuLimit
        )
        self.src['enableVerticalScaling']['doNotDownsizeMemoryLimit'] = (
            self.verticalScaling_doNotDownsizeMemoryLimit
        )
        self.src['enableVerticalScaling']['honorCpuRequestLimitRatio'] = (
            self.verticalScaling_honorCpuRequestLimitRatio
        )
        self.src['enableVerticalScaling']['honorMemoryRequestLimitRatio'] = (
            self.verticalScaling_honorMemoryRequestLimitRatio
        )
        self.src['optimizePvcDeployments']['enabled'] = self.optimizePvcDeployments
        __ensure_dict__(self.src, 'enableVerticalPodAutoscaler')['enabled'] = (
            self.enableVerticalPodAutoscaler
        )
        __ensure_dict__(self.src, 'enableAvailabilityActionOnOptimizedResourceOnly')['enabled'] = (
            self.enableAvailabilityActionOnOptimizedResourceOnly
        )
        __ensure_dict__(self.src, 'isInPlacePodResizing')['enabled'] = self.isInPlacePodResizing
        __ensure_dict__(self.src, 'smartSchedulerOptIn')['enabled'] = self.smartSchedulerOptIn
        gpu = __ensure_dict__(self.src, 'gpu')
        gpu['enableMig'] = self.gpu_enableMig
        gpu['enableFractionalGpu'] = self.gpu_enableFractionalGpu
        return self.src

    ########################################################################################################
    # Deprecated scalar views over the vertical scaling guardrails, kept so code written against the
    # pre value + unit SDK keeps working. Each one reads and writes the guardrail in the unit its name
    # states, whatever unit the guardrail itself is stored in.
    ########################################################################################################

    @property
    def verticalScaling_minPerContainerCpuInCores(self) -> float | None:
        """
        Deprecated. Use `verticalScaling_minPerContainerCpu`, which carries the unit with the value.

        The minimum CPU per container, in cores.
        """
        return __metric_scalar__(
            self.verticalScaling_minPerContainerCpu, K8sCpuValue, MetricUnit.CORES
        )

    @verticalScaling_minPerContainerCpuInCores.setter
    def verticalScaling_minPerContainerCpuInCores(self, cores: float | None):
        self.verticalScaling_minPerContainerCpu = (
            None if cores is None else K8sCpuValue(cores, MetricUnit.CORES)
        )

    @property
    def verticalScaling_minPerContainerMemoryInBytes(self) -> float | None:
        """
        Deprecated. Use `verticalScaling_minPerContainerMemory`, which carries the unit with the value.

        The minimum memory per container, in bytes.
        """
        return __metric_scalar__(
            self.verticalScaling_minPerContainerMemory, MemoryValue, MetricUnit.BYTES
        )

    @verticalScaling_minPerContainerMemoryInBytes.setter
    def verticalScaling_minPerContainerMemoryInBytes(self, memory_bytes: float | None):
        self.verticalScaling_minPerContainerMemory = (
            None if memory_bytes is None else MemoryValue(memory_bytes, MetricUnit.BYTES)
        )

    @property
    def verticalScaling_maxPerContainerCpuInCores(self) -> float | None:
        """
        Deprecated. Use `verticalScaling_maxPerContainerCpu`, which carries the unit with the value.

        The maximum CPU per container, in cores.
        """
        return __metric_scalar__(
            self.verticalScaling_maxPerContainerCpu, K8sCpuValue, MetricUnit.CORES
        )

    @verticalScaling_maxPerContainerCpuInCores.setter
    def verticalScaling_maxPerContainerCpuInCores(self, cores: float | None):
        self.verticalScaling_maxPerContainerCpu = (
            None if cores is None else K8sCpuValue(cores, MetricUnit.CORES)
        )

    @property
    def verticalScaling_maxPerContainerMemoryInBytes(self) -> float | None:
        """
        Deprecated. Use `verticalScaling_maxPerContainerMemory`, which carries the unit with the value.

        The maximum memory per container, in bytes.
        """
        return __metric_scalar__(
            self.verticalScaling_maxPerContainerMemory, MemoryValue, MetricUnit.BYTES
        )

    @verticalScaling_maxPerContainerMemoryInBytes.setter
    def verticalScaling_maxPerContainerMemoryInBytes(self, memory_bytes: float | None):
        self.verticalScaling_maxPerContainerMemory = (
            None if memory_bytes is None else MemoryValue(memory_bytes, MetricUnit.BYTES)
        )


############################################################################################################
# ECSAppSettings
############################################################################################################
class ECSAppSettings(ContainerAppSettings):
    """
    Settings for all ECS applications managed by Sedai. ECS applications are containerized applications running in an ECS cluster.
    This could be a task, service, or a container running in an ECS cluster.
    """

    __type = "ECSAppResourceSettingDetail"
    serviceAutoscalingEnabled: bool
    """
    Enable service autoscaling for the ECS application. Service autoscaling is the process of automatically scaling the
    resources of the service based on the load and performance metrics of the service.
    """
    verticalScaling_minCpu: ECSCpuValue | None
    """
    The minimum CPU required for the ECS application. This is the minimum amount of CPU that should be
    allocated to the application. `None` means no minimum is configured.

    The guardrail carries its unit alongside its value, so it can be expressed in whichever unit is
    natural for it - assigning a bare number is taken to mean ECS CPU units.

    .. code-block:: python

            from sedai.measurement import ECSCpuValue, MetricUnit

            settings.verticalScaling_minCpu = ECSCpuValue(0.5, MetricUnit.VCPU)
            settings.verticalScaling_minCpu = 512  # same guardrail, in CPU units
    """
    verticalScaling_minMemory: MemoryValue | None
    """
    The minimum memory required for the ECS application. This is the minimum amount of memory that should
    be allocated to the application. `None` means no minimum is configured. Assigning a bare number is
    taken to mean mebibytes, the unit ECS task definitions use for memory.
    """
    horizontalScaling_replicaIncrement: int
    """
    The Replica Increment Step is the fixed number of replica tasks that are added or removed from the ECS application during a single scaling event.
    It determines how aggressively the application scales in or out to handle changes in load.
     """

    def __parse__(self):
        super().__parse__()
        self.horizontalScaling_replicaIncrement = self.src['enableHorizontalScaling'][
            'replicaIncrement'
        ]
        self.serviceAutoscalingEnabled = self.src['enableServiceAutoscalingConfiguration'][
            'enabled'
        ]
        self.verticalScaling_minCpu = ECSCpuValue.__parse__(
            self.src['enableVerticalScaling'].get('minCpu')
        )
        self.verticalScaling_minMemory = MemoryValue.__parse__(
            self.src['enableVerticalScaling'].get('minMemory'), MetricUnit.MEBI_BYTES
        )

    def __serialize__(self):
        super().__serialize__()
        self.src['enableHorizontalScaling']['replicaIncrement'] = (
            self.horizontalScaling_replicaIncrement
        )
        self.src['enableServiceAutoscalingConfiguration']['enabled'] = (
            self.serviceAutoscalingEnabled
        )
        self.src['enableVerticalScaling']['minCpu'] = __serialize_metric__(
            self.verticalScaling_minCpu, ECSCpuValue
        )
        self.src['enableVerticalScaling']['minMemory'] = __serialize_metric__(
            self.verticalScaling_minMemory, MemoryValue, MetricUnit.MEBI_BYTES
        )
        return self.src

    ########################################################################################################
    # Deprecated scalar views over the vertical scaling guardrails. Before the guardrails carried their
    # unit, `verticalScaling_minCpu` was a bare number of ECS CPU units and `verticalScaling_minMemory` a
    # bare number of mebibytes; these read and write the guardrails in exactly those units.
    ########################################################################################################

    @property
    def verticalScaling_minCpuInCpuUnits(self) -> float | None:
        """
        Deprecated. Use `verticalScaling_minCpu`, which carries the unit with the value.

        The minimum CPU for the application, in ECS CPU units.
        """
        return __metric_scalar__(self.verticalScaling_minCpu, ECSCpuValue, MetricUnit.CPU_UNITS)

    @verticalScaling_minCpuInCpuUnits.setter
    def verticalScaling_minCpuInCpuUnits(self, cpu_units: float | None):
        self.verticalScaling_minCpu = (
            None if cpu_units is None else ECSCpuValue(cpu_units, MetricUnit.CPU_UNITS)
        )

    @property
    def verticalScaling_minMemoryInMiB(self) -> float | None:
        """
        Deprecated. Use `verticalScaling_minMemory`, which carries the unit with the value.

        The minimum memory for the application, in mebibytes.
        """
        return __metric_scalar__(
            self.verticalScaling_minMemory,
            MemoryValue,
            MetricUnit.MEBI_BYTES,
            MetricUnit.MEBI_BYTES,
        )

    @verticalScaling_minMemoryInMiB.setter
    def verticalScaling_minMemoryInMiB(self, memory_mib: float | None):
        self.verticalScaling_minMemory = (
            None if memory_mib is None else MemoryValue(memory_mib, MetricUnit.MEBI_BYTES)
        )


############################################################################################################
# RDSSettings
############################################################################################################
class RDSSettings(BaseSettings):
    """
    Settings for all RDS database resources managed by Sedai (RDS instances and clusters). RDS has no
    sizing guardrails today (no instance-class allow/deny list, no storage/IOPS bounds) - only the
    optimization-restriction toggles below plus the common availability/optimization modes.
    """

    __type = "DatabaseResourceSettingDetail"

    isProd: bool
    """
    Is this database in production. If not, Sedai can take more aggressive actions to optimize it.
    """
    optimization_restrictCrossArchitectureRecommendations: bool
    """
    Guardrail: don't recommend an instance class on a different CPU architecture (e.g. Intel -> Graviton)
    than the one currently in use.
    """
    optimization_restrictBurstableInstanceRecommendations: bool
    """
    Guardrail: don't recommend burstable (e.g. `db.t`-family) instance classes.
    """
    optimization_ignoreAWSMaintenanceWindow: bool
    """
    Allow Sedai to act outside of the database's configured AWS maintenance window, rather than
    restricting actions to that window.
    """

    def __parse__(self):
        super().__parse__()
        self.isProd = self.src['isProd']['enabled']
        optimization = self.src['optimization']
        self.optimization_restrictCrossArchitectureRecommendations = optimization[
            'restrictCrossArchitectureRecommendations'
        ]['enabled']
        self.optimization_restrictBurstableInstanceRecommendations = optimization[
            'restrictBurstableInstanceRecommendations'
        ]['enabled']
        self.optimization_ignoreAWSMaintenanceWindow = optimization['ignoreAWSMaintenanceWindow'][
            'enabled'
        ]

    def __serialize__(self):
        super().__serialize__()
        self.src['isProd']['enabled'] = self.isProd
        optimization = self.src['optimization']
        optimization['restrictCrossArchitectureRecommendations']['enabled'] = (
            self.optimization_restrictCrossArchitectureRecommendations
        )
        optimization['restrictBurstableInstanceRecommendations']['enabled'] = (
            self.optimization_restrictBurstableInstanceRecommendations
        )
        optimization['ignoreAWSMaintenanceWindow']['enabled'] = (
            self.optimization_ignoreAWSMaintenanceWindow
        )
        return self.src


############################################################################################################
# BucketSettings
############################################################################################################
class BucketSettings(BaseSettings):
    """
    Settings for all storage buckets managed by Sedai. Storage buckets are used to store self.src and files in the cloud.
    """

    __type = "StorageBucketeResourceSettingDetail"
    __OPTIMIZATION_CONFIG_MODES: ClassVar[set] = {
        SettingsConfigMode.DATA_PILOT,
        SettingsConfigMode.CO_PILOT,
    }

    def __parse__(self):
        super().__parse__()

    def __serialize__(self):
        self.__validate__()
        super().__serialize__()
        return self.src

    def __validate__(self):

        if self.__to_enum__(self.optimizationMode) not in self.__OPTIMIZATION_CONFIG_MODES:
            raise ValueError(
                f"Invalid optimization mode for Bucket: {self.optimizationMode}"
                f"Allowed modes are: {self.__OPTIMIZATION_CONFIG_MODES}"
            )

        # bucket doesn't support availability, but the default value is set to DATA_PILOT.
        if self.__to_enum__(self.availabilityMode) != SettingsConfigMode.DATA_PILOT:
            raise ValueError(" Bucket doesn't support availability.")


class VolumeSettings(BaseSettings):
    """
    Settings for all storage volumes managed by Sedai. Storage volumes are used to store self.src and files in the cloud.
    """

    __type = "VolumeResourceSettingDetail"

    __CONFIG_MODES: ClassVar[set] = {SettingsConfigMode.DATA_PILOT, SettingsConfigMode.CO_PILOT}

    def __parse__(self):
        super().__parse__()

    def __serialize__(self):
        self.__validate__()
        super().__serialize__()
        return self.src

    def __validate__(self):

        if self.__to_enum__(self.optimizationMode) not in self.__CONFIG_MODES:
            raise ValueError(
                f"Invalid Optimization mode for Volume: {self.optimizationMode}"
                f"Allowed modes are: {self.__CONFIG_MODES}"
            )
        if self.__to_enum__(self.availabilityMode) not in self.__CONFIG_MODES:
            raise ValueError(
                f"Invalid Availability mode for Volume: {self.optimizationMode}"
                f"Allowed modes are: {self.__CONFIG_MODES}"
            )


############################################################################################################
# KubeNodePoolSettings
############################################################################################################
class KubeNodePoolSettings:
    """
    Settings for Kubernetes node pools managed by Sedai. Node pools don't have the availability/SLO/
    release-intelligence settings that other resources have - the backend intentionally ignores them
    on write for node pools - so unlike the other settings classes, this doesn't extend `BaseSettings`.
    Only an optimization mode plus the node-count / hardware-preference guardrails that govern node
    pool scaling recommendations are exposed here.
    """

    __type = "KubernetesNodePoolResourceSettingDetail"
    __CONFIG_MODES: ClassVar[list] = [
        SettingsConfigMode.DATA_PILOT,
        SettingsConfigMode.CO_PILOT,
        SettingsConfigMode.AUTO,
    ]

    optimizationMode: SettingsConfigMode
    """
    The optimization mode of the node pool. This setting determines if Sedai should autonomously
    optimize the node pool's scaling. Possible values: `DATA_PILOT`, `CO_PILOT`, `AUTO`.
    """

    minAllowedNumberOfNodes: int | None
    """
    Guardrail: the minimum number of nodes Sedai will allow the node pool to be scaled down to.
    """
    maxAllowedNumberOfNodes: int | None
    """
    Guardrail: the maximum number of nodes Sedai will allow the node pool to be scaled up to.
    A value of -1 means no maximum.
    """
    maxAllowedNumberOfIPs: int | None
    """
    Guardrail: the maximum number of IP addresses the node pool is allowed to consume.
    """
    minimumTempDiskSizeRequiredInGB: int | None
    """
    Guardrail: the minimum temporary/ephemeral disk size, in GB, a node in this pool must have.
    """

    nodeRecommendationGuardrails_whitelistedInstanceCategories: list[str] | None
    """
    Guardrail: instance categories (e.g. general purpose, compute optimized) Sedai is allowed to
    recommend for this node pool. `None`/empty means no restriction.
    """
    nodeRecommendationGuardrails_blacklistedInstanceCategories: list[str] | None
    """
    Guardrail: instance categories Sedai must never recommend for this node pool.
    """
    nodeRecommendationGuardrails_whitelistedInstanceFamilies: list[str] | None
    """
    Guardrail: instance families Sedai is allowed to recommend for this node pool.
    """
    nodeRecommendationGuardrails_blacklistedInstanceFamilies: list[str] | None
    """
    Guardrail: instance families Sedai must never recommend for this node pool.
    """
    nodeRecommendationGuardrails_excludeFlexAndBurstableInstanceTypes: bool | None
    """
    Guardrail: exclude flexible/burstable instance types (e.g. AWS T-family) from recommendations.
    """
    nodeRecommendationGuardrails_minCpu: K8sCpuValue | None
    """
    Guardrail: the minimum CPU Sedai will allow a recommended instance type to have.
    """
    nodeRecommendationGuardrails_maxCpu: K8sCpuValue | None
    """
    Guardrail: the maximum CPU Sedai will allow a recommended instance type to have.
    """
    nodeRecommendationGuardrails_minMemory: MemoryValue | None
    """
    Guardrail: the minimum memory Sedai will allow a recommended instance type to have.
    """
    nodeRecommendationGuardrails_maxMemory: MemoryValue | None
    """
    Guardrail: the maximum memory Sedai will allow a recommended instance type to have.
    """
    nodeRecommendationGuardrails_minNetworkBandwidthInGbps: float | None
    """
    Guardrail: the minimum network bandwidth, in Gbps, Sedai will allow a recommended instance type
    to have.
    """
    nodeRecommendationGuardrails_architectures: list[str] | None
    """
    Guardrail: CPU architectures (e.g. `amd64`, `arm64`) Sedai is allowed to recommend.
    """
    nodeRecommendationGuardrails_capacityTypes: list[str] | None
    """
    Guardrail: capacity types (e.g. `ON_DEMAND`, `SPOT`) Sedai is allowed to recommend.
    """

    def __init__(self, src):
        """@private"""
        self.src = src
        self.__parse__()

    def __to_enum__(self, value: str | SettingsConfigMode) -> SettingsConfigMode | None:
        if isinstance(value, SettingsConfigMode):
            return value
        if value is None:
            return None
        return SettingsConfigMode(value)

    def __to_str__(self, value: str | SettingsConfigMode) -> str:
        if isinstance(value, str) or value is None:
            return value
        return value.value

    def __parse__(self):
        self.optimizationMode = self.__to_enum__(self.src['optimization']['setting']['configMode'])
        self.minAllowedNumberOfNodes = self.src.get('minAllowedNumberOfNodes')
        self.maxAllowedNumberOfNodes = self.src.get('maxAllowedNumberOfNodes')
        self.maxAllowedNumberOfIPs = self.src.get('maxAllowedNumberOfIPs')
        self.minimumTempDiskSizeRequiredInGB = self.src.get('minimumTempDiskSizeRequiredInGB')

        guardrails = self.src.get('nodeRecommendationGuardrails') or {}
        self.nodeRecommendationGuardrails_whitelistedInstanceCategories = guardrails.get(
            'whitelistedInstanceCategories'
        )
        self.nodeRecommendationGuardrails_blacklistedInstanceCategories = guardrails.get(
            'blacklistedInstanceCategories'
        )
        self.nodeRecommendationGuardrails_whitelistedInstanceFamilies = guardrails.get(
            'whitelistedInstanceFamilies'
        )
        self.nodeRecommendationGuardrails_blacklistedInstanceFamilies = guardrails.get(
            'blacklistedInstanceFamilies'
        )
        self.nodeRecommendationGuardrails_excludeFlexAndBurstableInstanceTypes = guardrails.get(
            'excludeFlexAndBurstableInstanceTypes'
        )
        self.nodeRecommendationGuardrails_minCpu = K8sCpuValue.__parse__(guardrails.get('minCpu'))
        self.nodeRecommendationGuardrails_maxCpu = K8sCpuValue.__parse__(guardrails.get('maxCpu'))
        self.nodeRecommendationGuardrails_minMemory = MemoryValue.__parse__(
            guardrails.get('minMemory')
        )
        self.nodeRecommendationGuardrails_maxMemory = MemoryValue.__parse__(
            guardrails.get('maxMemory')
        )
        self.nodeRecommendationGuardrails_minNetworkBandwidthInGbps = guardrails.get(
            'minNetworkBandwidthInGbps'
        )
        self.nodeRecommendationGuardrails_architectures = guardrails.get('architectures')
        self.nodeRecommendationGuardrails_capacityTypes = guardrails.get('capacityTypes')

    def __serialize__(self):
        self.__validate__()
        self.src['optimization']['setting']['configMode'] = self.__to_str__(self.optimizationMode)
        self.src['minAllowedNumberOfNodes'] = self.minAllowedNumberOfNodes
        self.src['maxAllowedNumberOfNodes'] = self.maxAllowedNumberOfNodes
        self.src['maxAllowedNumberOfIPs'] = self.maxAllowedNumberOfIPs
        self.src['minimumTempDiskSizeRequiredInGB'] = self.minimumTempDiskSizeRequiredInGB

        guardrails = __ensure_dict__(self.src, 'nodeRecommendationGuardrails')
        guardrails['whitelistedInstanceCategories'] = (
            self.nodeRecommendationGuardrails_whitelistedInstanceCategories
        )
        guardrails['blacklistedInstanceCategories'] = (
            self.nodeRecommendationGuardrails_blacklistedInstanceCategories
        )
        guardrails['whitelistedInstanceFamilies'] = (
            self.nodeRecommendationGuardrails_whitelistedInstanceFamilies
        )
        guardrails['blacklistedInstanceFamilies'] = (
            self.nodeRecommendationGuardrails_blacklistedInstanceFamilies
        )
        guardrails['excludeFlexAndBurstableInstanceTypes'] = (
            self.nodeRecommendationGuardrails_excludeFlexAndBurstableInstanceTypes
        )
        guardrails['minCpu'] = __serialize_metric__(
            self.nodeRecommendationGuardrails_minCpu, K8sCpuValue
        )
        guardrails['maxCpu'] = __serialize_metric__(
            self.nodeRecommendationGuardrails_maxCpu, K8sCpuValue
        )
        guardrails['minMemory'] = __serialize_metric__(
            self.nodeRecommendationGuardrails_minMemory, MemoryValue
        )
        guardrails['maxMemory'] = __serialize_metric__(
            self.nodeRecommendationGuardrails_maxMemory, MemoryValue
        )
        guardrails['minNetworkBandwidthInGbps'] = (
            self.nodeRecommendationGuardrails_minNetworkBandwidthInGbps
        )
        guardrails['architectures'] = self.nodeRecommendationGuardrails_architectures
        guardrails['capacityTypes'] = self.nodeRecommendationGuardrails_capacityTypes
        return self.src

    def __validate__(self):
        if self.__to_enum__(self.optimizationMode) not in self.__CONFIG_MODES:
            raise ValueError(
                f"Invalid optimization mode for node pool: {self.optimizationMode}. "
                f"Allowed modes are: {self.__CONFIG_MODES}"
            )


type_map = {
    "AppCommonResourceSettingDetail": APPSettings,
    "ServerlessFunctionResourceSettingDetail": ServerlessSettings,
    "KubernetesAppResourceSettingDetail": KubeAppSettings,
    "ECSAppResourceSettingDetail": ECSAppSettings,
    "StorageBucketeResourceSettingDetail": BucketSettings,
    "VolumeResourceSettingDetail": VolumeSettings,
    "KubernetesNodePoolResourceSettingDetail": KubeNodePoolSettings,
    "DatabaseResourceSettingDetail": RDSSettings,
}

"""
@private
"""


############################################################################################################
# Settings
############################################################################################################
class Settings:
    """
    Settings for all resources managed by Sedai. This setting configuration is for a set of resources, grouped
    either in a group in Sedai or at the level of the account or cluster.
    """

    app_settings: APPSettings | None
    """
    The settings for all application resources. `None` if this group/account predates this
    resource type and has no persisted settings for it.
    """
    serverless_settings: ServerlessSettings | None
    """
    The settings for all serverless resources. `None` if unavailable - see `app_settings`.
    """
    kube_app_settings: KubeAppSettings | None
    """
    The settings for all Kubernetes application resources. `None` if unavailable - see `app_settings`.
    """
    ecs_app_settings: ECSAppSettings | None
    """
    The settings for all ECS application resources. `None` if unavailable - see `app_settings`.
    """
    bucket_settings: BucketSettings | None
    """
    The settings for all storage bucket resources. `None` if unavailable - see `app_settings`.
    """
    volume_settings: VolumeSettings | None
    """
    The settings for all storage volume resources. `None` if unavailable - see `app_settings`.
    """
    rds_settings: RDSSettings | None
    """
    The settings for all RDS database resources. `None` if unavailable - see `app_settings`.
    """
    node_pool_settings: KubeNodePoolSettings | None
    """
    The settings for all Kubernetes node pool resources. `None` if unavailable - see `app_settings`.
    """

    def __init__(self, src):
        """
        @private
        """
        self.src = src
        # a section can be present but null (e.g. a group/account whose persisted keys predate
        # that resource type), so default every section to None for callers to feature-detect
        self.app_settings = None
        self.serverless_settings = None
        self.kube_app_settings = None
        self.ecs_app_settings = None
        self.bucket_settings = None
        self.volume_settings = None
        self.rds_settings = None
        self.node_pool_settings = None
        self.__parse__()

    def __parse__(self):
        """
        @private
        """
        for key, value in self.src.items():
            if value is None:
                continue
            if key == "appCommonSettings":
                self.app_settings = APPSettings(value)
                self.app_settings.__parse__()
            elif key == "serverlessSettings":
                self.serverless_settings = ServerlessSettings(value)
                self.serverless_settings.__parse__()
            elif key == "kubeSettings":
                self.kube_app_settings = KubeAppSettings(value)
                self.kube_app_settings.__parse__()
            elif key == "ecsSettings":
                self.ecs_app_settings = ECSAppSettings(value)
                self.ecs_app_settings.__parse__()
            elif key == "bucketSettings":
                self.bucket_settings = BucketSettings(value)
                self.bucket_settings.__parse__()
            elif key == "volumeSettings":
                self.volume_settings = VolumeSettings(value)
                self.volume_settings.__parse__()
            elif key == "databaseSettings":
                self.rds_settings = RDSSettings(value)
                self.rds_settings.__parse__()
            elif key == "kubeNodePoolSettings":
                self.node_pool_settings = KubeNodePoolSettings(value)
                self.node_pool_settings.__parse__()

    def __serialize__(self):
        """
        @private
        """
        __src = copy.deepcopy(self.src)
        for key, value in __src.items():
            if value is None:
                continue
            if key == "appCommonSettings":
                __merge_dict_recursive__(value, self.app_settings.__serialize__())
            elif key == "serverlessSettings":
                __merge_dict_recursive__(value, self.serverless_settings.__serialize__())
            elif key == "kubeSettings":
                __merge_dict_recursive__(value, self.kube_app_settings.__serialize__())
            elif key == "ecsSettings":
                __merge_dict_recursive__(value, self.ecs_app_settings.__serialize__())
            elif key == "bucketSettings":
                __merge_dict_recursive__(value, self.bucket_settings.__serialize__())
            elif key == "volumeSettings":
                __merge_dict_recursive__(value, self.volume_settings.__serialize__())
            elif key == "databaseSettings":
                __merge_dict_recursive__(value, self.rds_settings.__serialize__())
            elif key == "kubeNodePoolSettings":
                __merge_dict_recursive__(value, self.node_pool_settings.__serialize__())

        return __src


def __merge_dict_recursive__(dict1, dict2):
    for key, value in dict2.items():
        # Only recurse where both sides are dictionaries. A guardrail that was unset in the response
        # and has since been given a value is a null on one side and an object on the other, and has
        # to be replaced outright rather than merged into.
        if isinstance(value, dict) and isinstance(dict1.get(key), dict):
            __merge_dict_recursive__(dict1[key], value)
        else:
            dict1[key] = value


############################################################################################################
# Managing resource, group and account settings
############################################################################################################


def get_resource_settings(resource_id):
    """
    Get the settings for a resource with the given resource ID.
    The returned settings object will be of the appropriate type based on the type of the resource.

    :param resource_id: The ID of the resource.
    :return: The settings for the resource.
    """
    request = api.GetRequest(
        '/api/settingsV2/topology/configs/resource', params={'resourceId': resource_id}
    )
    response = api.do_get(request)
    settings_json = response['result']['attributes']['setting']
    type = settings_json['type']
    setting_obj = type_map[type](settings_json)
    setting_obj.__parse__()
    return setting_obj


def update_resource_settings(resource_id, settings):
    """
    Update the settings for a resource with the given resource ID.
    The settings object should be of the appropriate type based on the type of the resource.

    :param resource_id: The ID of the resource.
    :param settings: The settings for the resource.
    :return: True if the settings were updated successfully, False otherwise.
    :raises: Exception if the settings could not be updated.

    """
    payload = {'resourceId': resource_id, 'setting': settings.__serialize__(), 'overriden': True}
    request = api.PostRequest('/api/settingsV2/topology/configs/resource', payload=payload)
    response = api.do_post(request)
    if response['status'] != 'OK':
        raise RuntimeError(f"Failed to update resource settings: {response['message']}")
    return True


def get_group_settings(group_id):
    """
    Get the settings for a group with the given group ID.
    :param group_id: The ID of the group.
    :return: A settings object containing the settings for the group.
    """
    try:
        request = api.GetRequest(
            '/api/settingsV2/topology/configs/group', params={'groupIdentifier': group_id}
        )
        response = api.do_get(request)
        settings_json = response['result']['setting']
        setting_obj = Settings(settings_json)
        setting_obj.__parse__()
        return setting_obj
    except Exception as e:  # noqa: BLE001 - intentional catch-all boundary; logs/wraps and degrades gracefully
        raise RuntimeError(
            f"Failed to get group settings; you may have to initialize the group settings first: {e}"
        )


def update_group_settings(group_id, settings):
    """
    Update the settings for a group with the given group ID.
    :param group_id: The ID of the group.
    :param settings: The settings for the group.
    :return: True if the settings were updated successfully, False otherwise.
    :raises: Exception if the settings could not be updated.
    """
    payload = settings.__serialize__()

    request = api.PostRequest(f'/api/settingsV2/topology/configs/group/{group_id}', payload=payload)
    response = api.do_post(request)
    if response['status'] != 'OK':
        raise RuntimeError(f"Failed to update group settings: {response['message']}")
    return True


def initialize_group_settings(group_id):
    """
    Initialize the settings for a group with the given group ID. When a group is
    created, the settings for the group need to be initialized before they can be updated.
    :param group_id: The ID of the group.
    :return: True if the settings were initialized successfully, False otherwise.
    :raises: Exception if the settings could not be initialized.
    """
    request = api.PostRequest(f'/api/settingsV2/topology/group/init?groupId={group_id}', payload={})
    response = api.do_post(request)
    if response['status'] != 'OK':
        raise RuntimeError(f"Failed to initialize group settings: {response['message']}")
    return True


def enable_group_for_settings(group_id: str) -> bool:
    """
    Enables the settings for a group with the given group ID.

    :param group_id: The ID of the group.
    :return: True if the settings were enabled successfully, False otherwise.
    :raises: Exception if the settings could not be enabled.
    """
    request = api.PostRequest(
        f'/api/sedaigroup/enable/group?isActive=true&groupIdentifiers={group_id}', payload={}
    )
    response = api.do_post(request)
    if response['status'] != 'OK':
        raise RuntimeError(f"Failed to enable group settings: {response['message']}")
    return True


def disable_group_for_settings(group_id: str) -> bool:
    """
    Disables the settings for a group with the given group ID.

    :param group_id: The ID of the group.
    :return: True if the settings were disabled successfully, False otherwise.
    :raises: Exception if the settings could not be disabled.
    """
    request = api.PostRequest(
        f'/api/sedaigroup/enable/group?isActive=false&groupIdentifiers={group_id}', payload={}
    )
    response = api.do_post(request)
    if response['status'] != 'OK':
        raise RuntimeError(f"Failed to disable group settings: {response['message']}")
    return True


def get_account_settings(account_id):
    """
    Get the settings for an account with the given account ID.
    :param account_id: The ID of the account.
    :return: The settings for the account.

    """
    request = api.GetRequest(
        '/api/settingsV2/topology/configs/account', params={'accountId': account_id}
    )
    response = api.do_get(request)
    settings_json = response['result']['attributes']['setting']
    setting_obj = Settings(settings_json)
    setting_obj.__parse__()
    return setting_obj


def update_account_settings(account_id, settings):
    """
    Update the settings for an account with the given account ID.
    :param account_id: The ID of the account.
    :param settings: The settings for the account.
    :return: True if the settings were updated successfully, False otherwise.
    :raises: Exception if the settings could not be updated.
    """
    payload = settings.__serialize__()

    request = api.PostRequest(
        f'/api/settingsV2/topology/configs/account/{account_id}', payload=payload
    )
    response = api.do_post(request)
    if response['status'] != 'OK':
        raise RuntimeError(f"Failed to update account settings: {response['message']}")
    return True


def __disable_monitoring(settings: Settings):
    settings.kube_app_settings.releaseIntelligenceMode = SettingsConfigMode.OFF
    settings.app_settings.releaseIntelligenceMode = SettingsConfigMode.OFF
    settings.bucket_settings.releaseIntelligenceMode = SettingsConfigMode.OFF
    settings.volume_settings.releaseIntelligenceMode = SettingsConfigMode.OFF
    settings.serverless_settings.releaseIntelligenceMode = SettingsConfigMode.OFF
    settings.ecs_app_settings.releaseIntelligenceMode = SettingsConfigMode.OFF


def disable_account_monitoring(account_id: str):
    """
    This function is deprecated.
    Disable monitoring for an account with the given account ID.
    :param account_id: The ID of the account.
    """
    acc_settings = get_account_settings(account_id)
    __disable_monitoring(acc_settings)
    return update_account_settings(account_id=account_id, settings=acc_settings)


def disable_group_monitoring(group_id: str):
    """
    This function is deprecated.
    Disable monitoring for the group with the given group ID.
    :param group_id: The ID of the group.
    """
    group_settings = get_group_settings(group_id=group_id)
    __disable_monitoring(group_settings)
    return update_group_settings(group_id=group_id, settings=group_settings)


def disable_resource_monitoring(resource_id: str):
    """
    Disable monitoring for a resource with the given resource ID.
    :param resource_id: The ID of the resource.
    """
    res_settings = get_resource_settings(resource_id)
    res_settings.releaseIntelligenceMode = SettingsConfigMode.OFF
    return update_resource_settings(resource_id=resource_id, settings=res_settings)
