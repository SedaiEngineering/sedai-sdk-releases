from sedai.__impl import api, log
from sedai.credentials import (
    AWSCredentials,
    DatadogCredentials,
    FederatedPrometheusCredentials,
    GKEMonitoringCredentials,
    NewrelicCredentials,
)


def add_cloudwatch_monitoring(
    account_id: str,
    credentials: AWSCredentials = None,
    lb_dimensions: list | None = None,
    app_dimensions: list | None = None,
    instance_dimensions: list | None = None,
    use_account_credentials: bool = True,
):
    """
    Add CloudWatch monitoring to an account
    :param account_id: The Sedai account id
    :param credentials: A valid AWS credentials object. Refer to :ref:`credentials` for more details
    :param lb_dimensions: The list of load balancer dimensions. Default: ["load_balancer_name"]
    :param app_dimensions: The list of application dimensions. Default: ["application_id"]
    :param instance_dimensions: The list of instance dimensions. Default: ["instance_id"]
    :param use_account_credentials: Boolean indicating whether to use account credentials. Default: True
    :return: Boolean indicating if the monitoring provider was created successfully. If mandatory fields are missing,
    then an exception is raised.

    By default, account credentials are used for cloudwatch too.
    For custom credentials, set use_account_credentials to False and provide the valid credentials
    """
    if account_id is None:
        raise ValueError("account_id is required")
    if credentials is None and use_account_credentials is False:
        raise ValueError("credentials is required")

    if lb_dimensions is None:
        lb_dimensions = ["load_balancer_name"]
    if app_dimensions is None:
        app_dimensions = ["application_id"]
    if instance_dimensions is None:
        instance_dimensions = ["instance_id"]

    payload = {
        "instanceDimensions": instance_dimensions,
        "appDimensions": app_dimensions,
        "lbDimensions": lb_dimensions,
        "integrationType": "AGENTLESS",
        "monitoringProvider": "CLOUDWATCH",
        "siteDiscoveryEnabled": False,
        "name": f"Cloudwatch for {account_id}",
        "alertIntegrationEnabled": False,
        "details": {
            "monitoringProvider": "CLOUDWATCH",
            **(
                {"useAccountCredentials": True}
                if use_account_credentials
                else {"credentialsDetail": {"credentials": credentials.to_dict()}}
            ),
        },
    }

    request = api.PostRequest(f'/api/monitoring/monitoringProviders/accounts/{account_id}', payload)
    response = api.do_post(request)
    if response['status'] != 'OK':
        log(f"Failed to create monitoring provider: {response['message']}")
        return False
    else:
        log("Successfully created monitoring provider: CloudWatch")
        return True


def add_new_relic_monitoring(
    account_id: str,
    new_relic_account_id: str,
    api_server: str,
    credentials: NewrelicCredentials,
    name: str | None = None,
    lb_dimensions: list | None = None,
    app_dimensions: list | None = None,
    instance_dimensions: list | None = None,
    container_dimensions: list | None = None,
    namespace_dimensions: list | None = None,
    cluster_dimensions: list | None = None,
    integration_type: str | None = "AGENTLESS",
):
    """
    Add New Relic monitoring to an account
    :param account_id: The account id
    :param new_relic_account_id: The new relic account id
    :param api_server: The new relic api server
    :param credentials: The New Relic monitoring credentials. Refer to :ref:`credentials` for more details
    :param name: An optional name for the monitoring provider
    :param lb_dimensions: The list of load balancer dimensions. Default: ["load_balancer_name", "entity.name"]
    :param app_dimensions: The list of application dimensions. Default: ["application_id", "appName", "entity.name"]
    :param instance_dimensions: The list of instance dimensions. Default: ["instance_id","k8s.podName","k8s.pod.name"]
    :param container_dimensions: The list of container dimensions. Default: ["container", "k8s.container.name", "k8s.containerName"]
    :param namespace_dimensions: The list of namespace dimensions. Default: ["k8s.namespaceName"]
    :param cluster_dimensions: The list of cluster dimensions. Default: ["clusterName"]
    :param integration_type: The integration type. Valid values are: `AGENTLESS`, `AGENT_BASED`. Default: `AGENTLESS`
    :return: Boolean indicating if the monitoring provider was created successfully. If mandatory fields are missing,
    then an exception is raised.

    For the list of dimentsions, if the list is passed, then that list is used as is. If the list is not passed, the default
    list is used. If an empty list is passed, then no dimensions are used.
    """

    if account_id is None:
        raise ValueError("account_id is required")
    if new_relic_account_id is None:
        raise ValueError("new_relic_account_id is required")
    if api_server is None:
        raise ValueError("api_server is required")
    if credentials is None:
        raise ValueError("credentials is required")

    if name is None:
        name = f"Cloud Monitoring for new relic account {account_id}"
    if instance_dimensions is None:
        instance_dimensions = ["instace_id", "k8s.podName", "k8s.pod.name"]
    if app_dimensions is None:
        app_dimensions = ["application_id", "appName", "entity.name"]
    if lb_dimensions is None:
        lb_dimensions = ["load_balancer_name", "entity.name"]
    if container_dimensions is None:
        container_dimensions = ["container", "k8s.container.name", "k8s.containerName"]
    if namespace_dimensions is None:
        namespace_dimensions = ["k8s.namespaceName"]
    if cluster_dimensions is None:
        cluster_dimensions = ["clusterName"]
    if integration_type is None:
        integration_type = "AGENTLESS"

    payload = {
        "instanceDimensions": instance_dimensions,
        "appDimensions": app_dimensions,
        "lbDimensions": lb_dimensions,
        "integrationType": integration_type,
        "containerDimensions": container_dimensions,
        "namespaceDimensions": namespace_dimensions,
        "clusterDimensions": cluster_dimensions,
        "siteDiscoveryEnabled": False,
        "name": name,
        "monitoringProvider": "NEWRELIC",
        "alertIntegrationEnabled": False,
        "details": {
            "monitoringProvider": "NEWRELIC",
            "credentialsDetail": {"credentials": credentials.to_dict()},
            "enableAccountIdSupport": True,
            "newRelicAccountId": new_relic_account_id,
            "apiServer": api_server,
        },
    }

    request = api.PostRequest(f'/api/monitoring/monitoringProviders/accounts/{account_id}', payload)
    response = api.do_post(request)
    if response['status'] != 'OK':
        log(f"Failed to create monitoring provideer: {response['message']}")
        return False
    else:
        log(f"Successfully created monitoring provider: {name}")
        return True


def get_monitoring_providers_for_account(account_id: str):
    """
    Get all monitoring providers for an account
    :param account_id: The Sedai account id
    :return: A list of monitoring provider objects, or empty list if none found
    """
    if account_id is None:
        raise ValueError("account_id is required")

    request = api.GetRequest(f'/api/monitoring/monitoringProviders/accounts/{account_id}')
    response = api.do_get(request)
    if response['status'] == 'OK' and response.get('result'):
        return response['result']
    return []


def get_monitoring_provider(monitoring_provider_id: str):
    """
    Get a monitoring provider by id
    :param monitoring_provider_id: The monitoring provider id
    :return: The monitoring provider object, or None if not found
    """
    if monitoring_provider_id is None:
        raise ValueError("monitoring_provider_id is required")

    request = api.GetRequest(f'/api/monitoring/monitoringProviders/{monitoring_provider_id}')
    response = api.do_get(request)
    if response['status'] == 'OK' and response.get('result'):
        return response['result'][0]
    return None


def add_or_update_gke_monitoring(
    account_id: str,
    project_id: str,
    credentials: GKEMonitoringCredentials,
    monitoring_provider_id: str | None = None,
    name: str | None = None,
    lb_dimensions: list | None = None,
    app_dimensions: list | None = None,
    instance_dimensions: list | None = None,
    region_dimensions: list | None = None,
    container_dimensions: list | None = None,
    namespace_dimensions: list | None = None,
    cluster_dimensions: list | None = None,
    integration_type: str = "AGENT_BASED",
):
    """
    Add or update GKE monitoring for an account
    :param account_id: The account id
    :param project_id: The GCP project id
    :param credentials: The GKE monitoring credentials. Refer to :ref:`credentials` for more details
    :param monitoring_provider_id: The existing monitoring provider id. If provided, the monitoring provider is updated;
    otherwise a new one is created.
    :param name: An optional name for the monitoring provider
    :return: Boolean indicating if the monitoring provider was created or updated successfully.
    """
    if account_id is None:
        raise ValueError("account_id is required")
    if project_id is None:
        raise ValueError("project_id is required")
    if credentials is None:
        raise ValueError("credentials is required")

    if name is None:
        name = f"Cloud Monitoring for GKE account {account_id}"
    if instance_dimensions is None:
        instance_dimensions = ["pod_name"]
    if app_dimensions is None:
        app_dimensions = ["application_id"]
    if lb_dimensions is None:
        lb_dimensions = ["destination_service_name"]
    if container_dimensions is None:
        container_dimensions = ["container_name"]
    if namespace_dimensions is None:
        namespace_dimensions = ["destination_service_namespace", "namespace_name"]
    if cluster_dimensions is None:
        cluster_dimensions = ["cluster_name"]
    if region_dimensions is None:
        region_dimensions = ["location"]

    payload = {
        "instanceDimensions": instance_dimensions,
        "appDimensions": app_dimensions,
        "lbDimensions": lb_dimensions,
        "integrationType": integration_type,
        "containerDimensions": container_dimensions,
        "namespaceDimensions": namespace_dimensions,
        "clusterDimensions": cluster_dimensions,
        "siteDiscoveryEnabled": False,
        "id": monitoring_provider_id,
        "name": name,
        "monitoringProvider": "GKEMONITORING",
        "alertIntegrationEnabled": False,
        "regionDimensions": region_dimensions,
        "details": {
            "monitoringProvider": "GKEMONITORING",
            "credentialsDetail": {"credentials": credentials.to_dict()},
            "disableCertificateValidation": False,
            "projectId": project_id,
        },
    }

    request = api.PostRequest(f'/api/monitoring/monitoringProviders/accounts/{account_id}', payload)
    response = api.do_post(request)
    if response['status'] != 'OK':
        log(f"Failed to create or update GKE monitoring provider: {response['message']}")
        return False
    else:
        action = "updated" if monitoring_provider_id else "created"
        log(f"Successfully {action} GKE monitoring provider: {name}")
        return True


def add_GKE_monitoring(
    account_id: str,
    project_id: str,
    credentials: GKEMonitoringCredentials,
    name: str | None = None,
    lb_dimensions: list | None = None,
    app_dimensions: list | None = None,
    instance_dimensions: list | None = None,
    region_dimensions: list | None = None,
    container_dimensions: list | None = None,
    namespace_dimensions: list | None = None,
    cluster_dimensions: list | None = None,
    integration_type: str = "AGENT_BASED",
):
    """
    Add GKE monitoring to an account
    :param account_id: The account id
    :param project_id: The project id
    :param credentials: The GKE monitoring credentials. Refer to :ref:`credentials` for more details
    :param name: An optional name for the monitoring provider
    :param lb_dimensions: The list of load balancer dimensions. Default: ["destination_service_name"]
    :param app_dimensions: The list of application dimensions. Default: ["application_id"]
    :param instance_dimensions: The list of instance dimensions. Default: ["pod_name"]
    :param region_dimensions: The list of region dimensions. Default: ["location"]
    :param container_dimensions: The list of container dimensions. Default: ["container_name"]
    :param namespace_dimensions: The list of namespace dimensions. Default: ["destination_service_namespace", "namespace_name"]
    :param cluster_dimensions: The list of cluster dimensions. Default: ["cluster_name"]
    :param integration_type: The integration type. Valid values are: `AGENTLESS`, `AGENT_BASED`. Default: `AGENT_BASED`
    :return: Boolean indicating if the monitoring provider was created successfully. If mandatory fields are missing,
    then an exception is raised.

    For the list of dimentsions, if the list is passed, then that list is used as is. If the list is not passed, the default
    list is used. If an empty list is passed, then no dimensions are used.
    """

    if account_id is None:
        raise ValueError("account_id is required")
    if project_id is None:
        raise ValueError("project_id is required")
    if credentials is None:
        raise ValueError("credentials is required")

    if name is None:
        name = f"Cloud Monitoring for GKE account {account_id}"
    if instance_dimensions is None:
        instance_dimensions = ["pod_name"]
    if app_dimensions is None:
        app_dimensions = ["application_id"]
    if lb_dimensions is None:
        lb_dimensions = ["destination_service_name"]
    if container_dimensions is None:
        container_dimensions = ["container_name"]
    if namespace_dimensions is None:
        namespace_dimensions = ["destination_service_namespace", "namespace_name"]
    if cluster_dimensions is None:
        cluster_dimensions = ["cluster_name"]
    if region_dimensions is None:
        region_dimensions = ["location"]

    payload = {
        "instanceDimensions": instance_dimensions,
        "appDimensions": app_dimensions,
        "lbDimensions": lb_dimensions,
        "integrationType": integration_type,
        "containerDimensions": container_dimensions,
        "namespaceDimensions": namespace_dimensions,
        "clusterDimensions": cluster_dimensions,
        "siteDiscoveryEnabled": False,
        "name": name,
        "monitoringProvider": "GKEMONITORING",
        "alertIntegrationEnabled": False,
        "regionDimensions": region_dimensions,
        "details": {
            "monitoringProvider": "GKEMONITORING",
            "credentialsDetail": {"credentials": credentials.to_dict()},
            "disableCertificateValidation": False,
            "projectId": project_id,
        },
    }

    request = api.PostRequest(f'/api/monitoring/monitoringProviders/accounts/{account_id}', payload)
    response = api.do_post(request)
    if response['status'] != 'OK':
        log(f"Failed to create monitoring provideer: {response['message']}")
        return False
    else:
        log(f"Successfully created monitoring provider: {name}")
        return True


def add_datadog_monitoring(
    account_id: str,
    credentials: DatadogCredentials,
    name: str | None = None,
    lb_dimensions: list | None = None,
    app_dimensions: list | None = None,
    instance_dimensions: list | None = None,
    region_dimensions: list | None = None,
    container_dimensions: list | None = None,
    namespace_dimensions: list | None = None,
    cluster_dimensions: list | None = None,
    az_dimensions: list | None = None,
    env_dimensions: list | None = None,
    instance_id_pattern: str | None = None,
    integration_type: str = "AGENTLESS",
):
    """
    Add Datadog monitoring to an account
    :param account_id: The account id
    :param credentials: The Datadog credentials. Refer to :ref:`credentials` for more details
    :param name: An optional name for the monitoring provider
    :param lb_dimensions: The list of load balancer dimensions. Default: ["destination_service_name"]
    :param app_dimensions: The list of application dimensions. Default: ["application_id"]
    :param instance_dimensions: The list of instance dimensions. Default: ["pod_name"]
    :param region_dimensions: The list of region dimensions. Default: ["location"]
    :param container_dimensions: The list of container dimensions. Default: ["container_name"]
    :param namespace_dimensions: The list of namespace dimensions. Default: ["destination_service_namespace", "namespace_name", "kube_namespace]
    :param cluster_dimensions: The list of cluster dimensions. Default: ["cluster_name"]
    :param az_dimensions: The list of availability zone dimensions. Default: ["availability_zone"]
    :param env_dimensions: The list of environment dimensions. Default: []
    :param instance_id_pattern: The instance id pattern. Default: None
    :param integration_type: The integration type. Valid values are: `AGENTLESS`, `AGENT_BASED`. Default: `AGENTLESS`
    :return: Boolean indicating if the monitoring provider was created successfully. If mandatory fields are missing,
    then an exception is raised.
    """

    if account_id is None:
        raise ValueError("account_id is required")
    if credentials is None:
        raise ValueError("credentials is required")

    if name is None:
        name = f"Cloud Monitoring for Datadog account {account_id}"
    if instance_dimensions is None:
        instance_dimensions = ["pod_name"]
    if app_dimensions is None:
        app_dimensions = ["application_id"]
    if lb_dimensions is None:
        lb_dimensions = ["destination_service_name"]
    if container_dimensions is None:
        container_dimensions = ["container_name"]
    if namespace_dimensions is None:
        namespace_dimensions = ["destination_service_namespace", "namespace_name", "kube_namespace"]
    if cluster_dimensions is None:
        cluster_dimensions = ["cluster_name"]
    if region_dimensions is None:
        region_dimensions = ["location"]
    if az_dimensions is None:
        az_dimensions = ["availability_zone"]
    if env_dimensions is None:
        env_dimensions = []
    if instance_id_pattern is None:
        instance_id_pattern = None

    payload = {
        "instanceDimensions": instance_dimensions,
        "appDimensions": app_dimensions,
        "lbDimensions": lb_dimensions,
        "integrationType": integration_type,
        "containerDimensions": container_dimensions,
        "namespaceDimensions": namespace_dimensions,
        "clusterDimensions": cluster_dimensions,
        "azDimensions": az_dimensions,
        "envDimensions": env_dimensions,
        "instanceIdPattern": instance_id_pattern,
        "siteDiscoveryEnabled": False,
        "name": name,
        "monitoringProvider": "DATADOG",
        "alertIntegrationEnabled": False,
        "regionDimensions": region_dimensions,
        "details": {
            "monitoringProvider": "DATADOG",
            "credentialsDetail": {"credentials": credentials.to_dict()},
            "customCertificates": None,
            "disableCertificateValidation": False,
            "endpoint": "https://api.datadoghq.com/",
            "enableAllMetrics": False,
            "enableEnvSpecialHandling": False,
        },
    }

    request = api.PostRequest(f'/api/monitoring/monitoringProviders/accounts/{account_id}', payload)
    response = api.do_post(request)
    if response['status'] != 'OK':
        log(f"Failed to create monitoring provider: {response['message']}")
        return False
    else:
        log(f"Successfully created Datadog monitoring provider: {name}")
        return True


def add_or_update_datadog_monitoring(
    account_id: str,
    credentials: DatadogCredentials,
    monitoring_provider_id: str | None = None,
    name: str | None = None,
    lb_dimensions: list | None = None,
    app_dimensions: list | None = None,
    instance_dimensions: list | None = None,
    region_dimensions: list | None = None,
    container_dimensions: list | None = None,
    namespace_dimensions: list | None = None,
    cluster_dimensions: list | None = None,
    az_dimensions: list | None = None,
    env_dimensions: list | None = None,
    instance_id_pattern: str | None = None,
    integration_type: str = "AGENTLESS",
):
    """
    Add or Update Datadog monitoring of an account
    :param monitoring_provider_id: The Datadog monitoring id
    :param account_id: The account id
    :param credentials: The Datadog credentials. Refer to :ref:`credentials` for more details
    :param name: An optional name for the monitoring provider
    :param lb_dimensions: The list of load balancer dimensions. Default: ["destination_service_name"]
    :param app_dimensions: The list of application dimensions. Default: ["application_id"]
    :param instance_dimensions: The list of instance dimensions. Default: ["pod_name"]
    :param region_dimensions: The list of region dimensions. Default: ["location"]
    :param container_dimensions: The list of container dimensions. Default: ["container_name"]
    :param namespace_dimensions: The list of namespace dimensions. Default: ["destination_service_namespace", "namespace_name", "kube_namespace]
    :param cluster_dimensions: The list of cluster dimensions. Default: ["cluster_name"]
    :param az_dimensions: The list of availability zone dimensions. Default: ["availability_zone"]
    :param env_dimensions: The list of environment dimensions. Default: []
    :param instance_id_pattern: The instance id pattern. Default: None
    :param integration_type: The integration type. Valid values are: `AGENTLESS`, `AGENT_BASED`. Default: `AGENTLESS`
    :return: Boolean indicating if the monitoring provider was created or updated successfully. If mandatory fields are missing,
    then an exception is raised.
    """
    if account_id is None:
        raise ValueError("account_id is required")
    if credentials is None:
        raise ValueError("credentials is required")

    if monitoring_provider_id is None:
        monitoring_provider_id = None
    if name is None:
        name = f"Cloud Monitoring for Datadog account {account_id}"
    if instance_dimensions is None:
        instance_dimensions = ["pod_name"]
    if app_dimensions is None:
        app_dimensions = ["application_id"]
    if lb_dimensions is None:
        lb_dimensions = ["destination_service_name"]
    if container_dimensions is None:
        container_dimensions = ["container_name"]
    if namespace_dimensions is None:
        namespace_dimensions = ["destination_service_namespace", "namespace_name", "kube_namespace"]
    if cluster_dimensions is None:
        cluster_dimensions = ["cluster_name"]
    if region_dimensions is None:
        region_dimensions = ["location"]
    if az_dimensions is None:
        az_dimensions = ["availability_zone"]
    if env_dimensions is None:
        env_dimensions = []
    if instance_id_pattern is None:
        instance_id_pattern = None

    payload = {
        "instanceDimensions": instance_dimensions,
        "appDimensions": app_dimensions,
        "lbDimensions": lb_dimensions,
        "integrationType": integration_type,
        "containerDimensions": container_dimensions,
        "namespaceDimensions": namespace_dimensions,
        "clusterDimensions": cluster_dimensions,
        "azDimensions": az_dimensions,
        "envDimensions": env_dimensions,
        "instanceIdPattern": instance_id_pattern,
        "siteDiscoveryEnabled": False,
        "id": monitoring_provider_id,
        "name": name,
        "monitoringProvider": "DATADOG",
        "alertIntegrationEnabled": False,
        "regionDimensions": region_dimensions,
        "details": {
            "monitoringProvider": "DATADOG",
            "credentialsDetail": {"credentials": credentials.to_dict()},
            "customCertificates": None,
            "disableCertificateValidation": False,
            "endpoint": "https://api.datadoghq.com/",
            "enableAllMetrics": False,
            "enableEnvSpecialHandling": False,
        },
    }

    request = api.PostRequest(f'/api/monitoring/monitoringProviders/accounts/{account_id}', payload)
    response = api.do_post(request)
    if response['status'] != 'OK':
        log(f"Failed to create or update monitoring provider: {response['message']}")
        return False
    else:
        log(f"Successfully created or updated Datadog monitoring provider: {name}")
        return True


def delete_monitoring_provider(monitoring_provider_id: str):
    """
    Deleted monitoring provider of an account
    :param monitoring_provider_id: The monitoring provider id
    :return: Boolean indicating if the monitoring provider was deleted successfully. If monitoring_provider_id is missing,
    then an exception is raised.
    """
    if monitoring_provider_id is None:
        raise ValueError("monitoring_provider_id is required")

    payload = {"monitoring_provider_id": monitoring_provider_id}

    request = api.DeleteRequest(
        f'/api/monitoring/monitoringProviders/{monitoring_provider_id}', payload
    )
    response = api.do_delete(request)
    if response['status'] != 'OK':
        log(f"Failed to delete monitoring provider: {response['message']}")
        return False
    else:
        log(f"Successfully deleted monitoring provider: {id}")
        return True


def add_federated_prometheus_monitoring(
    account_id: str,
    credentials: FederatedPrometheusCredentials,
    endpoint: str,
    name: str | None = None,
    lb_dimensions: list | None = None,
    app_dimensions: list | None = None,
    instance_dimensions: list | None = None,
    region_dimensions: list | None = None,
    container_dimensions: list | None = None,
    namespace_dimensions: list | None = None,
    cluster_dimensions: list | None = None,
    az_dimensions: list | None = None,
    env_dimensions: list | None = None,
    instance_id_pattern: str | None = None,
    integration_type: str | None = "AGENTLESS",
):
    """
    Add Federated Prometheus monitoring to an account
    :param account_id: The account id
    :param credentials: The Federated Prometheus credentials. Refer to :ref:`credentials` for more details
    :param endpoint: The Federated Prometheus endpoint.
    :param name: An optional name for the monitoring provider
    :param lb_dimensions: The list of load balancer dimensions. Default: ["service"]
    :param app_dimensions: The list of application dimensions. Default: ["application_id"]
    :param instance_dimensions: The list of instance dimensions. Default: ["pod"]
    :param region_dimensions: The list of region dimensions. Default: ["region"]
    :param container_dimensions: The list of container dimensions. Default: ["container"]
    :param namespace_dimensions: The list of namespace dimensions. Default: ["namespace"]
    :param cluster_dimensions: The list of cluster dimensions. Default: []
    :param az_dimensions: The list of availability zone dimensions. Default: ["availability_zone"]
    :param env_dimensions: The list of environment dimensions. Default: []
    :param instance_id_pattern: The instance id pattern. Default: None
    :param integration_type: The integration type. Valid values are: `AGENTLESS`, `AGENT_BASED`. Default: `AGENTLESS`
    :return: Boolean indicating if the monitoring provider was created successfully. If mandatory fields are missing,
    then an exception is raised.
    """

    if account_id is None:
        raise ValueError("account_id is required")
    if credentials is None:
        raise ValueError("credentials is required")

    if name is None:
        name = f"Cloud Monitoring for Federated Prometheus account {account_id}"
    if instance_dimensions is None:
        instance_dimensions = ["pod"]
    if app_dimensions is None:
        app_dimensions = ["application_id"]
    if lb_dimensions is None:
        lb_dimensions = ["service"]
    if container_dimensions is None:
        container_dimensions = ["container"]
    if namespace_dimensions is None:
        namespace_dimensions = ["namespace"]
    if region_dimensions is None:
        region_dimensions = ["region"]
    if az_dimensions is None:
        az_dimensions = ["availability_zone"]
    if env_dimensions is None:
        env_dimensions = []
    if cluster_dimensions is None:
        cluster_dimensions = []
    if instance_id_pattern is None:
        instance_id_pattern = None

    payload = {
        "instanceDimensions": instance_dimensions,
        "appDimensions": app_dimensions,
        "lbDimensions": lb_dimensions,
        "integrationType": integration_type,
        "containerDimensions": container_dimensions,
        "namespaceDimensions": namespace_dimensions,
        "clusterDimensions": cluster_dimensions,
        "azDimensions": az_dimensions,
        "envDimensions": env_dimensions,
        "instanceIdPattern": instance_id_pattern,
        "siteDiscoveryEnabled": False,
        "name": name,
        "monitoringProvider": "FEDERATEDPROMETHEUS",
        "alertIntegrationEnabled": False,
        "regionDimensions": region_dimensions,
        "details": {
            "monitoringProvider": "FEDERATEDPROMETHEUS",
            "credentialsDetail": {"credentials": credentials.to_dict()},
            "customCertificates": None,
            "disableCertificateValidation": False,
            "endpoint": endpoint,
        },
    }

    request = api.PostRequest(f'/api/monitoring/monitoringProviders/accounts/{account_id}', payload)
    response = api.do_post(request)
    if response['status'] != 'OK':
        log(f"Failed to create monitoring provider: {response['message']}")
        return False
    else:
        log(f"Successfully created Federated Prometheus monitoring provider: {name}")
        return True
