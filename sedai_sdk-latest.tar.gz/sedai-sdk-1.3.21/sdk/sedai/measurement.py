############################################################################################################
# Value + unit measurement objects.
#
# Sedai's cpu and memory guardrails are carried over the API as `{value, metricUnit}` objects rather
# than bare numbers, so a guardrail can be expressed in whichever unit is natural for it - cores or
# millicores for Kubernetes cpu, CPU units or vCPUs for ECS cpu, bytes or GiB for memory. The classes
# in this module parse that representation, serialize it back, and convert between units.
#
# The classes are as follows:
# MetricUnit: The units a measurement can be expressed in
# MetricValue: The base class for all value + unit objects
# K8sCpuValue: A Kubernetes cpu measurement
# ECSCpuValue: An ECS cpu measurement
# MemoryValue: A memory measurement
############################################################################################################

from enum import Enum
from typing import ClassVar

_KIB = 1024.0
_MIB = _KIB * 1024
_GIB = _MIB * 1024
_TIB = _GIB * 1024
_PIB = _TIB * 1024
_EIB = _PIB * 1024


class MetricUnit(Enum):
    """
    The unit a [MetricValue](#MetricValue) is expressed in. Only a subset of these units is valid for
    any one kind of measurement - see `MetricValue.allowed_units`.
    """

    CORES = "CORES"
    """CPU cores."""
    MILLICORES = "MILLICORES"
    """Thousandths of a CPU core. This is the unit behind Kubernetes' `250m` notation."""
    CENTICORES = "CENTICORES"
    """Hundredths of a CPU core."""
    MICROCORES = "MICROCORES"
    """Millionths of a CPU core."""
    NANOCORES = "NANOCORES"
    """Billionths of a CPU core."""
    VCPU = "VCPU"
    """A virtual CPU. Equivalent to a core for Kubernetes, and to 1024 CPU units for ECS."""
    CPU_UNITS = "CPU_UNITS"
    """ECS CPU units. 1024 CPU units make up one vCPU."""

    BYTES = "BYTES"
    """Bytes."""
    KILO_BYTES = "KILO_BYTES"
    """Decimal kilobytes (1000 bytes)."""
    MEGA_BYTES = "MEGA_BYTES"
    """Decimal megabytes (1000^2 bytes)."""
    GIGA_BYTES = "GIGA_BYTES"
    """Decimal gigabytes (1000^3 bytes)."""
    TERA_BYTES = "TERA_BYTES"
    """Decimal terabytes (1000^4 bytes)."""
    PETA_BYTES = "PETA_BYTES"
    """Decimal petabytes (1000^5 bytes)."""
    EXA_BYTES = "EXA_BYTES"
    """Decimal exabytes (1000^6 bytes)."""
    KIBI_BYTES = "KIBI_BYTES"
    """Binary kibibytes (1024 bytes). This is the unit behind Kubernetes' `512Ki` notation."""
    MEBI_BYTES = "MEBI_BYTES"
    """Binary mebibytes (1024^2 bytes). This is the unit ECS task definitions use for memory."""
    GIBI_BYTES = "GIBI_BYTES"
    """Binary gibibytes (1024^3 bytes)."""
    TEBI_BYTES = "TEBI_BYTES"
    """Binary tebibytes (1024^4 bytes)."""
    PEBI_BYTES = "PEBI_BYTES"
    """Binary pebibytes (1024^5 bytes)."""
    EXBI_BYTES = "EXBI_BYTES"
    """Binary exbibytes (1024^6 bytes)."""


class MetricValue:
    """
    A measurement expressed as a number together with the unit that number is in. This is the base
    class for [K8sCpuValue](#K8sCpuValue), [ECSCpuValue](#ECSCpuValue) and
    [MemoryValue](#MemoryValue); use one of those rather than this class directly.
    """

    # The name the API discriminates this kind of measurement by, in the payload's `type` field.
    _JSON_TYPE: ClassVar[str] = ""
    # The unit a bare number is taken to be in when no unit is given.
    _DEFAULT_UNIT: ClassVar[MetricUnit | None] = None
    # The valid units for this kind of measurement, mapped to how many base units each one is.
    _CONVERSIONS: ClassVar[dict] = {}

    def __init__(self, value: float | None = None, metricUnit: "MetricUnit | str | None" = None):
        """
        :param value: The magnitude of the measurement. `None` leaves the measurement unset.
        :param metricUnit: The unit `value` is in. Defaults to the base unit for this kind of
            measurement - cores for Kubernetes cpu, CPU units for ECS cpu, bytes for memory.
        :raises ValueError: If `metricUnit` is not a valid unit for this kind of measurement.
        """
        self.__src = {}
        self.value = value
        self.metricUnit = self._DEFAULT_UNIT if metricUnit is None else metricUnit

    @property
    def value(self) -> float | None:
        """
        The magnitude of the measurement, in `metricUnit`. `None` means the measurement is not set -
        for a guardrail that means the guardrail is unbounded and Sedai applies its own default.
        """
        return self.__value

    @value.setter
    def value(self, value: float | None):
        self.__value = None if value is None else float(value)

    @property
    def metricUnit(self) -> MetricUnit:
        """
        The unit `value` is expressed in. The API rejects a measurement with no unit, so this is
        always one of `allowed_units`.
        """
        return self.__metricUnit

    @metricUnit.setter
    def metricUnit(self, metricUnit: "MetricUnit | str"):
        self.__metricUnit = self.__validated_unit__(metricUnit)

    @classmethod
    def allowed_units(cls) -> list:
        """
        The units this kind of measurement can be expressed in.
        """
        return list(cls._CONVERSIONS)

    def value_in(self, metricUnit: "MetricUnit | str") -> float | None:
        """
        This measurement converted to `metricUnit`.

        :param metricUnit: The unit to convert to.
        :return: The converted magnitude, or `None` if the measurement is not set.
        :raises ValueError: If `metricUnit` is not a valid unit for this kind of measurement.
        """
        metricUnit = self.__validated_unit__(metricUnit)
        if self.value is None:
            return None
        return self.value * self._CONVERSIONS[self.metricUnit] / self._CONVERSIONS[metricUnit]

    @classmethod
    def __validated_unit__(cls, metricUnit):
        """@private"""
        if isinstance(metricUnit, str):
            metricUnit = MetricUnit(metricUnit)
        if metricUnit not in cls._CONVERSIONS:
            raise ValueError(
                f"Invalid unit for {cls.__name__}: {metricUnit}. "
                f"Allowed units are: {[unit.value for unit in cls._CONVERSIONS]}"
            )
        return metricUnit

    @classmethod
    def __coerce__(cls, value, defaultUnit=None):
        """
        @private
        Accept either a value + unit object or a bare number, so that assigning a plain number to a
        guardrail keeps working. A bare number is taken to be in `defaultUnit`.
        """
        if value is None or isinstance(value, cls):
            return value
        if isinstance(value, MetricValue):
            raise TypeError(f"Expected a {cls.__name__}, got a {type(value).__name__}")
        return cls(value, defaultUnit)

    @classmethod
    def __parse__(cls, src, defaultUnit=None):
        """@private"""
        if src is None or isinstance(src, MetricValue):
            return cls.__coerce__(src, defaultUnit)
        if not isinstance(src, dict):
            # A bare number: a payload from a Sedai instance that predates value + unit guardrails.
            return cls(src, defaultUnit)
        parsed = cls(src.get('value'), src.get('metricUnit') or defaultUnit)
        # Keep whatever else the API sent, so a round trip does not drop fields the SDK does not model.
        parsed.__src = src
        return parsed

    def __serialize__(self):
        """@private"""
        serialized = dict(self.__src)
        # The API discriminates the measurement types by name, so the payload has to carry it.
        serialized['type'] = self._JSON_TYPE
        serialized['value'] = self.value
        serialized['metricUnit'] = self.metricUnit.value
        return serialized

    def __eq__(self, other):
        if type(self) is not type(other):
            return NotImplemented
        if self.value is None or other.value is None:
            return self.value == other.value
        return self.value_in(self._DEFAULT_UNIT) == other.value_in(self._DEFAULT_UNIT)

    def __hash__(self):
        return hash((type(self).__name__, self.value_in(self._DEFAULT_UNIT)))

    def __repr__(self):
        return f"{type(self).__name__}({self.value}, {self.metricUnit})"

    def __str__(self):
        return f"{self.value} {self.metricUnit.value}"


class K8sCpuValue(MetricValue):
    """
    A Kubernetes cpu measurement, such as a per-container cpu guardrail. A bare number with no unit
    is taken to be in `MetricUnit.CORES`.
    """

    _JSON_TYPE: ClassVar[str] = "K8sCpuValue"
    _DEFAULT_UNIT: ClassVar[MetricUnit] = MetricUnit.CORES
    _CONVERSIONS: ClassVar[dict] = {
        MetricUnit.CORES: 1.0,
        MetricUnit.VCPU: 1.0,
        MetricUnit.CENTICORES: 1e-2,
        MetricUnit.MILLICORES: 1e-3,
        MetricUnit.MICROCORES: 1e-6,
        MetricUnit.NANOCORES: 1e-9,
    }

    def to_cores(self) -> float | None:
        """
        This measurement in cpu cores, or `None` if it is not set.
        """
        return self.value_in(MetricUnit.CORES)

    def to_millicores(self) -> float | None:
        """
        This measurement in millicores, or `None` if it is not set.
        """
        return self.value_in(MetricUnit.MILLICORES)


class ECSCpuValue(MetricValue):
    """
    An ECS cpu measurement, such as the minimum cpu guardrail for an ECS service. A bare number with
    no unit is taken to be in `MetricUnit.CPU_UNITS`.
    """

    _JSON_TYPE: ClassVar[str] = "ECSCpuValue"
    _DEFAULT_UNIT: ClassVar[MetricUnit] = MetricUnit.CPU_UNITS
    _CONVERSIONS: ClassVar[dict] = {
        MetricUnit.CPU_UNITS: 1.0,
        MetricUnit.VCPU: 1024.0,
    }

    def to_cpu_units(self) -> float | None:
        """
        This measurement in ECS CPU units, or `None` if it is not set.
        """
        return self.value_in(MetricUnit.CPU_UNITS)

    def to_vcpus(self) -> float | None:
        """
        This measurement in vCPUs, or `None` if it is not set.
        """
        return self.value_in(MetricUnit.VCPU)


class MemoryValue(MetricValue):
    """
    A memory measurement, such as a per-container memory guardrail. A bare number with no unit is
    taken to be in `MetricUnit.BYTES`.
    """

    _JSON_TYPE: ClassVar[str] = "MemoryValue"
    _DEFAULT_UNIT: ClassVar[MetricUnit] = MetricUnit.BYTES
    _CONVERSIONS: ClassVar[dict] = {
        MetricUnit.BYTES: 1.0,
        MetricUnit.KILO_BYTES: 1e3,
        MetricUnit.MEGA_BYTES: 1e6,
        MetricUnit.GIGA_BYTES: 1e9,
        MetricUnit.TERA_BYTES: 1e12,
        MetricUnit.PETA_BYTES: 1e15,
        MetricUnit.EXA_BYTES: 1e18,
        MetricUnit.KIBI_BYTES: _KIB,
        MetricUnit.MEBI_BYTES: _MIB,
        MetricUnit.GIBI_BYTES: _GIB,
        MetricUnit.TEBI_BYTES: _TIB,
        MetricUnit.PEBI_BYTES: _PIB,
        MetricUnit.EXBI_BYTES: _EIB,
    }

    def to_bytes(self) -> float | None:
        """
        This measurement in bytes, or `None` if it is not set.
        """
        return self.value_in(MetricUnit.BYTES)

    def to_mib(self) -> float | None:
        """
        This measurement in mebibytes (1024^2 bytes), or `None` if it is not set.
        """
        return self.value_in(MetricUnit.MEBI_BYTES)

    def to_gib(self) -> float | None:
        """
        This measurement in gibibytes (1024^3 bytes), or `None` if it is not set.
        """
        return self.value_in(MetricUnit.GIBI_BYTES)

    def to_gb(self) -> float | None:
        """
        This measurement in decimal gigabytes (1000^3 bytes), or `None` if it is not set.
        """
        return self.value_in(MetricUnit.GIGA_BYTES)
