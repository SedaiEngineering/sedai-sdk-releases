from sedai.__impl import api, log
from sedai.__impl.model_converter import transform
from sedai.credentials import SedaiCredentials

__account_fields = [
    "id",
    "name",
    "providerAccountId",
    "accountDetails.cloudProvider",
    "accountDetails.integrationType",
    "accountDetails.projectId",
    "accountDetails.subscriptionId",
    "accountDetails.tenantId",
]

__account_fields_lite = ["id", "name", "cloudProvider", "serviceProvider", "enabled"]

CLOUD_PROVIDERS = ["AWS", "AZURE", "GCP", "KUBERNETES"]
INTEGRATION_TYPES = ["AGENTLESS", "AGENT_BASED"]
CLUSTER_PROVIDERS = ["AWS", "AZURE", "GCP", "SELF_MANAGED"]


def get_all_accounts():
    """
    Get all accounts that are integrated with Sedai
    :return: A list of accounts
    Each account is an object with the following fields:

    - **id** - the account id in Sedai
    - **name** - the name of the account as specified by the user
    - **providerAccountId** - the account id in the cloud provider
    -  **accountDetails.cloudProvider** - the cloud provider of the account. Values are: `AWS`,
     `AZURE`, `GCP`, `KUBERNETES`, `VMWARE`
    - **accountDetails.integrationType** - the type of integration. Values are: `AGENTLESS`, `AGENT_BASED`

    Sample code:
    .. code-block:: python

            models.to_json(account.get_all_accounts())

    Output:
    .. code-block:: json

            [
                {
                    "id": "5f4f5d3a-9c6e-4b3e-8a5a-1e4b6b5b2a7e",
                    "name": "test env",
                    "accountDetails": {
                        "cloudProvider": "AWS",
                        "integrationType": "AGENTLESS"
                    }
                }
            ]

    """
    request = api.GetRequest('/api/site/accounts')
    response = api.do_get(request)
    if response['status'] == 'OK' and response['result'] is not None:
        return transform(response['result'], __account_fields)


def get_all_accounts_lite():
    """
    Get a lightweight list of all accounts integrated with Sedai.
    Faster than :py:func:`get_all_accounts` as it returns a reduced set of fields.
    Use this when you only need basic account info such as id, name, cloudProvider.

    :return: A list of accounts with the following fields:

    - **id** - the account id in Sedai
    - **name** - the name of the account
    - **cloudProvider** - the cloud provider. Values are: `AWS`, `AZURE`, `GCP`, `KUBERNETES`
    - **serviceProvider** - the underlying service provider for Kubernetes clusters. Values are: `AWS`, `AZURE`, `GCP`
    - **enabled** - whether the account is enabled
    """
    request = api.GetRequest('/api/site/accounts/lite')
    response = api.do_get(request)
    if response['status'] == 'OK' and response['result'] is not None:
        return transform(response['result'], __account_fields_lite)
    return []


def search_accounts_by_provider_account_id(provider_account_id):
    """
    Search for all accounts that are integrated with Sedai that match the given provider account id
    :param provider_account_id: The providerAccountId of the account to search for
    :return: A list of accounts that match the given providerAccountId. Output is in the same structure
     as :py:func:`get_all_accounts`
    """
    accounts = get_all_accounts()
    return transform(list(filter(lambda x: x.providerAccountId == provider_account_id, accounts)))


def search_accounts_by_name(name):
    """
    Search for all accounts that are integrated with Sedai that match the given name
    :param name: The name of the account to search for
    :return: A list of accounts that match the given name. Output is in the same structure
     as :py:func:`get_all_accounts_lite`
    """
    request = api.GetRequest('/api/site/accounts/lite/by-name', params={'accountName': name})
    response = api.do_get(request)
    if response['status'] == 'OK' and response['result'] is not None:
        return transform(response['result'], __account_fields_lite)
    return []


def _resolve_unique_account_by_name(name):
    """
    Resolve exactly one account by name. Account names are not unique in Sedai, so this raises
    rather than guessing when the name is ambiguous.
    :param name: The name of the account
    :return: The single account matching the given name
    :raises ValueError: If no account is found with the given name
    :raises RuntimeError: If more than one account is found with the given name
    """
    accounts = search_accounts_by_name(name)
    if len(accounts) == 0:
        log(f"No account found with name: {name}")
        raise ValueError(f"No account found with name: {name}")
    if len(accounts) > 1:
        ids = ", ".join(a.id for a in accounts)
        log(f"More than one account found with name: {name}. Matching ids: {ids}")
        raise RuntimeError(f"More than one account found with name: {name}. Matching ids: {ids}")
    return accounts[0]


def search_accounts_by_id(id):
    """
    Search for all accounts that are integrated with Sedai that match the given id
    :param id: The accountId of the account to search for
    :return: A list of accounts that match the given id. Output is in the same structure
     as :py:func:`get_all_accounts`
    """
    request = api.GetRequest('/api/site/accounts/' + id)
    response = api.do_get(request)
    if response['status'] == 'OK' and response['result'] is not None:
        return transform(list(response['result']), __account_fields)
    return []


def create_account(
    name: str,
    cloud_provider: str,
    credentials: SedaiCredentials,
    integration_type: str,
    cluster_provider: str | None = None,
    cluster_url: str | None = None,
    ca_certificate: str | None = None,
    project_id: str | None = None,
):
    """
    Create an account in Sedai
    :param name: The name of the account
    :param cloud_provider: Cloud provider of the account. Valid values are: `AWS`, `AZURE`, `GCP`, `KUBERNETES`
    :param credentials: Credentials for the account. See :ref:`credentials` for more details
    :param integration_type: Type of integration for Kubernetes accounts. Valid values are: `AGENTLESS`, `AGENT_BASED`
    :param cluster_provider: Cluster provider for Kubernetes accounts. Required when adding Kubernetes clusters. Valid values are: `AWS`, `AZURE`, `GCP`, `SELF_MANAGED`
    :param cluster_url: URL of the Kubernetes cluster. Required when adding agentless Kubernetes clusters.
    :param ca_certificate: Optional Certifying Authority Certificate for connecting agentlessly to Kubernetes clusters.
    :param project_id: The GCP project id. Required when adding GCP accounts.
    :return: True if the account was created successfully, False otherwise
    """
    if cloud_provider not in CLOUD_PROVIDERS:
        raise ValueError("Invalid cloud provider: " + cloud_provider)
    if integration_type not in INTEGRATION_TYPES:
        raise ValueError("Invalid integration type: " + integration_type)

    metadata = {}
    if cloud_provider == "KUBERNETES":
        if cluster_provider not in CLUSTER_PROVIDERS:
            raise ValueError(
                "cluster_provider is required for Kubernetes accounts. Valid values are: "
                + ", ".join(CLUSTER_PROVIDERS)
            )
        if integration_type == "AGENTLESS" and credentials is None:
            from sedai.credentials import AwsRoleCredentials

            credentials = AwsRoleCredentials(role_arn=None, external_id=None)

        if cluster_url is not None:
            metadata["clusterUrl"] = cluster_url

        if ca_certificate is not None:
            metadata["caCertData"] = ca_certificate

        metadata["clusterProvider"] = cluster_provider
        metadata["clusterName"] = name

    payload = {
        "accountDetails": {
            "cloudProvider": cloud_provider,
            "integrationType": integration_type,
            "enabled": True,
            "metadata": metadata,
            "expedite": False,
            "projectId": project_id,
            "credentialsDetail": {"credentials": credentials.to_dict()},
        },
        "name": name,
    }

    request = api.PostRequest('/api/site/accounts', payload)
    response = api.do_post(request)
    if response['status'] != 'OK':
        log(f"Failed to create account: {response['message']}")
        return ""
    else:
        log(f"Successfully created account: {name}")
        return response['result']['accountId']


def update_account(
    id: str,
    name: str | None = None,
    cloud_provider: str | None = None,
    credentials: SedaiCredentials | None = None,
    integration_type: str | None = None,
    cluster_provider: str | None = None,
    cluster_url: str | None = None,
    ca_certificate: str | None = None,
    project_id: str | None = None,
    subscription_id: str | None = None,
    tenant_id: str | None = None,
):
    """
    Update an account in Sedai
    :param id: The id of the account
    :param name: The name of the account
    :param cloud_provider: Cloud provider of the account. Valid values are: `AWS`, `AZURE`, `GCP`, `KUBERNETES`
    :param credentials: Credentials for the account. See :ref:`credentials` for more details
    :param integration_type: Type of integration for Kubernetes accounts. Valid values are: `AGENTLESS`, `AGENT_BASED`
    :param cluster_provider: Cluster provider for Kubernetes accounts. Required when adding Kubernetes clusters. Valid values are: `AWS`, `AZURE`, `GCP`, `SELF_MANAGED`
    :param cluster_url: URL of the Kubernetes cluster. Required when adding agentless Kubernetes clusters.
    :param ca_certificate: Optional Certifying Authority Certificate for connecting agentlessly to Kubernetes clusters.
    :param project_id: The GCP project id. Required when adding GCP accounts.
    :param subscription_id: The Azure subscription id. Required when adding Azure accounts.
    :param tenant_id: The Azure tenant id. Required when adding Azure accounts.
    :return: True if the account was updated successfully, False otherwise
    """
    accounts = search_accounts_by_id(id)
    if len(accounts) == 0:
        log("No account with id: " + id)
        raise ValueError("No account with id: " + id)

    existing_account = accounts[0]
    if name is None:
        name = existing_account.name
    if cloud_provider is None:
        cloud_provider = existing_account.accountDetails.cloudProvider
    if integration_type is None:
        integration_type = existing_account.accountDetails.integrationType

    if cloud_provider not in CLOUD_PROVIDERS:
        raise ValueError("Invalid cloud provider: " + cloud_provider)
    if integration_type not in INTEGRATION_TYPES:
        raise ValueError("Invalid integration type: " + integration_type)
    if cloud_provider == "GCP" and project_id is None:
        if existing_account.accountDetails.projectId is None:
            raise ValueError("project_id is required for GCP accounts")
        project_id = existing_account.accountDetails.projectId

    if cloud_provider == "AZURE":
        if subscription_id is None:
            subscription_id = existing_account.accountDetails.subscriptionId
        if tenant_id is None:
            tenant_id = existing_account.accountDetails.tenantId

    metadata = {}
    if cloud_provider == "KUBERNETES":
        if cluster_provider not in CLUSTER_PROVIDERS:
            raise ValueError(
                "cluster_provider is required for Kubernetes accounts. Valid values are: "
                + ", ".join(CLUSTER_PROVIDERS)
            )
        if integration_type == "AGENTLESS" and credentials is None:
            from sedai.credentials import AwsRoleCredentials

            credentials = AwsRoleCredentials(role_arn=None, external_id=None)

        if cluster_url is not None:
            metadata["clusterUrl"] = cluster_url

        if ca_certificate is not None:
            metadata["caCertData"] = ca_certificate

        if cluster_provider is not None:
            metadata["clusterProvider"] = cluster_provider

        if name is not None:
            metadata["clusterName"] = name

    payload = {
        "accountDetails": {
            "cloudProvider": cloud_provider,
            "integrationType": integration_type,
            "enabled": True,
            "metadata": metadata,
        },
        "name": name,
        "id": id,
    }

    if cloud_provider == "GCP" and project_id is not None:
        payload["accountDetails"]["projectId"] = project_id

    if cloud_provider == "AZURE":
        if subscription_id is not None:
            payload["accountDetails"]["subscriptionId"] = subscription_id
        if tenant_id is not None:
            payload["accountDetails"]["tenantId"] = tenant_id

    if credentials is not None:
        payload["accountDetails"]["credentialsDetail"] = {"credentials": credentials.to_dict()}
    request = api.PostRequest('/api/site/accounts', payload)
    response = api.do_post(request)

    if response['status'] != 'OK':
        log(f"Failed to update account: {response['message']}")
        return ""
    else:
        log(f"Successfully updated account: {name}")
        return response['result']['accountId']


def delete_account(name):
    """
    Delete an account in Sedai, looked up by name.

    Account names are not unique in Sedai. If the name matches more than one account this raises
    rather than deleting an arbitrary one - use :py:func:`delete_account_by_id` instead.

    :param name: Name of the account to delete
    :return: True if the account was deleted successfully, False otherwise
    :raises ValueError: If no account is found with the given name
    :raises RuntimeError: If more than one account is found with the given name
    """
    account = _resolve_unique_account_by_name(name)
    request = api.DeleteRequest('/api/site/accounts/' + account.id)
    response = api.do_delete(request)
    if response['status'] != 'OK':
        log(f"Failed to delete account: {response['message']}")
        return False
    else:
        log(f"Successfully deleted account: {name}")
        return True


def delete_account_by_id(id):
    """
    Delete an account in Sedai
    :param id: Id of the account to delete
    :return: True if the account was deleted successfully, False otherwise
    """
    request = api.DeleteRequest('/api/site/accounts/' + id)
    response = api.do_delete(request)
    if response['status'] != 'OK':
        log(f"Failed to delete account: {response['message']}")
        return False
    else:
        log(f"Successfully deleted account: {id}")
        return True


def test_connection(account_id):
    """
    Test the connection to the account
    :param account_id: The Sedai account id
    :return: True if the connection was successful, False otherwise
    """

    payload = {"accountId": account_id}

    request = api.PostRequest('/api/site/account/' + account_id + '/testConnection', payload)
    response = api.do_post(request)
    if response['status'] != 'OK':
        log(f"Failed to test connection: {response['message']}")
        return False
    elif not response['result']['connectionStatus']:
        log(f"Test connection failed: {response['result']['reason']}")
        return False
    else:
        log(f"Successfully tested connection for account: {account_id}")
        return True


def get_agent_installation_command(name):
    """
    Get the agent installation command for the given account
    :param name: Name of the account
    :return: The agent installation command details
    Contains the following fields:
    - **accountId** - The Sedai account id
    - **apiKey** - The Sedai API key used for the command
    - **kubeInstallCmd** - The kubectl command to install the agent on Kubernetes clusters
    - **helmInstallCmd** - The helm command to install the agent on Kubernetes clusters

    Output:
    .. code-block:: json

        {
            "accountId": "n9dngzfd",
            "apiKey": "eyJhbGciOiJSUzI1NiJ9...[Truncated]",
            "kubeInstallCmd": "kubectl apply -f “https://[Truncated. URL for the YAML file]“",
            "helmInstallCmd": "helm upgrade --install sedai-smart-agent-abc oci://[...] --version 1.21.36 -f “https://[Truncated. URL for the YAML file]“]"
        }

    :raises ValueError: If no account is found with the given name
    :raises RuntimeError: If more than one account is found with the given name
    """
    account = _resolve_unique_account_by_name(name)
    return get_agent_installation_command_by_id(account.id)


def get_agent_installation_command_by_id(account_id):
    """
    Get the agent installation command for the given account id
    :param account_id: The Sedai account id
    :return: The agent installation command details, or None if the request failed
    Contains the following fields:
    - **accountId** - The Sedai account id
    - **apiKey** - The Sedai API key used for the command
    - **kubeInstallCmd** - The kubectl command to install the agent on Kubernetes clusters
    - **helmInstallCmd** - The helm command to install the agent on Kubernetes clusters

    Output:
    .. code-block:: json

        {
            "accountId": "n9dngzfd",
            "apiKey": "eyJhbGciOiJSUzI1NiJ9...[Truncated]",
            "kubeInstallCmd": "kubectl apply -f “https://[Truncated. URL for the YAML file]“",
            "helmInstallCmd": "helm upgrade --install sedai-smart-agent-abc oci://[...] --version 1.21.36 -f “https://[Truncated. URL for the YAML file]“]"
        }

    """
    request = api.GetRequest('/api/agent/accounts/' + account_id + '/agent-installation-cmds')
    response = api.do_get(request)
    if response['status'] != 'OK' or response['result'] is None:
        log(
            f"Failed to get agent installation command for account {account_id}: {response.get('message')}"
        )
        return None
    return transform(response['result'])


def get_whitelisted_instance_types(account_id: str) -> dict:
    """
    Get the account-level whitelisted instance types guardrail. When a whitelist is configured for an
    account, Sedai will only recommend/execute into instance types on this list.
    :param account_id: The Sedai account id
    :return: A dict mapping instance type name to its price per unit, e.g. `{"m5.large": 0.096}`
    """
    request = api.GetRequest(
        f'/api/settingsV2/topology/instanceTypes/account/{account_id}/whitelistedinstances'
    )
    response = api.do_get(request)
    if response['status'] != 'OK':
        log(f"Failed to get whitelisted instance types: {response['message']}")
        return {}
    return response['result'] or {}


def add_whitelisted_instance_type(
    account_id: str, instance_type: str, price_per_unit: float
) -> bool:
    """
    Add an instance type to the account-level whitelist guardrail.
    :param account_id: The Sedai account id
    :param instance_type: The instance type to whitelist, e.g. `"m5.large"`
    :param price_per_unit: The price per unit for this instance type
    :return: True if the instance type was whitelisted successfully, False otherwise (e.g. it's
     already on the blacklist)
    """
    payload = {"instanceType": instance_type, "pricePerUnit": price_per_unit}
    request = api.PostRequest(
        f'/api/settingsV2/topology/instanceTypes/account/{account_id}/whitelistedinstances', payload
    )
    try:
        response = api.do_post(request)
    except api.APIException as e:
        log(f"Failed to whitelist instance type {instance_type}: {e}")
        return False
    if response['status'] != 'OK':
        log(f"Failed to whitelist instance type {instance_type}: {response['message']}")
        return False
    return True


def remove_whitelisted_instance_type(account_id: str, instance_type: str) -> bool:
    """
    Remove an instance type from the account-level whitelist guardrail.
    :param account_id: The Sedai account id
    :param instance_type: The instance type to remove from the whitelist
    :return: True if an instance type was actually removed, False otherwise (including if
     `instance_type` wasn't on the whitelist to begin with)
    """
    request = api.DeleteRequest(
        f'/api/settingsV2/topology/instanceTypes/account/whitelistedinstances/account/{account_id}/{instance_type}'
    )
    response = api.do_delete(request)
    if response['status'] != 'OK':
        log(f"Failed to remove whitelisted instance type {instance_type}: {response['message']}")
        return False
    # status OK doesn't mean it deleted anything - check the actual deleted-row count.
    return (response.get('result') or 0) > 0


def get_blacklisted_instance_types(account_id: str) -> list:
    """
    Get the account-level blacklisted instance types guardrail. Sedai will never recommend/execute
    into an instance type on this list.
    :param account_id: The Sedai account id
    :return: A list of blacklisted instance type names
    """
    request = api.GetRequest(
        f'/api/settingsV2/topology/instanceTypes/account/{account_id}/blacklistedinstances'
    )
    response = api.do_get(request)
    if response['status'] != 'OK':
        log(f"Failed to get blacklisted instance types: {response['message']}")
        return []
    return response['result'] or []


def add_blacklisted_instance_type(account_id: str, instance_type: str) -> bool:
    """
    Add an instance type to the account-level blacklist guardrail.
    :param account_id: The Sedai account id
    :param instance_type: The instance type to blacklist, e.g. `"m5.large"`
    :return: True if the instance type was blacklisted successfully, False otherwise (e.g. it's
     already on the whitelist)
    """
    payload = {"instanceType": instance_type}
    request = api.PostRequest(
        f'/api/settingsV2/topology/instanceTypes/account/{account_id}/blacklistedinstances', payload
    )
    try:
        response = api.do_post(request)
    except api.APIException as e:
        log(f"Failed to blacklist instance type {instance_type}: {e}")
        return False
    if response['status'] != 'OK':
        log(f"Failed to blacklist instance type {instance_type}: {response['message']}")
        return False
    return True


def remove_blacklisted_instance_type(account_id: str, instance_type: str) -> bool:
    """
    Remove an instance type from the account-level blacklist guardrail.
    :param account_id: The Sedai account id
    :param instance_type: The instance type to remove from the blacklist
    :return: True if an instance type was actually removed, False otherwise (including if
     `instance_type` wasn't on the blacklist to begin with)
    """
    request = api.DeleteRequest(
        f'/api/settingsV2/topology/instanceTypes/account/blacklistedinstances/account/{account_id}/{instance_type}'
    )
    response = api.do_delete(request)
    if response['status'] != 'OK':
        log(f"Failed to remove blacklisted instance type {instance_type}: {response['message']}")
        return False
    # status OK doesn't mean it deleted anything - check the actual deleted-row count.
    return (response.get('result') or 0) > 0
