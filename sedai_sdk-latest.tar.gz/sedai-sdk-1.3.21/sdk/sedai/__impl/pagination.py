from typing import Any


class PaginatedResponse:
    def __init__(self, content: list[Any], next_page: int, total_pages: int | None = None):
        """
        @private
        :param content: The content of the current page.
        :param next_page: The 1-based index of the next page to fetch. If None, no more pages are available.
        :param total_pages: The total number of pages in the collection.
        """
        self.content = content
        self.next_page = next_page
        self.total_pages = total_pages
