from sedai.__impl import api, log


def get_resource_tags(resource_id):
    """
    Retrieve list of tags associated with a resource
    :param resource_id: The ID of the resource (str)
    :type resource_id: str
    :return: List of tags
    :rtype: List[Dict[str,str]] or None
    Each tag is an object with the following fields:
    - **key** - tag key
    - **value** - tag value

    Output:
    .. code-block:: json

            [
                {
                    "key": "Name",
                    "value": "example-k8s-cluster"
                },
                {
                    "key": "region",
                    "value": "us-east-1"
                }
            ]

    """
    request = api.GetRequest('/api/ui/resource/resource-tags', params={'resourceId': resource_id})
    response = api.do_get(request)
    if response['status'] != 'OK':
        log(f"Failed to get resource tags: {response['message']}")
        return None
    else:
        log("Successfully got resource tag")
        return response['result']


def get_clusters():
    """
    Get all clusters that have discovered, group-assigned resources in Sedai.
    :return: A list of clusters. Each entry is an object with the following fields:

    - **name** - the name of the cluster
    - **clusterId** - the Sedai id of the cluster
    - **clusterType** - the type of the cluster, e.g. "KUBERNETES" or "ECS"
    - **cloudProvider** - the cloud provider of the cluster's account
    - **accountId** - the Sedai account id backing the cluster
    - **accountName** - the name of the account backing the cluster
    - **region** - the region the cluster is in
    """
    request = api.GetRequest('/api/site/clusters')
    response = api.do_get(request)
    if response['status'] != 'OK':
        log(f"Failed to get clusters: {response['message']}")
        return None
    else:
        log("Successfully got clusters")
        return response['result']
