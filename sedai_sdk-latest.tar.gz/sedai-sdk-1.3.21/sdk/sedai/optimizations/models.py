from types import SimpleNamespace
from typing import Any


class ResourceConfig:
    """
    The configuration of a resource monitored by Sedai.
    """

    def __init__(self):
        pass


class WorkloadConfig(ResourceConfig):
    """
    Configuration for a Kubernetes workload.
    """

    replicas: int
    """
    Replica count for this workload.
    """

    def __init__(self, replicas: int):
        """@private"""
        self.replicas = replicas


class KubeContainerConfig(ResourceConfig):
    """
    Container configuration of a Kubernetes resource monitored by Sedai.
    """

    memory_request: SimpleNamespace | None
    """
    Minimum memory requested for the container if set.
    """
    memory_limit: SimpleNamespace | None
    """
    Maximum memory allowed for the container if set.
    """
    cpu_request: SimpleNamespace | None
    """
    Minimum CPU units requested for the container if set.
    """
    cpu_limit: SimpleNamespace | None
    """
    Maximum CPU units allowed for the container if set.
    """

    def __init__(
        self,
        mem_req: SimpleNamespace | None,
        mem_limit: SimpleNamespace | None,
        cpu_req: SimpleNamespace | None,
        cpu_limit: SimpleNamespace | None,
    ):
        """@private"""
        self.memory_request = mem_req
        self.memory_limit = mem_limit
        self.cpu_request = cpu_req
        self.cpu_limit = cpu_limit


class NodegroupDetails:
    """
    Details of a single nodegroup for hosting a cluster.
    """

    name: str
    """
    Name of the node group.
    """
    instance_type: str
    """
    Instance type for this node group.
    """
    memory_bytes: float
    """
    Memory for this node group.
    """
    vcpus: int
    """
    VCPUs for this node group.
    """
    num_nodes: int
    """
    Number of nodes in this node group.
    """
    min_num_nodes: int
    """
    Minimum number of nodes in this node group.
    """
    max_num_nodes: int
    """
    Maximum number of nodes in this node group.
    """

    def __init__(
        self,
        name: str | None = None,
        instance_type: str | None = None,
        memory_bytes: float | None = None,
        vcpus: int | None = None,
        num_nodes: int | None = None,
        min_num_nodes: int | None = None,
        max_num_nodes: int | None = None,
    ):
        """@private"""
        self.name = name
        self.instance_type = instance_type
        self.memory_bytes = memory_bytes
        self.vcpus = vcpus
        self.num_nodes = num_nodes
        self.min_num_nodes = min_num_nodes
        self.max_num_nodes = max_num_nodes


class NodegroupConfig(ResourceConfig):
    """
    The nodegroup configuration for hosting a cluster.
    """

    nodegroups: list[NodegroupDetails]
    """
    List of nodegroups for this cluster.
    """

    def __init__(self):
        """@private"""
        self.nodegroups = []


class NodegroupDetails:
    """
    Details of a single nodegroup for hosting a cluster.
    """

    name: str
    """
    Name of the node group.
    """
    instance_type: str
    """
    Instance type for this node group.
    """
    memory_bytes: float
    """
    Memory for this node group.
    """
    vcpus: int
    """
    VCPUs for this node group.
    """
    num_nodes: int
    """
    Number of nodes in this node group.
    """
    min_num_nodes: int
    """
    Minimum number of nodes in this node group.
    """
    max_num_nodes: int
    """
    Maximum number of nodes in this node group.
    """

    def __init__(
        self,
        name: str | None = None,
        instance_type: str | None = None,
        memory_bytes: float | None = None,
        vcpus: int | None = None,
        num_nodes: int | None = None,
        min_num_nodes: int | None = None,
        max_num_nodes: int | None = None,
    ):
        """@private"""
        self.name = name
        self.instance_type = instance_type
        self.memory_bytes = memory_bytes
        self.vcpus = vcpus
        self.num_nodes = num_nodes
        self.min_num_nodes = min_num_nodes
        self.max_num_nodes = max_num_nodes


class S3IntelligentTieringConfig:
    """
    Configuration for S3 intelligent tiering.
    """

    config_id: str
    """
    The ID of the configuration.
    """

    prefix: str
    """
    The prefix for the configuration.
    """

    tags: dict[str, str]
    """
    The tags for the configuration.
    """

    archive_threshold_days: dict[str, int]
    """
    The archive threshold in days for the configuration.
    """

    def __init__(
        self,
        config_id: str,
        prefix: str,
        tags: dict[str, str],
        archive_threshold_days: dict[str, int],
    ):
        """@private"""
        self.config_id = config_id
        self.prefix = prefix
        self.tags = tags
        self.archive_threshold_days = archive_threshold_days


class S3LifecycleRule:
    """
    Configuration for S3 lifecycle rules.
    """

    rule_id: str
    """
    The ID of the rule.
    """

    enabled: bool
    """
    Whether the rule is enabled.
    """

    transitions: list[dict[str, Any]]
    """
    The transitions for the rule.
    """

    def __init__(self, rule_id: str, enabled: bool, transitions: list[dict[str, Any]]):
        """@private"""
        self.rule_id = rule_id
        self.enabled = enabled
        self.transitions = transitions


class S3BucketConfig:
    """
    Configuration for an S3 bucket.
    """

    bucket_name: str
    """
    The name of the bucket.
    """

    intelligent_tiering_configs: list[S3IntelligentTieringConfig]
    """
    The intelligent tiering configurations for the bucket.
    """

    lifecycle_rules: list[S3LifecycleRule]
    """
    The lifecycle rules for the bucket.
    """

    def __init__(
        self,
        bucket_name: str,
        intelligent_tiering_configs: list[S3IntelligentTieringConfig],
        lifecycle_rules: list[SimpleNamespace],
    ):
        """@private"""
        self.bucket_name = bucket_name
        self.intelligent_tiering_configs = intelligent_tiering_configs
        self.lifecycle_rules = lifecycle_rules


class VolumeConfig(ResourceConfig):
    """
    Configuration for a volume.
    """

    size_gb: int
    """
    The size of the volume in GB.
    """

    iops: int
    """
    The IOPS of the volume.
    """

    throughput: int
    """
    The throughput of the volume.
    """

    def __init__(self, src: dict):
        """@private"""
        super().__init__()
        self.size_gb = src.get("sizeInGB")
        self.iops = src.get("iops")
        self.throughput = src.get("throughput")


class EBSVolumeConfig(VolumeConfig):
    """
    Configuration for an EBS volume.
    Extends `VolumeConfig` with additional attributes specific to EBS.
    """

    __type = "EBSVolumeConfigState"

    volume_type: str
    """
    The type of the volume.
    """

    def __init__(self, src: dict):
        """@private"""
        super().__init__(src)
        self.volume_type = src.get("volumeType")


class AzureDiskConfig(VolumeConfig):
    """
    Azure-specific configuration for a disk.

    Extends `VolumeConfig` with additional attributes specific to Azure,
    such as disk type and performance tier.
    """

    __type = "AzureDiskConfigState"

    disk_type: str
    """
    The type of the Azure disk (e.g., Premium_LRS, StandardSSD_LRS, Standard_LRS).
    """

    tier: str
    """
    The performance tier of the Azure disk (e.g., P4, P10, P20, E10).
    """

    def __init__(self, src: dict):
        super().__init__(src)
        self.disk_type = src.get("diskType")
        self.tier = src.get("tier")


class ECSContainerConfig:
    """
    Configuration for an ECS container.
    """

    container_name: str
    """
    The name of the container.
    """

    container_image: str
    """
    The image of the container.
    """

    memory_soft_limit: int
    """
    The soft memory limit of the container.
    """

    memory_hard_limit: int
    """
    The hard memory limit of the container.
    """

    cpu_soft_limit: int
    """
    The soft CPU limit of the container.
    """

    def __init__(
        self,
        container_name: str,
        container_image: str,
        memory_soft_limit: int,
        memory_hard_limit: int,
        cpu_soft_limit: int,
    ):
        """@private"""
        self.container_name = container_name
        self.container_image = container_image
        self.memory_soft_limit = memory_soft_limit
        self.memory_hard_limit = memory_hard_limit
        self.cpu_soft_limit = cpu_soft_limit


class ECSResourceConfig:
    """
    Configuration for an ECS resource.
    """

    desired_count: int
    """
    The desired count of the resource.
    """

    running_count: int
    """
    The running count of the resource.
    """

    task_cpu_hard_limit_units: float | None
    """
    The hard CPU limit of the task.
    """

    task_memory_hard_limit_mib: float | None
    """
    The hard memory limit of the task.
    """

    container_configs: list[ECSContainerConfig]
    """
    The container configurations for the resource.
    """

    def __init__(
        self,
        desired_count: int,
        running_count: int,
        task_cpu_hard_limit_units: float | None,
        task_memory_hard_limit_mib: float | None,
        container_configs: list[ECSContainerConfig],
    ):
        """@private"""
        self.desired_count = desired_count
        self.running_count = running_count
        self.task_cpu_hard_limit_units = task_cpu_hard_limit_units
        self.task_memory_hard_limit_mib = task_memory_hard_limit_mib
        self.container_configs = container_configs


class KubeResourceConfig:
    """
    Configuration for a Kubernetes resource.
    """

    def __init__(self, container_configs: dict[str, KubeContainerConfig], replicas: int):
        """@private"""
        self.container_configs = container_configs
        self.replicas = replicas


class LambdaResourceConfig:
    """
    Configuration for a Serverless Lambda resource.
    """

    memory_size: int
    """
    The memory size configured for the Lambda function.
    """

    timeout: int
    """
    The timeout configured for the Lambda function.
    """

    reserved_concurrency: int | None
    """
    The reserved concurrency of the Lambda function if configured.
    """

    provisioned_concurrency: int | None
    """
    The provisioned concurrency of the Lambda function if configured.
    """

    def __init__(
        self,
        memory_size: int,
        timeout: int,
        reserved_concurrency: int | None,
        provisioned_concurrency: int | None,
    ):
        """@private"""
        self.memory_size = memory_size
        self.timeout = timeout
        self.reserved_concurrency = reserved_concurrency
        self.provisioned_concurrency = provisioned_concurrency
