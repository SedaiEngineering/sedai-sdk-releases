from datetime import datetime, timezone


class JobHealth:
    job_id: str | None
    job_status: str | None
    is_healthy: bool | None
    last_refreshed_on: datetime | None
    health_check_time: datetime | None
    last_healthy_on: datetime | None
    message: str | None

    def __init__(
        self,
        job_id: str | None = None,
        job_status: str | None = None,
        is_healthy: bool | None = None,
        last_refreshed_on: datetime | None = None,
        health_check_time: datetime | None = None,
        last_healthy_on: datetime | None = None,
        message: str | None = None,
    ):
        self.job_id = job_id
        self.job_status = job_status
        self.is_healthy = is_healthy
        self.last_refreshed_on = last_refreshed_on
        self.health_check_time = health_check_time
        self.last_healthy_on = last_healthy_on
        self.message = message

    @classmethod
    def from_api_response(cls, data: dict) -> "JobHealth":
        return cls(
            job_id=data.get("jobId"),
            job_status=data.get("jobStatus"),
            is_healthy=data.get("healthy"),
            last_refreshed_on=(
                datetime.fromtimestamp(data.get("lastRefreshedOn"), tz=timezone.utc)
                if data.get("lastRefreshedOn") is not None
                else None
            ),
            health_check_time=(
                datetime.fromtimestamp(data.get("healthCheckTime"), tz=timezone.utc)
                if data.get("healthCheckTime") is not None
                else None
            ),
            last_healthy_on=(
                datetime.fromtimestamp(data.get("lastHealthyOn"), tz=timezone.utc)
                if data.get("lastHealthyOn") is not None
                else None
            ),
            message=data.get("message"),
        )


class MessageStats:
    """
    Details of message stats.
    """

    action: str | None
    average_execution_time_millis: int | None
    total_executions: int | None
    successful_executions: int | None
    failed_executions: int | None

    def __init__(
        self,
        action: str | None = None,
        average_execution_time_millis: int | None = None,
        total_executions: int | None = None,
        successful_executions: int | None = None,
        failed_executions: int | None = None,
    ):
        self.action = action
        self.average_execution_time_millis = average_execution_time_millis
        self.total_executions = total_executions
        self.successful_executions = successful_executions
        self.failed_executions = failed_executions

    @classmethod
    def message_stats_from_response(cls, data: dict) -> "MessageStats":
        return cls(
            action=data.get("commandAction"),
            average_execution_time_millis=data.get("averageExecutionTimeMillis"),
            total_executions=data.get("totalExecutions"),
            successful_executions=data.get("successfulExecutions"),
            failed_executions=data.get("failedExecutions"),
        )


class SmartAgentHealth:
    """
    Details of smart agents.
    """

    account_id: str | None
    account_name: str | None
    is_healthy: bool | None
    is_agent_available: bool | None
    live_connection_status: bool | None
    connection_type: str | None
    version: str | None
    desired_version: str | None
    last_supported_version: str | None
    upgrade_needed: bool | None
    spec_controller_version: str | None
    latest_health_check_time: datetime | None
    job_health_list: list[JobHealth] | None
    message_stats: list[MessageStats] | None = None

    def __init__(
        self,
        account_id: str | None = None,
        account_name: str | None = None,
        is_healthy: bool | None = None,
        is_agent_available: bool | None = None,
        live_connection_status: bool | None = None,
        connection_type: str | None = None,
        version: str | None = None,
        desired_version: str | None = None,
        last_supported_version: str | None = None,
        upgrade_needed: bool | None = None,
        spec_controller_version: str | None = None,
        latest_health_check_time: datetime | None = None,
        job_health_list: list[JobHealth] | None = None,
        message_stats: list[MessageStats] | None = None,
    ):
        self.account_id = account_id
        self.account_name = account_name
        self.is_healthy = is_healthy
        self.is_agent_available = is_agent_available
        self.live_connection_status = live_connection_status
        self.connection_type = connection_type
        self.version = version
        self.desired_version = desired_version
        self.last_supported_version = last_supported_version
        self.upgrade_needed = upgrade_needed
        self.spec_controller_version = spec_controller_version
        self.latest_health_check_time = latest_health_check_time
        self.job_health_list = job_health_list
        self.message_stats = message_stats

    @classmethod
    def health_info_from_response(cls, data: dict) -> "SmartAgentHealth":
        details_data = data.get("details") or {}
        job_list = details_data.get("jobHealthList") or []

        jobs = [JobHealth.from_api_response(job) for job in job_list if isinstance(job, dict)]

        return cls(
            account_id=data.get("accountId"),
            account_name=data.get("accountName"),
            is_healthy=data.get("healthy"),
            is_agent_available=data.get("agentAvailable"),
            live_connection_status=data.get("liveConnectionStatus"),
            connection_type=data.get("connectionType"),
            version=data.get("version"),
            desired_version=data.get("desiredVersion"),
            last_supported_version=data.get("lastSupportedVersion"),
            upgrade_needed=data.get("upgradeNeeded"),
            spec_controller_version=data.get("specControllerVersion"),
            latest_health_check_time=(
                datetime.fromtimestamp(details_data.get("latestHealthCheckTime"), tz=timezone.utc)
                if details_data.get("latestHealthCheckTime") is not None
                else None
            ),
            job_health_list=jobs,
            message_stats=None,
        )
