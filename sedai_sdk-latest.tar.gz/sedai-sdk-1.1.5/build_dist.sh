# !/bin/bash

# Remove the dist, docs and release directories if they exist
if [ -d dist ]; then
  rm -rf dist
fi

# Detlete any *.egg-info dir recursively from current directory
find . -type d -name '*.egg-info' -exec rm -rf {} +

Creatiing the python distribution
python setup.py sdist

# Current directory
current_dir=$(pwd)

# Check if ../sedai-sdk-releases exists if not clone the repository from git@github.com:SedaiEngineering/sedai-sdk-releases.git

if [ -d ../sedai-sdk-releases ]; then
    echo "Directory ../sedai-sdk-releases exists."
else
    echo "Directory ../sedai-sdk-releases does not exist."
    echo "Cloning the repository from git@github.com:SedaiEngineering/sedai-sdk-releases.git"
    cd ..
    git clone git@github.com:SedaiEngineering/sedai-sdk-releases.git
    cd $current_dir
fi

# Copy the distribution to the release directory
cp -r dist/* ../sedai-sdk-releases

# Rename the distribution to sedai-sdk-<version>.tar.gz to sedai-sdk-latest.tar.gz
cd ../sedai-sdk-releases
pwd
mv sedai-sdk-*.tar.gz sedai_sdk-latest.tar.gz


###############

# Copy example to the release directory
cp -r $current_dir/examples ../sedai-sdk-releases

# Recursively delete all files ending with .env from examples directory
find ../sedai-sdk-releases/examples -type f -name '*.env' -exec rm -f {} +

# Recursively delete all files ending with .pyc from examples directory
find ../sedai-sdk-releases/examples -type f -name '*.pyc' -exec rm -f {} +


