from sedai.__impl import config

_log = None


def __initLogger(logger=None):
    global _log
    if logger != None:
        _log = logger
    else:
        import logging
        _log = logging.getLogger()


# Later in the module
def log(message):
    print(message)
    _log.info(message)


def init():
    __initLogger()
    log("Initializing SDK")
    config.get_config()
    log("SDK Initialized")


init()
