from types import SimpleNamespace

from sedai.__impl import api, log
from sedai.__impl.resource import create_resource, validate_resource
from sedai.__impl.settings import _AccountLevelSettings, _GroupLevelSettings
from sedai.__impl.settings import add_settings, get_merged_settings, add_account_settings, add_group_settings, \
    validate_settings


# __SETTINGS_LEVELS = ["account", "group", "resource"]


def get_resource_settings(account_id, resource_id):
    """
    Get the settings for a resource
    :param account_id: The Sedai account ID in
    :param resource_id: The resource ID
    :return: A resource object representing the resource, with the settings populated
    to the current settings values.

   - **settings** - the settings object. Refer to the documentation for the specific resource type :ref:`resource_types` for the settings structure.
    """

    # Create a resource object to hold the settings
    resource = create_resource(account_id, resource_id)

    # Get the account settings
    account_settings = get_account_settings(account_id)
    if account_settings is None:
        raise ValueError("Could not find account settings for account: " + account_id)

    # Get the resource config from the account settings
    resource_config = None
    for config in account_settings:
        resource_config = config['resourceConfig']
        if resource_id is not None and resource_config['resourceId'] == resource_id:
            # resource_config = resource_config['resourceConfigs']
            break

    if resource_config is None:
        raise ValueError(f"Could not find resource settings for resource:  ({resource_id})")
    else:
        resource.resource_name = resource_config['resourceName']
        resource.resource_type = resource_config['resourceType']
        resource_config = resource_config['resourceConfigs']
        resource = add_settings(resource, resource_config)

    return resource


def update_resource_settings(resource):
    """
    Update the settings for a resource
    :param resource: The resource object to update. It is recommended to use the :py:func:`get_resource_settings`
    function to get the resource object first and then update the settings.
    :return: bool - True if the settings were updated successfully, False otherwise

    Sample code:

    .. code-block:: python

            from sedai import settings, account

            account = account.search_accounts_by_name("Account Name")
            account_id = account[0].account_id
            resource_id = "btbszpib/Deployment/sedai-labs-02-us-east-1/argocd/argocd-applicationset-controller"

            resource = settings.get_resource_settings(account_id, resource_id)
            resource.settings.availability.configMode = 'AUTO'
            settings.update_resource_settings(resource)



    """

    validate_resource(resource)
    resoruce_configs = get_merged_settings(resource)

    resource_dict = dict()
    resource_dict['resourceId'] = resource.resource_id
    resource_dict['accountId'] = resource.account_id
    resource_dict['resourceName'] = resource.resource_name
    resource_dict['resourceType'] = resource.resource_type
    resource_dict['resourceConfigs'] = resoruce_configs


    request = api.PostRequest('/api/settings/topology/update/configs/resources', [resource_dict])
    response = api.do_post(request)
    if response['status'] != 'OK':
        log(f"Failed to update resource settings: {response['message']}")
        raise ValueError(f"Failed to update resource settings: {response['message']}")
    else:
        log(f"Successfully updated resource settings: {resource.resource_id}")
        return True


def get_account_settings(account_id):
    # GET 'https://piedpiper.sedai.app/api/settings/topology/configs/account/resources?accountId=btbszpib'

    request = api.GetRequest('/api/settings/topology/configs/account/resources?accountId=' + account_id)
    response = api.do_get(request)
    if response['status'] == 'OK' and response['result'] is not None:
        return response['result']
    else:
        return None


def get_account_level_setting(account_id):
    """
    Get the settings for an account
    :param account_id: The Sedai account ID in
    :return: account level settings details of the given account.
    """

    request = api.GetRequest('/api/settings/topology/configs/account/' + account_id)
    response = api.do_get(request)
    if response['status'] == 'OK' and response['result'] is not None:
        return response['result']
    else:
        return None


def get_account_level_resource_config(account_id):
    """
    Get the settings for an account
    :param account_id: The Sedai account ID 
    :return: an accountLevelResourceConfig object representing the account Level config, with the settings populated to the current settings values.

    """

    account_settings = get_account_level_setting(account_id)
    account = SimpleNamespace()

    if account_settings is None:
        raise ValueError("Could not find account settings for account: " + account_id)

    # Get the accountLevelResourceConfig from the account settings
    account_level_resource_config = account_settings['accountLevelResourceConfig']

    if account_level_resource_config is None:
        raise ValueError(f"Could not find account settings for account:  ({account_id})")
    else:
        account.settings = add_account_settings(account_level_resource_config)

    return account.settings


def update_account_setting(account_id, account_settings):
    """
    Update the settings for an account
    :param account_id: The Sedai account ID
    :param account_settings: The account settings object to update. It is recommended to use the :py:func:`get_account_level_resource_config`
    function to get the account settings object first and then update the settings.
    :return: bool - True if the settings were updated successfully, False otherwise
    """

    validate_settings(account_settings)
    account = _AccountLevelSettings.get_merged_settings(account_settings)

    request = api.PostRequest(f'/api/settings/topology/update/configs/account/{account_id}', account)
    response = api.do_post(request)
    if response['status'] != 'OK':
        log(f"Failed to update account settings: {response['message']}")
        raise ValueError(f"Failed to update account settings: {response['message']}")
    else:
        log(f"Successfully updated account settings: {account_id}")
        return True


def get_groups_settings():
    """
    Get the settings for a group
    :return: the list of group level settings.
    """

    request = api.GetRequest('/api/settings/topology/configs/groups')
    response = api.do_get(request)
    if response['status'] == 'OK' and response['result'] is not None:
        return response['result']
    else:
        return None


def get_group_level_resource_config_detail(group_id):
    """
    Get the settings for a group
    :param group_id: The Sedai group id
    :return: A group object representing the group level resource config detail, with the settings populated to the current settings values.

   - **settings** - the settings object. 
    """

    group = SimpleNamespace()

    # Get the group settings
    group_settings = get_groups_settings()
    if group_settings is None:
        raise ValueError("Could not find group settings")

    # Get the group config from the group settings
    group_config = None
    for config in group_settings:
        group_config = config['groupLevelResourceConfigDetail']
        if group_id is not None and config['groupId'] == group_id:
            break

    # Get the groupLevelResourceConfigDetail from the group settings
    group_level_resource_config = group_config

    if group_config is None:
        raise ValueError(f"Could not find group settings for resource:  ({group_id})")
    else:
        group.settings = add_group_settings(group_level_resource_config)

    return group.settings


def update_group_setting(group_id, group_settings):
    """
    Update the settings for a group
    :param group_id: The Sedai group_id
    :param group_settings: The group settings object to update. It is recommended to use the :py:func:`get_group_level_resource_config_detail`
    function to get the group settings object first and then update the settings.
    :return: bool - True if the settings were updated successfully, False otherwise
    """

    validate_settings(group_settings)
    group = _GroupLevelSettings.get_merged_settings(group_settings)

    request = api.PostRequest(f'/api/settings/topology/update/configs/group/{group_id}', group)
    response = api.do_post(request)
    if response['status'] != 'OK':
        log(f"Failed to update group settings: {response['message']}")
        raise ValueError(f"Failed to update group settings: {response['message']}")
    else:
        log(f"Successfully updated group settings: {group_id}")
        return True
