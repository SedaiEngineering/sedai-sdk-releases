# !/bin/bash
# Check if a /tmp/venv directory exists. Delete it if it does.

if [ -d /tmp/venv ]; then
  rm -rf /tmp/venv
fi

# Deactivate any existing virtual environment
deactivate
conda deactivate


# Create a new virtual environment in /tmp/venv
python3 -m venv /tmp/venv

# Activate the virtual environment
source /tmp/venv/bin/activate

# Install the requirements_dev.txt file in the virtual environment
pip install -r requirements_dev.txt

# Get the full path to the current directory and add it to the PYTHONPATH

export PYTHONPATH=$(pwd)/sdk
