import unittest

from sedai import account, models, credentials


class AccountTest(unittest.TestCase):
    def test_01_get_account(self):
        acs = account.get_all_accounts()
        # jsonify and pretty print

        # print(models.to_json(acs, indent=4))
        # assert acs is not None and type (acs) is list

        self.assertIsNotNone(acs)
        self.assertTrue(type(acs) is list)
        self.assertTrue(len(acs) > 0)

    def test_02_get_account_by_name(self):
        acs = account.search_accounts_by_name('test env')

        # print(models.to_json(acs, indent=4))

        self.assertIsNotNone(acs)
        self.assertTrue(type(acs) is list)
        self.assertTrue(len(acs) > 0)
        for ac in acs:
            self.assertEqual(ac.name, 'test env')

        ac = acs[0]

        # print(ac)
        # print(models.to_json(ac, indent=4))
        # print(models.to_dict(ac))
        self.assertEqual(ac.name, 'test env')
        self.assertEqual(ac.accountDetails.cloudProvider, 'GCP')
        self.assertEqual(ac.accountDetails.integrationType, 'AGENTLESS')
        self.assertEqual(ac.id, '7kbyomhs')

    def test_03_create_account(self):
        # Create different types of accounts with different credentials
        # AWS
        aws_account = account.create_account(
            name='aws account',
            cloud_provider='AWS',
            integration_type='AGENTLESS',
            credentials=credentials.AwsRoleCredentials(
                role_arn='role_arn',
                external_id='external_id'
            )
        )
        self.assertIsNotNone(aws_account)

        # Azure
        azure_account = account.create_account(
            name='azure account',
            cloud_provider='AZURE',
            integration_type='AGENTLESS',
            credentials=credentials.AzureClientCredentials(
                client_id='client_id',
                client_secret='client_secret'
            )
        )
        self.assertIsNotNone(azure_account)

        # GCP
        gcp_account = account.create_account(
            name='gcp account',
            cloud_provider='GCP',
            integration_type='AGENTLESS',
            credentials=credentials.GCPServiceAccountJsonCredentials(
                service_account_json='service_account_json'
            )
        )
        self.assertIsNotNone(gcp_account)

        # Kubernetes with agent
        kubernetes_account = account.create_account(
            name='kubernetes account with agent',
            cloud_provider='KUBERNETES',
            integration_type='AGENT_BASED',
            credentials=credentials.FederatedPrometheusJWT(
                bearer_token='bearer_token'
            ),
            cluster_provider='AWS'
        )
        self.assertIsNotNone(kubernetes_account)

        # # Kubernetes without agent
        # kubernetes_account = account.create_account(
        #     name='kubernetes account without agent',
        #     cloud_provider='KUBERNETES',
        #     integration_type='AGENTLESS',
        #     credentials=None,
        #     cluster_provider='GCP'
        # )
        # self.assertIsNotNone(kubernetes_account)

    def test_delete_accounts(self):
        account_names = ['aws account', 'azure account', 'gcp account', 'kubernetes account with agent',
                         'kubernetes account without agent']
        for account_name in account_names:
            try:
                response = account.delete_account(account_name)
                print(response)
                print(f"Deleted account: {account_name}")
            except Exception as e:
                print(f"Failed to delete account: {account_name}. Error: {e}")
                pass

    def test_04_get_agent_installation_command(self):
        command = account.get_agent_installation_command('kubernetes account with agent')
        command = models.to_json(command, indent=4)
        print(command)
        self.assertIsNotNone(command)


if __name__ == '__main__':
    unittest.main()
