import unittest


class MonitoringProviderTest(unittest.TestCase):
    def test_01_create_monitoring_provider_default(self):
        from sedai import monitoring_provider
        from sedai import credentials
        from sedai import account

        tc = credentials.GKEMonitoringCredentials(
            service_account_json='service_account_json'
        )

        accounts = account.search_accounts_by_name("GKE")
        account_id = accounts[1].id

        gke_mp = monitoring_provider.add_GKE_monitoring(
            account_id=account_id,
            project_id='project_id',
            credentials=credentials.GKEMonitoringCredentials(
                service_account_json='service_account_json'
            )
        )

        self.assertIsNotNone(gke_mp)
        self.assertTrue(gke_mp)

    def test_02_create_monitoring_provider(self):
        from sedai import monitoring_provider
        from sedai import credentials
        from sedai import account

        tc = credentials.GKEMonitoringCredentials(
            service_account_json='service_account_json'
        )
        accounts = account.search_accounts_by_name("GKE")
        account_id = accounts[1].id

        gke_mp = monitoring_provider.add_GKE_monitoring(
            account_id=account_id,
            project_id='project_id',
            credentials=credentials.GKEMonitoringCredentials(
                service_account_json='service_account_json'
            ),
            lb_dimensions=['test_val1', 'test_val_2'],
            region_dimensions=['region_val1', 'region_val_2']
        )

        self.assertIsNotNone(gke_mp)
        self.assertTrue(gke_mp)
