import unittest

from sdk.sedai import group


class GroupTest(unittest.TestCase):
    def test_01_get_group(self):
        grp = group.get_all_groups()
        # jsonify and pretty print

        # print(models.to_json(grp, indent=4))
        # assert grp is not None and type (grp) is list

        self.assertIsNotNone(grp)
        self.assertTrue(type(grp) is list)
        self.assertTrue(len(grp) > 0)

    def test_02_groups_by_name(self):
        grp = group.search_groups_by_name('test1')

        # print(models.to_json(grp, indent=4))
        print(grp)
        self.assertIsNotNone(grp)
        self.assertTrue(type(grp) is list)
        self.assertTrue(len(grp) > 0)
        for gp in grp:
            self.assertEqual(gp.name, 'test1')

        gp = grp[0]

        self.assertEqual(gp.name, 'test1')

    def test_03_create_group(self):
        grp = group.create_group(
            name='Group-test',
            tags={
                "keyName": [
                    "Value1", "Value2"
                ]
            },
            cluster=['cluster'],
            region=['region'],
            namespace=['namespace'],
            autoRefresh=True
        )
        self.assertIsNotNone(grp)


if __name__ == '__main__':
    unittest.main()
