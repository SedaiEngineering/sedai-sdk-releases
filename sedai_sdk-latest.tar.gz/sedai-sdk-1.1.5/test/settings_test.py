import unittest

from sedai import settings


class SettingsTest(unittest.TestCase):
    # def test_to_settings(self):
    #     from sedai.__impl.settings import add_settings
    #     resourceConfigs =  {
    #         "type": "KubernetesAppResourceConfigDetail",
    #         "availability": {
    #             "scope": "RESOURCE_OVERRIDE",
    #             "configCategory": "AVAILABILITY",
    #             "configMode": "MANUAL"
    #         },
    #         "random": {
    #             "scope": "RESOURCE_OVERRIDE",
    #             "configCategory": "RANDOM",
    #             "configMode": "MANUAL"
    #         },
    #         "slo": {
    #             "scope": "RESOURCE_OVERRIDE",
    #             "configCategory": "SLO",
    #             "configMode": "MANUAL"
    #         },
    #         "releaseIntelligence": {
    #             "scope": "RESOURCE_OVERRIDE",
    #             "configCategory": "RELEASE_INTELLIGENCE",
    #             "configMode": "MANUAL"
    #         },
    #         "optimization": {
    #             "type": "KubernetesOptimizationResourceConfigCategoryDetail",
    #             "optimizationConfig": {
    #             "scope": "RESOURCE_OVERRIDE",
    #             "configCategory": "OPTIMIZATION",
    #             "configMode": "MANUAL"
    #             },
    #             "optimizationFocus": {
    #             "type": "KubernetesOptimizationFocusItem",
    #             "focus": "COST_AND_DURATION",
    #             "maxMemoryIncreasePct": None,
    #             "maxCPUIncreasePct": None,
    #             "maxLatencyIncreasePct": 0
    #             }
    #         },
    #         "enableVerticalScaling": {
    #             "status": True
    #         },
    #         "enableHorizontalScaling": {
    #             "horizontalScalingConfig": {
    #             "status": False
    #             },
    #             "minReplicas": None,
    #             "maxReplicas": None,
    #             "replicaMultiplier": None,
    #             "horizontalScalingConfigMode": False
    #         },
    #         "enablePredictiveScaling": {
    #             "status": False
    #         },
    #         "autonomousActionWithoutTraffic": {
    #             "status": True
    #         },
    #         "isProd": {
    #             "status": True
    #         }
    #     }
    #     settings = to_settings(resourceConfigs)
    #     from sedai.models import to_json
    #     print(to_json(settings, indent=4))
    #     settings.availability.configMode = 'AUTO'
    #
    #     print(to_json(settings, indent=4))

    # print(settings.settings)

    def test_01_get_resource_settings(self):
        resource_id = "sctfpt1c/Deployment/sedai-labs-02-us-east-1/argocd/argocd-applicationset-controller"
        account_id = "sctfpt1c"
        resource = settings.get_resource_settings(account_id, resource_id=resource_id)
        print(resource)

    def test_02_update_resource_settings(self):
        resource_id = "sctfpt1c/Deployment/sedai-labs-02-us-east-1/argocd/argocd-applicationset-controller"
        account_id = "sctfpt1c"
        resource = settings.get_resource_settings(account_id, resource_id=resource_id)
        mode = "AUTO"
        # print(resource)
        # print("Before")
        # print(resource.settings.availability.configMode)
        resource.settings.availability.configMode = mode
        # print(resource)
        settings.update_resource_settings(resource)
        resource = settings.get_resource_settings(account_id, resource_id=resource_id)
        # print("After")
        # print(resource.settings.availability.configMode)

        self.assertEqual(resource.settings.availability.configMode, mode)

    # Test for updating AWS Lambda resource
    def test_03_update_resource_settings(self):
        resource_id = "arn:aws:lambda:us-east-1:072125767554:function:DatadogIntegration-DatadogA-DatadogAPICallFunction-WyMLyKaJBCAT:$LATEST"
        account_id = "mstk5sjb"
        resource = settings.get_resource_settings(account_id, resource_id=resource_id)
        mode = "MANUAL"
        print(resource)
        # print("Before")
        # print(resource.settings.availability.configMode)
        # resource.settings.availability.configMode = mode
        # print(resource)
        settings.update_resource_settings(resource)
        resource = settings.get_resource_settings(account_id, resource_id=resource_id)
        # print("After")
        # print(resource.settings.availability.configMode)

        self.assertEqual(resource.settings.availability.configMode, mode)

    def test_04_update_account_setting(self):
        account_id = "mstk5sjb"
        account_settings = settings.get_account_level_resource_config(account_id)
        # print("Before")
        # print(account_settings)
        mode = "MANUAL"
        account_settings.serverlessSpecificDetail.optimization.optimizationConfig.configMode = mode
        settings.update_account_setting(account_id, account_settings)
        account_settings = settings.get_account_level_resource_config(account_id)
        # print("After")
        # print(account_settings.serverlessSpecificDetail.optimization.optimizationConfig.configMode)
        self.assertEqual(account_settings.serverlessSpecificDetail.optimization.optimizationConfig.configMode, mode)

    def test_05_update_group_settings(self):
        group_id = "0e324f81-4066-4010-ad1a-1b2b8c93aa0a"
        group_settings = settings.get_group_level_resource_config_detail(group_id)
        # print("Before")
        # print(group_settings)
        mode = False
        group_settings.ecsSpecificDetail.isProd.status = mode
        settings.update_group_setting(group_id, group_settings)
        group_settings = settings.get_group_level_resource_config_detail(group_id)
        # print("After")
        # print(group_settings.ecsSpecificDetail.isProd.status)
        self.assertEqual(group_settings.ecsSpecificDetail.isProd.status, mode)
