import os
import unittest

from sedai.__impl.api import GetRequest, APIException, do_get, PostRequest, DeleteRequest, do_post, do_delete
from sedai.__impl.config import load_config


class ConfigTest(unittest.TestCase):
    def test_01_config_from_env(self):
        # Set env vars
        os.environ["SEDAI_BASE_URL"] = "tenant"
        os.environ["SEDAI_API_TOKEN"] = "env_token"
        config = load_config()
        # TENANT should come from the env var set above
        self.assertNotEqual(config["SEDAI_BASE_URL"], "tenant")
        print(config["SEDAI_API_TOKEN"])
        # SEDAI_API_TOKEN should come from the test.env file
        self.assertNotEqual(config["SEDAI_API_TOKEN"], "env_token")

    def test_02_config_from_file(self):
        # Set env vars
        os.environ["SEDAI_BASE_URL"] = "tenant"
        os.environ["SEDAI_API_TOKEN"] = "token"

        # Get the directory of this file
        dir_path = os.path.dirname(os.path.realpath(__file__))
        override_file = os.path.join(dir_path, "override.env")
        print(override_file)

        config = load_config(overrrid_file=override_file)
        # TENANT should come from the env var set above
        self.assertEqual(config["SEDAI_BASE_URL"], "https://tenant")
        # SEDAI_API_TOKEN should come from the override.env file
        self.assertEqual(config["SEDAI_API_TOKEN"], "override_token")

    def test_03_test_bad_token(self):
        # Get the directory of this file

        config = load_config()
        # TENANT should come from the env var set above
        config["SEDAI_API_TOKEN"] = "bad_token"

        get = GetRequest("/accounts")
        with self.assertRaises(APIException):
            do_get(get)

        post = PostRequest("/accounts", {})
        with self.assertRaises(APIException):
            do_post(post)

        delete = DeleteRequest("/accounts", {})
        with self.assertRaises(APIException):
            do_delete(delete)


if __name__ == '__main__':
    unittest.main()
