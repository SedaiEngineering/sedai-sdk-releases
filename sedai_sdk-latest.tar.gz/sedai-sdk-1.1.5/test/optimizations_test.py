import unittest

from sedai import optimizations


class FeaturesTest(unittest.TestCase):
    def test_01_get_recommendations(self):
        recommendation = optimizations.get_recommendations()
        # jsonify and pretty print

        # print(models.to_json(recommendation, indent=4))
        # assert recommendation is not None and type (recommendation) is list

        self.assertIsNotNone(recommendation)
        self.assertTrue(type(recommendation) is dict)
        self.assertIsNotNone(recommendation['recommendations'])

    def test_02_get_opportunities_account(self):
        opportunities = optimizations.get_opportunities('account', 'mstk5sjb')
        # jsonify and pretty print

        # print(models.to_json(opportunities, indent=4))
        # assert opportunities is not None and type (opportunities) is list
        self.assertTrue(type(opportunities['content']) is list)
        self.assertIsNotNone(opportunities['content'])

    def test_03_get_opportunities_cluster(self):
        opportunities = optimizations.get_opportunities('cluster', 'mstk5sjb')
        # jsonify and pretty print

        # print(models.to_json(opportunities, indent=4))
        # assert opportunities is not None and type (opportunities) is list

        self.assertTrue(type(opportunities['content']) is list)
        self.assertIsNotNone(opportunities['content'])


if __name__ == '__main__':
    unittest.main()
