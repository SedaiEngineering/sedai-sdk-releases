class SedaiCredentials:

    def __init__(self):
        self.credentialsProvider = "AWS_ENV_SUPPLIED"

    def __to_dict(self):
        return self.__dict__

    def to_dict(self):
        return self.__dict__


class AWSCredentials(SedaiCredentials):
    pass

class AwsKeyCredentials(AWSCredentials):
    """AWS Access Key and Secret Key based credentials"""

    def __init__(self, access_key_id, secret_access_key):
        """
        :type access_key_id: str
        :param access_key_id: The AWS access key id
        :param secret_access_key: The AWS secret access key
        """
        self.accessKeyId = access_key_id
        self.secretAccessKey = secret_access_key
        self.credentialsProvider = "AWS_STATIC"


class AwsRoleCredentials(AWSCredentials):
    """AWS Role based credentials"""

    def __init__(self, role_arn, external_id=None):
        """
        :type role_arn: str
        :param role_arn: The AWS role arn
        :param external_id: An optional external id to use with the role
        """
        self.role = role_arn
        self.externalId = external_id
        self.credentialsProvider = "AWS_ENV_SUPPLIED"


class AzureClientCredentials(SedaiCredentials):
    """Azure Client ID and Client Secret based credentials"""

    def __init__(self, client_id, client_secret):
        """
        :type client_id: str
        :param client_id: The Azure client id
        :param client_secret: The Azure client secret
        """
        self.clientId = client_id
        self.clientSecret = client_secret
        self.credentialsProvider = "AZURE_CLIENT_CREDENTIALS"


class FederatedPrometheusCredentials(SedaiCredentials):
    pass


class FederatedPrometheusNoAuth(FederatedPrometheusCredentials):
    """Prometheus federated without authentication
    This is a placheolder object, with no actual credentials
    """

    def __init__(self):
        self.credentialsProvider = "FEDERATEDPROMETHEUS_NO_AUTH"


class FederatedPrometheusJWT(FederatedPrometheusCredentials):
    """Prometheus federated with JWT authentication"""

    def __init__(self, bearer_token):
        """
        :type bearer_token: str
        :param bearer_token: The JWT token to use for authentication
        """
        self.bearerToken = bearer_token
        self.credentialsProvider = "FEDERATEDPROMETHEUS_JWT"


class FederatedPrometheusClientCredentials(FederatedPrometheusCredentials):
    """Prometheus federated with client credentials"""

    def __init__(self, token_endpoint, client_id, client_secret):
        """
        :type token_endpoint: str
        :param token_endpoint: The token endpoint to use for authentication
        :param client_id: The client id to use for authentication
        :param client_secret: The client secret to use for authentication
        """
        self.tokenEndpoint = token_endpoint
        self.clientId = client_id
        self.clientSecret = client_secret
        self.credentialsProvider = "FEDERATEDPROMETHEUS_CLIENT_CREDENTIALS"


class DatadogCredentials(SedaiCredentials):
    """Datadog API Key based credentials"""

    def __init__(self, application_key, api_key):
        """
        :type application_key: str
        :param application_key: The Datadog application key
        :param api_key: The Datadog API key
        """
        self.applicationKey = application_key
        self.apiKey = api_key
        self.credentialsProvider = "DATADOG"


class GCPServiceAccountJsonCredentials(SedaiCredentials):
    """GCP Service Account JSON based credentials"""

    def __init__(self, service_account_json):
        """
        :type service_account_json: str
        :param service_account_json: The GCP service account JSON
        """
        self.serviceAccountJson = service_account_json
        self.credentialsProvider = "GCP_SERVICE_ACCOUNT_JSON"


class GKEMonitoringCredentials(SedaiCredentials):
    """GKE Monitoring credentials"""

    def __init__(self, service_account_json=None):
        """
        :type service_account_json: str
        :param service_account_json: The GCP service account JSON
        """
        self.keyFile = service_account_json
        self.credentialsProvider = "GKEMonitoring"

class NewrelicCredentials(SedaiCredentials):
    """Newrelic API Key based credentials"""

    def __init__(self, api_key):
        """
        :type api_key: str
        :param api_key: The Newrelic API key
        """
        self.apiKey = api_key
        self.credentialsProvider = "NEWRELIC"

class KubernetesCredentials(SedaiCredentials):
    def __init__(self):
        self.credentialsProvider = "KUBERNETES_ENV_SUPPLIED"


class TokenCredentials(SedaiCredentials):
    """Token based credentials"""

    def __init__(self, token):
        self.token = token
        self.credentialsProvider = "TOKEN"
