import json

from sedai.__impl.model_converter import _SimpleNamespace_to_dict, __nsEncoder


def to_json(model, **kwargs):
    """
    Convert a model returned bu the SDK to a JSON string
    :param model: The model to convert
    :param kwargs: Any additional arguments to pass to json.dumps
    :return: The converted JSON String
    """
    return json.dumps(model, cls=__nsEncoder, **kwargs)


def to_dict(model):
    """
    Convert a model returned by the SDK to a dictionary
    :param model: The model to convert
    :return: The converted dictionary
    """
    return _SimpleNamespace_to_dict(model)
