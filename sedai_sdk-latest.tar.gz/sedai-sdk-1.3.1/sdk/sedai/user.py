from sedai.__impl import api
from sedai.__impl.model_converter import transform
import functools

keys = ["userId","displayName","firstName","lastName","profileUrl","pictureUrl","email","roles","sedaiRoles","verificationHash","createdTime","updatedTime","identityProvider","verified"]


@functools.lru_cache()
def get_profile():
    request = api.GetRequest('/api/userProfile')
    response = api.do_get(request)
    return transform(response, keys=keys)