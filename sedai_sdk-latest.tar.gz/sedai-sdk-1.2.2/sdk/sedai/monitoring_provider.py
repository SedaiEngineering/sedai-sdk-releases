from sedai.__impl import api, log
from sedai.credentials import DatadogCredentials, GKEMonitoringCredentials, AWSCredentials


def add_cloudwatch_monitoring(account_id: str,
                              credentials: AWSCredentials,
                              lb_dimensions: list = None,
                              app_dimensions: list = None,
                              instance_dimensions: list = None):
    """
    Add CloudWatch monitoring to an account
    :param account_id: The Sedai account id
    :param credentials: A valid AWS credentials object. Refer to :ref:`credentials` for more details
    :param lb_dimensions: The list of load balancer dimensions. Default: ["load_balancer_name"]
    :param app_dimensions: The list of application dimensions. Default: ["application_id"]
    :param instance_dimensions: The list of instance dimensions. Default: ["instance_id"]
    :return: Boolean indicating if the monitoring provider was created successfully. If mandatory fields are missing,
    then an exception is raised.
    """
    if account_id is None:
        raise ValueError("account_id is required")
    if credentials is None:
        raise ValueError("credentials is required")

    if lb_dimensions is None:
        lb_dimensions = ["load_balancer_name"]
    if app_dimensions is None:
        app_dimensions = ["application_id"]
    if instance_dimensions is None:
        instance_dimensions = ["instance_id"]

    payload = {
        "instanceDimensions": instance_dimensions,
        "appDimensions": app_dimensions,
        "lbDimensions": lb_dimensions,
        "integrationType": "AGENTLESS",
        "monitoringProvider": "CLOUDWATCH",
        'siteDiscoveryEnabled': False,
        'name': f'Cloudwatch for {account_id}',
        "alertIntegrationEnabled": False,
        "details": {
            "monitoringProvider": "CLOUDWATCH",
            "credentialsDetail": {
                "credentials": credentials.to_dict()
            }
        }
    }

    request = api.PostRequest(f'/api/monitoring/monitoringProviders/accounts/{account_id}', payload)
    response = api.do_post(request)
    if response['status'] != 'OK':
        log(f"Failed to create monitoring provider: {response['message']}")
        return False
    else:
        log(f"Successfully created monitoring provider: CloudWatch")
        return True


def add_GKE_monitoring(account_id: str,
                       project_id: str,
                       credentials: GKEMonitoringCredentials,
                       name: str = None,
                       lb_dimensions: list = None,
                       app_dimensions: list = None,
                       instance_dimensions: list = None,
                       region_dimensions: list = None,
                       container_dimensions: list = None,
                       namespace_dimensions: list = None,
                       cluster_dimensions: list = None,
                       integration_type: str = "AGENT_BASED"):
    """
    Add GKE monitoring to an account
    :param account_id: The account id
    :param project_id: The project id
    :param credentials: The GKE monitoring credentials. Refer to :ref:`credentials` for more details
    :param name: An optional name for the monitoring provider
    :param lb_dimensions: The list of load balancer dimensions. Default: ["destination_service_name"]
    :param app_dimensions: The list of application dimensions. Default: ["application_id"]
    :param instance_dimensions: The list of instance dimensions. Default: ["pod_name"]
    :param region_dimensions: The list of region dimensions. Default: ["location"]
    :param container_dimensions: The list of container dimensions. Default: ["container_name"]
    :param namespace_dimensions: The list of namespace dimensions. Default: ["destination_service_namespace", "namespace_name"]
    :param cluster_dimensions: The list of cluster dimensions. Default: ["cluster_name"]
    :param integration_type: The integration type. Valid values are: `AGENTLESS`, `AGENT_BASED`. Default: `AGENT_BASED`
    :return: Boolean indicating if the monitoring provider was created successfully. If mandatory fields are missing,
    then an exception is raised.

    For the list of dimentsions, if the list is passed, then that list is used as is. If the list is not passed, the default
    list is used. If an empty list is passed, then no dimensions are used.
    """

    if account_id is None:
        raise ValueError("account_id is required")
    if project_id is None:
        raise ValueError("project_id is required")
    if credentials is None:
        raise ValueError("credentials is required")

    if name is None:
        name = f"Cloud Monitoring for GKE account {account_id}"
    if instance_dimensions is None:
        instance_dimensions = ["pod_name"]
    if app_dimensions is None:
        app_dimensions = ["application_id"]
    if lb_dimensions is None:
        lb_dimensions = ["destination_service_name"]
    if container_dimensions is None:
        container_dimensions = ["container_name"]
    if namespace_dimensions is None:
        namespace_dimensions = ["destination_service_namespace", "namespace_name"]
    if cluster_dimensions is None:
        cluster_dimensions = ["cluster_name"]
    if region_dimensions is None:
        region_dimensions = ["location"]

    payload = {
        "instanceDimensions": instance_dimensions,
        "appDimensions": app_dimensions,
        "lbDimensions": lb_dimensions,
        "integrationType": integration_type,
        "containerDimensions": container_dimensions,
        "namespaceDimensions": namespace_dimensions,
        "clusterDimensions": cluster_dimensions,
        "siteDiscoveryEnabled": False,
        "name": name,
        "monitoringProvider": "GKEMONITORING",
        "alertIntegrationEnabled": False,
        "regionDimensions": region_dimensions,
        "details": {
            "monitoringProvider": "GKEMONITORING",
            "credentialsDetail": {
                "credentials": credentials.to_dict()
            },
            "disableCertificateValidation": False,
            "projectId": project_id
        }
    }

    request = api.PostRequest(f'/api/monitoring/monitoringProviders/accounts/{account_id}', payload)
    response = api.do_post(request)
    if response['status'] != 'OK':
        log(f"Failed to create monitoring provideer: {response['message']}")
        return False
    else:
        log(f"Successfully created monitoring provider: {name}")
        return True


def add_datadog_monitoring(account_id: str,
                           credentials: DatadogCredentials,
                           name: str = None,
                           lb_dimensions: list = None,
                           app_dimensions: list = None,
                           instance_dimensions: list = None,
                           region_dimensions: list = None,
                           container_dimensions: list = None,
                           namespace_dimensions: list = None,
                           cluster_dimensions: list = None,
                           az_dimensions: list = None,
                           env_dimensions: list = None,
                           instance_id_pattern: str = None,  
                           integration_type: str = "AGENTLESS"):
    """
    Add Datadog monitoring to an account
    :param account_id: The account id
    :param credentials: The Datadog credentials. Refer to :ref:`credentials` for more details
    :param name: An optional name for the monitoring provider
    :param lb_dimensions: The list of load balancer dimensions. Default: ["destination_service_name"]
    :param app_dimensions: The list of application dimensions. Default: ["application_id"]
    :param instance_dimensions: The list of instance dimensions. Default: ["pod_name"]
    :param region_dimensions: The list of region dimensions. Default: ["location"]
    :param container_dimensions: The list of container dimensions. Default: ["container_name"]
    :param namespace_dimensions: The list of namespace dimensions. Default: ["destination_service_namespace", "namespace_name"]
    :param cluster_dimensions: The list of cluster dimensions. Default: ["cluster_name"]
    :param az_dimensions: The list of availability zone dimensions. Default: ["availability_zone"]
    :param env_dimensions: The list of environment dimensions. Default: []
    :param instance_id_pattern: The instance id pattern. Default: None
    :param integration_type: The integration type. Valid values are: `AGENTLESS`, `AGENT_BASED`. Default: `AGENTLESS`
    :return: Boolean indicating if the monitoring provider was created successfully. If mandatory fields are missing,
    then an exception is raised.
    """



    if account_id is None:
        raise ValueError("account_id is required")
    if credentials is None:
        raise ValueError("credentials is required")

    if name is None:
        name = f"Cloud Monitoring for Datadog account {account_id}"
    if instance_dimensions is None:
        instance_dimensions = ["pod_name"]
    if app_dimensions is None:
        app_dimensions = ["application_id"]
    if lb_dimensions is None:
        lb_dimensions = ["destination_service_name"]
    if container_dimensions is None:
        container_dimensions = ["container_name"]
    if namespace_dimensions is None:
        namespace_dimensions = ["destination_service_namespace", "namespace_name"]
    if cluster_dimensions is None:
        cluster_dimensions = ["cluster_name"]
    if region_dimensions is None:
        region_dimensions = ["location"]
    if az_dimensions is None:
        az_dimensions = ["availability_zone"]
    if env_dimensions is None:
        env_dimensions = []
    if instance_id_pattern is None:
        instance_id_pattern = None

    payload = {
        "instanceDimensions": instance_dimensions,
        "appDimensions": app_dimensions,
        "lbDimensions": lb_dimensions,
        "integrationType": integration_type,
        "containerDimensions": container_dimensions,
        "namespaceDimensions": namespace_dimensions,
        "clusterDimensions": cluster_dimensions,
        "azDimensions": az_dimensions,
        "envDimensions": env_dimensions,
        "instanceIdPattern": instance_id_pattern,
        "siteDiscoveryEnabled": False,
        "name": name,
        "monitoringProvider": "DATADOG",
        "alertIntegrationEnabled": False,
        "regionDimensions": region_dimensions,
        "details": {
            "monitoringProvider": "DATADOG",
            "credentialsDetail": {
                "credentials": credentials.to_dict()
            },
            "customCertificates": None,
            "disableCertificateValidation": False,
            "endpoint": "https://api.datadoghq.com/",
            "enableAllMetrics": False,
            "enableEnvSpecialHandling": False        
        },
    }

    request = api.PostRequest(f'/api/monitoring/monitoringProviders/accounts/{account_id}', payload)
    response = api.do_post(request)
    if response['status'] != 'OK':
        log(f"Failed to create monitoring provider: {response['message']}")
        return False
    else:
        log(f"Successfully created Datadog monitoring provider: {name}")
        return True
    