"""
    ## General Conventions
- Data returned by get calls is returned as objects of [SimpleNameSpace](https://docs.python.org/3/library/types.html#types.SimpleNamespace).
These objects can be accessed with the dot notation. For eg: `account.account_id` returns the account id of the account object.

- If  the response is a list, the list is returned as a list of objects of SimpleNameSpace.
- Data returned by get calls can be converted to a dictionary using the `to_dict()` method from the `models` module.

.. code-block:: python

        models.to_dict(account.get_all_accounts())
        # returns a list of dictionaries. Each dictionary represents an account.

- Data returned by get calls can be converted to a JSON string using the `to_json()` method from the `models` module.

.. code-block:: python

            models.to_json(account.get_all_accounts())




## Getting Started

Assuming your base instance url is https://acme.sedai.cloud, go to https://acme.sedai.cloud/settings/apikeys
    and generate an API key. You will use this API key to initialize the SDK.

Create a virtual environment and install the SDK using pip:

.. code-block:: bash

            pip install sedai-sdk.zip



Create a file called `.env` in the root of your project and add the following lines:

.. code-block:: bash

                SEDAI_BASE_URL=https://acme.sedai.cloud
                SEDAI_API_TOKEN=<your api key>

Create a file called `test.py` with the following code:

.. code-block:: python

                from sedai import account, models

                account = account.get_all_accounts()
                print(models.to_json(account, indent=4))




"""
