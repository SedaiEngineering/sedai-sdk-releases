from sedai.__impl import api, log
from sedai.account import search_accounts_by_id
from typing import List, Optional, Dict
from types import SimpleNamespace
from sedai.__impl.model_converter import transform
from datetime import datetime
from sedai.util import __get_paginated_response
from warnings import warn


__OPPORTUNITIES_LEVELS = ["account", "cluster"]
__PAGINATION_FIELDS = ['nextPage', 'totalCount']


class ResourceConfig:
    """
    The configuration of a resource monitored by Sedai.
    """

    def __init__(self):
        pass


class WorkloadConfig(ResourceConfig):
    """
    Configuration for a Kubernetes workload.
    """

    replicas: int
    """
    Replica count for this workload.
    """

    def __init__(self, replicas: int):
        """@private"""
        self.replicas = replicas


class KubeContainerConfig(ResourceConfig):
    """
    Container configuration of a Kubernetes resource monitored by Sedai.
    """

    memory_request: Optional[SimpleNamespace]
    """
    Minimum memory requested for the container if set.
    """
    memory_limit: Optional[SimpleNamespace]
    """
    Maximum memory allowed for the container if set.
    """
    cpu_request: Optional[SimpleNamespace]
    """
    Minimum CPU units requested for the container if set.
    """
    cpu_limit: Optional[SimpleNamespace]
    """
    Maximum CPU units allowed for the container if set.
    """

    def __init__(
        self,
        mem_req: Optional[SimpleNamespace],
        mem_limit: Optional[SimpleNamespace],
        cpu_req: Optional[SimpleNamespace],
        cpu_limit: Optional[SimpleNamespace],
    ):
        """@private"""
        self.memory_request = mem_req
        self.memory_limit = mem_limit
        self.cpu_request = cpu_req
        self.cpu_limit = cpu_limit


class NodegroupDetails:
    """
    Details of a single nodegroup for hosting a cluster.
    """

    name: str
    """
    Name of the node group.
    """
    instance_type: str
    """
    Instance type for this node group.
    """
    memory_bytes: float
    """
    Memory for this node group.
    """
    vcpus: int
    """
    VCPUs for this node group.
    """
    num_nodes: int
    """
    Number of nodes in this node group.
    """
    min_num_nodes: int
    """
    Minimum number of nodes in this node group.
    """
    max_num_nodes: int
    """
    Maximum number of nodes in this node group.
    """

    def __init__(
        self,
        name: str,
        instance_type: str,
        memory_bytes: float,
        vcpus: int,
        num_nodes: int,
        min_num_nodes: int,
        max_num_nodes: int,
    ):
        """@private"""
        self.name = name
        self.instance_type = instance_type
        self.memory_bytes = memory_bytes
        self.vcpus = vcpus
        self.num_nodes = num_nodes
        self.min_num_nodes = min_num_nodes
        self.max_num_nodes = max_num_nodes


class NodegroupConfig(ResourceConfig):
    """
    The nodegroup configuration for hosting a cluster.
    """

    nodegroups: List[NodegroupDetails]
    """
    List of nodegroups for this cluster.
    """

    def __init__(self):
        """@private"""
        self.nodegroups = []


class NodegroupOptimization:
    """
    Optimizations for the nodegroup configuration of a cluster.
    """

    original_nodegroup_config: NodegroupConfig
    """
    The original nodegroup configuration for this cluster.
    """
    recommended_nodegroup_config_original: NodegroupConfig
    """
    Recommendations for the original nodegroup configuration for this cluster.
    """
    recommended_nodegroup_config_optimal: NodegroupConfig
    """
    Recommended optimal nodegroup configuration for this cluster.
    """

    def __init__(self):
        self.original_nodegroup_config = NodegroupConfig()
        self.recommended_nodegroup_config_original = NodegroupConfig()
        self.recommended_nodegroup_config_optimal = NodegroupConfig()


class ResourceOptimization:
    """
    Details of an optimization proposed for a resource.
    """

    resource_name: str
    """
    Name of the resource for which the optimization was proposed.
    """
    resource_id: str
    """
    ID of the resource for which the optimization was proposed.
    """
    account_id: str
    """
    Account ID of the resource for which the optimization was proposed.
    """
    optimization_time: Optional[datetime]
    """
    Time at which the optimization was performed for completed optimizations.
    """

    def __init__(
        self,
        resource_name: str,
        resource_id: str,
        account_id: str,
        optimization_time: Optional[datetime] = None,
    ):
        """@private"""
        self.resource_name = resource_name
        self.resource_id = resource_id
        self.account_id = account_id
        self.optimization_time = optimization_time


class KubeResourceOptimization(ResourceOptimization):
    """
    Details of an optimization proposed for a Kubernetes resource.
    """

    original_container_config: Dict[str, KubeContainerConfig]
    """
    The original container configuration of the Kubernetes resource.
    """
    recommended_container_config: Dict[str, KubeContainerConfig]
    """
    Optimized container configuration recommended by Sedai.
    """
    original_workload_config: WorkloadConfig
    """
    The original workload configuration of the Kubernetes resource.
    """
    recommended_workload_config: WorkloadConfig
    """
    Optimized workload configuration recommended by Sedai.
    """

    def __init__(
        self,
        resource_name: str,
        resource_id: str,
        account_id: str,
        original_config: Dict,
        recommended_config: Dict,
        optimization_time: Optional[datetime] = None,
    ):
        self.original_container_config = dict()
        self.recommended_container_config = dict()

        # TODO: Temporarily resolving name from ID
        if resource_name is None and resource_id is not None:
            resource_name = resource_id.split("/")[-1]

        super().__init__(
            resource_name=resource_name,
            resource_id=resource_id,
            account_id=account_id,
            optimization_time=optimization_time,
        )

        pre_container_config_map = original_config['kubeContainerConfigStateMap']
        post_container_config_map = recommended_config['kubeContainerConfigStateMap']
        for name, pre_config in pre_container_config_map.items():
            pre_cpu_limit = None
            pre_cpu_req = None
            pre_mem_limit = None
            pre_mem_req = None
            post_cpu_limit = None
            post_cpu_req = None
            post_mem_limit = None
            post_mem_req = None
            container_config_fields = ['value', 'metricUnit']
            post_config = post_container_config_map[name]

            if not pre_config['cpuRequestNotSet']:
                pre_cpu_req = transform(pre_config['cpuRequestValue'], container_config_fields)
            if not pre_config['cpuLimitNotSet']:
                pre_cpu_limit = transform(pre_config['cpuLimitValue'], container_config_fields)
            if not pre_config['memoryRequestNotSet']:
                pre_mem_req = transform(pre_config['memoryRequestValue'], container_config_fields)
            if not pre_config['memoryLimitNotSet']:
                pre_mem_limit = transform(pre_config['memoryLimitValue'], container_config_fields)

            if not post_config['cpuRequestNotSet']:
                post_cpu_req = transform(post_config['cpuRequestValue'], container_config_fields)
            if not post_config['cpuLimitNotSet']:
                post_cpu_limit = transform(post_config['cpuLimitValue'], container_config_fields)
            if not post_config['memoryRequestNotSet']:
                post_mem_req = transform(post_config['memoryRequestValue'], container_config_fields)
            if not post_config['memoryLimitNotSet']:
                post_mem_limit = transform(post_config['memoryLimitValue'], container_config_fields)
            pre_container_config = KubeContainerConfig(
                pre_mem_req, pre_mem_limit, pre_cpu_req, pre_cpu_limit
            )
            post_container_config = KubeContainerConfig(
                post_mem_req, post_mem_limit, post_cpu_req, post_cpu_limit
            )
            self.original_container_config[name] = pre_container_config
            self.recommended_container_config[name] = post_container_config

        pre_replicas = original_config['replicas']
        recommended_replicas = recommended_config['replicas']
        self.original_workload_config = WorkloadConfig(pre_replicas)
        self.recommended_workload_config = WorkloadConfig(recommended_replicas)


class ResourceOpportunity:
    """
    Details of potential resource optimization opportunities.
    This may also include opportunities for resources that are set to autonomous.
    """

    account_id: str
    """
    Account ID of the resource for which the optimization was proposed.
    """
    resource_name: str
    """
    Name of the resource for which the optimization was proposed.
    """

    def __init__(self, src: dict):
        """@private"""
        self.src = src
        self.__parse__()

    def __parse__(self):
        self.account_id = self.src.get('accountId', None)
        self.resource_name = self.src.get('resource_name', None)


class ClusterOpportunity(ResourceOpportunity):
    """
    Details of all potential optimization opportunities for a cluster.
    """

    cost_projection_summary: SimpleNamespace
    """
    Summary of the estimated cost projection for this cluster.
    """
    nodegroup_optimization: NodegroupOptimization
    """
    Details of nodegroup optimizations recommended for this cluster.
    """
    workload_optimizations: List[ResourceOptimization]
    """
    Details of workload optimizations recommended for this cluster.
    """

    def __init__(self, src: dict):
        self.nodegroup_optimization = NodegroupOptimization()
        self.workload_optimizations = []
        super().__init__(src)

    def __parse__(self):
        super().__parse__()
        self.report_id = self.src['reportId']

        optimization_recommendations = self.src['optimizationRecommendations']
        self.workload_optimization_id = optimization_recommendations['proposed']['workloads'][
            'workloadOptimizationId'
        ]
        curr_nodegroups_conf = optimization_recommendations['current']
        rec_curr_nodegroups_conf = optimization_recommendations['proposed']['honourNodeGroups']
        rec_ignore_nodegroups_conf = optimization_recommendations['proposed']['ignoreNodeGroups']

        curr_nodegroups = None
        rec_curr_nodegroups = None
        rec_optimal_nodegroups = None

        if curr_nodegroups_conf is not None:
            curr_nodegroups = curr_nodegroups_conf['nodeGroups']

        if rec_curr_nodegroups_conf is not None:
            rec_curr_nodegroups = rec_curr_nodegroups_conf['nodeGroups']

        if rec_ignore_nodegroups_conf is not None:
            rec_optimal_nodegroups = rec_ignore_nodegroups_conf['nodeGroups']

        if curr_nodegroups is not None:
            for ng in curr_nodegroups:
                nodegroup_name = ng.get('nodeGroupName', None)
                instanceType = ng.get('instanceType', None)
                memory_bytes = ng.get('memoryInBytes', None)
                num_nodes = ng.get('numberOfNodes', None)
                min_num_nodes = ng.get('minNumOfNodes', None)
                max_num_nodes = ng.get('maxNumOfNodes', None)

                vcpus = ng.get('vcpus', None)
                nodegroup = NodegroupDetails(
                    name=nodegroup_name,
                    instance_type=instanceType,
                    memory_bytes=memory_bytes,
                    vcpus=vcpus,
                    num_nodes=num_nodes,
                    min_num_nodes=min_num_nodes,
                    max_num_nodes=max_num_nodes,
                )
                self.nodegroup_optimization.original_nodegroup_config.nodegroups.append(nodegroup)

        if rec_curr_nodegroups is not None:
            for ng in rec_curr_nodegroups:
                nodegroup_name = ng.get('nodeGroupName', None)
                instanceType = ng.get('instanceType', None)
                memory_bytes = ng.get('memoryInBytes', None)
                vcpus = ng.get('vcpus', None)
                num_nodes = ng.get('numberOfNodes', None)
                min_num_nodes = ng.get('minNumOfNodes', None)
                max_num_nodes = ng.get('maxNumOfNodes', None)

                nodegroup = NodegroupDetails(
                    name=nodegroup_name,
                    instance_type=instanceType,
                    memory_bytes=memory_bytes,
                    vcpus=vcpus,
                    num_nodes=num_nodes,
                    min_num_nodes=min_num_nodes,
                    max_num_nodes=max_num_nodes,
                )
                self.nodegroup_optimization.recommended_nodegroup_config_original.nodegroups.append(
                    nodegroup
                )

        if rec_optimal_nodegroups is not None:
            for ng in rec_optimal_nodegroups:
                nodegroup_name = ng.get('nodeGroupName', None)
                instanceType = ng.get('instanceType', None)
                memory_bytes = ng.get('memoryInBytes', None)
                vcpus = ng.get('vcpus', None)
                num_nodes = ng.get('numberOfNodes', None)
                min_num_nodes = ng.get('minNumOfNodes', None)
                max_num_nodes = ng.get('maxNumOfNodes', None)

                nodegroup = NodegroupDetails(
                    name=nodegroup_name,
                    instance_type=instanceType,
                    memory_bytes=memory_bytes,
                    vcpus=vcpus,
                    num_nodes=num_nodes,
                    min_num_nodes=min_num_nodes,
                    max_num_nodes=max_num_nodes,
                )
                self.nodegroup_optimization.recommended_nodegroup_config_optimal.nodegroups.append(
                    nodegroup
                )

        cost_fields = [
            'currentMonthlyCost',
            'currentAverageMonthlyCost',
            'predictedMonthlyCost.total',
            'predictedAverageMonthlyCost',
            'predictedMonthlySavings',
            'predictedAverageMonthlySavings',
        ]
        self.cost_projection_summary = transform(self.src['costProjectionSummary'], cost_fields)


def get_recommendations():
    """
    Retrieves recommendations from the Sedai API.\n
    Returns:
        dict: A dictionary containing the recommendation data.
    """
    request = api.GetRequest('/api/ui/recommendations/allrecommendationsv3')
    response = api.do_get(request)
    if response['status'] != 'OK':
        log(f"Failed to get recommendation: {response['message']}")
        return None
    else:
        log(f"Successfully got recommendation")
        return response['result']


def get_opportunities(level, id):
    """
    Retrieves recommendations from the Sedai API.\n
    Returns:
        dict: A dictionary containing the recommendation data.
    """
    if level not in __OPPORTUNITIES_LEVELS:
        raise Exception(f"Invalid opportunities level: {level}")
    if level == "account":
        account = search_accounts_by_id(id)
        if len(account) == 0:
            log("Account with id: " + id + " does not exist")
            return False
        request = api.GetRequest(f'/api/cluster/optimization/summarylist?accountIds={id}')

    elif level == "cluster":
        request = api.GetRequest(f'/api/cluster/optimization/summarylist?clusterId={id}')

    response = api.do_get(request)
    if response['status'] != 'OK':
        log(f"Failed to get opportunities: {response['message']}")
        return None
    else:
        log(f"Successfully got opportunities")
        return response['result']


def get_workload_opportunities(
    workload_optimization_report_id: str,
    account_id: str,
    cluster_id: str = None,
    cluster_optimization_report_id: str = None,
    page_size: int = 10,
    page_start: int = 0,
    page_order_by: str = None,
    page_order_dir: str = None,
) -> SimpleNamespace:
    """
    @private
    Retrieve optimization opportunities for workloads on a cluster.
    :param workload_optimization_report_id: The workload optimization report ID for the resource.
    :param account_id: Account ID to retrieve opportunities for.
    :param cluster_id: ID of the cluster to retrieve opportunities for.
    :param cluster_optimization_report_id: The cluster optimization report ID.
    :param page_size: Page size to retrieve.
    :param page_start: Start of page to retrieve.
    :param page_order_by: Attribute to sort paging.
    :param page_order_dir: Sort direction for paging.
    :return: Available workload optimization opportunities.
    """
    warn(
        "This method is deprecated in version 1.2.3 and will be removed in a future release.",
        DeprecationWarning,
        stacklevel=2,
    )

    params = dict()
    if cluster_optimization_report_id is not None:
        params['clusterOptimizationProjectionReportId'] = cluster_optimization_report_id

    params['pageSize'] = page_size
    params['start'] = page_start
    if page_order_by is not None:
        params['orderBy'] = page_order_by
    if page_order_dir is not None:
        params['orderDir'] = page_order_dir

    request = api.GetRequest(
        f'/api/cluster/optimization/cost/{account_id}/{workload_optimization_report_id}',
        params=params,
    )
    response = api.do_get(request)
    if response['status'] != 'OK' or response['result'] is None:
        log(f"Failed to get opportunities: {response['message']}")
        return None

    log("Successfully got workload opportunities")

    recommendations_obj = response['result']
    page_obj = response['page']

    recommendations = []
    for recommendation_obj in recommendations_obj['content']:
        original_config = recommendation_obj['currResourceConfigState']
        recommended_config = recommendation_obj['recommendedResourceConfigState']
        recommendation = _get_resource_optimization_from_opt_obj(
            recommendation_obj, original_config, recommended_config
        )
        recommendations.append(recommendation)

    result = dict()
    result['recommendations'] = recommendations
    result['page'] = transform(page_obj, __PAGINATION_FIELDS)
    return transform(result)


def get_cluster_opportunities(
    cluster_id: str,
    optimization_targets: List[str] = None,
) -> ClusterOpportunity:
    """
    Returns details of available optimization opportunities for a cluster.
    :param cluster_id: ID of the cluster to retrieve opportunities for.
    :param optimization_targets: Optimization targets to consider. Possible options are `NODE`, `WORK_LOAD` and `PURCHASE_OPTION`.
    :return: Details of potential optimization opportunities for the given cluster.
    """
    cluster_opp_summary = get_opportunities('cluster', cluster_id)
    if not cluster_opp_summary or len(cluster_opp_summary['content']) == 0:
        log(f"No opportunities for cluster {cluster_id}")
        return None
    cluster_type = cluster_opp_summary['content'][0]['clusterType']
    account_id = cluster_opp_summary['content'][0]['accountId']
    cluster_name = cluster_opp_summary['content'][0]['name']

    params = dict()
    params['clusterId'] = cluster_id
    params['type'] = cluster_type
    if optimization_targets is not None and len(optimization_targets) > 0:
        params['target'] = optimization_targets

    request = api.GetRequest(
        f'/api/cluster/optimization/cost/{account_id}', params=params, doseq=True
    )

    response = api.do_get(request)
    if response['status'] != 'OK' or response['result'] is None:
        log(f"Failed to get opportunities: {response['message']}")
        return None

    log(f"Successfully retrieved opportunities for cluster {cluster_id}")
    opportunities_obj = response['result']

    if opportunities_obj['optimizationRecommendations'] is None:
        log(f"No optimizations available for cluster: {cluster_id}")
        return None

    cluster_opp = ClusterOpportunity(opportunities_obj)
    cluster_opp.account_id = account_id
    cluster_opp.resource_name = cluster_name

    # populate workload optimizations
    params = dict()
    params['clusterOptimizationProjectionReportId'] = cluster_opp.report_id
    endpoint = f'/api/cluster/optimization/cost/{account_id}/{cluster_opp.workload_optimization_id}'

    wl_optimizations = []
    for opts_page in __get_paginated_response(endpoint, params):
        for wl_opt_obj in opts_page:
            original_resource_state = wl_opt_obj['currResourceConfigState']
            recommended_resource_state = wl_opt_obj['recommendedResourceConfigState']
            wl_optimization = _get_resource_optimization_from_opt_obj(
                wl_opt_obj, original_resource_state, recommended_resource_state
            )
            wl_optimizations.append(wl_optimization)
    cluster_opp.workload_optimizations = wl_optimizations
    return cluster_opp


def get_resource_optimizations(
    account_id: str = None,
    resource_id: str = None,
    starttime: datetime = None,
    endtime: datetime = None,
    sort_by: str = None,
    sort_dir: str = None,
) -> List[ResourceOptimization]:
    """
    Get details of completed optimizations.
    :param account_id: Optional account ID to query for optimizations recommended
     for the given account.
    :param resource_id: Optional resource ID to query for optimizations recommended
     for the given resource.
    :param starttime: Retrieve optimizations performed after the given starttime.
    :param endtime: Retrieve optimizations performed before the given endtime.
    :param sort_by: Attribute to sort the retrieved optimizations by. Possible options are
        - `optimization_time`: The time at which the optimization was performed.
        - `cpu_change_core`: Change in CPU cores.
        - `cpu_change_vcpu`: Change in VCPUs.
        - `memory_change_mib`: Change in memory in MiBs.
        - `storage_change_gib`: Change in storage size in GiBs.
    :param sort_dir: Sort direction for retrieving optimizations. Possible options are `ASC` and `DESC`.
    """

    params = dict()
    if starttime:
        starttime_epoch_ms = starttime.timestamp() * 1000
        params['startTime'] = int(round(starttime_epoch_ms))
    if endtime:
        endtime_epoch_ms = endtime.timestamp() * 1000
        params['endTime'] = int(round(endtime_epoch_ms))
    if resource_id:
        params['resourceId'] = resource_id
    if account_id:
        params['accountId'] = account_id

    ORDER_BY_ATTRIBUTES = dict()
    ORDER_BY_ATTRIBUTES['optimization_time'] = 'post_release_time'
    ORDER_BY_ATTRIBUTES['cpu_change_core'] = 'cpu_change_core'
    ORDER_BY_ATTRIBUTES['cpu_change_vcpu'] = 'cpu_change_vcpu'
    ORDER_BY_ATTRIBUTES['memory_change_mib'] = 'memory_change_mib'
    ORDER_BY_ATTRIBUTES['storage_change_gib'] = 'storage_change_gib'

    if sort_by is not None:
        if sort_by not in ORDER_BY_ATTRIBUTES:
            raise ValueError(f"Invalid order_by attribute {sort_by}")

        sort_by = ORDER_BY_ATTRIBUTES[sort_by]

    endpoint = '/api/cumulative/report/optimizations/details'
    optimizations = list()

    for optimizations_page in __get_paginated_response(
        endpoint, params, order_by=sort_by, order_dir=sort_dir
    ):
        for optimization_obj in optimizations_page:
            original_config = optimization_obj['preConfigState']
            recommended_config = optimization_obj['postConfigState']
            recommendation = _get_resource_optimization_from_opt_obj(
                optimization_obj, original_config, recommended_config
            )
            optimizations.append(recommendation)

    return optimizations


def get_recommended_resource_state(resource_id: str) -> SimpleNamespace:
    """
    Get the latest available recommended state for a given resource.
    This is the state that Sedai automatically syncs resources to if Sedai Sync is enabled for that resource.
    :param resource_id: ID of the resource to retrieve the recommended state for.
    :return: The latest recommended resource state if available.
    """
    request = api.GetRequest(
        '/api/site/sedaisync/proposedconfig', params={"resourceId": resource_id}
    )
    response = api.do_get(request)

    if response['status'] != 'OK':
        log(f"Failed to get latest proposed sync state: {response['message']}")
        return None
    else:
        return transform(response['result'])


def _get_resource_optimization_from_opt_obj(
    opt_obj: Dict, original_config: Dict, recommended_config: Dict
) -> ResourceOptimization:
    resource_name = opt_obj['resourceName']
    resource_id = opt_obj['resourceId']
    account_id = opt_obj['accountId']
    config_type = original_config['type']
    optimization_time = None
    if 'optimizationTime' in opt_obj:
        optimization_time = (
            datetime.fromtimestamp(opt_obj['optimizationTime'] / 1000.0)
            if opt_obj['optimizationTime'] is not None
            else None
        )

    if config_type == "KubeResourceConfigState":
        optimization = KubeResourceOptimization(
            resource_name=resource_name,
            resource_id=resource_id,
            account_id=account_id,
            original_config=original_config,
            recommended_config=recommended_config,
            optimization_time=optimization_time,
        )
    else:
        optimization = ResourceOptimization(
            resource_name=resource_name,
            resource_id=resource_id,
            account_id=account_id,
            optimization_time=optimization_time,
        )
        optimization.original_resource_config = transform(original_config)
        optimization.recommended_resource_config = transform(recommended_config)

    return optimization
