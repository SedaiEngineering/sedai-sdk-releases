import json
from typing import Iterable


class GraphQLRequest:
    def __init__(self, query, fields):
        self.query = query
        self.fields = fields


class GraphQLQuery:
    pass


class GraphQLFuncQuery(GraphQLQuery):
    def __init__(self, fields: Iterable[str], func: str, params: dict = None):
        self.fields = fields
        self.func = func
        self.params = params

    def __query(self) -> str:

        _fields = "\n ".join(self.fields)
        _fields = f"nodes {{  {_fields}  }}"

        if self.params:
            _params = ", ".join(
                [f"{k}: \"{v}\"" if isinstance(v, str) else f"{k}: {v}" for k, v in self.params.items()])

            query_tmpl = """
            query {
                %s(%s) {
                    %s
                }
            }
            """
            return query_tmpl % (self.func, _params, _fields)
        else:
            query_tmpl = """
            query {
                %s {
                    %s
                }
            }
            """
            return query_tmpl % (self.func, _fields)

    def __str__(self) -> str:
        __base_query = self.__query()
        query = {"query": __base_query}
        return json.dumps(query, indent=4)
