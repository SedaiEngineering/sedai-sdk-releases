from json import JSONEncoder
from types import SimpleNamespace


def transform(obj, keys=None):
    if keys is None:
        return _to_SimpleNamespace(obj)
    else:
        key_map = __nest_keys(keys)
        model = __transform(obj, key_map)
        model = _to_SimpleNamespace(model)
        return model


# From https://stackoverflow.com/a/72778143
def _to_SimpleNamespace(d):
    if isinstance(d, SimpleNamespace):
        # TODO : We may still need to convert the fields inside the SimpleNamespace to SimpleNamespace
        return d

    # If d is a list, apply __to_model to each element of the list
    if isinstance(d, list):
        return [_to_SimpleNamespace(x) for x in d]
    # if d is a  simple type, return it
    if not isinstance(d, dict):
        return d
    # If d is a dict, apply __to_model to each value of the dict
    x = SimpleNamespace()
    _ = [setattr(x, k,
                 _to_SimpleNamespace(v) if isinstance(v, dict)
                 else [_to_SimpleNamespace(e) for e in v] if isinstance(v, list)
                 else v) for k, v in d.items()]
    return x


def _SimpleNamespace_to_dict(d):
    # If d is a list, apply __to_model to each element of the list
    if isinstance(d, list):
        return [_SimpleNamespace_to_dict(x) for x in d]
    # if d is a  simple type, return it
    if not isinstance(d, SimpleNamespace):
        return d
    # If d is a dict, apply __to_model to each value of the dict
    x = {}
    for k, v in d.__dict__.items():
        if isinstance(v, SimpleNamespace):
            x[k] = _SimpleNamespace_to_dict(v)
        elif isinstance(v, list):
            x[k] = [_SimpleNamespace_to_dict(e) for e in v]
        else:
            x[k] = v
    return x


def __nest_keys(keys):
    nested = {}
    for key in keys:
        parts = key.split('.')
        if len(parts) == 1:
            nested[key] = None
        else:
            key = parts[0]
            value = __nest_keys(['.'.join(parts[1:])])
            if key in nested:
                nested[key].update(value)
            else:
                nested[key] = value
    return nested


def __transform(obj, key_map):
    if type(obj) is list:
        for item in obj:
            __transform(item, key_map)
    elif type(obj) is dict:
        # remove all keys that are not in the key_map
        for key in list(obj.keys()):
            if key not in key_map:
                del obj[key]
            else:
                __transform(obj[key], key_map[key])

    return obj


class __nsEncoder(JSONEncoder):
    def default(self, obj):
        if isinstance(obj, SimpleNamespace):
            return obj.__dict__
        return super(__nsEncoder, self).default(obj)


class __model_list(list):
    pass
