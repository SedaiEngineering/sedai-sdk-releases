from setuptools import setup

setup(
    name='sedai-sdk',
    version='1.3.4',
    packages=[
        'sedai',
        'sedai.optimizations',
        'sedai.__impl',
        'sedai.__impl.jsonpath',
        'sedai.__impl.urllib3',
        'sedai.__impl.urllib3.contrib',
        'sedai.__impl.urllib3.util',
    ],
    install_requires=[
        # List your dependencies here
    ],
)
