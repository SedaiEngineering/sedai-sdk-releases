from datetime import datetime

from sedai.__impl import api
from sedai.__impl.model_converter import transform


def _to_epoch_ms(value) -> int:
    """Convert a datetime object or epoch ms integer to epoch milliseconds."""
    if isinstance(value, datetime):
        return int(value.timestamp() * 1000)
    return int(value)


def get_onboarded_resources_count():
    """
    Get the count of onboarded resources.

    :return: Count of onboarded resources
    """
    request = api.GetRequest('/api/autonomousoverview/onboardedResources/count')
    response = api.do_get(request)
    return transform(response)


def get_observing_resources_count(start_time, end_time):
    """
    Get the count of observing resources within a time range.

    :param start_time: Start time as a datetime object or epoch milliseconds (int)
    :param end_time: End time as a datetime object or epoch milliseconds (int)
    :return: Count of observing resources
    """
    params = {
        'startTime': _to_epoch_ms(start_time),
        'endTime': _to_epoch_ms(end_time),
    }
    request = api.GetRequest('/api/autonomousoverview/observingResources/count', params=params)
    response = api.do_get(request)
    return transform(response)


def get_exporter_scrape_api_count(start_time, end_time):
    """
    Get exporter scrape API call count time series within a time range.

    :param start_time: Start time as a datetime object or epoch milliseconds (int)
    :param end_time: End time as a datetime object or epoch milliseconds (int)
    :return: Time series data for scrape API call count
    """
    params = {
        'startTime': _to_epoch_ms(start_time),
        'endTime': _to_epoch_ms(end_time),
    }
    request = api.GetRequest('/api/autonomousoverview/exporter/scrape/api/count', params=params)
    response = api.do_get(request)
    return transform(response)


def get_onboard():
    """
    Get onboard information from the autonomous overview.

    :return: Onboard data as SimpleNamespace objects
    """
    request = api.GetRequest('/api/autonomousoverview/onboard')
    response = api.do_get(request)
    return transform(response)


def get_enabled_metrics_count(target="global", account_ids=None):
    """
    Get the count of enabled and total metrics.

    Pages through all metrics settings results and counts metrics
    where shouldMonitor is true (enabled) vs total.

    :param target: Target scope for metrics (default: "global")
    :param account_ids: Optional list of account IDs to filter by
    :return: Tuple of (enabled_count, total_count)
    """
    page_size = 50
    page_number = 0
    enabled_count = 0
    total_count = 0

    while True:
        params = {
            'target': target,
            'limitCount': page_size,
            'offsetCount': page_number,
        }
        if account_ids:
            params['accountIds'] = ','.join(account_ids)
        request = api.GetRequest('/api/monitoring/metrics/settings/ui/paged', params=params)
        response = api.do_get(request)
        results = response.get('result', [])

        total_count += len(results)
        for item in results:
            if item.get('shouldMonitor') is True:
                enabled_count += 1

        if len(results) < page_size:
            break
        page_number += 1

    return enabled_count, total_count
