from datetime import datetime, timezone
from typing import List, Optional


class JobHealth:
    job_id: Optional[str]
    job_status: Optional[str]
    is_healthy: Optional[bool]
    last_refreshed_on: Optional[datetime]
    health_check_time: Optional[datetime]
    last_healthy_on: Optional[datetime]
    message: Optional[str]

    def __init__(
            self,
            job_id: Optional[str] = None,
            job_status: Optional[str] = None,
            is_healthy: Optional[bool] = None,
            last_refreshed_on: Optional[datetime] = None,
            health_check_time: Optional[datetime] = None,
            last_healthy_on: Optional[datetime] = None,
            message: Optional[str] = None,
    ):
        self.job_id = job_id
        self.job_status = job_status
        self.is_healthy = is_healthy
        self.last_refreshed_on = last_refreshed_on
        self.health_check_time = health_check_time
        self.last_healthy_on = last_healthy_on
        self.message = message

    @classmethod
    def from_api_response(cls, data: dict) -> "JobHealth":
        return cls(
            job_id=data.get("jobId"),
            job_status=data.get("jobStatus"),
            is_healthy=data.get("healthy"),
            last_refreshed_on=(
                datetime.fromtimestamp(data.get("lastRefreshedOn"), tz=timezone.utc)
                if data.get("lastRefreshedOn") is not None
                else None
            ),
            health_check_time=(
                datetime.fromtimestamp(data.get("healthCheckTime"), tz=timezone.utc)
                if data.get("healthCheckTime") is not None
                else None
            ),
            last_healthy_on=(
                datetime.fromtimestamp(data.get("lastHealthyOn"), tz=timezone.utc)
                if data.get("lastHealthyOn") is not None
                else None
            ),
            message=data.get("message"),
        )


class MessageStats:
    """
        Details of message stats.
    """

    action: Optional[str]
    average_execution_time_millis: Optional[int]
    total_executions: Optional[int]
    successful_executions: Optional[int]
    failed_executions: Optional[int]

    def __init__(
            self,
            action: Optional[str] = None,
            average_execution_time_millis: Optional[int] = None,
            total_executions: Optional[int] = None,
            successful_executions: Optional[int] = None,
            failed_executions: Optional[int] = None,
    ):
        self.action = action
        self.average_execution_time_millis = average_execution_time_millis
        self.total_executions = total_executions
        self.successful_executions = successful_executions
        self.failed_executions = failed_executions


    @classmethod
    def message_stats_from_response(cls, data: dict) -> "MessageStats":
        return cls(
            action=data.get("commandAction"),
            average_execution_time_millis=data.get("averageExecutionTimeMillis"),
            total_executions=data.get("totalExecutions"),
            successful_executions=data.get("successfulExecutions"),
            failed_executions=data.get("failedExecutions"),
        )


class SmartAgentHealth:
    """
    Details of smart agents.
    """
    account_id: Optional[str]
    account_name: Optional[str]
    is_healthy: Optional[bool]
    is_agent_available: Optional[bool]
    live_connection_status: Optional[bool]
    connection_type: Optional[str]
    version: Optional[str]
    desired_version: Optional[str]
    last_supported_version: Optional[str]
    upgrade_needed: Optional[bool]
    spec_controller_version: Optional[str]
    latest_health_check_time: Optional[datetime]
    job_health_list: Optional[List[JobHealth]]
    message_stats: Optional[List[MessageStats]] = None

    def __init__(
            self,
            account_id: Optional[str] = None,
            account_name: Optional[str] = None,
            is_healthy: Optional[bool] = None,
            is_agent_available: Optional[bool] = None,
            live_connection_status: Optional[bool] = None,
            connection_type: Optional[str] = None,
            version: Optional[str] = None,
            desired_version: Optional[str] = None,
            last_supported_version: Optional[str] = None,
            upgrade_needed: Optional[bool] = None,
            spec_controller_version: Optional[str] = None,
            latest_health_check_time: Optional[datetime] = None,
            job_health_list: Optional[List[JobHealth]] = None,
            message_stats: Optional[List[MessageStats]] = None,
    ):
        self.account_id = account_id
        self.account_name = account_name
        self.is_healthy = is_healthy
        self.is_agent_available = is_agent_available
        self.live_connection_status = live_connection_status
        self.connection_type = connection_type
        self.version = version
        self.desired_version = desired_version
        self.last_supported_version = last_supported_version
        self.upgrade_needed = upgrade_needed
        self.spec_controller_version = spec_controller_version
        self.latest_health_check_time = latest_health_check_time
        self.job_health_list = job_health_list
        self.message_stats = message_stats


    @classmethod
    def health_info_from_response(cls, data: dict) -> "SmartAgentHealth":
        details_data = data.get("details") or {}
        job_list = details_data.get("jobHealthList") or []

        jobs = [
            JobHealth.from_api_response(job)
            for job in job_list
            if isinstance(job, dict)
        ]

        return cls(
            account_id=data.get("accountId"),
            account_name=data.get("accountName"),
            is_healthy=data.get("healthy"),
            is_agent_available=data.get("agentAvailable"),
            live_connection_status=data.get("liveConnectionStatus"),
            connection_type=data.get("connectionType"),
            version=data.get("version"),
            desired_version=data.get("desiredVersion"),
            last_supported_version=data.get("lastSupportedVersion"),
            upgrade_needed=data.get("upgradeNeeded"),
            spec_controller_version=data.get("specControllerVersion"),
            latest_health_check_time=(
                datetime.fromtimestamp(details_data.get("latestHealthCheckTime"), tz=timezone.utc)
                if details_data.get("latestHealthCheckTime") is not None
                else None
            ),
            job_health_list= jobs,
            message_stats=None
        )
