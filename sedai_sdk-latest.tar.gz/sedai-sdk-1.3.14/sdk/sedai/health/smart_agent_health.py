from sedai.__impl import api, log
from sedai.health.models import SmartAgentHealth, MessageStats


def get_agent_message_stats(account_id, duration):
    """
    Retrieve agent health statistics for a particular agent

    :param account_id: The ID of the smart agent (str)
    :type account_id: str
    :param duration: The duration of message stats (Expected ISO-8601 duration format) (str)
    :type duration: str
    :return: List of message stats objects.
    :rtype: List[MessageStats] or empty list

    Each item in the response is represented as a ``MessageStats`` object
    with the following fields:

    - **action** (str) – Action type
    - **average_execution_time_millis** (int) – Average execution time in milliseconds
    - **total_executions** (int) – Total number of executions
    - **successful_executions** (int) – Total number of successful executions
    - **failed_executions** (int) – Total number of failed executions

    Output:
    .. code-block:: python

         [
            MessageStats(
                action='Action_name',
                average_execution_time_millis=53091,
                total_executions=8,
                successful_executions=8,
                failed_executions=0
                )
        ]


    """
    request = api.GetRequest('/api/agent/message/stats/' + account_id + '/duration/' + duration)
    response = api.do_get(request)

    if response['status'] != 'OK':
        log(f"Failed to get agent message stats: {response['message']}")
        return []

    response_data = response['result']

    if not isinstance(response_data, list):
        return []

    message_stats: list[MessageStats] = [
        MessageStats.message_stats_from_response(message_stat)
        for message_stat in response_data
        if isinstance(message_stat, dict)
    ]
    return message_stats


def get_health_info():
    """
    Retrieve health information for all smart agents.

    :return: List of smart agent health objects
    :rtype: List[SmartAgentHealth] or empty list

    Each item in the response is represented as a ``SmartAgentHealth`` object
    with the following fields:

    - **account_id** (str) – The ID of the smart agent account
    - **account_name** (str) – Account name
    - **is_healthy** (bool) – Whether the agent is healthy
    - **is_agent_available** (bool) – Whether the agent is available
    - **live_connection_status** (bool) – Live connection status
    - **connection_type** (str) – Type of connection
    - **version** (str) – Current agent version
    - **desired_version** (str) – Desired agent version
    - **upgrade_needed** (bool) – Whether an upgrade is required
    - **last_supported_version** (str) – Last supported agent version
    - **spec_controller_version** (str) – Spec controller version
    - **latest_health_check_time** (datetime) – Last health check time
    - **job_health_list** (List[JobHealth]) - Health details of individual jobs
    - **message_stats** (List[MessageStats]) - Additional details of smart agent

    ``JobHealth`` contains:
    - **job_id** (str) – Job identifier
    - **job_status** (str) – Job execution status
    - **is_healthy** (bool) – Whether the job is healthy
    - **message** (str) – Status message
    - **last_refreshed_on** (datetime) - Last refreshed time
    - **health_check_time** (datetime) - Last health check time
    - **last_healthy_on** (datetime) - Last healthy on time

    ``MessageStats`` contains:
    - **action** (str) – Action type
    - **average_execution_time_millis** (int) – Average execution time in milliseconds
    - **total_executions** (int) – Total number of executions
    - **successful_executions** (int) – Total number of successful executions
    - **failed_executions** (int) – Total number of failed executions

    All datetime fields are in UTC


    Output:
    .. code-block:: python

         [
            SmartAgentHealth(
                account_id='yxvo2has',
                account_name='labs2-executable-windows-testing',
                is_healthy=True,
                is_agent_available=True,
                live_connection_status=True,
                connection_type='REST',
                version='v1.2.3',
                desired_version='v1.2.4',
                last_supported_version='v1.1.0',
                upgrade_needed=False,
                spec_controller_version='v1.0.0',
                latest_health_check_time=datetime.datetime(2026, 2, 10, 18, 16, 0, 359760),
                job_health_list=[
                    JobHealth(
                        job_id='AGENT_HEARTBEAT',
                        job_status='COMPLETED',
                        is_healthy=True,
                        last_refreshed_on=datetime.datetime(2026, 2, 10, 18, 13, 27, 667091),
                        health_check_time=datetime.datetime(2026, 2, 10, 18, 16, 0, 359753),
                        last_healthy_on=datetime.datetime(2026, 2, 10, 18, 16, 0, 359754),
                        message='Success',
                    )
                ],
                message_stats=[
                    MessageStats(
                        action='DISCOVER_KARPENTER',
                        average_execution_time_millis=62544,
                        total_executions=8,
                        successful_executions=8,
                        failed_executions=0,
                    )
                ]
            )
        ]

    """
    request = api.GetRequest('/api/health/agents')
    response = api.do_get(request)

    if response['status'] != 'OK':
        log(f"Failed to get smart agent info: {response['message']}")
        return []

    log("Successfully got sedai health info")
    response_data = response['result']

    if not isinstance(response_data, list):
        return []

    agents: list[SmartAgentHealth] = []

    for agent_data in response_data:
        agent = SmartAgentHealth.health_info_from_response(agent_data)

        if agent.account_id:
            agent.message_stats = get_agent_message_stats(agent.account_id, 'PT8H')
        agents.append(agent)

    return agents
