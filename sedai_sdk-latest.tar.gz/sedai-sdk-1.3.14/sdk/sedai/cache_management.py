from sedai.__impl import api
from sedai.__impl.model_converter import transform


def get_caches():
    """
    Get all caches from the system cache management.

    :return: List of caches as SimpleNamespace objects
    """
    request = api.GetRequest('/api/system/cache-management/caches')
    response = api.do_get(request)
    return transform(response)
