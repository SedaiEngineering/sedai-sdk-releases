from typing import List, Optional

from sedai.__impl import api, log

def get_prohibited_namespaces() -> Optional[List[str]]:
    """
    Retrieve the list of prohibited namespaces

    :return: List of prohibited namespaces or None if request fails
    :rtype: Optional[List[str]]

    Output:
    .. code-block:: json

            [
             "namespace1",
             "namespace2"
            ]

    """
    request = api.GetRequest('/api/configs/prohibitedNamespace')
    response = api.do_get(request)
    if response['status'] != 'OK':
        log(f"Failed to get prohibited namespaces: {response['message']}")
        return None
    else:
        log("Successfully retrieved prohibited namespaces")
        return response.get('result', [])


def add_prohibited_namespaces(namespaces: List[str]) -> Optional[List[str]]:
    """
    Add namespaces to the prohibited namespace list.

    :param namespaces: List of namespaces to add
    :type namespaces: List[str]
    :return: Updated list of prohibited namespaces or None if request fails
    :rtype: Optional[List[str]]

    Output:
    .. code-block:: json

            [
             "namespace1",
             "namespace2"
            ]

    """

    request = api.PostRequest(
        '/api/configs/prohibitedNamespace',
        payload=namespaces
    )

    response = api.do_post(request)

    if response['status'] != 'OK':
        log(f"Failed to add prohibited namespaces: {response['message']}")
        return None

    log("Successfully added prohibited namespaces")
    return response.get('result', [])


def delete_prohibited_namespaces(namespaces: List[str]) -> Optional[List[str]]:
    """
    Delete namespaces from the prohibited namespace list.

    Core/default namespaces cannot be deleted.

    :param namespaces: List of namespaces to delete
    :type namespaces: List[str]
    :return: Updated list of prohibited namespaces or None if request fails
    :rtype: Optional[List[str]]

    Output:
    .. code-block:: json

            [
             "namespace1",
             "namespace2"
            ]

    """

    request = api.DeleteRequest(
        '/api/configs/prohibitedNamespace',
        payload=namespaces
    )

    response = api.do_delete(request)

    if response['status'] != 'OK':
        log(f"Failed to delete prohibited namespaces: {response['message']}")
        return None

    log(response.get('message', "Successfully deleted prohibited namespaces"))
    return response.get('result', [])