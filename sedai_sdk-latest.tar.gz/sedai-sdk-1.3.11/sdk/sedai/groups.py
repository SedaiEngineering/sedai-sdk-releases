import json

from sedai import models
from sedai.__impl import api, log, graphql
from sedai.__impl.model_converter import transform
from sedai.util import __add_created, __add_modified

__group__fields = [
    "name",
    "id"]

_group_grapql_fields = ["definition", "groupId", "name", "awsLbCount", "awsTagsCount", "azureLbCount", "azureTagsCount",
                        "azureVmCount", "ebsCount", "ec2Count", "ecsCount", "kubeCount", "lambdaCount", "s3Count",
                        "streamingCount", ]


########################################################################################################################
# GroupDefinition
########################################################################################################################

class GroupDefinition:
    __resource_types = ["AWS_EBS", "AWS_EC2", "AWS_ECS", "AWS_LAMBDA", "AWS_S3", "AWS_TAGS", "AZURE_LB", "AZURE_VM",
                        "KUBERNETES_CRONJOB", "KUBERNETES_DEAMONSET", "KUBERNETES_DEPLOYMENT", "KUBERNETES_STATEFULSET"]

    name: str
    """@private"""
    tags: list
    """@private"""
    cluster: list
    """@private"""
    cloud: list
    """@private"""
    resourceType: list
    """@private"""
    manuallyAddedResources: list
    """@private"""
    region: list
    """@private"""
    namespace: list
    """@private"""
    autoRefresh: bool
    """@private"""
    parentGroupId: str
    """@private"""
    createdOn: int
    """@private"""
    createdBy: str
    """@private"""
    modifiedOn: int
    """@private"""
    modifiedBy: str
    """@private"""


    def __init__(self, name):
        """
        This class represents a group definition in Sedai. A group definition is used to define a group of resources
        This  class is used to create and update groups in Sedai .
        Initialize a new group definition with the given name"""

        self.name = name
        self.tags = []
        self.cluster = []
        self.cloud = []
        self.resourceType = []
        self.manuallyAddedResources = []
        self.region = []
        self.namespace = []
        self.autoRefresh = False
        self.parentGroupId = None

    @classmethod
    def from_definition(cls, definition):
        """
        Create a new GroupDefinition by copying an existing definition
        """
        obj = cls(definition.name)
        obj.tags = definition.tags or []
        obj.cluster = definition.cluster or []
        obj.cloud = definition.cloud or []
        obj.resourceType = definition.resourceType or []
        obj.manuallyAddedResources = definition.manuallyAddedResources or []
        obj.region = definition.region or []
        obj.namespace = definition.namespace or []
        obj.autoRefresh = definition.autoRefresh or False
        obj.parentGroupId = definition.parentGroupId or None
        return obj

    @staticmethod
    def from_json(json_data):
        """@private"""

        group = GroupDefinition(json_data['name'])
        group.tags = json_data['tags']
        group.cluster = json_data['cluster']
        group.cloud = json_data['cloud']
        group.resourceType = json_data['resourceType']
        group.manuallyAddedResources = json_data['manuallyAddedResources']
        group.region = json_data['region']
        group.namespace = json_data['namespace']
        group.autoRefresh = bool(json_data['autoRefresh'])
        group.parentGroupId = json_data['parentGroupId']
        group.createdOn = json_data['createdOn']
        group.createdBy = json_data['createdBy']
        group.modifiedOn = json_data['modifiedOn']
        group.modifiedBy = json_data['modifiedBy']
        return group

    def to_json(self):
        """@private"""

        return json.dumps(self.__dict__)

    def set_name(self, name):
        """
        Set the name of the group
        :param name:
        :return:
        """
        self.name = name

    def get_name(self):
        """
        Get the name of the group
        :return:  The name of the group
        """
        return self.name

    def set_auto_refresh(self, auto_refresh: bool):
        """
        Set the auto refresh of the group. Default is False
        :param auto_refresh:
        """
        self.autoRefresh = auto_refresh

    def get_auto_refresh(self):
        """
        Get the auto refresh setting of the group.
        When a resource is set to auto refresh, Sedai will frequently check for new resources that match the group's
        constraints and add them to the group. It will also remove resources that no longer match the constraints.
        :return:
        """
        return self.autoRefresh

    def set_parent_group_id(self, parent_group_id):
        """
        Set the parentGroupId of the group
        :param parent_group_id:
        :return:
        """
        self.parentGroupId = parent_group_id

    def get_parent_group_id(self):
        """
        Get the parentGroupId of the group
        :return:  The parentGroupId of the group
        """
        return self.parentGroupId

    def add_tag(self, key, value):
        """
        Add a tag to the group definition. The tags are used to filter resources that are added to the group.
        :param key: The tag key
        :param value: The tag value
        :return: None
        """
        # Find the entry with the key if it exists.
        entry = next((tag for tag in self.tags if tag['key'] == key), None)
        if not entry:
            # Create and add a new entry if it does not exist.
            entry = {'key': key, 'regex': [], 'exact': []}
            self.tags.append(entry)

        # Update the entry with the value.
        if '*' in value:
            entry['regex'].append(value)
            # Remove duplicates
            entry['regex'] = list(set(entry['regex']))
        else:
            entry['exact'].append(value)
            # Remove duplicates
            entry['exact'] = list(set(entry['exact']))

    def remove_tag(self, key, value=None):
        """
        Remove a tag from the group definition.
        :param key: The tag key
        :param value: The tag value to remove. If not provided, the entire tag is removed.
        :return:
        """
        # Find the entry with the key if it exists.
        entry = next((tag for tag in self.tags if tag['key'] == key), None)
        if entry:
            if value:
                # Remove the value from the entry.
                if '*' in value and value in entry['regex']:
                    entry['regex'].remove(value)
                elif value in entry['exact']:
                    entry['exact'].remove(value)
            else:
                # Remove the entry if no value is provided.
                self.tags.remove(entry)

    def add_cluster(self, cluster_id=None, cluster_name=None):
        """
        Add a cluster identified by the cluster ID or name to the group definition.
        :param cluster_id: The ID of the cluster to add. This is the fully qualified name of the cluster,
         such as the ARN of an AWS cluster
        :param cluster_name: The name of the cluster to add. Either the cluster name or the cluster ID must
         be provided.
        :return: None
        """

        if cluster_id is None and cluster_name is None:
            raise ValueError("Either cluster id or name must be provided")

        if cluster_id is None:
            fields = ['clusterId', 'clusterName']
            func = 'countPerCluster'

            params = dict()
            params['searchtext'] = f"%{cluster_name}%"
            params['first'] = 1
            params['offset'] = 0
            query_obj = graphql.GraphQLFuncQuery(fields, func, params)
            query_str = str(query_obj)
            request = api.PostRequest('/api/graphql', query_str)
            response = api.do_post(request)
            if (
                response['data'] is None
                or response['data']['countPerCluster'] is None
                or response['data']['countPerCluster']['nodes'] is None
                or len(response['data']['countPerCluster']['nodes']) == 0
            ):
                raise Exception(f"Cluster with name {cluster_name} not found")

            cluster_id = response['data']['countPerCluster']['nodes'][0]['clusterId']

        # Add to the cluster list and remove duplicates
        self.cluster.append(cluster_id)
        self.cluster = list(set(self.cluster))

    def remove_cluster(self, cluster_id: str = None, cluster_name: str = None):
        """
        Remove a cluster identified by the cluster id of cluster name from the group definition
        :param cluster_id: The id of the cluster to remove.
        :param cluster_name: The name of the cluster to remove.
         Either the cluster name or id must be provided.
        :return: None
        """
        if cluster_id is None and cluster_name is None:
            raise ValueError("Either cluster id or name must be provided")

        if cluster_id is None:
            fields = ['clusterId', 'clusterName']
            func = 'countPerCluster'

            params = dict()
            params['searchtext'] = f"%{cluster_name}%"
            params['first'] = 1
            params['offset'] = 0
            query_obj = graphql.GraphQLFuncQuery(fields, func, params)
            query_str = str(query_obj)
            request = api.PostRequest('/api/graphql', query_str)
            response = api.do_post(request)
            if (
                response['data'] is None
                or response['data']['countPerCluster'] is None
                or response['data']['countPerCluster']['nodes'] is None
                or len(response['data']['countPerCluster']['nodes']) == 0
            ):
                raise Exception(f"Cluster with name {cluster_name} not found")

            cluster_id = response['data']['countPerCluster']['nodes'][0]['clusterId']

        if cluster_id in self.cluster:
            self.cluster.remove(cluster_id)

    def add_region(self, region):
        """
        Add a region to the group definition
        :param region: The region to add
        :return: None
        """
        # Add to the region list and remove duplicates
        self.region.append(region)
        self.region = list(set(self.region))

    def remove_region(self, region):
        """
        Remove a region from the group definition
        :param region: The region to remove
        :return: None
        """
        if region in self.region:
            self.region.remove(region)

    def add_namespace(self, namespace):
        """
        Add a namespace to the group definition
        :param namespace: The namespace to add
        :return: None
        """
        # Add to the namespace list and remove duplicates
        self.namespace.append(namespace)
        self.namespace = list(set(self.namespace))

    def remove_namespace(self, namespace):
        """
        Remove a namespace from the group definition
        :param namespace: The namespace to remove
        :return: None
        """
        if namespace in self.namespace:
            self.namespace.remove(namespace)

    def add_account_id(self, account_id):
        """
        Add an account_id to the group definition
        :param account_id: The account_id to add
        :return: None
        """
        # Add to the cloud list and remove duplicates
        self.cloud.append(account_id)
        self.cloud = list(set(self.cloud))

    def remove_account_id(self, account_id):
        """
        Remove an account_id from the group definition
        :param account_id: The account_id to remove
        :return: None
        """
        if account_id in self.cloud:
            self.cloud.remove(account_id)

    def add_resource_type(self, resource_type):
        """
        Add a resource type to the group definition
        :param resource_type: The resource type to add
        :return: None
        """
        if resource_type in self.__resource_types:
            # Add to the resource type list and remove duplicates
            self.resourceType.append(resource_type)
            self.resourceType = list(set(self.resourceType))
        else:
            log(f"Invalid resource type: {resource_type}")

    def remove_resource_type(self, resource_type):
        """
        Remove a resource type from the group definition
        :param resource_type: The resource type to remove
        :return: None
        """
        if resource_type in self.resourceType:
            self.resourceType.remove(resource_type)

    def add_resource_id(self, resource_id):
        """
        Add a resource id to the group definition
        :param resource_id: The resource id to add
        :return: None
        """
        # Add to the resource id list and remove duplicates
        self.manuallyAddedResources.append(resource_id)
        self.manuallyAddedResources = list(set(self.manuallyAddedResources))

    def remove_resource_id(self, resource_id):
        """
        Remove a resource id from the group definition
        :param resource_id: The resource id to remove
        :return: None
        """
        if resource_id in self.manuallyAddedResources:
            self.manuallyAddedResources.remove(resource_id)

    def __str__(self):
        return f"GroupDefinition(name={self.name}, tags={self.tags}, cluster={self.cluster}, region={self.region}, " \
               f"namespace={self.namespace}, autoRefresh={self.autoRefresh}) "

    def __repr__(self):
        return self.__str__

class Group:
    """
    Must contain:
      - groupId: str
      - name: str
      - definition: GroupDefinition (or object with .to_json())
    """

    def __init__(self, groupId: str, name: str, definition: GroupDefinition):
        self.groupId = groupId
        self.name = name
        self.definition = definition

########################################################################################################################
# Group Operations
########################################################################################################################

def get_all_groups():
    """
    Get all groups that are integrated with Sedai
    :return: A list of groups
    Each entry is an object with the following fields:

    - **id** - the group id in within Sedai
    - **name** - the name of the group (str)
    """
    request = api.GetRequest('/api/sedaigroup/groups')
    response = api.do_get(request)
    if response['status'] == 'OK' and response['result'] is not None:
        return transform(response['result'], __group__fields)


def search_groups_by_name(name: str ):
    """
    Search for all groups that are integrated with Sedai that match the given name
    :param name: The name of the group to search for
    :return: A list of groups that match the given id. Output is in the same structure
     as :py:func:`get_all_groups`
    """
    groups = get_all_groups()
    return transform(list(filter(lambda x: x.name == name, groups)))


def search_groups_by_id(id: str):
    """
    Search for all groups that are integrated with Sedai that match the given id
    :param id: The groupId of the group to search for
    :return: A list of groups that match the given name. Output is in the same structuredef get_group_details(name):
     as :py:func:`get_all_groups`
    """
    groups = get_all_groups()
    return transform(list(filter(lambda x: x.id == id, groups)))


def get_group(name: str):
    """
    Get the details of a group. This includes the group definition and the details of the real-time resources
    Thiis includes the following fields:
    - **definition** - The group definition
    - **groupId** - The group id in within Sedai
    - **name** - the name of the group (str)
    - **awsLbCount** - The number of AWS Load Balancers in the group
    - **awsTagsCount** - The number of AWS Tags in the group
    - **azureLbCount** - The number of Azure Load Balancers in the group
    - **azureTagsCount** - The number of Azure Tags in the group
    - **azureVmCount** - The number of Azure Virtual Machines in the group
    - **ebsCount** - The number of AWS Elastic Block Storage in the group
    - **ec2Count** - The number of AWS EC2 instances in the group
    - **ecsCount** - The number of AWS ECS instances in the group
    - **kubeCount** - The number of Kubernetes resources in the group
    - **lambdaCount** - The number of AWS Lambda functions in the group
    - **s3Count** - The number of AWS S3 buckets in the group
    - **streamingCount** - The number of streaming resources in the group
    :param name: The name of the group to search for
    :return: The group details
    :raises Exception: If more than one group is found with the same name
    """
    qo = graphql.GraphQLFuncQuery(fields=_group_grapql_fields, func="groupDetails", params={"groupName": name})
    query_str = str(qo)
    request = api.PostRequest('/api/graphql', query_str)
    response = api.do_post(request)
    if response['data'] is not None and response['data']['groupDetails'] is not None and \
            response['data']['groupDetails']['nodes'] is not None and \
            len(response['data']['groupDetails']['nodes']) > 0:
        # More than one group found
        if len(response['data']['groupDetails']['nodes']) > 1:
            log(f"More than one group found with name: {name}")
            raise Exception(f"More than one group found with name: {name}")

        details = response['data']['groupDetails']['nodes'][0]
        # Convert the definition to json and then to GroupDefinition
        definition = json.loads(details['definition'])
        definition = GroupDefinition.from_json(definition)
        details = transform(details, _group_grapql_fields)
        details.definition = definition
        return details
    else:
        # Nothing found
        return None

def get_group_by_id(group_id: str ):
    """
    Get the details of a group. This includes the group definition and the details of the real-time resources
    This includes the following fields:
    - **groupId** - the id of the group (str)
    - **definition** - The group definition
    - **name** - the name of the group (str)
    - **groupKind** - the kind of the group (str) if exists - can be ACCOUNT, RESOURCE_GROUP, NAMESPACE, SUB_GROUP
    - **parentId** - the parent group id of the group if its the subgroup
    - **awsLbCount** - The number of AWS Load Balancers in the group
    - **awsTagsCount** - The number of AWS Tags in the group
    - **azureLbCount** - The number of Azure Load Balancers in the group
    - **azureTagsCount** - The number of Azure Tags in the group
    - **azureVmCount** - The number of Azure Virtual Machines in the group
    - **ebsCount** - The number of AWS Elastic Block Storage in the group
    - **ec2Count** - The number of AWS EC2 instances in the group
    - **ecsCount** - The number of AWS ECS instances in the group
    - **kubeCount** - The number of Kubernetes resources in the group
    - **lambdaCount** - The number of AWS Lambda functions in the group
    - **s3Count** - The number of AWS S3 buckets in the group
    - **streamingCount** - The number of streaming resources in the group
    :param group_id: The id of the group whose details is to be fetched
    :return: The group details
    """

    url = f"/api/sedaigroup/allGroupDefinitions/{group_id}"
    request = api.GetRequest(url)
    response = api.do_get(request)

    # Basic validation
    if response is None or response.get("status") != "OK":
        log(f"No group found with id: {group_id}")
        return None

    result = response.get("result", {})
    all_defs = result.get("allGroupDefinitions", {})
    edges = all_defs.get("edges", [])
    node = edges[0].get('node')

    # Convert definition JSON to GroupDefinition object
    definition_json = node.get('definition')
    if isinstance(definition_json, str):
        # if backend sends definition as string
        definition_json = json.loads(definition_json)

    definition_obj = GroupDefinition.from_json(definition_json)

    # Build a simple group object to return
    class GroupObj:
        pass

    group = GroupObj()
    group.groupId = node.get("groupId")
    group.name = node.get("name")
    group.definition = definition_obj

    # Copy all additional counts to the object
    for key, value in node.items():
        if key not in ["definition"]:
            setattr(group, key, value)

    return group

def update_group(group : Group):
    """
    Updates a Sedai Group definition
    :param group: Group object with attributes groupId, name, and definition
    :return: True if update succeeded, False otherwise
    """
    group_id = group.groupId
    group_name = group.name
    definition = group.definition

    # Apply any modifications to the definition if needed
    __add_modified(definition)
    definition_json = definition.to_json()
    url = f"/api/sedaigroup/updateGroupDefinition/{group_id}/{group_name}"
    request = api.PostRequest(url, definition_json)

    try:
        response = api.do_post(request)
        # Optional: check response status here if API returns a status field
        if response and response.get("status") == 'OK':
            __refresh_group_resources(group_id)
            log(f"Group {group_name} updated successfully")
            return True
        else:
            return False
    except Exception as ex:
        log.error(f"Failed to update group {group_id}, {group_name}", exc_info=ex)
        return False


def create_group(group: GroupDefinition):
    """
    Create a Sedai group.
    :param group: GroupDefinition object to create. Must include `name`.
                  Optional fields: tags, cluster, cloud, resourceType,
                  manuallyAddedResources, region, namespace, autoRefresh, parentGroupId.
    :return: True if the group was successfully created, False otherwise.
    :raises Exception: If a group with the same name already exists.
    """
    definition = group
    # Check if a group with the same name already exists
    groups = search_groups_by_name(definition.name)

    if len(groups) == 0:
        log("Group with name: " + definition.name + " does not exist. Creating shell")
        url = f"/api/sedaigroup/create/{definition.name}"
        __add_created(definition)
        payload = json.loads(definition.to_json())
        request = api.PostRequest(url, payload, headers={"Accept": "application/json"})

        response = api.do_post(request)
        if response['status'] != 'OK':
            log(f"Failed to create group: {response['message']}")
            return False
        else:
            log(f"Successfully created group: {definition.name}")
            return True
    else:
        log(f"Group with name: {definition.name} already exists")
        raise Exception(f"Group with name: {definition.name} already exists")

def delete_group(group_id: str):
    """
    Delete a group from Sedai
    :param group_id:  The id of the group to delete
    :return: True if successful, False otherwise
    """

    query = f"""
    mutation MyMutation {{
        deleteGroupDefinitionByGroupId(
            input: {{
                groupId: "{group_id}"
            }}
        ) {{
            clientMutationId
            deletedGroupDefinitionId
        }}
    }}
    """
    url = "/api/graphql"
    payload = {
        "query": query
    }
    request = api.PostRequest(url, payload)
    response = api.do_post(request)
    if 'errors' in response and len(response['errors']) > 0:
        log(response)
        raise Exception(f"Failed to delete group: {response['errors'][0]['message']}")
    else:
        log("Successfully deleted group")
        return True

def __refresh_group_resources(group_id: str):
    # curl 'https://test.sedai.cloud/api/sedaigroup/updategroupresources/cad5eb85-5f1e-4b3d-864e-95b1b9ca4a43
    url = f"/api/sedaigroup/updategroupresources/{group_id}"
    request = api.GetRequest(url)
    response = api.do_get(request)
    return response

