from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional

from sedai.util import __get_paginated_response


class SettingsEventType(Enum):
    """
    Represents the type of event.

    This enum categorizes the different types of changes that can occur to settings
    for resources, groups or accounts.
    """

    CUSTOM_SETTINGS_CREATE = "CUSTOM_SETTINGS_CREATE"
    """
    Custom settings for this resource/group/account created.
    """
    CUSTOM_SETTINGS_UPDATE = "CUSTOM_SETTINGS_UPDATE"
    """
    Custom settings for this resource/group/account updated.
    """
    CUSTOM_SETTINGS_RESET = "CUSTOM_SETTINGS_RESET"
    """
    Custom settings for this resource/group/account reset.
    """


class SettingChangeDetails:
    """
    Represents the details of the change made in some field for a particular setting type.
    """

    setting_key: str
    """
    The setting field that was modified.
    """
    description: str
    """
    Description of the setting modified.
    """
    initial_value: Any
    """
    Original value before modification.
    """
    new_value: Any
    """
    Final value after modification.
    """

    def __init__(self, setting_key: str, description: str, initial_value: Any, new_value: Any):
        """
        @private
        """
        self.setting_key = setting_key
        self.description = description
        self.initial_value = initial_value
        self.new_value = new_value


class SettingsChangeEvent:
    """
    Represents a change in the settings for an entity (resource, group or account), including the type
    of change, who made the change, when it occured and what specific settings were modified.
    """

    event_type: SettingsEventType
    """
    Type of modification.
    """
    updated_user: str
    """
    Which user performed the modification.
    """
    updated_time: datetime
    """
    Time at which the modification was performed.
    """
    updated_settings: List[SettingChangeDetails]
    """
    List of modified fields.
    """

    def __init__(self, event_type):
        """
        @private
        """
        self.event_type = event_type
        self.updated_user = None
        self.updated_time = None
        self.updated_settings = list()


def get_resource_settings_history(
    resource_id: str, start_time: Optional[datetime] = None, end_time: Optional[datetime] = None
) -> List[SettingsChangeEvent]:
    """
    Retrieve the history of settings changes for a particular resource.
    """
    endpoint = '/api/settingsV2/topology/logs/resource'
    params = dict()
    params['resourceId'] = resource_id

    if start_time is not None:
        starttime_epoch_ms = start_time.timestamp() * 1000
        params['startTime'] = int(round(starttime_epoch_ms))

    if end_time is not None:
        endtime_epoch_ms = end_time.timestamp() * 1000
        params['endTime'] = int(round(endtime_epoch_ms))

    settings_history = []
    for logs_page in __get_paginated_response(endpoint, params):
        for log_obj in logs_page:
            changes = log_obj['changes']
            if changes is not None:
                events = _parse_log_events(log_obj)
                settings_history.extend(events)

    return settings_history


def get_group_settings_history(
    group_id: str, start_time: Optional[datetime] = None, end_time: Optional[datetime] = None
) -> List[SettingsChangeEvent]:
    """
    Retrieve the history of settings changes for a particular group.
    """
    endpoint = '/api/settingsV2/topology/logs/group'
    params = dict()
    params['groupId'] = group_id

    if start_time is not None:
        starttime_epoch_ms = start_time.timestamp() * 1000
        params['startTime'] = int(round(starttime_epoch_ms))

    if end_time is not None:
        endtime_epoch_ms = end_time.timestamp() * 1000
        params['endTime'] = int(round(endtime_epoch_ms))

    settings_history = []
    for logs_page in __get_paginated_response(endpoint, params):
        for log_obj in logs_page:
            changes = log_obj['changes']
            if changes is not None:
                events = _parse_log_events(log_obj)
                settings_history.extend(events)

    return settings_history


def get_account_settings_history(
    account_id: str, start_time: Optional[datetime] = None, end_time: Optional[datetime] = None
) -> List[SettingsChangeEvent]:
    """
    Retrieve the history of settings changes for a particular account.
    """
    endpoint = '/api/settingsV2/topology/logs/account'
    params = dict()
    params['accountId'] = account_id

    if start_time is not None:
        starttime_epoch_ms = start_time.timestamp() * 1000
        params['startTime'] = int(round(starttime_epoch_ms))

    if end_time is not None:
        endtime_epoch_ms = end_time.timestamp() * 1000
        params['endTime'] = int(round(endtime_epoch_ms))

    settings_history = []
    for logs_page in __get_paginated_response(endpoint, params):
        for log_obj in logs_page:
            changes = log_obj['changes']
            if changes is not None:
                events = _parse_log_events(log_obj)
                settings_history.extend(events)

    return settings_history


def _parse_log_events(log_obj: Dict) -> List[SettingsChangeEvent]:
    events = []
    updated_time_epoch = log_obj['updatedTime']
    logged_time = (
        datetime.fromtimestamp(updated_time_epoch / 1000.0)
        if updated_time_epoch is not None
        else None
    )
    changes = log_obj['changes']
    if changes is None:
        return events

    setting_type_to_event_map = dict()
    for change_key, change_obj in changes.items():
        if change_key == "attributes_change":
            attribute_change_event = _parse_attribute_changes(change_obj)
            attribute_change_event.updated_time = logged_time
            events.append(attribute_change_event)
        else:
            _process_settings_change(change_key, change_obj, setting_type_to_event_map)

    for event in setting_type_to_event_map.values():
        if event.updated_time is None:
            event.updated_time = logged_time
        events.append(event)
    return events


def _parse_attribute_changes(change_obj: Dict) -> SettingsChangeEvent:
    event = None
    ATTRIBUTE_FIELDS_IGNORED = ['group_id', 'resource_id']

    if change_obj['before'] is not None and change_obj['after'] is not None:
        event = SettingsChangeEvent(event_type=SettingsEventType.CUSTOM_SETTINGS_UPDATE)
        for key, original_value in change_obj['before'].items():
            if key in ATTRIBUTE_FIELDS_IGNORED:
                continue

            new_value = change_obj['after'][key]
            if original_value != new_value:
                settings_change = SettingChangeDetails(
                    setting_key=key,
                    description=None,
                    initial_value=original_value,
                    new_value=new_value,
                )
                event.updated_settings.append(settings_change)

    elif change_obj["before"] is not None:
        event = SettingsChangeEvent(event_type=SettingsEventType.CUSTOM_SETTINGS_RESET)
        for key, original_value in change_obj['before'].items():
            if key in ATTRIBUTE_FIELDS_IGNORED:
                continue

            settings_change = SettingChangeDetails(
                setting_key=key,
                description=None,
                initial_value=original_value,
                new_value=None,
            )
            event.updated_settings.append(settings_change)

    else:
        event = SettingsChangeEvent(event_type=SettingsEventType.CUSTOM_SETTINGS_CREATE)
        for key, new_value in change_obj['after'].items():
            if key in ATTRIBUTE_FIELDS_IGNORED:
                continue

            settings_change = SettingChangeDetails(
                setting_key=key,
                description=None,
                initial_value=None,
                new_value=new_value,
            )
            event.updated_settings.append(settings_change)

    return event


def _process_settings_change(
    change_key: str, change_obj: Dict, setting_type_to_event_map: Dict
) -> SettingsChangeEvent:
    setting_type, setting_key = change_key.rsplit('.', 1)

    if change_obj['before'] is not None and change_obj['after'] is not None:
        change_event = setting_type_to_event_map.get(
            setting_type, SettingsChangeEvent(event_type=SettingsEventType.CUSTOM_SETTINGS_UPDATE)
        )
        if setting_key == "updatedUser":
            change_event.updated_user = change_obj.get('after', None)
            return
        elif setting_key == "updatedTime":
            change_event.updated_time = _parse_time_from_str(change_obj.get('after', None))
            return
    elif change_obj['before'] is not None:
        change_event = setting_type_to_event_map.get(
            setting_type, SettingsChangeEvent(event_type=SettingsEventType.CUSTOM_SETTINGS_RESET)
        )
        if setting_key == "updatedUser":
            change_event.updated_user = change_obj.get('before', None)
            return
        elif setting_key == "updatedTime":
            change_event.updated_time = _parse_time_from_str(change_obj.get('before', None))
            return
    else:
        change_event = setting_type_to_event_map.get(
            setting_type, SettingsChangeEvent(event_type=SettingsEventType.CUSTOM_SETTINGS_CREATE)
        )
        if setting_key == "updatedUser":
            change_event.updated_user = change_obj.get('after', None)
            return
        elif setting_key == "updatedTime":
            change_event.updated_time = _parse_time_from_str(change_obj.get('after', None))
            return

    settings_change = SettingChangeDetails(
        setting_key=change_key,
        description=change_obj.get('description', None),
        initial_value=change_obj.get('before', None),
        new_value=change_obj.get('after', None),
    )
    change_event.updated_settings.append(settings_change)
    setting_type_to_event_map[setting_type] = change_event


def _parse_time_from_str(time_str: str):
    if time_str is None:
        return None

    return datetime.strptime(time_str, "%Y-%m-%d %H:%M:%S.%f")
