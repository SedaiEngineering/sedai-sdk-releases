from enum import Enum
from typing import Optional, List

from sedai.__impl import api, log
from sedai.optimizations import AzureDiskConfig, EBSVolumeConfig, VolumeConfig


class ResourceOpportunityStatus(Enum):
    """
    This enum class, ResourceOpportunityStatus, defines possible statuses for a resource optimization opportunity:
    Use this enum to represent and check the evaluation status of a resource in optimization workflows.

    - `NOT_EVALUATED`: The resource has not yet been evaluated for optimization opportunities.
    - `NO_OPPORTUNITY`: No optimization opportunity is available for the resource.
    - `OPPORTUNITY_AVAILABLE`: An optimization opportunity is available for the resource.
    """
    NOT_EVALUATED = "NOT_EVALUATED"
    NO_OPPORTUNITY = "NO_OPPORTUNITY"
    OPPORTUNITY_AVAILABLE = "OPPORTUNITY_AVAILABLE"

    def __str__(self) -> str:
        return self.value


class MetricValue:

    """
    Represents metric specifications by associating numeric values with their corresponding units.

    When printed, the object displays the machine-friendly representation of the metric.
    All attributes can also be accessed directly using the dot (.) operator.
    """

    value: float
    """
    The raw value for the metric.
    """
    unit: str
    """
    Unit of the metric value.
    """
    machine_friendly_representation : str
    """
    Readable representation with value and unit.
    """


    def __init__(self, src: dict):
        """@private"""
        self.value = src.get("value")
        self.unit = src.get("metricUnit")
        self.machine_friendly_representation = src.get("machineFriendlyRepresentation")

    def __str__(self):
        return self.machine_friendly_representation


class OpportunityDetails:
    """
    Base class for showing Opportunity details for a resource.

    """

    sedai_resource_id: str
    """
    Id used in Sedai corresponding to the resource mentioned.
    """
    resource_name: str
    """
    Name of the resource.
    """
    monthly_cost_impact_pct: float
    """
    Monthly cost impact percentage.
    """
    monthly_cost_impact: float
    """
    Monthly cost impact.
    """
    pre_ops_monthly_cost: float
    """
    Monthly cost before the optimization.
    """
    post_ops_monthly_cost: float
    """
    Monthly cost after the optimization.
    """
    opportunity_status: ResourceOpportunityStatus

    def __init__(self, src: dict):
        """@private"""
        self.sedai_resource_id = src.get("sedaiResourceId")
        self.resource_name = src.get("resourceName")
        self.monthly_cost_impact_pct = src.get("monthlyCostImpactPct")
        self.monthly_cost_impact = src.get("monthlyCostImpact")
        self.pre_ops_monthly_cost = src.get("preOpsMonthlyCost")
        self.post_ops_monthly_cost = src.get("postOpsMonthlyCost")
        self.opportunity_status = ResourceOpportunityStatus(src.get("resourceOpportunityStatus"))


class VolumeOpportunityDetails(OpportunityDetails):

    """
    Represents an optimization opportunity for Azure disks.
    Captures details about current and recommended instance types, pricing impact,
    and related instance configurations.
    """

    __type = "VolumeOptimizationOpportunityModel"

    current_config : Optional[VolumeConfig] = None
    """
    Current config for the resource.
    """
    recommended_config : Optional[VolumeConfig] = None
    """
    Recommended config for the resource.
    """

    __instance_type_map = {
        "AzureDiskConfigState": AzureDiskConfig,
        "EBSVolumeConfigState": EBSVolumeConfig
    }

    def __init__(self, src: dict):
        super().__init__(src)
        self.__parse__(src)

    def __parse__(self, src : dict):
        current = src.get("currentConfig") or {}
        recommended = src.get("recommendedConfig") or {}

        config_type = current.get("type") or recommended.get("type")
        if config_type not in self.__instance_type_map:
            log(f"Unsupported volume type : {config_type}")
            return

        config_class = self.__instance_type_map[config_type]

        if src.get("currentConfig"):
            self.current_config = config_class(src["currentConfig"])

        if src.get("recommendedConfig"):
            self.recommended_config = config_class(src["recommendedConfig"])


class InstanceConfig:
    """
    Details of the instance.
    """
    instance_names: List[str] = None
    """
    Names of the instances.
    """
    current_type: Optional[str] = None
    """
    Current instance type.
    """
    recommended_type: Optional[str] = None
    """
    Recommended instance type after optimization.
    """
    account: Optional[str] = None
    """
    Account name to which the instance belongs.
    """
    region: Optional[str] = None
    """
    Region where the instance is deployed.
    """
    quantity: int = 0
    """
    Number of instances of the given type.
    """
    pre_cpu: Optional["MetricValue"] = None
    """
    CPU values before optimization.
    """
    post_cpu: Optional["MetricValue"] = None
    """
    CPU values after optimization.
    """
    pre_memory: Optional["MetricValue"] = None
    """
    Memory values before optimization.
    """
    post_memory: Optional["MetricValue"] = None
    """
    Memory values after optimization.
    """
    pre_max_network_bandwidth: Optional[str] = None
    """
    Maximum network bandwidth before optimization.
    """
    post_max_network_bandwidth: Optional[str] = None
    """
    Maximum network bandwidth after optimization.
    """
    pre_ebs_throughput: Optional[str] = None
    """
    EBS throughput before optimization.
    """
    post_ebs_throughput: Optional[str] = None
    """
    EBS throughput after optimization.
    """
    pre_max_ebs_bandwidth: Optional["MetricValue"] = None
    """
    Maximum EBS bandwidth before optimization.
    """
    post_max_ebs_bandwidth: Optional["MetricValue"] = None
    """
    Maximum EBS bandwidth after optimization.
    """
    pre_instance_family: Optional[str] = None
    """
    Instance family before optimization.
    """
    post_instance_family: Optional[str] = None
    """
    Instance family after optimization.
    """
    pre_cpu_clockspeed: Optional[float] = None
    """
    CPU clock speed in GHz before optimization.
    """
    post_cpu_clockspeed: Optional[float] = None
    """
    CPU clock speed in GHz after optimization.
    """


    def __set__region(self, region):

        region_split = region.split("/")
        if len(region_split) == 2:
            self.region = region_split[1]
        else:
            self.region = region


    def __init__(self, src: dict):
        """@private"""
        self.instance_names = src.get("instanceNames")
        self.current_type = src.get("currentType")
        self.recommended_type = src.get("recommendedType")
        self.account = src.get("account")
        self.quantity = src.get("quantity")
        self.pre_cpu = MetricValue(src.get("preCpu"))
        self.post_cpu = MetricValue(src.get("postCpu"))
        self.pre_memory = MetricValue(src.get("preMemory"))
        self.post_memory = MetricValue(src.get("postMemory"))
        self.pre_max_network_bandwidth = src.get("preMaxNetworkBandwidth")
        self.post_max_network_bandwidth = src.get("postMaxNetworkBandwidth")
        self.pre_ebs_throughput = src.get("preEbsThroughput")
        self.post_ebs_throughput = src.get("postEbsThroughput")
        self.pre_max_ebs_bandwidth = MetricValue(src.get("preMaxEBSBandwidth"))
        self.post_max_ebs_bandwidth = MetricValue(src.get("postMaxEBSBandwidth"))
        self.pre_instance_family = src.get("preInstanceFamily")
        self.post_instance_family = src.get("postInstanceFamily")
        self.pre_cpu_clockspeed = src.get("preCpuClockspeed")
        self.post_cpu_clockspeed = src.get("postCpuClockspeed")
        self.__set__region(src.get("region") or "")


class VMOpportunityDetails(OpportunityDetails):
    """
    Represents an optimization opportunity for virtual machines (VMs).
    Captures details about current and recommended instance types, pricing impact,
    and related instance configurations.
    """

    __type = "VMOptimizationOpportunityModel"

    current_instance_type: str
    """
    Current VM instance type.
    """
    recommended_instance_type: str
    """
    Recommended VM instance type after optimization.
    """
    pre_on_demand_pricing: float
    """
    Current on-demand pricing cost (before optimization).
    """
    post_on_demand_pricing: float
    """
    On-demand pricing cost after applying the recommended instance type.
    """
    estimated_on_demand_pricing_impact: float
    """
    Estimated cost savings (or increase) in on-demand pricing due to optimization.
    """
    instance_configs: List[InstanceConfig] = None
    """
    List of instance configuration details before and after optimization.
    """

    def __init__(self, src: dict):
        super().__init__(src)
        self.current_instance_type = src.get("currentInstanceType")
        self.recommended_instance_type = src.get("recommendedInstanceType")
        self.pre_on_demand_pricing = src.get("preOnDemandPricing")
        self.post_on_demand_pricing = src.get("postOnDemandPricing")
        self.estimated_on_demand_pricing_impact = src.get("estimatedOnDemandPricingImpact")
        self.instance_configs = self.instance_configs = [InstanceConfig(cfg) for cfg in (src.get("instanceConfigs") or [])]


__type_map = {
    "VolumeOptimizationOpportunityModel" : VolumeOpportunityDetails,
    "VMOptimizationOpportunityModel"      : VMOpportunityDetails
}

def get_opportunity_for_resource(
        provider_resource_id : str
)-> VMOpportunityDetails | VolumeOpportunityDetails:
    """
    Fetches optimization opportunities for a given resource, such as VMs and volumes.

    :param provider_resource_id: The unique identifier of the resource in cloud provider for which optimization opportunities are to be retrieved.

    :return: An instance of the opportunity details for the specified resource.
             Depending on the resource type, this will be either `VMOpportunityDetails` or `VolumeOpportunityDetails`.
    """
    params = dict()
    params['providerResourceId'] = provider_resource_id
    request = api.GetRequest(
        f'/api/autonomousOpportunities/individualResource', params=params, doseq=True
    )
    response = api.do_get(request)
    if response['status'] != 'OK' or response['result'] is None:
        log(f"Failed to fetch opportunity")
        return None

    resource_opportunity_json = response['result']
    resource_type = resource_opportunity_json['type']
    opportunity = __type_map[resource_type](resource_opportunity_json)
    return opportunity


