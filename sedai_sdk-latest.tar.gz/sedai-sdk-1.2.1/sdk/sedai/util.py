import time

from sedai.user import get_profile

"""@private"""



def __get_user_and_time():
    profile = get_profile()
    user_id = profile.displayName
    # Get current time
    time_stamp = int(time.time() * 1000)
    return user_id, time_stamp


def __add_created(obj):
    user_id, time_stamp = __get_user_and_time()
    obj.createdBy = user_id
    obj.createdOn = time_stamp
    return obj


def __add_modified(obj):
    user_id, time_stamp = __get_user_and_time()
    obj.modifiedBy = user_id
    obj.modifiedOn = time_stamp
    return obj