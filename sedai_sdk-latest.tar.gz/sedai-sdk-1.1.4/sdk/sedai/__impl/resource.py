from types import SimpleNamespace


def validate_resource(resource):
    if not isinstance(resource, SimpleNamespace):
        raise ValueError("resource must be a SimpleNamespace")

    if not hasattr(resource, 'account_id'):
        raise ValueError("resource must have an account_id field")

    if not hasattr(resource, 'resource_name') and not hasattr(resource, 'resource_id'):
        raise ValueError("resource must have a resource_name or resource_id field")

    return resource


def create_resource(account_id, resource_id, **kwargs):
    resource = SimpleNamespace()
    resource.account_id = account_id
    resource.resource_id = resource_id
    for key, value in kwargs.items():
        setattr(resource, key, value)

    return validate_resource(resource)
