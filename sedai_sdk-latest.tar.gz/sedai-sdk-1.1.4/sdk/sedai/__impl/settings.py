import json

from sedai.__impl.model_converter import _to_SimpleNamespace, _SimpleNamespace_to_dict


def add_settings(resource, resource_config):
    if resource_config is None:
        raise ValueError("Invalid settings from API")

    type = resource_config['type']
    if type == 'KubernetesAppResourceConfigDetail':
        resource.settings = _KubeSettings.get_settings(resource_config)
    elif type == 'ECSAppResourceConfigDetail':
        resource.settings = _ECSSettings.get_settings(resource_config)
    elif type == 'ServerlessFunctionResourceConfigDetail':
        resource.settings = _ServerlessFunctionSettings.get_settings(resource_config)
    elif type == 'AzureAppResourceConfigDetail':
        resource.settings = _AzureSettings.get_settings(resource_config)
    else:
        raise ValueError("Unknown resource type: " + type)
    return resource


def get_merged_settings(resource):
    if resource.resource_type == 'APP':
        return _KubeSettings.get_merged_settings(resource.settings)
    elif resource.resource_type == 'SERVERLESS_FUNCTION':
        return _ServerlessFunctionSettings.get_merged_settings(resource.settings)
    else:
        raise ValueError("Unknown resource type: " + resource.resource_type)


def add_account_settings(account_settings):
    if account_settings is None:
        raise ValueError("Invalid settings from API")

    settings = _AccountLevelSettings.get_settings(account_settings)
    return settings


def add_group_settings(group_settings):
    if group_settings is None:
        raise ValueError("Invalid settings from API")

    settings = _GroupLevelSettings.get_settings(group_settings)
    return settings


def validate_settings(settings):
    print(settings)

    if not hasattr(settings, 'appSpecificDetail'):
        raise ValueError("settings must have an appSpecificDetail field")

    if not hasattr(settings, 'availability'):
        raise ValueError("settings must have a availability field")

    if not hasattr(settings, 'ecsSpecificDetail'):
        raise ValueError("settings must have a ecsSpecificDetail field")

    if not hasattr(settings, 'kubeSpecificDetail'):
        raise ValueError("settings must have a kubeSpecificDetail field")

    if not hasattr(settings, 'releaseIntelligence'):
        raise ValueError("settings must have an releaseIntelligence field")

    if not hasattr(settings, 'serverlessSpecificDetail'):
        raise ValueError("settings must have a serverlessSpecificDetail field")

    if not hasattr(settings, 'slo'):
        raise ValueError("settings must have a slo field")


class _SedaiSettings:
    @staticmethod
    def _to_settings(resource_config, settings_keys):
        settings = {}
        for full_key in settings_keys:
            key_parts = full_key.split('.')

            source = resource_config
            target = settings
            for sub_key in key_parts:
                source = source.get(sub_key)
                if source is None:
                    break
                else:
                    if type(source) is dict:
                        target = target.setdefault(sub_key, {})
                    else:
                        target[sub_key] = source
        return settings

    @staticmethod
    def _merge(template: dict, settings: dict, settings_keys: list):
        for full_key in settings_keys:
            key_parts = full_key.split('.')

            source = settings
            target = template
            for sub_key in key_parts:
                source = source.get(sub_key)
                if source is None or target is None:
                    break
                else:
                    if type(source) is dict:
                        target = target.get(sub_key)
                        continue
                    else:
                        target[sub_key] = source
                        break

        return template


class _KubeSettings(_SedaiSettings):
    settings_keys = [
        "availability.configMode",
        "slo.configMode",
        "releaseIntelligence.configMode",
        "optimization.optimizationConfig.configMode",
        "optimization.optimizationFocus.focus",
        "optimization.optimizationFocus.maxMemoryIncreasePct",
        "optimization.optimizationFocus.maxCPUIncreasePct",
        "optimization.optimizationFocus.maxLatencyIncreasePct",
        "enableVerticalScaling.status",
        "enableHorizontalScaling.horizontalScalingConfig.status",
        "enableHorizontalScaling.minReplicas",
        "enableHorizontalScaling.maxReplicas",
        "enableHorizontalScaling.replicaMultiplier",
        "enableHorizontalScaling.horizontalScalingConfigMode",
        "enablePredictiveScaling.status",
        "autonomousActionWithoutTraffic.status",
        "isProd.status"]

    settings_key_map = {
        "availability.configMode": {"type": "enum", "values": ["MANUAL", "AUTO", "OFF"]},
        "slo.configMode": {"type": "enum", "values": ["MANUAL", "AUTO", "OFF"]},
        "releaseIntelligence.configMode": {"type": "enum", "values": ["MANUAL", "AUTO", "OFF"]},
        "optimization.optimizationConfig.configMode": {"type": "enum", "values": ["MANUAL", "AUTO", "OFF"]},
        "optimization.optimizationFocus.focus": {"type": "enum", "values": ["COST", "DURATION", "COST_AND_DURATION"]},
        "optimization.optimizationFocus.maxMemoryIncreasePct": {"type": "number", "min": 0, "max": 100},
        "optimization.optimizationFocus.maxCPUIncreasePct": {"type": "number", "min": 0, "max": 100},
        "optimization.optimizationFocus.maxLatencyIncreasePct": {"type": "number", "min": 0, "max": 100},
        "enableVerticalScaling.status": {"type": "boolean"},
        "enableHorizontalScaling.horizontalScalingConfig.status": {"type": "boolean"},
        "enableHorizontalScaling.minReplicas": {"type": "number", "min": 0},
        "enableHorizontalScaling.maxReplicas": {"type": "number", "min": 0},
        "enableHorizontalScaling.replicaMultiplier": {"type": "number", "min": 0},
        "enableHorizontalScaling.horizontalScalingConfigMode": {"type": "boolean"},
        "enablePredictiveScaling.status": {"type": "boolean"},
        "autonomousActionWithoutTraffic.status": {"type": "boolean"},
        "isProd.status": {"type": "boolean"}
    }

    settings_dict_template = {
        "type": "KubernetesAppResourceConfigDetail",
        "availability": {
            "scope": "RESOURCE_OVERRIDE",
            "configCategory": "AVAILABILITY",
        },
        "slo": {
            "scope": "RESOURCE_OVERRIDE",
            "configCategory": "SLO",
        },
        "releaseIntelligence": {
            "scope": "RESOURCE_OVERRIDE",
            "configCategory": "RELEASE_INTELLIGENCE",
        },
        "optimization": {
            "type": "KubernetesOptimizationResourceConfigCategoryDetail",
            "optimizationConfig": {
                "scope": "RESOURCE_OVERRIDE",
                "configCategory": "OPTIMIZATION",
            },
            "optimizationFocus": {
                "type": "KubernetesOptimizationFocusItem",
            }
        },
        "enableVerticalScaling": {
        },
        "enableHorizontalScaling": {
            "horizontalScalingConfig": {
            },
        },
        "enablePredictiveScaling": {
        },
        "autonomousActionWithoutTraffic": {
        },
        "isProd": {
        }
    }

    def get_settings(resource_config):
        settings = _SedaiSettings._to_settings(resource_config, _KubeSettings.settings_keys)
        return _to_SimpleNamespace(settings)

    def get_merged_settings(settings):
        settings = _SimpleNamespace_to_dict(settings)
        merged_settings = _SedaiSettings._merge(_KubeSettings.settings_dict_template, settings,
                                                _KubeSettings.settings_keys)
        return merged_settings


class _ECSSettings(_SedaiSettings):
    settings_keys = [
        "availability.configMode",
        "slo.configMode",
        "releaseIntelligence.configMode",
        "optimization.optimizationConfig.configMode",
        "optimization.optimizationFocus.focus",
        "optimization.optimizationFocus.maxMemoryIncreasePct",
        "optimization.optimizationFocus.maxCPUIncreasePct",
        "optimization.optimizationFocus.maxLatencyIncreasePct",
        "enableVerticalScaling.minCpu",
        "enableVerticalScaling.minMemory",
        "enableVerticalScaling.status",
        "enableHorizontalScaling.status",
        "enableHorizontalScaling.minReplicas",
        "enableHorizontalScaling.maxReplicas",
        "enableHorizontalScaling.replicaIncrement",
        "enableServiceAutoscalingConfiguration.status",
        "enablePredictiveScaling.status",
        "autonomousActionWithoutTraffic.status",
        "isProd.status"]

    settings_key_map = {
        "availability.configMode": {"type": "enum", "values": ["MANUAL", "AUTO", "OFF"]},
        "slo.configMode": {"type": "enum", "values": ["MANUAL", "AUTO", "OFF"]},
        "releaseIntelligence.configMode": {"type": "enum", "values": ["MANUAL", "AUTO", "OFF"]},
        "optimization.optimizationConfig.configMode": {"type": "enum", "values": ["MANUAL", "AUTO", "OFF"]},
        "optimization.optimizationFocus.focus": {"type": "enum", "values": ["COST", "DURATION", "COST_AND_DURATION"]},
        "optimization.optimizationFocus.maxMemoryIncreasePct": {"type": "number", "min": 0, "max": 100},
        "optimization.optimizationFocus.maxCPUIncreasePct": {"type": "number", "min": 0, "max": 100},
        "optimization.optimizationFocus.maxLatencyIncreasePct": {"type": "number", "min": 0, "max": 100},
        "enableVerticalScaling.minCpu": {"type": "number", "min": 0, "max": 100},
        "enableVerticalScaling.minMemory": {"type": "number", "min": 0, "max": 100},
        "enableVerticalScaling.status": {"type": "boolean"},
        "enableHorizontalScaling.status": {"type": "boolean"},
        "enableHorizontalScaling.minReplicas": {"type": "number", "min": 0},
        "enableHorizontalScaling.maxReplicas": {"type": "number", "min": 0},
        "enableHorizontalScaling.replicaIncrement": {"type": "number", "min": 0},
        "enableServiceAutoscalingConfiguration.status": {"type": "boolean"},
        "enablePredictiveScaling.status": {"type": "boolean"},
        "autonomousActionWithoutTraffic.status": {"type": "boolean"},
        "isProd.status": {"type": "boolean"}
    }

    settings_dict_template = {
        "type": "ECSAppResourceConfigDetail",
        "availability": {
            "scope": "RESOURCE_OVERRIDE",
            "configCategory": "AVAILABILITY",
        },
        "slo": {
            "scope": "RESOURCE_OVERRIDE",
            "configCategory": "SLO",
        },
        "releaseIntelligence": {
            "scope": "RESOURCE_OVERRIDE",
            "configCategory": "RELEASE_INTELLIGENCE",
        },
        "optimization": {
            "type": "ECSOptimizationResourceConfigCategoryDetail",
            "optimizationConfig": {
                "scope": "RESOURCE_OVERRIDE",
                "configCategory": "OPTIMIZATION",
            },
            "optimizationFocus": {
                "type": "ECSOptimizationFocusItem",
            }
        },
        "enableVerticalScaling": {
        },
        "enableHorizontalScaling": {
        },
        "enableServiceAutoscalingConfiguration": {
        },
        "enablePredictiveScaling": {
        },
        "autonomousActionWithoutTraffic": {
        },
        "isProd": {
        }
    }

    def get_settings(resource_config):
        settings = _SedaiSettings._to_settings(resource_config, _ECSSettings.settings_keys)
        return _to_SimpleNamespace(settings)

    def get_merged_settings(settings):
        settings = _SimpleNamespace_to_dict(settings)
        merged_settings = _SedaiSettings._merge(_ECSSettings.settings_dict_template, settings,
                                                _ECSSettings.settings_keys)
        return merged_settings


class _ServerlessFunctionSettings(_SedaiSettings):
    settings_keys = [
        "availability.configMode",
        "slo.configMode",
        "releaseIntelligence.configMode",
        "optimization.autonomousConcurrency.status",
        "optimization.optimizationConfig.configMode",
        "optimization.optimizationFocus.focus",
        "optimization.optimizationFocus.autoOptMaxCostChangePct",
        "optimization.optimizationFocus.autoOptMaxLatencyChangePct",
        "optimization.provisionedConcurrencyOptimization.status",
        "optimization.telemetryLogging.status",
    ]

    settings_key_map = {
        "availability.configMode": {"type": "enum", "values": ["MANUAL", "AUTO", "OFF"]},
        "slo.configMode": {"type": "enum", "values": ["MANUAL", "AUTO", "OFF"]},
        "releaseIntelligence.configMode": {"type": "enum", "values": ["MANUAL", "AUTO", "OFF"]},
        "optimization.autonomousConcurrency.status": {"type": "boolean"},
        "optimization.optimizationConfig.configMode": {"type": "enum", "values": ["MANUAL", "AUTO", "OFF"]},
        "optimization.optimizationFocus.focus": {"type": "enum", "values": ["COST", "DURATION", "COST_AND_DURATION"]},
        "optimization.optimizationFocus.autoOptMaxCostChangePct": {"type": "number", "min": 0, "max": 100},
        "optimization.optimizationFocus.autoOptMaxLatencyChangePct": {"type": "number", "min": 0, "max": 100},
        "optimization.provisionedConcurrencyOptimization.status": {"type": "boolean"},
        "optimization.telemetryLogging.status": {"type": "boolean"},
    }

    settings_dict_template = {
        "type": "ServerlessFunctionResourceConfigDetail",
        "availability": {
            "scope": "RESOURCE_OVERRIDE",
            "configCategory": "AVAILABILITY",
        },
        "slo": {
            "scope": "RESOURCE_OVERRIDE",
            "configCategory": "SLO",
        },
        "releaseIntelligence": {
            "scope": "RESOURCE_OVERRIDE",
            "configCategory": "RELEASE_INTELLIGENCE",
        },
        "optimization": {
            "type": "ServerlessOptimizationResourceConfigCategoryDetail",
            "autonomousConcurrency": {
            },
            "optimizationConfig": {
                "scope": "RESOURCE_OVERRIDE",
                "configCategory": "OPTIMIZATION",
            },
            "optimizationFocus": {
                "type": "ServerlessOptimizationFocusItem",
            },
            "provisionedConcurrencyOptimization": {
            },
            "telemetryLogging": {
            },
        },
    }

    def get_settings(resource_config):
        settings = _SedaiSettings._to_settings(resource_config, _ServerlessFunctionSettings.settings_keys)
        return _to_SimpleNamespace(settings)

    def get_merged_settings(settings):
        settings = _SimpleNamespace_to_dict(settings)
        merged_settings = _SedaiSettings._merge(_ServerlessFunctionSettings.settings_dict_template, settings,
                                                _ServerlessFunctionSettings.settings_keys)
        return merged_settings


class _AzureSettings(_SedaiSettings):
    settings_keys = [
        "availability.configMode",
        "slo.configMode",
        "releaseIntelligence.configMode",
        "optimization.optimizationConfig.configMode"
    ]

    settings_key_map = {
        "availability.configMode": {"type": "enum", "values": ["MANUAL", "AUTO", "OFF"]},
        "slo.configMode": {"type": "enum", "values": ["MANUAL", "AUTO", "OFF"]},
        "releaseIntelligence.configMode": {"type": "enum", "values": ["MANUAL", "AUTO", "OFF"]},
        "optimization.optimizationConfig.configMode": {"type": "enum", "values": ["MANUAL", "AUTO", "OFF"]}
    }

    settings_dict_template = {
        "type": "KubernetesAppResourceConfigDetail",
        "availability": {
            "scope": "RESOURCE_OVERRIDE",
            "configCategory": "AVAILABILITY",
        },
        "slo": {
            "scope": "RESOURCE_OVERRIDE",
            "configCategory": "SLO",
        },
        "releaseIntelligence": {
            "scope": "RESOURCE_OVERRIDE",
            "configCategory": "RELEASE_INTELLIGENCE",
        },
        "optimization": {
            "type": "KubernetesOptimizationResourceConfigCategoryDetail",
            "optimizationConfig": {
                "scope": "RESOURCE_OVERRIDE",
                "configCategory": "OPTIMIZATION",
            },
            "optimizationFocus": {
                "type": "KubernetesOptimizationFocusItem",
            }
        }
    }

    def get_settings(resource_config):
        settings = _SedaiSettings._to_settings(resource_config, _AzureSettings.settings_keys)
        return _to_SimpleNamespace(settings)

    def get_merged_settings(settings):
        settings = _SimpleNamespace_to_dict(settings)
        merged_settings = _SedaiSettings._merge(_AzureSettings.settings_dict_template, settings,
                                                _AzureSettings.settings_keys)
        return merged_settings


class _AccountLevelSettings(_SedaiSettings):
    settings_keys = [
        "availability.configMode",
        "slo.configMode",
        "releaseIntelligence.configMode",
        "kubeSpecificDetail.optimization.optimizationConfig.configMode",
        "kubeSpecificDetail.optimization.optimizationFocus.focus",
        "kubeSpecificDetail.optimization.optimizationFocus.maxMemoryIncreasePct",
        "kubeSpecificDetail.optimization.optimizationFocus.maxCPUIncreasePct",
        "kubeSpecificDetail.optimization.optimizationFocus.maxLatencyIncreasePct",
        "kubeSpecificDetail.enableVerticalScaling.status",
        "kubeSpecificDetail.enableHorizontalScaling.horizontalScalingConfig.status",
        "kubeSpecificDetail.enableHorizontalScaling.minReplicas",
        "kubeSpecificDetail.enableHorizontalScaling.maxReplicas",
        "kubeSpecificDetail.enableHorizontalScaling.replicaMultiplier",
        "kubeSpecificDetail.enableHorizontalScaling.horizontalScalingConfigMode",
        "kubeSpecificDetail.enablePredictiveScaling.status",
        "kubeSpecificDetail.autonomousActionWithoutTraffic.status",
        "kubeSpecificDetail.isProd.status",
        "appSpecificDetail.optimization.optimizationConfig.configMode",
        "ecsSpecificDetail.optimization.optimizationConfig.configMode",
        "ecsSpecificDetail.optimization.optimizationFocus.focus",
        "ecsSpecificDetail.optimization.optimizationFocus.maxMemoryIncreasePct",
        "ecsSpecificDetail.optimization.optimizationFocus.maxCPUIncreasePct",
        "ecsSpecificDetail.optimization.optimizationFocus.maxLatencyIncreasePct",
        "ecsSpecificDetail.enableVerticalScaling.minCpu",
        "ecsSpecificDetail.enableVerticalScaling.minMemory",
        "ecsSpecificDetail.enableVerticalScaling.status",
        "ecsSpecificDetail.enableHorizontalScaling.status",
        "ecsSpecificDetail.enableHorizontalScaling.minReplicas",
        "ecsSpecificDetail.enableHorizontalScaling.maxReplicas",
        "ecsSpecificDetail.enableHorizontalScaling.replicaIncrement",
        "ecsSpecificDetail.enableServiceAutoscalingConfiguration.status",
        "ecsSpecificDetail.enablePredictiveScaling.status",
        "ecsSpecificDetail.autonomousActionWithoutTraffic.status",
        "ecsSpecificDetail.isProd.status",
        "serverlessSpecificDetail.optimization.autonomousConcurrency.status",
        "serverlessSpecificDetail.optimization.optimizationConfig.configMode",
        "serverlessSpecificDetail.optimization.optimizationFocus.focus",
        "serverlessSpecificDetail.optimization.optimizationFocus.autoOptMaxCostChangePct",
        "serverlessSpecificDetail.optimization.optimizationFocus.autoOptMaxLatencyChangePct",
        "serverlessSpecificDetail.optimization.provisionedConcurrencyOptimization.status",
        "serverlessSpecificDetail.optimization.telemetryLogging.status",
    ]

    settings_key_map = {
        "availability.configMode": {"type": "enum", "values": ["MANUAL", "AUTO", "OFF"]},
        "slo.configMode": {"type": "enum", "values": ["MANUAL", "AUTO", "OFF"]},
        "releaseIntelligence.configMode": {"type": "enum", "values": ["MANUAL", "AUTO", "OFF"]},
        "kubeSpecificDetail.optimization.optimizationConfig.configMode": {"type": "enum",
                                                                          "values": ["MANUAL", "AUTO", "OFF"]},
        "kubeSpecificDetail.optimization.optimizationFocus.focus": {"type": "enum", "values": ["COST", "DURATION",
                                                                                               "COST_AND_DURATION"]},
        "kubeSpecificDetail.optimization.optimizationFocus.maxMemoryIncreasePct": {"type": "number", "min": 0,
                                                                                   "max": 100},
        "kubeSpecificDetail.optimization.optimizationFocus.maxCPUIncreasePct": {"type": "number", "min": 0, "max": 100},
        "kubeSpecificDetail.optimization.optimizationFocus.maxLatencyIncreasePct": {"type": "number", "min": 0,
                                                                                    "max": 100},
        "kubeSpecificDetail.enableVerticalScaling.status": {"type": "boolean"},
        "kubeSpecificDetail.enableHorizontalScaling.horizontalScalingConfig.status": {"type": "boolean"},
        "kubeSpecificDetail.enableHorizontalScaling.minReplicas": {"type": "number", "min": 0},
        "kubeSpecificDetail.enableHorizontalScaling.maxReplicas": {"type": "number", "min": 0},
        "kubeSpecificDetail.enableHorizontalScaling.replicaMultiplier": {"type": "number", "min": 0},
        "kubeSpecificDetail.enableHorizontalScaling.horizontalScalingConfigMode": {"type": "boolean"},
        "kubeSpecificDetail.enablePredictiveScaling.status": {"type": "boolean"},
        "kubeSpecificDetail.autonomousActionWithoutTraffic.status": {"type": "boolean"},
        "kubeSpecificDetail.isProd.status": {"type": "boolean"},
        "appSpecificDetail.optimization.optimizationConfig.configMode": {"type": "enum",
                                                                         "values": ["MANUAL", "AUTO", "OFF"]},
        "ecsSpecificDetail.optimization.optimizationConfig.configMode": {"type": "enum",
                                                                         "values": ["MANUAL", "AUTO", "OFF"]},
        "ecsSpecificDetail.optimization.optimizationFocus.focus": {"type": "enum",
                                                                   "values": ["COST", "DURATION", "COST_AND_DURATION"]},
        "ecsSpecificDetail.optimization.optimizationFocus.maxMemoryIncreasePct": {"type": "number", "min": 0,
                                                                                  "max": 100},
        "ecsSpecificDetail.optimization.optimizationFocus.maxCPUIncreasePct": {"type": "number", "min": 0, "max": 100},
        "ecsSpecificDetail.optimization.optimizationFocus.maxLatencyIncreasePct": {"type": "number", "min": 0,
                                                                                   "max": 100},
        "ecsSpecificDetail.enableVerticalScaling.minCpu": {"type": "number", "min": 0, "max": 100},
        "ecsSpecificDetail.enableVerticalScaling.minMemory": {"type": "number", "min": 0, "max": 100},
        "ecsSpecificDetail.enableVerticalScaling.status": {"type": "boolean"},
        "ecsSpecificDetail.enableHorizontalScaling.status": {"type": "boolean"},
        "ecsSpecificDetail.enableHorizontalScaling.minReplicas": {"type": "number", "min": 0},
        "ecsSpecificDetail.enableHorizontalScaling.maxReplicas": {"type": "number", "min": 0},
        "ecsSpecificDetail.enableHorizontalScaling.replicaIncrement": {"type": "number", "min": 0},
        "ecsSpecificDetail.enableServiceAutoscalingConfiguration.status": {"type": "boolean"},
        "ecsSpecificDetail.enablePredictiveScaling.status": {"type": "boolean"},
        "ecsSpecificDetail.autonomousActionWithoutTraffic.status": {"type": "boolean"},
        "ecsSpecificDetail.isProd.status": {"type": "boolean"},
        "serverlessSpecificDetail.optimization.autonomousConcurrency.status": {"type": "boolean"},
        "serverlessSpecificDetail.optimization.optimizationConfig.configMode": {"type": "enum",
                                                                                "values": ["MANUAL", "AUTO", "OFF"]},
        "serverlessSpecificDetail.optimization.optimizationFocus.focus": {"type": "enum", "values": ["COST", "DURATION",
                                                                                                     "COST_AND_DURATION"]},
        "serverlessSpecificDetail.optimization.optimizationFocus.autoOptMaxCostChangePct": {"type": "number", "min": 0,
                                                                                            "max": 100},
        "serverlessSpecificDetail.optimization.optimizationFocus.autoOptMaxLatencyChangePct": {"type": "number",
                                                                                               "min": 0, "max": 100},
        "serverlessSpecificDetail.optimization.provisionedConcurrencyOptimization.status": {"type": "boolean"},
        "serverlessSpecificDetail.optimization.telemetryLogging.status": {"type": "boolean"},
    }

    settings_dict_template = {
        "type": "CompositeResourceConfigDetail",
        "availability": {
            "scope": "RESOURCE_OVERRIDE",
            "configCategory": "AVAILABILITY",
        },
        "slo": {
            "scope": "RESOURCE_OVERRIDE",
            "configCategory": "SLO",
        },
        "releaseIntelligence": {
            "scope": "RESOURCE_OVERRIDE",
            "configCategory": "RELEASE_INTELLIGENCE",
        },
        "kubeSpecificDetail": {
            "optimization": {
                "type": "KubernetesOptimizationResourceConfigCategoryDetail",
                "optimizationConfig": {
                    "scope": "RESOURCE_OVERRIDE",
                    "configCategory": "OPTIMIZATION",
                },
                "optimizationFocus": {
                    "type": "KubernetesOptimizationFocusItem",
                }
            },
            "enableVerticalScaling": {
            },
            "enableHorizontalScaling": {
                "horizontalScalingConfig": {
                },
            },
            "enablePredictiveScaling": {
            },
            "autonomousActionWithoutTraffic": {
            },
            "isProd": {
            }
        },
        "appSpecificDetail": {
            "optimization": {
                "type": "OptimizationResourceConfigCategoryDetail",
                "optimizationConfig": {
                    "scope": "RESOURCE_OVERRIDE",
                    "configCategory": "OPTIMIZATION",
                }
            }
        },
        "ecsSpecificDetail": {
            "optimization": {
                "type": "ECSOptimizationResourceConfigCategoryDetail",
                "optimizationConfig": {
                    "scope": "RESOURCE_OVERRIDE",
                    "configCategory": "OPTIMIZATION",
                },
                "optimizationFocus": {
                    "type": "ECSOptimizationFocusItem",
                }
            },
            "enableVerticalScaling": {
            },
            "enableHorizontalScaling": {
            },
            "enableServiceAutoscalingConfiguration": {
            },
            "enablePredictiveScaling": {
            },
            "autonomousActionWithoutTraffic": {
            },
            "isProd": {
            }
        },
        "serverlessSpecificDetail": {
            "optimization": {
                "type": "ServerlessOptimizationResourceConfigCategoryDetail",
                "autonomousConcurrency": {
                },
                "optimizationConfig": {
                    "scope": "RESOURCE_OVERRIDE",
                    "configCategory": "OPTIMIZATION",
                },
                "optimizationFocus": {
                    "type": "ServerlessOptimizationFocusItem",
                },
                "provisionedConcurrencyOptimization": {
                },
                "telemetryLogging": {
                },
            },
        },
        "supportedResourceTypes": None,
        "optimizationCategoryConfigMode": None,
        "optimization": None
    }

    def get_settings(accountLevelResourceConfig):
        settings = _SedaiSettings._to_settings(accountLevelResourceConfig, _AccountLevelSettings.settings_keys)
        return _to_SimpleNamespace(settings)

    def get_merged_settings(settings):
        settings = _SimpleNamespace_to_dict(settings)
        merged_settings = _SedaiSettings._merge(_AccountLevelSettings.settings_dict_template, settings,
                                                _AccountLevelSettings.settings_keys)
        return json.dumps(merged_settings)


class _GroupLevelSettings(_SedaiSettings):
    settings_keys = [
        "availability.configMode",
        "slo.configMode",
        "releaseIntelligence.configMode",
        "kubeSpecificDetail.optimization.optimizationConfig.configMode",
        "kubeSpecificDetail.optimization.optimizationFocus.focus",
        "kubeSpecificDetail.optimization.optimizationFocus.maxMemoryIncreasePct",
        "kubeSpecificDetail.optimization.optimizationFocus.maxCPUIncreasePct",
        "kubeSpecificDetail.optimization.optimizationFocus.maxLatencyIncreasePct",
        "kubeSpecificDetail.enableVerticalScaling.status",
        "kubeSpecificDetail.enableHorizontalScaling.horizontalScalingConfig.status",
        "kubeSpecificDetail.enableHorizontalScaling.minReplicas",
        "kubeSpecificDetail.enableHorizontalScaling.maxReplicas",
        "kubeSpecificDetail.enableHorizontalScaling.replicaMultiplier",
        "kubeSpecificDetail.enableHorizontalScaling.horizontalScalingConfigMode",
        "kubeSpecificDetail.enablePredictiveScaling.status",
        "kubeSpecificDetail.autonomousActionWithoutTraffic.status",
        "kubeSpecificDetail.isProd.status",
        "appSpecificDetail.optimization.optimizationConfig.configMode",
        "ecsSpecificDetail.optimization.optimizationConfig.configMode",
        "ecsSpecificDetail.optimization.optimizationFocus.focus",
        "ecsSpecificDetail.optimization.optimizationFocus.maxMemoryIncreasePct",
        "ecsSpecificDetail.optimization.optimizationFocus.maxCPUIncreasePct",
        "ecsSpecificDetail.optimization.optimizationFocus.maxLatencyIncreasePct",
        "ecsSpecificDetail.enableVerticalScaling.minCpu",
        "ecsSpecificDetail.enableVerticalScaling.minMemory",
        "ecsSpecificDetail.enableVerticalScaling.status",
        "ecsSpecificDetail.enableHorizontalScaling.status",
        "ecsSpecificDetail.enableHorizontalScaling.minReplicas",
        "ecsSpecificDetail.enableHorizontalScaling.maxReplicas",
        "ecsSpecificDetail.enableHorizontalScaling.replicaIncrement",
        "ecsSpecificDetail.enableServiceAutoscalingConfiguration.status",
        "ecsSpecificDetail.enablePredictiveScaling.status",
        "ecsSpecificDetail.autonomousActionWithoutTraffic.status",
        "ecsSpecificDetail.isProd.status",
        "serverlessSpecificDetail.optimization.autonomousConcurrency.status",
        "serverlessSpecificDetail.optimization.optimizationConfig.configMode",
        "serverlessSpecificDetail.optimization.optimizationFocus.focus",
        "serverlessSpecificDetail.optimization.optimizationFocus.autoOptMaxCostChangePct",
        "serverlessSpecificDetail.optimization.optimizationFocus.autoOptMaxLatencyChangePct",
        "serverlessSpecificDetail.optimization.provisionedConcurrencyOptimization.status",
        "serverlessSpecificDetail.optimization.telemetryLogging.status",
    ]

    settings_key_map = {
        "availability.configMode": {"type": "enum", "values": ["MANUAL", "AUTO", "OFF"]},
        "slo.configMode": {"type": "enum", "values": ["MANUAL", "AUTO", "OFF"]},
        "releaseIntelligence.configMode": {"type": "enum", "values": ["MANUAL", "AUTO", "OFF"]},
        "kubeSpecificDetail.optimization.optimizationConfig.configMode": {"type": "enum",
                                                                          "values": ["MANUAL", "AUTO", "OFF"]},
        "kubeSpecificDetail.optimization.optimizationFocus.focus": {"type": "enum", "values": ["COST", "DURATION",
                                                                                               "COST_AND_DURATION"]},
        "kubeSpecificDetail.optimization.optimizationFocus.maxMemoryIncreasePct": {"type": "number", "min": 0,
                                                                                   "max": 100},
        "kubeSpecificDetail.optimization.optimizationFocus.maxCPUIncreasePct": {"type": "number", "min": 0, "max": 100},
        "kubeSpecificDetail.optimization.optimizationFocus.maxLatencyIncreasePct": {"type": "number", "min": 0,
                                                                                    "max": 100},
        "kubeSpecificDetail.enableVerticalScaling.status": {"type": "boolean"},
        "kubeSpecificDetail.enableHorizontalScaling.horizontalScalingConfig.status": {"type": "boolean"},
        "kubeSpecificDetail.enableHorizontalScaling.minReplicas": {"type": "number", "min": 0},
        "kubeSpecificDetail.enableHorizontalScaling.maxReplicas": {"type": "number", "min": 0},
        "kubeSpecificDetail.enableHorizontalScaling.replicaMultiplier": {"type": "number", "min": 0},
        "kubeSpecificDetail.enableHorizontalScaling.horizontalScalingConfigMode": {"type": "boolean"},
        "kubeSpecificDetail.enablePredictiveScaling.status": {"type": "boolean"},
        "kubeSpecificDetail.autonomousActionWithoutTraffic.status": {"type": "boolean"},
        "kubeSpecificDetail.isProd.status": {"type": "boolean"},
        "appSpecificDetail.optimization.optimizationConfig.configMode": {"type": "enum",
                                                                         "values": ["MANUAL", "AUTO", "OFF"]},
        "ecsSpecificDetail.optimization.optimizationConfig.configMode": {"type": "enum",
                                                                         "values": ["MANUAL", "AUTO", "OFF"]},
        "ecsSpecificDetail.optimization.optimizationFocus.focus": {"type": "enum",
                                                                   "values": ["COST", "DURATION", "COST_AND_DURATION"]},
        "ecsSpecificDetail.optimization.optimizationFocus.maxMemoryIncreasePct": {"type": "number", "min": 0,
                                                                                  "max": 100},
        "ecsSpecificDetail.optimization.optimizationFocus.maxCPUIncreasePct": {"type": "number", "min": 0, "max": 100},
        "ecsSpecificDetail.optimization.optimizationFocus.maxLatencyIncreasePct": {"type": "number", "min": 0,
                                                                                   "max": 100},
        "ecsSpecificDetail.enableVerticalScaling.minCpu": {"type": "number", "min": 0, "max": 100},
        "ecsSpecificDetail.enableVerticalScaling.minMemory": {"type": "number", "min": 0, "max": 100},
        "ecsSpecificDetail.enableVerticalScaling.status": {"type": "boolean"},
        "ecsSpecificDetail.enableHorizontalScaling.status": {"type": "boolean"},
        "ecsSpecificDetail.enableHorizontalScaling.minReplicas": {"type": "number", "min": 0},
        "ecsSpecificDetail.enableHorizontalScaling.maxReplicas": {"type": "number", "min": 0},
        "ecsSpecificDetail.enableHorizontalScaling.replicaIncrement": {"type": "number", "min": 0},
        "ecsSpecificDetail.enableServiceAutoscalingConfiguration.status": {"type": "boolean"},
        "ecsSpecificDetail.enablePredictiveScaling.status": {"type": "boolean"},
        "ecsSpecificDetail.autonomousActionWithoutTraffic.status": {"type": "boolean"},
        "ecsSpecificDetail.isProd.status": {"type": "boolean"},
        "serverlessSpecificDetail.optimization.autonomousConcurrency.status": {"type": "boolean"},
        "serverlessSpecificDetail.optimization.optimizationConfig.configMode": {"type": "enum",
                                                                                "values": ["MANUAL", "AUTO", "OFF"]},
        "serverlessSpecificDetail.optimization.optimizationFocus.focus": {"type": "enum", "values": ["COST", "DURATION",
                                                                                                     "COST_AND_DURATION"]},
        "serverlessSpecificDetail.optimization.optimizationFocus.autoOptMaxCostChangePct": {"type": "number", "min": 0,
                                                                                            "max": 100},
        "serverlessSpecificDetail.optimization.optimizationFocus.autoOptMaxLatencyChangePct": {"type": "number",
                                                                                               "min": 0, "max": 100},
        "serverlessSpecificDetail.optimization.provisionedConcurrencyOptimization.status": {"type": "boolean"},
        "serverlessSpecificDetail.optimization.telemetryLogging.status": {"type": "boolean"},
    }

    settings_dict_template = {
        "type": "CompositeResourceConfigDetail",
        "availability": {
            "scope": "RESOURCE_OVERRIDE",
            "configCategory": "AVAILABILITY",
        },
        "slo": {
            "scope": "RESOURCE_OVERRIDE",
            "configCategory": "SLO",
        },
        "releaseIntelligence": {
            "scope": "RESOURCE_OVERRIDE",
            "configCategory": "RELEASE_INTELLIGENCE",
        },
        "kubeSpecificDetail": {
            "optimization": {
                "type": "KubernetesOptimizationResourceConfigCategoryDetail",
                "optimizationConfig": {
                    "scope": "RESOURCE_OVERRIDE",
                    "configCategory": "OPTIMIZATION",
                },
                "optimizationFocus": {
                    "type": "KubernetesOptimizationFocusItem",
                }
            },
            "enableVerticalScaling": {
            },
            "enableHorizontalScaling": {
                "horizontalScalingConfig": {
                },
            },
            "enablePredictiveScaling": {
            },
            "autonomousActionWithoutTraffic": {
            },
            "isProd": {
            }
        },
        "appSpecificDetail": {
            "optimization": {
                "type": "OptimizationResourceConfigCategoryDetail",
                "optimizationConfig": {
                    "scope": "RESOURCE_OVERRIDE",
                    "configCategory": "OPTIMIZATION",
                }
            }
        },
        "ecsSpecificDetail": {
            "optimization": {
                "type": "ECSOptimizationResourceConfigCategoryDetail",
                "optimizationConfig": {
                    "scope": "RESOURCE_OVERRIDE",
                    "configCategory": "OPTIMIZATION",
                },
                "optimizationFocus": {
                    "type": "ECSOptimizationFocusItem",
                }
            },
            "enableVerticalScaling": {
            },
            "enableHorizontalScaling": {
            },
            "enableServiceAutoscalingConfiguration": {
            },
            "enablePredictiveScaling": {
            },
            "autonomousActionWithoutTraffic": {
            },
            "isProd": {
            }
        },
        "serverlessSpecificDetail": {
            "optimization": {
                "type": "ServerlessOptimizationResourceConfigCategoryDetail",
                "autonomousConcurrency": {
                },
                "optimizationConfig": {
                    "scope": "RESOURCE_OVERRIDE",
                    "configCategory": "OPTIMIZATION",
                },
                "optimizationFocus": {
                    "type": "ServerlessOptimizationFocusItem",
                },
                "provisionedConcurrencyOptimization": {
                },
                "telemetryLogging": {
                },
            },
        },
        "supportedResourceTypes": None,
        "optimizationCategoryConfigMode": None,
        "optimization": None
    }

    def get_settings(groupLevelResourceConfig):
        settings = _SedaiSettings._to_settings(groupLevelResourceConfig, _GroupLevelSettings.settings_keys)
        return _to_SimpleNamespace(settings)

    def get_merged_settings(settings):
        settings = _SimpleNamespace_to_dict(settings)
        merged_settings = _SedaiSettings._merge(_GroupLevelSettings.settings_dict_template, settings,
                                                _GroupLevelSettings.settings_keys)
        return json.dumps(merged_settings)
