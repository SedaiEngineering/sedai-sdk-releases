"""
This file contains the resource types that are used in the SEDAI SDK.
"""


class KubernetesAppResource:
    """
    A Kubernetes application resource

    It typically represents a Kubernetes application running in a namespace.
    Contains the following fields:
    **account_id** - The Sedai account id
    **resource_id** - The resource id
    **resource_name** - The resource name
    **settings** - The resource settings

    For Kubernetes resources. The settings object contains the following fields:
    - **availability** - The availability settings
    - **availability.configMode** - The availability configuration mode. Possible values are:
        - `AUTO` - Availability is automatically determined by Sedai
        - `CO_PILOT` - Availability is manually configured by the user
        - `DATA_PILOT` - Availability is turned off for the resource
    - **slo** - The SLO settings
    - **slo.configMode** - The SLO configuration mode. Possible values are:
        - `AUTO` - SLO is automatically determined by Sedai
        - `CO_PILOT` - SLO is manually configured by the user
        - `OFF` - SLO is turned off for the resource
    - **releaseIntelligence** - The release intelligence settings
    - **releaseIntelligence.configMode** - The release intelligence configuration mode. Possible values are:
        - `AUTO` - Release intelligence is automatically determined by Sedai
        - `CO_PILOT` - Release intelligence is manually configured by the user
        - `OFF` - Release intelligence is turned off for the resource
    - **optimization** - The optimization settings
    - **optimization.optimizationConfig** - The optimization configuration
    - **optimization.optimizationConfig.configMode** - The optimization configuration mode. Possible values are:
        - `AUTO` - Optimization is automatically determined by Sedai
        - `CO_PILOT` - Optimization is manually configured by the user
        - `DATA_PILOT` - Optimization is turned off for the resource
    - **optimization.optimizationFocus** - The optimization focus
    - **optimization.optimizationFocus.focus** - The optimization focus. Possible values are:
        - `COST` - Optimize for cost
        - `DURATION` - Optimize for duration
        - `COST_AND_DURATION` - Optimize for cost and duration
    - **optimization.optimizationFocus.maxMemoryIncreasePct** - The maximum memory increase percentage
    - **optimization.optimizationFocus.maxCPUIncreasePct** - The maximum CPU increase percentage
    - **optimization.optimizationFocus.maxLatencyIncreasePct** - The maximum latency increase percentage
    - **enableVerticalScaling** - The vertical scaling settings
    - **enableVerticalScaling.status** - The vertical scaling status. Possible values are:
        - `True` - Vertical scaling is enabled
        - `False` - Vertical scaling is disabled
    - **enableHorizontalScaling** - The horizontal scaling settings
    - **enableHorizontalScaling.horizontalScalingConfig** - The horizontal scaling configuration
    - **enableHorizontalScaling.horizontalScalingConfig.status** - The horizontal scaling status. Possible values are:
        - `True` - Horizontal scaling is enabled
        - `False` - Horizontal scaling is disabled
    - **enableHorizontalScaling.minReplicas** - The minimum number of replicas
    - **enableHorizontalScaling.maxReplicas** - The maximum number of replicas
    - **enableHorizontalScaling.replicaMultiplier** - The replica multiplier
    - **enableHorizontalScaling.horizontalScalingConfigMode** - The horizontal scaling configuration mode. Possible values are:
        - `True` - Horizontal scaling is automatically determined by Sedai
        - `False` - Horizontal scaling is manually configured by the user
    - **enablePredictiveScaling** - The predictive scaling settings
    - **enablePredictiveScaling.status** - The predictive scaling status. Possible values are:
        - `True` - Predictive scaling is enabled
        - `False` - Predictive scaling is disabled
    - **autonomousActionWithoutTraffic** - The autonomous action without traffic settings
    - **autonomousActionWithoutTraffic.status** - The autonomous action without traffic status. Possible values are:
        - `True` - Autonomous action without traffic is enabled
        - `False` - Autonomous action without traffic is disabled
    - **isProd** - The production status settings
    - **isProd.status** - The production status. Possible values are:
        - `True` - The resource is in production
        - `False` - The resource is not in production
    """
