from sedai.__impl import api, log

def get_resource_tags(resource_id):
    """
    Retrieve list of tags associated with a resource
    :param resource_id: The ID of the resource (str)
    :type resource_id: str
    :return: List of tags
    :rtype: List[Dict[str,str]] or None
    Each tag is an object with the following fields:
    - **key** - tag key
    - **value** - tag value

    Output:
    .. code-block:: json

            [
                {
                    "key": "Name",
                    "value": "example-k8s-cluster"
                },
                {
                    "key": "region",
                    "value": "us-east-1"
                }
            ]

    """
    request = api.GetRequest('/api/ui/resource/resource-tags',params=dict(resourceId=resource_id))
    response = api.do_get(request)
    if response['status'] != 'OK':
        log(f"Failed to get resource tags: {response['message']}")
        return None
    else:
        log("Successfully got resource tag")
        return response['result']